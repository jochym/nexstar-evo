/* -------------------------------------------------------------------------- */
/* -               Access the thermal control for a C20                     - */
/* -------------------------------------------------------------------------- */
/*                                                                            */
/* Copyright 2010 John Kielkopf                                               */
/*                                                                            */
/* Distributed under the terms of the General Public License (see LICENSE)    */
/*                                                                            */
/* John Kielkopf (kielkopf@louisville.edu)                                    */
/*                                                                            */
/* Date: October 25, 2010                                                     */
/* Version: 1.0                                                               */
/*                                                                            */
/* History:                                                                   */
/*                                                                            */
/* October 25, 2010                                                           */
/*   Version 1.0                                                              */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <time.h>
#include <sys/time.h>
#include <sys/types.h>
#include <unistd.h>
#include <sys/stat.h>
#include <sys/ioctl.h>
#include <fcntl.h>
#include <termios.h>
#include <math.h>
#include <sys/select.h>
#include "thermal.h"

#define NULL_PTR(x) (x *)0

#ifndef TRUE
#define TRUE 1
#endif

#ifndef FALSE
#define FALSE 0
#endif


/* Communications variables and routines for internal use */

int thermalportfd;
int thermalconnectflag = FALSE;

/* Thermal commands */

int CheckConnectThermal(void);
int ConnectThermal(void);
int SetFan(int fancmd);
int GetTemperature(double *teltemperature);
int WriteTemperature(double teltemperature);
int DisconnectThermal(void);


/* Serial port untilities */

typedef fd_set telfds;

int readn(int fd, char *ptr, int nbytes, int sec);
int writen(int fd, char *ptr, int nbytes);
int telstat(int fd,int sec,int usec);

/* Main program */

int main(int argc, char *argv[])
{
  int fancmd;
  char *testfan;
  int flag;
  double teltemperature;
  
  if (argc !=2) 
  { 
    printf("Usage: setfan fancmd \n");
    printf("\n");
    printf("Set the telescope cooling fans \n");
    printf("\n");
    printf("Commands: 0 (off) 1 (slow)  2 (fast)\n");
    return(0);
  }

  fancmd = strtod(argv[1],&testfan);
  if ( (fancmd < 0) || (fancmd > 2) )
  {
    return(0);
  }
  
  flag = ConnectThermal();
  if (flag == FALSE)
  {
    fprintf(stderr,"Cannot connect to telescope thermal system ...\n");
    return(1);
  }  
  usleep(1000000);
  flag = SetFan(fancmd);
  if (flag == FALSE)
  {
    fprintf(stderr,"Thermal system does not respond to request ...\n");
  }  
  usleep(1000000);
  GetTemperature(&teltemperature);
  fprintf(stdout,"%.0f\n",teltemperature);
  WriteTemperature(teltemperature);
  flag = DisconnectThermal();
  return(0);
} 


/* Report on thermal system connection status */

int CheckConnectThermal(void)
{
  if (thermalconnectflag == TRUE)
  {
    return(TRUE);
  }
  else
  {
    return(FALSE);
  }
}

/* Connect to the thermal system serial interface */
/* Returns without action if thermalconnectflag is TRUE */
/* Sets thermalconnectflag TRUE on success */

int ConnectThermal(void)
{  
  struct termios tty;
  char thermalport[32];
  
  /* Packet to request version of azimuth motor driver */
  
  char sendstr[] = { 0x50, 0x01, 0x10, 0xfe, 0x00, 0x00, 0x00, 0x02 };
      
  /* Packet format:              */
  /*   preamble                  */
  /*   packet length             */
  /*   destination               */
  /*   message id                */
  /*   three message bytes       */
  /*   number of response bytes  */
   
  char returnstr[32];
  
  /* Packet format:              */
  /*   response bytes if any     */
  /*   #                         */
  
  int numRead;
  int limits, flag;
  
  if(thermalconnectflag != FALSE)
  {
    fprintf(stderr,"Thermal system is already connected ... \n");
    return(0);
  }
  
  /* Make the connection         */
  
  /* thermalportfd = open("/dev/ttyS0",O_RDWR); */
  
  strcpy(thermalport,THERMALPORT);
  thermalportfd = open(thermalport,O_RDWR);
  if(thermalportfd == -1)
  {
    fprintf(stderr,"Thermal serial port is not available ... \n");
    thermalconnectflag = FALSE;
    return(0);
  }
  
  thermalconnectflag = TRUE;
  
  tcgetattr(thermalportfd,&tty);
  cfsetospeed(&tty, (speed_t) B9600);
  cfsetispeed(&tty, (speed_t) B9600);
  tty.c_cflag = (tty.c_cflag & ~CSIZE) | CS8;
  tty.c_iflag =  IGNBRK;
  tty.c_lflag = 0;
  tty.c_oflag = 0;
  tty.c_cflag |= CLOCAL | CREAD;
  tty.c_cc[VMIN] = 1;
  tty.c_cc[VTIME] = 5;
  tty.c_iflag &= ~(IXON|IXOFF|IXANY);
  tty.c_cflag &= ~(PARENB | PARODD);
  tcsetattr(thermalportfd, TCSANOW, &tty);

  /* Flush the input (read) buffer */

  tcflush(thermalportfd,TCIOFLUSH);
  
  return(1);
}

int SetFan(int fancmd)
{
  /* Default fan string for off */
  
  char outputstr[] = { 0x50, 0x02, 0x13, 0x27, 0x00, 0x00, 0x00, 0x00 };
  char inputstr[2048];
  
  /* The C20 has one speed */
  /* This switch turns on  the fans without regard to speed */
  
  if ( fancmd > 0 )
  {
    outputstr[4] = 0x01;
  } 

  /* Send the command */
  writen(thermalportfd,outputstr,8);

  /* Wait up to a second for an acknowledgement */
  
  for (;;) 
  {
    if ( readn(thermalportfd,inputstr,1,1) ) 
    {
      if (inputstr[0] == '#') break;
    }
    else 
    { 
      fprintf(stderr,"No acknowledgement from thermal control\n");
    }
  } 
}

int GetTemperature(double *teltemperature)
{
  char outputstr[] = { 0x50, 0x02, 0x12, 0x26, 0x00, 0x00, 0x00, 0x02 };
  char returnstr[2048];  
  int b0,b1;
  int count;
  double value;
    
  value = 0.;
    
  /* Send the command */
  
  writen(thermalportfd,outputstr,8);    
  
  /* Read a response */

  readn(thermalportfd,returnstr,3,1);

  b0 = (unsigned char) returnstr[0];
  b1 = (unsigned char) returnstr[1];
  
  /* In the C20 the counts are left shifted by 4 bits */
  /* The total count comes in increments of 16 for a 12 bit sensor */

  /* These counts roll over to 255 when the counter goes negative. */
  /* That is, 256*255 + 255 is -1 */
  
  count = 256*b0 + b1;

  /* Use a scale which goes negative below zero */
  
  if (count > 32768)
  {
    count = count - 65537;
  }

  /* Apply the calibration for the Maxim DS18B20 sensor in the OTA */
  /* Right shift the bits to match the specification calibration */
  
  value = count/16;
  value = 0.0625 * value;
  
  /* Test for out of range as an indicator of sensor not present */
  /* Set an out of range value that is not annoying in a display */
  
  if ((value < -50 ) || (value > 50) )
  {
    value = 0.;
  }  
 
  *teltemperature = value;
  return;
}


/* Write temperature to a system status file */

int WriteTemperature(double teltemperature)
{
  FILE* outfile;
  outfile = fopen("/usr/local/observatory/status/teltemperature","w");
  if ( outfile == NULL )
  {
    fprintf(stderr,"Cannot update teltemperature status file\n");
    return FALSE;
  }

  fprintf(outfile, "%lf\n", teltemperature);      
  fclose(outfile);
  return TRUE;
}


/* Close serial connection to fan and reset fanconnectflag */

int DisconnectThermal(void)
{  
  if(thermalconnectflag == TRUE)
  {
    close(thermalportfd);
    thermalconnectflag = FALSE;
    return(TRUE);
  }
  thermalconnectflag = FALSE;
  return(FALSE);
}


/* Serial port utilities */

int writen(fd, ptr, nbytes)
int fd;
char *ptr;
int nbytes;
{
  int nleft, nwritten;
  nleft = nbytes;
  while (nleft > 0) 
  {
    nwritten = write (fd, ptr, nleft);
    if (nwritten <=0 ) break;
    nleft -= nwritten;
    ptr += nwritten;
  }
  return (nbytes - nleft);
}

int readn(fd, ptr, nbytes, sec)
int fd;
char *ptr;
int nbytes;
int sec;
{
  int stat;
  int nleft, nread;
  nleft = nbytes;
  while (nleft > 0) 
  {
    stat = telstat(fd,sec,0);
    if (stat <=  0 ) break;
    nread  = read (fd, ptr, nleft);
    if (nread <= 0)  break;
    nleft -= nread;
    ptr += nread;
  }
  return (nbytes - nleft);
}


/* Examines the read status of a file descriptor.                       */
/* The timeout (sec, usec) specifies a maximum interval to              */
/* wait for data to be available in the descriptor.                     */
/* To effect a poll, the timeout (sec, usec) should be 0.               */
/* Returns non-negative value on data available.                        */
/* 0 indicates that the time limit referred by timeout expired.         */
/* On failure, it returns -1 and errno is set to indicate the error.    */

int telstat(fd,sec,usec)
register int fd, sec, usec;
{
  int ret;
  int width;
  struct timeval timeout;
  telfds readfds;

  memset((char *)&readfds,0,sizeof(readfds));
  FD_SET(fd, &readfds);
  width = fd+1;
  timeout.tv_sec = sec;
  timeout.tv_usec = usec;
  ret = select(width,&readfds,NULL_PTR(telfds),NULL_PTR(telfds),&timeout);
  return(ret);
}
