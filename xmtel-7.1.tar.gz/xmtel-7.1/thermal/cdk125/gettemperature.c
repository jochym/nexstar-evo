/* -------------------------------------------------------------------------- */
/* -             Get the temperature From a Planewave EFA                   - */
/* -------------------------------------------------------------------------- */
/*                                                                            */
/* Copyright 2010 John Kielkopf                                               */
/*                                                                            */
/* Distributed under the terms of the General Public License (see LICENSE)    */
/*                                                                            */
/* John Kielkopf (kielkopf@louisville.edu)                                    */
/*                                                                            */
/* Date: November 14, 2010                                                    */
/* Version: 1.0                                                               */
/*                                                                            */
/* History:                                                                   */
/*                                                                            */
/* November 14, 2010                                                          */
/*   Version 1.0                                                              */
/*     Released                                                               */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <time.h>
#include <sys/time.h>
#include <unistd.h>
#include <fcntl.h>
#include <termios.h>

#include <sys/ioctl.h>
#include <sys/stat.h>
#include <sys/types.h>

#include "thermal.h"

#define NULL_PTR(x) (x *)0

#ifndef TRUE
#define TRUE 1
#endif

#ifndef FALSE
#define FALSE 0
#endif



/* Communications variables and routines for internal use */

int thermalportfd;
int thermalconnectflag = FALSE;


/* Thermal commands */

int CheckConnectThermal(void);
int ConnectThermal(void);
int GetTemperature(double *teltemperature, int sensor);
int WriteTemperature(double teltemperature);
int DisconnectThermal(void);


/* Serial port untilities */

typedef fd_set telfds;

int readn(int fd, char *ptr, int nbytes, int sec);
int writen(int fd, char *ptr, int nbytes);
int telstat(int fd,int sec,int usec);

/* Main program */

int main(int argc, char *argv[])
{
  char *testthermal;
  int flag;
  double teltemperature;
  int tempsensor = 0;
  int newsensor = -1;
    
  /* Primary mirror thermal sensor by default */
  
  if (argc > 2) 
  { 
    printf("Usage: gettemperature [sensor]\n");
    printf("\n");
    printf("Read the telescope temperature \n");
    printf("Returns current temperature in Celsius \n");
    printf("Updates observatory status \n\n");
    printf("Sensor: 0 (primary/default)  1 (ambient)   2 (secondary)\n");
    printf("\n");
    return(0);
  }

  if (argc == 2)
  {
    newsensor = strtod(argv[1],&testthermal);
    if ( (newsensor >= 0) && (newsensor <= 2) )  
    {
      tempsensor = newsensor;
    }
  }
    

  flag = ConnectThermal();
  if (flag == FALSE)
  {
    fprintf(stderr,"Cannot connect to telescope thermal system ...\n");
    return(1);
  }  
  GetTemperature(&teltemperature, tempsensor);
  WriteTemperature(teltemperature);
  flag = DisconnectThermal();
  return(0);
} 


/* Report on thermal system connection status */

int CheckConnectThermal(void)
{
  if (thermalconnectflag == TRUE)
  {
    return(TRUE);
  }
  else
  {
    return(FALSE);
  }
}

/* Connect to the efa serial interface */
/* Returns without action if thermalconnectflag is TRUE */
/* Sets thermalconnectflag TRUE on success */

int ConnectThermal(void)
{  
  struct termios tty;
  char thermalport[32];
  int b0, b1;
  
  /* Request efa version */
  
  char sendstr[] = { 0x50, 0x01, 0x12, 0xfe, 0x00, 0x00, 0x00, 0x02 };
      
  /* Packet format:              */
  /*   preamble                  */
  /*   message length            */
  /*   destination               */
  /*   message id                */
  /*   three message bytes       */
  /*   number of response bytes  */

  char returnstr[] = { 0x00, 0x00, 0x00 };
  
  /* Packet format:              */
  /*   response bytes if any     */
  /*   0x23 = #                  */
  
  if(thermalconnectflag != FALSE)
  {
    fprintf(stderr,"EFA is already connected ... \n");
    return(0);
  }
  
  /* Make the connection                        */
  
  /* thermalportfd = open("/dev/ttyS0",O_RDWR); */
  
  strcpy(thermalport,THERMALPORT);
  thermalportfd = open(thermalport,O_RDWR);
  if(thermalportfd == -1)
  {
    fprintf(stderr,"EFA serial port is not available ... \n");
    thermalconnectflag = FALSE;
    return(0);
  }
  
  thermalconnectflag = TRUE;
  
  tcgetattr(thermalportfd,&tty);
  cfsetospeed(&tty, (speed_t) B9600);
  cfsetispeed(&tty, (speed_t) B9600);
  tty.c_cflag |=  CLOCAL | CS8 | CREAD;
  tcsetattr(thermalportfd, TCSANOW, &tty);

  /* Flush the input (read) buffer */

  tcflush(thermalportfd,TCIOFLUSH);
  
  /* Send the command */
  
  writen(thermalportfd,sendstr,8);    

  /* Read a response including the closing 0x23 */

  readn(thermalportfd,returnstr,3,1);

  b0 = (unsigned char) returnstr[0];
  b1 = (unsigned char) returnstr[1];
  
  /* Uncomment the following for diagnostic */
  
  /* fprintf(stderr,"EFA version %d.%d\n",b0,b1); */
 
  return(1);
}


int GetTemperature(double *teltemperature, int tempsensor)
{
  char outputstr[] = { 0x50, 0x02, 0x12, 0x26, 0x00, 0x00, 0x00, 0x02 };
  char returnstr[] = { 0x00, 0x00, 0x00, 0x00 };  
  int b0,b1,b2;
  int count, count0, count1;
  double value;
  double tempsign;
    
  /* Select sensor primary = 0; ambient = 1; secondary = 2 */
  /* outputstr[4] = 0x0; */
  /* outputstr[4] = 0x1; */
  
    
  if (tempsensor == 0)
  {
    outputstr[4] = 0x0;
  }  
  else if (tempsensor == 1)
  {
    outputstr[4] = 0x1;
  }
  else if (tempsensor == 2)
  {
    outputstr[4] = 0x2;
  }
  else
  {
    outputstr[4] = 0x0;
  }
      
  value = 0.;
    
  /* Send the command */
  
  writen(thermalportfd,outputstr,8);    
  
  /* Read a response */

  readn(thermalportfd,returnstr,3,1);

  b0 = (unsigned char) returnstr[0];
  b1 = (unsigned char) returnstr[1];
      
  /* In our CDK125 b0 is the least signficant 8 bits of a 12 bit word.  */
  /* High bit of b1 determines sign. */
  /* Untested for temperatures that would use other bits of b1. */
    
  count = b0 + 256*b1;
  
  /* Use a scale which goes negative below zero and sets the sign bit */
  
  tempsign = 1.;
  if (count > 32767)
  {
    /* Set the sign flag */
    tempsign = -1.;
    
    /* Invert the count under 2^16 = 65536 such that 0xFFFFFFFE = 65535 => -1 */
    count = 65536 - count;
  }

  /* Apply the calibration for the Maxim DS18B20 sensor in the EFA */
  
  value = count;
  value = 0.0625 * value * tempsign;
  
  /* Test for out of range as an indicator of sensor not present */
  /* Set an out of range value that is not annoying in a display */
  
  if ((value < -50 ) || (value > 50) )
  {
    /* value = 0.; */
  }  
 
  *teltemperature = value;
  return;
}


/* Write temperature to a system status file */

int WriteTemperature(double teltemperature)
{
  FILE* outfile;
  outfile = fopen("/usr/local/observatory/status/teltemperature","w");
  if ( outfile == NULL )
  {
    fprintf(stderr,"Cannot update teltemperature status file\n");
    return FALSE;
  }
  fprintf(stdout, "%.1f\n", teltemperature);
  fprintf(outfile, "%lf\n", teltemperature);      
  fclose(outfile);
  return TRUE;
}


/* Close serial connection to fan and reset fanconnectflag */

int DisconnectThermal(void)
{  
  if(thermalconnectflag == TRUE)
  {
    close(thermalportfd);
    thermalconnectflag = FALSE;
    return(TRUE);
  }
  thermalconnectflag = FALSE;
  return(FALSE);
}


/* Serial port utilities */

int writen(fd, ptr, nbytes)
int fd;
char *ptr;
int nbytes;
{
  int nleft, nwritten;
  nleft = nbytes;
  while (nleft > 0) 
  {
    nwritten = write (fd, ptr, nleft);
    if (nwritten <=0 ) break;
    nleft -= nwritten;
    ptr += nwritten;
  }
  return (nbytes - nleft);
}

int readn(fd, ptr, nbytes, sec)
int fd;
char *ptr;
int nbytes;
int sec;
{
  int stat;
  int nleft, nread;
  nleft = nbytes;
  while (nleft > 0) 
  {
    stat = telstat(fd,sec,0);
    if (stat <=  0 ) break;
    nread  = read (fd, ptr, nleft);
    if (nread <= 0)  break;
    nleft -= nread;
    ptr += nread;
  }
  return (nbytes - nleft);
}


/* Examines the read status of a file descriptor.                       */
/* The timeout (sec, usec) specifies a maximum interval to              */
/* wait for data to be available in the descriptor.                     */
/* To effect a poll, the timeout (sec, usec) should be 0.               */
/* Returns non-negative value on data available.                        */
/* 0 indicates that the time limit referred by timeout expired.         */
/* On failure, it returns -1 and errno is set to indicate the error.    */

int telstat(fd,sec,usec)
register int fd, sec, usec;
{
  int ret;
  int width;
  struct timeval timeout;
  telfds readfds;

  memset((char *)&readfds,0,sizeof(readfds));
  FD_SET(fd, &readfds);
  width = fd+1;
  timeout.tv_sec = sec;
  timeout.tv_usec = usec;
  ret = select(width,&readfds,NULL_PTR(telfds),NULL_PTR(telfds),&timeout);
  return(ret);
}
