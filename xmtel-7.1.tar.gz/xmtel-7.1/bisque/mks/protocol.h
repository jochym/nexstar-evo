/* -------------------------------------------------------------------------- */
/* -         Header for Paramount MKS3 command set telescope control          */
/* -------------------------------------------------------------------------- */
/*                                                                            */
/* Copyright 2010-2014 John Kielkopf                                          */
/* kielkopf@louisville.edu                                                    */
/*                                                                            */
/* Date: June 14, 2014                                                        */
/*                                                                            */
/* Date: July 1, 2012                                                         */
/* Version: 6.0                                                               */
/*                                                                            */
/* History:                                                                   */
/*                                                                            */
/* August 20, 2010                                                            */
/*   Version 1.0                                                              */
/*                                                                            */
/* November 17, 2010                                                          */
/*   Version 1.1                                                              */
/*     Updated focus, rotator, fan entries                                    */
/*                                                                            */
/* October 10, 2011                                                           */
/*   Version 2.3                                                              */
/*                                                                            */
/* January 29, 2012                                                           */
/*   Version 2.4                                                              */
/*                                                                            */
/* July 1, 2012                                                               */
/*   Version 2.5                                                              */
/*     Leapsecond incremented                                                 */
/*                                                                            */
/* June 14, 2014                                                              */
/*   Version 3.0                                                              */
/*     Updated for xmtel 7.0 with xpa                                         */
/*                                                                            */




/* Focus and temperature files */

#define FOCUSFILE "/usr/local/observatory/status/telfocus"
#define TEMPERATUREFILE "/usr/local/observatory/status/teltemperature"
#define ROTATEFILE "/usr/local/observatory/status/telrotate"
#define MAXPATHLEN 100

/* Count scaling defines relationship of telescope pointing to encoder counts */
/* Signs relate sense of shaft rotation to encoder increment */
/* Counts here are unsigned and sign is set by altsign and azsign */


/* Trial values from sky test */

/* #define AZCOUNTPERDEG  30000.0  */
/* #define ALTCOUNTPERDEG 20000.0  */

/* Values based on Paramount data reported by TheSky */
/* Signs are reset in the driver */

#define AZCOUNTPERDEG  32000.0  
#define ALTCOUNTPERDEG   20833.33333333 

#define ALTSIGN -1.0
#define AZSIGN 1.0
       
/* Set this for maximum slew rate in degree/sec for some controllers */
/* Also see the value of SLEWFAST below */

#define MAXSLEWRATE 4

/* Site parameters are not defined here.  */    

/* The difference between terrestrial and ephemeris time is determined */
/*   by the accumulated number of leapseconds at this moment.   */

/* Updated on July 1, 2012 from 34.0  */
 
#define LEAPSECONDS    35.0

/* Important constant */

#define PI             3.14159265358

/* The following parameters are used internally to set speed and direction. */
/* Do not change these values.  */

/* Slew motion speeds  */

#define	GUIDE		1
#define	CENTER		2
#define	FIND		4
#define	SLEW		8
 
/* Slew directions                                                            */

#define	NORTH		1
#define	SOUTH		2
#define	EAST		4
#define	WEST		8

/* Focus commands                             */
/* Distance from the CCD to the focal plane   */
/* Direction is + from the CCD toward the sky */
/* Used by Focus(focuscmd, focusspd)          */

#define FOCUSSPD4       8   /* Fast    */
#define FOCUSSPD3       4   /* Medium  */
#define FOCUSSPD2       2   /* Slow    */
#define FOCUSSPD1       1   /* Precise */

#define FOCUSCMDOUT     1   /* CCD moves away from sky */
#define FOCUSCMDOFF     0   /* CCD does not move */
#define FOCUSCMDIN     -1   /* CCD moves toward the  sky */


/* Rotator commands */

#define ROTATESPDFAST       3   /* Fast set */
#define ROTATESPDSLOW       2   /* Slow set */
#define ROTATESPDSIDEREAL   1   /* Sidereal rate */
#define ROTATECMDCW         1   /* Camera rotates CW looking toward the sky */
#define ROTATECMDOFF        0   /* Camera does not rotate */
#define ROTATECMDCCW       -1   /* Camera rotates CCW looking toward the sky */

/* Fan commands */

#define FANCMDHIGH      2   /* cooling fan on high speed */
#define FANCMDLOW       1   /* cooling fan on low speed */
#define FANCMDOFF       0   /* cooling fan off */

/* Dew heater commands */

#define HEATERCMDHIGH      2   /* dew heater on high */
#define HEATERCMDLOW       1   /* dew heater on low */
#define HEATERCMDOFF       0   /* dew heater off */


/* Pointing models (bit mapped and additive) */

#define RAW       0      /* Unnmodified but assumed zero corrected */
#define OFFSET    1      /* Correct for target offset*/
#define REFRACT   2      /* Correct for atmospheric refraction */
#define POLAR     4      /* Correct for polar axis misalignment */ 
#define DYNAMIC   8      /* Correct for errors in real time */


/* Display epochs (selected with GUI button) */

#define J2000    0      /* Epoch 2000.0 as entered or precessed without pm */
#define EOD      1      /* Epoch of date with pm if available  (default) */

/* Mounts                                                                    */

#define ALTAZ  0        /* Alt-azimuth mount with at least 2-axis tracking */ 
#define EQFORK 1        /* Equatorial fork */
#define GEM    2        /* German equatorial */

/* Slew tolerances intentionally kept large to minimize looping */

#define SLEWTOLRA  0.006667  /* 0.1/15 hour    or 24 seconds of time */
#define SLEWTOLDEC 0.1       /* 0.1    degree  or  6 minutes of arc  */
#define SLEWFAST   0         /* Set to 1 for fast slew with caution !! */

/* Slew software limits */

#define MINTARGETALT   0.    /* Minimum target altitude in degrees */



