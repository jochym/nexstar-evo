#!/usr/bin/python
import ephem
mercury = ephem.Mercury()
mercury.compute(ephem.now())
print mercury.ra, mercury.dec


