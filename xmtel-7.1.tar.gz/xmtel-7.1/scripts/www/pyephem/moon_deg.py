#!/usr/bin/python
import ephem
import math
moon = ephem.Moon()
moon.compute(ephem.now())
radeg = float(moon.ra)*180./math.pi
decdeg = float(moon.dec)*180./math.pi
print radeg, decdeg


