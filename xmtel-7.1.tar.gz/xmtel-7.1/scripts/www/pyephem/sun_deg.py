#!/usr/bin/python
import ephem
import math
sun = ephem.Sun()
sun.compute(ephem.now())
radeg = float(sun.ra)*180./math.pi
decdeg = float(sun.dec)*180./math.pi
print radeg, decdeg


