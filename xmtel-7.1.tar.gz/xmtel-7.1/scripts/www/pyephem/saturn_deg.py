#!/usr/bin/python
import ephem
import math
saturn = ephem.Saturn()
saturn.compute(ephem.now())
radeg = float(saturn.ra)*180./math.pi
decdeg = float(saturn.dec)*180./math.pi
print radeg, decdeg


