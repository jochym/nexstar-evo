#!/usr/bin/python
import ephem
import math
mercury = ephem.Mercury()
mercury.compute(ephem.now())
radeg = float(mercury.ra)*180./math.pi
decdeg = float(mercury.dec)*180./math.pi
print radeg, decdeg


