#!/usr/bin/python
import ephem
venus = ephem.Venus()
venus.compute(ephem.now())
print venus.ra, venus.dec


