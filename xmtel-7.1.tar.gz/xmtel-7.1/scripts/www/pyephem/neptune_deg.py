#!/usr/bin/python
import ephem
import math
neptune = ephem.Neptune()
neptune.compute(ephem.now())
radeg = float(neptune.ra)*180./math.pi
decdeg = float(neptune.dec)*180./math.pi
print radeg, decdeg


