#!/usr/bin/python
import ephem
sun = ephem.Sun()
sun.compute(ephem.now())
print sun.ra, sun.dec


