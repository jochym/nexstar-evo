#!/usr/bin/python
import ephem
import math
uranus = ephem.Uranus()
uranus.compute(ephem.now())
radeg = float(uranus.ra)*180./math.pi
decdeg = float(uranus.dec)*180./math.pi
print radeg, decdeg


