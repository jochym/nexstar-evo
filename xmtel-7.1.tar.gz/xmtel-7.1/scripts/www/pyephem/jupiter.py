#!/usr/bin/python
import ephem
j = ephem.Jupiter()
j.compute(ephem.now())
print j.ra, j.dec


