#!/usr/bin/python
import ephem
n = ephem.Neptune()
n.compute(ephem.now())
print n.ra, n.dec


