#!/usr/bin/python
import ephem
mars = ephem.Mars()
mars.compute(ephem.now())
print mars.ra, mars.dec


