#!/usr/bin/python
import ephem
moon = ephem.Moon()
moon.compute(ephem.now())
print moon.ra, moon.dec


