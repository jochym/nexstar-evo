#!/usr/bin/python
import ephem
import math
mars = ephem.Mars()
mars.compute(ephem.now())
radeg = float(mars.ra)*180./math.pi
decdeg = float(mars.dec)*180./math.pi
print radeg, decdeg


