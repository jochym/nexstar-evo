#!/usr/bin/python
import ephem
u = ephem.Uranus()
u.compute(ephem.now())
print u.ra, u.dec


