#!/bin/sh
cd /home/www/htdocs/remote/video/
seconds=`date +%s`
filename="cdk20s_field"_$seconds".jpg"
curl -o tmp/$filename --no-keepalive "http://user:password@139.86.48.96/axis-cgi/jpg/image.cgi?resolution=4CIF&camera=1" >/dev/null
echo "Content-type: text/html"
echo ""
echo '<img src=tmp'/$filename' height=500 >'
exit
