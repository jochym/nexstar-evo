#!/bin/sh
cd /home/www/htdocs/remote/video/
seconds=`date +%s`
filename="telescope"_$seconds".jpg"
curl -o tmp/$filename --no-keepalive "http://user:password@192.168.1.203/axis-cgi/jpg/image.cgi?resolution=4CIF&camera=2" >/dev/null
echo "Content-type: text/html"
echo ""
echo '<img src=tmp'/$filename'>'
exit
