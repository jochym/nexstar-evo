#!/bin/sh
cd /home/www/htdocs/remote/video/
seconds=`date +%s`
filename="cdk20n_inside"_$seconds".jpg"
curl -o tmp/$filename --no-keepalive "http://user:password@136.165.99.85/axis-cgi/jpg/image.cgi?resolution=4CIF&camera=1" >/dev/null
echo "Content-type: text/html"
echo ""
echo '<img src=tmp'/$filename'>'
exit
