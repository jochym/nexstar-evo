#!/bin/sh
cd /home/www/htdocs/remote/video/
seconds=`date +%s`
filename="rc24_field"_$seconds".jpg"
curl -o tmp/$filename --no-keepalive "http://192.168.1.252/axis-cgi/jpg/image.cgi?resolution=4CIF&camera=1" >/dev/null
echo "Content-type: text/html"
echo ""
echo '<img src=tmp'/$filename' height=500 >'
exit
