#!/bin/sh
cd /home/www/htdocs/remote/video/
seconds=`date +%s`
filename="mtkent_ptz"_$seconds".jpg"
curl -o tmp/$filename --no-keepalive "http://139.86.48.94/axis-cgi/jpg/image.cgi?resolution=4CIF" >/dev/null
echo "Content-type: text/html"
echo ""
echo '<img src=tmp'/$filename'>'
exit
