#!/bin/sh
cd /home/www/htdocs/remote/video/
seconds=`date +%s`
filename="rc24_ptz"_$seconds".jpg"
curl -o tmp/$filename --no-keepalive "http://192.168.1.251/axis-cgi/jpg/image.cgi?resolution=4CIF" >/dev/null
echo "Content-type: text/html"
echo ""
echo '<img src=tmp'/$filename'>'
exit
