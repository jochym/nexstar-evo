#!/bin/sh
cd /home/www/htdocs/remote/rollroof/
seconds=`date +%s`
filename="field"_$seconds".jpg"
curl -o tmp/$filename --no-keepalive "http://user:password@192.168.1.203/axis-cgi/jpg/image.cgi?resolution=4CIF&camera=3" 1>/dev/null 2>/dev/null
echo "Content-type: text/html"
echo ""
echo 'http://moondog.astro.louisville.edu/remote/rollroof/tmp/'$filename
exit
