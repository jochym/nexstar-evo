#!/bin/sh
cd /home/www/htdocs/remote/rollroof/
seconds=`date +%s`
filename="sky"_$seconds".jpg"
curl -o tmp/$filename --no-keepalive "http://user:password@136.165.99.82/axis-cgi/jpg/image.cgi?resolution=4CIF" >/dev/null
echo "Content-type: text/html"
echo ""
echo '<img src=tmp'/$filename'>'
exit
