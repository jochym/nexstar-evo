#!/bin/sh
cd /home/www/htdocs/remote/rollroof/
seconds=`date +%s`
filename="field"_$seconds".jpg"
#curl -o tmp/$filename --no-keepalive "http://wispi.astro.louisville.edu/sbig/image.jpg" >/dev/null
cp /home/www/htdocs/remote/rollroof/sbig/latest.jpg tmp/$filename
echo "Content-type: text/html"
echo ""
echo '<img src=tmp'/$filename' width=800>'
exit
