#!/bin/sh
cd /home/www/htdocs/remote/rollroof/
seconds=`date +%s`
filename="nikon"_$seconds".jpg"
curl -o tmp/$filename --no-keepalive "http://wispi.astro.louisville.edu/nikon/latest.jpg" >/dev/null
cp tmp/$filename /home/www/htdocs/remote/rollroof/nikon/latest.jpg 
echo "Content-type: text/html"
echo ""
echo '<img src=tmp'/$filename' width=720>'
exit
