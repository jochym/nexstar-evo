#!/bin/bash
cd /home/www/htdocs/remote/rollroof/paramount/
rm current.html 2>/dev/null
curl -o current.html --no-keepalive "http://wispi.astro.louisville.edu/cgi-bin/get_paramount_current.sh" 1>/dev/null 2>/dev/null
echo "Content-type: text/html"
echo ""
echo $(cat /home/www/htdocs/remote/rollroof/paramount/current.html)
exit
