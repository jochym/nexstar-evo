#!/bin/sh
cd /home/www/htdocs/remote/rollroof/sbig/
seconds=`date +%s`
filename_jpg="sbig"_$seconds".jpg"
filename_fits="sbig"_$seconds".fits"

curl --no-keepalive "http://wispi.astro.louisville.edu/cgi-bin/expose_sbig.sh" 1>/dev/null 2>/dev/null
curl -o images/$filename_jpg --no-keepalive "http://wispi.astro.louisville.edu/sbig/latest.jpg" 1>/dev/null 2>/dev/null
curl -o fits/$filename_fits --no-keepalive "http://wispi.astro.louisville.edu/sbig/latest.fits" 1>/dev/null 2>/dev/null

cp images/$filename_jpg latest.jpg
cp images/$filename_jpg tmp/$filename_jpg
cp images/$filename_jpg /home/www/htdocs/remote/rollroof/tmp/$filename_jpg
echo "Content-type: text/html"
echo ""
echo '<img src=/remote/rollroof/tmp'/$filename_jpg' width=720>'
exit
