#!/bin/bash
cd /home/www/htdocs/remote/rollroof/nikon
seconds=`date +%s`
filename="nikon"_$seconds".jpg"
cp latest.jpg tmp/$filename 
echo "Content-type: text/html"
echo ""
echo '<img src=/remote/rollroof/nikon/tmp/'$filename' width=720>'
exit
