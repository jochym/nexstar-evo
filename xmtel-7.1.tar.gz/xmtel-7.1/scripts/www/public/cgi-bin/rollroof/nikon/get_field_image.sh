#!/bin/bash
cd /home/www/htdocs/remote/rollroof/nikon
seconds=`date +%s`
filename="field"_$seconds".jpg"
imagelink=$(curl --no-keepalive "http://moondog.astro.louisville.edu/cgi-bin/link_rollroof_field_image.sh/" 2>/dev/null)
curl -o tmp/$filename --no-keepalive "$imagelink" 1>/dev/null 2>/dev/null
echo "Content-type: text/html"
echo ""
echo '<img src=/remote/rollroof/nikon/tmp'/$filename' height=500 >'
exit
