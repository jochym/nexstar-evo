#!/bin/bash
cd /home/www/htdocs/remote/rollroof/nikon
seconds=`date +%s`
filename="nikon"_$seconds".jpg"
curl --no-keepalive "http://wispi.astro.louisville.edu/cgi-bin/expose_nikon.sh" 1>/dev/null 2>/dev/null
curl -o images/$filename --no-keepalive "http://wispi.astro.louisville.edu/nikon/latest.jpg" 1>/dev/null 2>/dev/null

cp images/$filename latest.jpg
cp images/$filename tmp/$filename
cp images/$filename /home/www/htdocs/remote/rollroof/tmp/$filename
echo "Content-type: text/html"
echo ""
echo '<img src=/remote/rollroof/tmp'/$filename' width=720>'
exit
