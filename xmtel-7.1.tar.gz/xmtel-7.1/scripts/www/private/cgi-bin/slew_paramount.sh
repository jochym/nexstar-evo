#!/bin/bash

# Send the requests to the indiserver 

slewcmd="/usr/local/bin/setINDI tel.goto.target=On"
$slewcmd 1>/dev/null 2>/dev/null
echo "Content-type: text/html"
echo ""
#echo "Query String:  "$QUERY_STRING
#echo "<br>"
#echo "Parsed Argument:  "$ARGX
#echo "<br>"
exit
