#!/bin/sh
echo "Content-type: text/html"
echo ""

# Assign the output of the local utility lst_hms to lst in this script
lst=$(/usr/local/bin/lst_hms)
utc=$(date --utc)

# Assign the outputs of gphoto2 to variables in this script
# Expected response examples:

#   nikoniso "Current: 400" 
#   nikonexp "Current: 1.00s"

# Response string is processed most simply with awk looking for the value in the expected location
# A more complete parsing would detect and flag an unexpected response appropriately

# Parse a response from gphoto2 using Bash string manipulation:
# Here %%Choice:* removes everthing from right to left to the last Choice:
# The #*Current: removes  everything from the left through Current:

response0=$(gphoto2 --quiet --get-config shutterspeed)
#nikonexp=$(echo $response0 | awk '{print $7}')
response1=${response0%%Choice:*}
nikonexp=${response1#*Current:}
response0=$(gphoto2 --quiet --get-config iso)
#nikoniso=$(echo $response0 | awk '{print $7}')
response1=${response0%%Choice:*}
nikoniso=${response1#*Current:}
utc=$(echo $utc | awk '{print $4}')

# Generate an html table to insert in the webpage

echo '<center>'
echo '<table bgcolor="#ffd0e2" border="2" cellpadding="8" cellspacing="1" width="800">'  
echo '<tbody>'
echo '<tr>'

echo '<td align="center" height="40" width="160"> &nbsp;<b>UTC</b>&nbsp; </td>'
echo '<td align="center" height="40" width="160"> &nbsp;<b>LST</b>&nbsp; </td>'
echo '<td align="center" height="40" width="160"> &nbsp;<b>ISO</b>&nbsp; </td>'
echo '<td align="center" height="40" width="160"> &nbsp;<b>Exposure</b>&nbsp; </td>'
echo '</tr>'
echo '<tr>'
echo '<td align="center" height="40" width="160">&nbsp;'
echo $utc
echo '</td>'
echo '<td align="center" height="40" width="160">&nbsp;'
echo $lst 
echo '</td>'
echo '<td align="center" height="40" width="160">&nbsp;'
echo $nikoniso
echo '</td>'
echo '<td align="center" height="40" width="160">&nbsp;' 
echo $nikonexp
echo '</td>'
echo '</tr>'

echo '</table>'
echo '</center>'

exit
