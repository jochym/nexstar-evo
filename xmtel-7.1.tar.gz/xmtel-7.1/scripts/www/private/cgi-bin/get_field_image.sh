#!/bin/sh
cd /home/www/htdocs/nikon
seconds=`date +%s`
filename="sky"_$seconds".jpg"
imagelink=$(curl --no-keepalive "http://moondog.astro.louisville.edu/cgi-bin/link_rollroof_field_image.sh/" 2>/dev/null)
curl -o tmp/$filename --no-keepalive "$imagelink" 1>/dev/null 2>/dev/null
echo "Content-type: text/html"
echo ""
echo '<img src=tmp'/$filename' height=500 >'
exit
