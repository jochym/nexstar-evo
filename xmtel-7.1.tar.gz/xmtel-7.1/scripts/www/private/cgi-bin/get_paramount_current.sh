#!/bin/sh

# This script requires utility functions lst_hms, utc, and dd2dms from the sidereal package.

echo "Content-type: text/html"
echo ""

# Assign the output of the local utility lst_hms to lst in this script
lst=$(/usr/local/bin/lst_hms)
utc=$(date --utc)

# Assign the outputs of getINDI to variables in this script
# Expected response examples:

#  telra "tel.telescope_2000.ra=3.7721097027329264506" 
#  teldec "tel.telescope_2000.dec=23.948265425394094308"

# Response string is processed most simply with awk looking for the value in the expected location
# A more complete parsing would detect and flag an unexpected response appropriately

# Parse a response from getINDI using Bash string manipulation:
# In the gphoto2 prototype %%Choice:* removes everthing from right to left to the last Choice:
# Similary  #*Current: removes  everything from the left through Current:

responsera=$(/usr/local/bin/getINDI tel.telescope_2000.ra)
telra=${responsera#*=}

responsedec=$(/usr/local/bin/getINDI tel.telescope_2000.dec)
teldec=${responsedec#*=}

telra=$(/usr/local/bin/dd2dms $telra 2>/dev/null)
teldec=$(/usr/local/bin/dd2dms $teldec 2>/dev/null)

utc=$(echo $utc | awk '{print $4}')

# Generate an html table to insert in the webpage

echo '<center>'
echo '<table bgcolor="#ffd0e2" border="2" cellpadding="8" cellspacing="1" width="800">'  
echo '<tbody>'
echo '<tr>'

echo '<td align="center" height="40" width="160"> &nbsp;<b>UTC</b>&nbsp; </td>'
echo '<td align="center" height="40" width="160"> &nbsp;<b>LST</b>&nbsp; </td>'
echo '<td align="center" height="40" width="160"> &nbsp;<b>RA</b>&nbsp; </td>'
echo '<td align="center" height="40" width="160"> &nbsp;<b>Dec</b>&nbsp; </td>'
echo '</tr>'
echo '<tr>'
echo '<td align="center" height="40" width="160">&nbsp;'
echo $utc
echo '</td>'
echo '<td align="center" height="40" width="160">&nbsp;'
echo $lst 
echo '</td>'
echo '<td align="center" height="40" width="160">&nbsp;'
echo $telra
echo '</td>'
echo '<td align="center" height="40" width="160">&nbsp;' 
echo $teldec
echo '</td>'
echo '</tr>'

echo '</table>'
echo '</center>'

exit
