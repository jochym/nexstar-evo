#!/bin/bash

# Set the defaults
targetra=0.0
targetdec=0.0


# Parse the the arguments in the cgi request

# For a request such as this --
#
#  http://localhost/cgi-bin/myprog.sh?namex=valuex&namey=valuey&namez=valuez
#
# Script will loop through all of the arguments 
#   in environment variable "QUERY_STRING"
#   as separated by the delimiter "&". Thus the
#   script loops three times with the following "Args":
#
#     namex=valuex
#     namey=valuey
#     namez=valuez
#
#   For each "Args" line, look for each token separated by the delimeter "=" 
#   Component 1 is ($1) and component 2 is ($2).
#   Use "sed" to parse and substitute characters.
#   A blank space is substituted for all %20's.

# Save the old internal field separator.

OIFS="$IFS"

# Set the field separator to & and parse the QUERY_STRING at the ampersand.

IFS="${IFS}&"
set $QUERY_STRING
Args="$*"
IFS="$OIFS"

# Next parse the individual "name=value" tokens.

ARGX=""
ARGY=""

for i in $Args ;do

# Set the field separator to =
  
  IFS="${OIFS}="
  set $i
  IFS="${OIFS}"

  case $1 in

# Filter for "/" not applied here
    
    ra)
    ARGX="`echo $2 | sed 's|%20| |g'`"
    targetra=$ARGX
    ;;
    
    dec)
    ARGY="${2/\// /}"
    targetdec=$ARGY
    ;;
    
    

# Unrecognized variable $1 passed by FORM in QUERY_STRING.
# Parsed values will be $ARGX $ARGY $ARGZ

  esac

done


echo $(date)>/tmp/paramount_remote_target.txt
echo "Set target">>/tmp/paramount_remote_target.txt


set_target_ra="/usr/local/bin/setINDI tel.target_2000.ra=$targetra"
$set_target_ra 1>/dev/null 2>/dev/null
set_target_dec="/usr/local/bin/setINDI tel.target_2000.dec=$targetdec"
$set_target_dec 1>/dev/null 2>/dev/null


echo $(date)>/tmp/paramount_remote_target.txt
echo "Set target">>/tmp/paramount_remote_target.txt
echo $set_target_ra>>/tmp/paramount_remote_target.txt
echo $set_target_dec>>/tmp/paramount_remote_target.txt




echo "Content-type: text/html"
echo ""
exit
