#!/bin/bash
cd /home/www/htdocs/nikon/
seconds=`date +%s`
filename="nikon"_$seconds".jpg"
#echo $filename >errors.txt
snap="gphoto2 --quiet --capture-image-and-download --filename images/$filename"
$snap 1>/dev/null 2>/dev/null
#$snap 1>>errors.txt 2>>errors.txt
cp images/$filename latest.jpg
echo "Content-type: text/html"
echo ""
echo '<img src=images'/$filename' height=500 >'
exit
