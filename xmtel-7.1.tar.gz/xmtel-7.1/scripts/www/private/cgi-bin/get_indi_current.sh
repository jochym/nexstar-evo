#!/bin/sh
echo "Content-type: text/html"
echo ""
# Assign the output of the local utility lst_hms to lst in this script
lst=$(/usr/local/bin/lst_hms)
echo '<center>'
echo '<table bgcolor="#ffd0e2" border="2" cellpadding="8" cellspacing="1" width="800">'  
echo '<tbody>'
echo '<tr>'
echo '<td align="center" height="40" width="160"> &nbsp;RA&nbsp; </td>'
echo '<td align="center" height="40" width="160"> &nbsp;Dec&nbsp; </td>'
echo '<td align="center" height="40" width="160"> &nbsp;HA&nbsp; </td>'
echo '<td align="center" height="40" width="160"> &nbsp;LST&nbsp; </td>'
echo '<td align="center" height="40" width="160"> &nbsp;Status&nbsp; </td>'
echo '</tr>'
echo '<tr>'
echo '<td align="center" height="40" width="160"> &nbsp;&nbsp;  </td>'
echo '<td align="center" height="40" width="160"> &nbsp;-52:00:00&nbsp; </td>'
echo '<td align="center" height="40" width="160"> &nbsp;00:00:01&nbsp; </td>'
echo '<td align="center" height="40" width="160">'
echo $lst
echo '</td>'
echo '<td align="center" height="40" width="160"> &nbsp;Parked&nbsp; </td>'
echo '</tr>'

echo '</table>'
echo '</center>'
exit
