#!/bin/sh
cd /home/www/htdocs/nikon
seconds=`date +%s`
filename="tmp/cdk125"_$seconds".jpg"
cp latest.jpg $filename 
echo "Content-type: text/html"
echo ""
echo '<img src='$filename' width=720>'
exit
