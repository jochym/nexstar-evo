#!/bin/bash
cd /home/www/htdocs/sbig/
seconds=`date +%s`
filename_jpg="sbig"_$seconds".jpg"
filename_fits="sbig"_$seconds".fits"
#echo $filename >errors.txt
snap=" "
$snap 1>/dev/null 2>/dev/null
#$snap 1>>errors.txt 2>>errors.txt
cp images/$filename latest.jpg
echo "Content-type: text/html"
echo ""
echo '<img src=images'/$filename_jpg' height=500 >'
exit
