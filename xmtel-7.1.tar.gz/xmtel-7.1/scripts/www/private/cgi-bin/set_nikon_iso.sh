#!/bin/bash

# Set the defaults

nikoniso=15

# Parse the the arguments in the cgi request

# For a request such as this --
#
#  http://localhost/cgi-bin/myprog.sh?namex=valuex&namey=valuey&namez=valuez
#
# Script will loop through all of the arguments 
#   in environment variable "QUERY_STRING"
#   as separated by the delimiter "&". Thus the
#   script loops three times with the following "Args":
#
#     namex=valuex
#     namey=valuey
#     namez=valuez
#
#   For each "Args" line, look for each token separated by the delimeter "=" 
#   Component 1 is ($1) and component 2 is ($2).
#   Use "sed" to parse and substitute characters.
#   A blank space is substituted for all %20's.

# Save the old internal field separator.

OIFS="$IFS"

# Set the field separator to & and parse the QUERY_STRING at the ampersand.

IFS="${IFS}&"
set $QUERY_STRING
Args="$*"
IFS="$OIFS"

# Next parse the individual "name=value" tokens.

ARGX=""

for i in $Args ;do

# Set the field separator to =
  
  IFS="${OIFS}="
  set $i
  IFS="${OIFS}"

  case $1 in

# Filter for "/" not applied here
    
    iso)
    ARGX="`echo $2 | sed 's|%20| |g'`"
    nikoniso=$ARGX
    ;;


# Unrecognized variable $1 passed by FORM in QUERY_STRING.
# Parsed values will be $ARGX $ARGY $ARGZ

  esac

done

# Send the requests to the camera through gphoto2

set_iso="gphoto2 --quiet --set-config iso=$nikoniso"
$set_iso 1>/dev/null 2>/dev/null
echo "Content-type: text/html"
echo ""
#echo "Query String:  "$QUERY_STRING
#echo "<br>"
#echo "Parsed Argument:  "$ARGX
#echo "<br>"
exit
