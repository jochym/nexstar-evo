
CC = gcc

GCCFLAGS = -ffast-math -Wall
LIBROOT = ./
LIBLILXML = ../liblilxml
CFLAGS = $(GCCFLAGS) -I$(LIBLILXML)
LDFLAGS = -L$(LIBROOT) -L$(LIBLILXML)
LIBS =	-lm  -llilxml 

OBJS =				\
	indidrivermain.o	\
	eventloop.o		\
	protocol.o 		\
	pointing.o		\
	algorithms.o		\
        format.o		\
	tel.o			

all:	tel 

tel:	$(OBJS)
	$(CC) $(LDFLAGS) -o $@ $(OBJS) $(LIBS)

clean:
	rm -fr *.o tel
