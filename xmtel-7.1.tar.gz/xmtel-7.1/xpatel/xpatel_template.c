/* -------------------------------------------------------------------------- */
/* -                   Astronomical Telescope Control                       - */
/* -                          XmTel XPA Server                              - */
/* -                                                                        - */
/* -------------------------------------------------------------------------- */
/*                                                                            */
/* Copyright (c) 2014 John Kielkopf                                           */
/* kielkopf@louisville.edu                                                    */
/*                                                                            */
/* This file is part of XmTel.                                                */
/*                                                                            */
/* -------------------------------------------------------------------------- */
/*                                                                            */
/* This program is based on stest.c distributed with xpa version 2.1.5        */
/* XPA and stest are                                                          */
/* Copyright (c) 1999-2003 Smithsonian Astrophysical Observatory              */
/*                                                                            */
/* -------------------------------------------------------------------------- */
/*                                                                            */
/*                                                                            */
/*                                                                            */
/* Date: March 22, 2014                                                       */
/* Version: 1.0                                                               */
/*                                                                            */
/* -------------------------------------------------------------------------- */


#define HAVE_STRING_H 1
#define HAVE_MALLOC_H 1
#define HAVE_STDLIB_H 1
#define HAVE_UNISTD_H 1
#define HAVE_SETJMP_H 1
#include "xpap.h"

#define MAX_FPS 10

extern char *optarg;
extern int optind;

XPA xpa1;
int  quiet=0;
int n=0;
size_t  save_bytes=-1;
char *save_buf=NULL;

char *mode="";
char name[SZ_LINE];
char xclass[SZ_LINE];


/* Prototypes for telescope commands */

int send_server_cb (void *client_data, void *call_data, char *paramlist,
  char **buf, size_t *len);

int receive_server_cb (void *client_data, void *call_data, char *paramlist,
  char *buf, size_t len);

int send_cmd2_cb (void *client_data, void *call_data, char *paramlist,
  char **buf, size_t *len);

int receive_cmd2_cb (void *client_data, void *call_data, char *paramlist,
  char *buf, size_t len);


/* Command: server */

int send_server_cb (void *client_data, void *call_data, char *paramlist,
  char **buf, size_t *len)
{
  char *s = (char *)client_data;
  XPA xpa = (XPA)call_data;
  char tbuf[SZ_LINE];
  char xtemplate[SZ_LINE];
  int sendbuf=0;
  int ip;
  
  /* Callback provides */
  /*   server in string s */
  /*   arguments to server in string paramlist */

  /* Diagnostic entrance */
  if( !quiet )
  {
    fprintf(stdout, "tel send_server_cb started -- #%d: %s:%s %s (%s)\n",
    n++, xpa_class(xpa), xpa_name(xpa), xpa_method(xpa), s);
  }

  /* Process paramlist */
  
  if( paramlist && *paramlist )
  {
    ip = 0;
    word(paramlist, xtemplate, &ip);
    if( !quiet )
    {
      fprintf(stdout, "\tparamlist: %s\n", paramlist);
    }
    if( !strncmp(paramlist, "buf", 3) )
    {
      sendbuf=1;
    }
    else if( !strcmp(paramlist, "exit") )
    {
      if( !quiet )
      {
	fprintf(stdout, "Exiting with cleanup\n");
      }
      XPAFree(xpa1);      
    }
    else if( !strcmp(paramlist, "Exit") )
    {
      if( !quiet )
      {      
	fprintf(stdout, "Exiting immediately\n");
      }
      exit(0);
    }
  }

  /* return information about this xpa */
  if( !sendbuf )
  {
    snprintf(tbuf, SZ_LINE,
      "class: %s\nname: %s\nmethod: %s\nsendian: %s\ncendian: %s\n",
      xpa_class(xpa), xpa_name(xpa), xpa_method(xpa),
      xpa_sendian(xpa), xpa_cendian(xpa));
  
    if( (xpa->send_mode & XPA_MODE_FILLBUF) )
    {
      send(xpa_datafd(xpa), tbuf, strlen(tbuf), 0);
      *len = 0;
      *buf = NULL;
      if( !quiet)
	fprintf(stdout, "\tcallback writes %d bytes to client\n",
	  (int)strlen(tbuf));
    }
    /* return the buffer and let xpa transmit it */
    else
    {
      *len = strlen(tbuf);
      *buf = (char *)xmalloc(*len);
      memcpy(*buf, tbuf, *len);
      if( !quiet)
	fprintf(stdout, "\ttel server callback returns %d bytes to xpa handler\n",
	  (int)strlen(tbuf));
    }
  }
  /* return the last buffer we were sent */
  else
  {
    if( (xpa->send_mode & XPA_MODE_FILLBUF) )
    {
      send(xpa_datafd(xpa), save_buf, save_bytes, 0);
      *len = 0;
      *buf = NULL;
      if( !quiet)
      {
	fprintf(stdout, "\tcallback writes %lu bytes to client\n", 
	  (unsigned long)save_bytes);
      }
    }
    /* return the buffer and let xpa transmit it */
    else
    {
      *len = save_bytes;
      *buf = (char *)xmalloc(*len);
      memcpy(*buf, save_buf, *len);
      if( !quiet)
      {
	fprintf(stdout, "\ttel server callback returns %lu bytes to xpa handler\n",
	  (unsigned long)save_bytes);
      }
    }
  }
  
  /* Diagnostic exit */
  
  if( !quiet )
  {
    fprintf(stdout, "tel send_server_cb completed \n");
  }
  else{
    fprintf(stdout, ".");
  }
  fflush(stdout);
  fflush(stderr);
  return(0);
}


int receive_server_cb (void *client_data, void *call_data, char *paramlist,
  char *buf, size_t len)
{
  XPA xpa = (XPA)call_data;
  char *s = (char *)client_data;
 
  /* Callback provides */
  /*   server in string s */
  /*   arguments to server in string paramlist */

  /* Diagnostic entrance */
  if( !quiet )
  {
    fprintf(stdout, "tel receive_server_cb started -- #%d: %s:%s %s (%s)\n",
    n++, xpa_class(xpa), xpa_name(xpa), xpa_method(xpa), s);
  }
  
  /* Process paramlist */
  
  if( paramlist && *paramlist )
  {
    if( !quiet )
    {
      fprintf(stdout, "\tparamlist: %s\n", paramlist);
    }
    if( !strcmp(paramlist, "exit") )
    {
      if( !quiet )
      { 	
        fprintf(stdout, "Exiting with cleanup\n");
      }
      XPAFree(xpa1);
      
    }
    else if( !strcmp(paramlist, "Exit") )
    {
      if( !quiet )
      {
	fprintf(stdout, "Exiting immediately\n");
      }
      exit(0);
    }
  }

  /* reset save buffer */
  if( save_buf != NULL )
  {
    xfree(save_buf);
    save_buf = NULL;
  }
  save_bytes = 0;
  
  if( !quiet )
  {
    fprintf(stdout, "\tenter callback with buf: %lu bytes\n", 
      (unsigned long)len);
  }
  save_bytes = len;
  save_buf = (char *)xmalloc(len);
  memcpy(save_buf, buf, len);
  
  /* Diagnostic exit */
  
  if( !quiet )
  {
    fprintf(stdout, "tel receive_server_cb completed\n");
  }
  else
  {
    fprintf(stdout, ".");
  }
  fflush(stdout);
  fflush(stderr);
  return(0);
}

/* Command: cmd2 */

int send_cmd2_cb (void *client_data, void *call_data, char *paramlist,
  char **buf, size_t *len)
{
  char *s = (char *)client_data;
  XPA xpa = (XPA)call_data;
  char tbuf[SZ_LINE];
  int sendbuf=0;
  
  /* Callback provides */
  /*   cmd2 in string s */
  /*   arguments to cmd2 in string paramlist */

  /* Diagnostic entrance */
  if( !quiet )
  {
    fprintf(stdout, "tel send_cmd2_cb started -- #%d: %s:%s %s (%s)\n",
    n++, xpa_class(xpa), xpa_name(xpa), xpa_method(xpa), s);
  }

  /* Process paramlist */
  
  if( paramlist && *paramlist )
  {
    if( !quiet )
    {
      fprintf(stdout, "\tparamlist: %s\n", paramlist);
    }
    if( !strncmp(paramlist, "test", 3) )
    {
      fprintf(stdout, "test\n");
      return(0);
    }
  }

  /* Return information about this xpa */
  if( !sendbuf )
  {
    snprintf(tbuf, SZ_LINE,
       "class: %s\nname: %s\nmethod: %s\nsendian: %s\ncendian: %s\n",
       xpa_class(xpa), xpa_name(xpa), xpa_method(xpa),
       xpa_sendian(xpa), xpa_cendian(xpa));
  
    if( (xpa->send_mode & XPA_MODE_FILLBUF) )
    {
      send(xpa_datafd(xpa), tbuf, strlen(tbuf), 0);
      *len = 0;
      *buf = NULL;
      if( !quiet)
	fprintf(stdout, "\tcallback writes %d bytes to client\n",
	  (int)strlen(tbuf));
    }
    /* Return the buffer and let xpa transmit it */
    else
    {
      *len = strlen(tbuf);
      *buf = (char *)xmalloc(*len);
      memcpy(*buf, tbuf, *len);
      if( !quiet)
	fprintf(stdout, "\tcallback returns %d bytes to xpa handler\n",
	  (int)strlen(tbuf));
    }
  }
  /* Return the last buffer we were sent */
  else
  {
    if( (xpa->send_mode & XPA_MODE_FILLBUF) )
    {
      send(xpa_datafd(xpa), save_buf, save_bytes, 0);
      *len = 0;
      *buf = NULL;
      if( !quiet)
	fprintf(stdout, "\ttel cmd2 callback writes %lu bytes to client\n", 
	  (unsigned long)save_bytes);
    }
    /* Return the buffer and let xpa transmit it */
    else
    {
      *len = save_bytes;
      *buf = (char *)xmalloc(*len);
      memcpy(*buf, save_buf, *len);
      if( !quiet)
	fprintf(stdout, "\ttel cmd2 callback returns %lu bytes to xpa handler\n",
	  (unsigned long)save_bytes);
    }
  }
  
  /* Diagnostic exit */
  
  if( !quiet )
  {
    fprintf(stdout, "tel send_cmd2_cb completed \n");
  }
  else
  {
    fprintf(stdout, ".");
  }
  fflush(stdout);
  fflush(stderr);
  return(0);
}


int receive_cmd2_cb (void *client_data, void *call_data, char *paramlist,
  char *buf, size_t len)
{
  XPA xpa = (XPA)call_data;
  char *s = (char *)client_data;
 

  /* Callback provides */
  /*   cmd2 in string s */
  /*   arguments to cmd2 in string paramlist */

  /* Diagnostic entrance */
  if( !quiet )
  {
    fprintf(stdout, "tel receive_cmd2_cb started -- #%d: %s:%s %s (%s)\n",
    n++, xpa_class(xpa), xpa_name(xpa), xpa_method(xpa), s);
  }
  
  /* Process paramlist */
  
  if( paramlist && *paramlist )
  {
    if( !quiet )
    {
      fprintf(stdout, "\tparamlist: %s\n", paramlist);
    }
    if( !strcmp(paramlist, "test") )
    {
      if( !quiet )
      {
	fprintf(stdout, "test\n");
      }
      return(0);
    }
  }
  
  /* Reset save buffer */
  if( save_buf != NULL )
  {
    xfree(save_buf);
    save_buf = NULL;
  }
  save_bytes = 0;
  
  if( !quiet )
  {
    fprintf(stdout, "\ttel cmd2 callback with buf: %lu bytes\n", 
      (unsigned long)len);
  }
  save_bytes = len;
  save_buf = (char *)xmalloc(len);
  memcpy(save_buf, buf, len);
  
  /* Diagnostic exit */
  
  if( !quiet )
  {
    fprintf(stdout, "tel receive_cmd2_cb completed\n");
  }
  else
  {
    fprintf(stdout, ".");
  }
  fflush(stdout);
  fflush(stderr);
  return(0);
}


/* Main program */

int main (int argc, char **argv)
{

  char tbuf[SZ_LINE];
  char cmd[SZ_LINE];
  int c;
  int delay=0;

  /* Process switch arguments */
  /* Telescope server xpatel would be started without arguments */
  
  /* Arguments recognized are: */
  
  /*   d int -- sets delay int seconds after starting bkgd cmd */
  /*   f cmd -- starts cmd in background */
  /*   q  -- runs quietly */
   
  
  *cmd = '\0';
  while ((c = getopt(argc, argv, "d:f:q")) != -1)
  {
    switch(c)
    {
    case 'd':
      delay = atoi(optarg);
      break;
    case 'f':
      snprintf(cmd, SZ_LINE, "%s %s &\n", argv[0], optarg);
      break;
    case 'q':
      quiet = 1;
      break;
    }
  }

  /* Prepare to start server */

  if( optind >= argc )
  {
    strcpy(name, "tel");
  }
  else
  {
    strcpy(name, argv[optind]);
  }
  
  strcpy(xclass, name);
  cluc(xclass);

  /* Telescope commands through xpa */
    
  /* Create the class tel */
  
  snprintf(tbuf, SZ_LINE, "%s", name);
  xpa1 = XPACmdNew(xclass, tbuf);
  if( xpa1 == NULL )
  {
    fprintf(stderr, "Could not start tel on xpa\n");
  }
  else
  {

    /* Add commands with their callbacks to tel */
    
    XPACmdAdd(xpa1, "server", "exit",
      send_server_cb, (void *)"server", mode, 
      receive_server_cb, (void *)"server", mode);

    XPACmdAdd(xpa1, "cmd2", "and help for cmd2",
      send_cmd2_cb, (void *)"cmd2", mode, 
      receive_cmd2_cb, (void *)"cmd2", mode);

    fprintf(stdout, "Commands have been added to %s using method: %s\n", 
      xpa_name(xpa1), xpa_method(xpa1));
  }
    
    
  /* Start another background process if option -f cmd */
  
  if( *cmd != '\0' )
  {
    fprintf(stdout, "starting bkgd process: %s", cmd);
    system(cmd);
  }

  /* Delay if requested by option -d int  */
  
  if( delay )
  {
    fprintf(stdout, "starting delay of %d seconds ...", delay);
    XPASleep(delay*1000);
    fprintf(stdout, " done\n");
  }
  
  fflush(stdout);
  fflush(stderr);

  /* Start select loop and monitor for requests */
   
  fprintf(stdout, "\nEntering tel select command loop ...\n");
  XPAMainLoop();
  goto done;
 

done:
  XPAFree(xpa1);

  /* Cleanup and exit */
  
  XPACleanup();
  if( save_buf ) xfree(save_buf);
  exit(0);
}
