/* -------------------------------------------------------------------------- */
/* -                   Astronomical Telescope Control                       - */
/* -                          XmTel XPA Server                              - */
/* -                                                                        - */
/* -------------------------------------------------------------------------- */
/*                                                                            */
/* Copyright (c) 2014 John Kielkopf                                           */
/* kielkopf@louisville.edu                                                    */
/*                                                                            */
/* This file is part of XmTel.                                                */
/*                                                                            */
/* -------------------------------------------------------------------------- */
/*                                                                            */
/* This program is based on stest.c distributed with xpa version 2.1.5        */
/* XPA and stest are                                                          */
/* Copyright (c) 1999-2003 Smithsonian Astrophysical Observatory              */
/*                                                                            */
/* -------------------------------------------------------------------------- */
/*                                                                            */
/*                                                                            */
/*                                                                            */
/* Date: March 20, 2014                                                       */
/* Version: 1.0                                                               */
/*                                                                            */
/* -------------------------------------------------------------------------- */


#define HAVE_STRING_H 1
#define HAVE_MALLOC_H 1
#define HAVE_STDLIB_H 1
#define HAVE_UNISTD_H 1
#define HAVE_SETJMP_H 1
#include "xpap.h"

int send_cb (void *client_data, void *call_data, char *paramlist,
  char **buf, size_t *len);

int receive_cb (void *client_data, void *call_data, char *paramlist,
  char *buf, size_t len);


#define MAX_FPS 10

extern char *optarg;
extern int optind;

XPA xpa1;
int  quiet=0;
int n=0;
size_t  save_bytes=-1;
char *save_buf=NULL;

char *mode="";
char name[SZ_LINE];
char xclass[SZ_LINE];

int send_cb (void *client_data, void *call_data, char *paramlist,
  char **buf, size_t *len)
{
  char *s = (char *)client_data;
  XPA xpa = (XPA)call_data;
  char tbuf[SZ_LINE];
  char xtemplate[SZ_LINE];
  char *names[MAX_FPS];
  char *bufs[MAX_FPS];
  char *errs[MAX_FPS];
  size_t lens[MAX_FPS];
  int sendbuf=0;
  int got;
  int i;
  int ip;

  /* introduce ourselves */
  if( !quiet )
  {
    fprintf(stdout, "SEND_CB #%d: %s:%s %s (%s)\n",
    n++, xpa_class(xpa), xpa_name(xpa), xpa_method(xpa), s);
  }

  /* process special paramlist tokens */
  if( paramlist && *paramlist ){
    ip = 0;
    word(paramlist, xtemplate, &ip);
    if( !quiet )
      fprintf(stdout, "\tparamlist: %s\n", paramlist);
    if( !strncmp(paramlist, "buf", 3) ){
      sendbuf=1;
    }
    else if( !strcmp(paramlist, "free") ){
      if( !quiet )
	fprintf(stdout, "Freeing xpa struct\n");
      XPAFree(xpa);
      return(0);
    }
    else if( !strcmp(paramlist, "exit") ){
      if( !quiet )
      {
	fprintf(stdout, "Exiting\n");
      }
      XPAFree(xpa1);
      
    }
    else if( !strcmp(paramlist, "Exit") ){
      if( !quiet )
	fprintf(stdout, "Exiting immediately\n");
      exit(0);
    }
    else if( !strncmp(paramlist, "error", 5) ){
      if( !quiet )
	fprintf(stdout, "\treturning error: %s\n", &paramlist[6]);
      *len = 0;
      *buf = NULL;
      if( strlen(paramlist) > 6 )
	XPAError(xpa, &paramlist[6]);
      else
	XPAError(xpa, "intentional error from client");
      return(-1);
    }
    else if( !strcmp(paramlist, "wait") || !strcmp(paramlist, "version") ){
      fprintf(stdout, "Press <CR> to continue ...");
      fgets(tbuf, SZ_LINE, stdin);
    }
    else if( !strcmp(paramlist, "poll") ){
repoll:
      fprintf(stdout, "Press 'q' to quit ...");
      got = XPAPoll (10000, 1);
      fprintf(stdout, " XPAPoll returns %d ...", got);
      fgets(tbuf, SZ_LINE, stdin);
      if( *tbuf != 'q' )
	goto repoll;
    }
    else if( !strncmp(paramlist, "fork ", 5) ){

    if( strlen(paramlist) > 5 ){
      fprintf(stdout, "fork command: %s\n", &paramlist[5]);
      /* child forks a command and exits */
      if(!(fork())){
        system(&paramlist[5]);
        /* should call _exit but this tests avoidance of atexit routine */
        exit(0);
      }
    }

    }
    else if( !strcmp(xtemplate, "xpaget") ){
      word(paramlist, xtemplate, &ip);
      got = XPAGet(xpa, xtemplate, &(paramlist[ip]), NULL,
		   bufs, lens, names, errs, MAX_FPS);
      if( !quiet )
	fprintf(stdout, "XPAGet (%s) returned %d buffer(s)\n", xtemplate, got);
      for(i=0; i<got; i++){
	if( !quiet )
	  fprintf(stdout, "\t%d: %s\n", i, names[i]);
	if( errs[i] == NULL ){
	  if( !quiet && (lens[i] > 0) ){
	    fprintf(stdout, "contents (%lu bytes):\n", (unsigned long)lens[i]);
	    fwrite(bufs[i], sizeof(char), lens[i], stdout);
	  }
	  if( !quiet )
	    fprintf(stdout, "\n");
	}
	else{
	  write(fileno(stdout), errs[i], strlen(errs[i]));
	}
	if( bufs[i] )
	  xfree(bufs[i]);
	if( names[i] )
	  xfree(names[i]);
	if( errs[i] )
	  xfree(errs[i]);
      }
    }
  }

  /* return information about this xpa */
  if( !sendbuf ){
    snprintf(tbuf, SZ_LINE,
	  "class: %s\nname: %s\nmethod: %s\nsendian: %s\ncendian: %s\n",
	  xpa_class(xpa), xpa_name(xpa), xpa_method(xpa),
	  xpa_sendian(xpa), xpa_cendian(xpa));
  
    if( (xpa->send_mode & XPA_MODE_FILLBUF) ){
      send(xpa_datafd(xpa), tbuf, strlen(tbuf), 0);
      *len = 0;
      *buf = NULL;
      if( !quiet)
	fprintf(stdout, "\tcallback writes %d bytes to client\n",
		(int)strlen(tbuf));
    }
    /* return the buffer and let xpa transmit it */
    else{
      *len = strlen(tbuf);
      *buf = (char *)xmalloc(*len);
      memcpy(*buf, tbuf, *len);
      if( !quiet)
	fprintf(stdout, "\tcallback returns %d bytes to xpa handler\n",
		(int)strlen(tbuf));
    }
  }
  /* return the last buffer we were sent */
  else{
    if( (xpa->send_mode & XPA_MODE_FILLBUF) ){
      send(xpa_datafd(xpa), save_buf, save_bytes, 0);
      *len = 0;
      *buf = NULL;
      if( !quiet)
	fprintf(stdout, "\tcallback writes %lu bytes to client\n", 
		(unsigned long)save_bytes);
    }
    /* return the buffer and let xpa transmit it */
    else{
      *len = save_bytes;
      *buf = (char *)xmalloc(*len);
      memcpy(*buf, save_buf, *len);
      if( !quiet)
	fprintf(stdout, "\tcallback returns %lu bytes to xpa handler\n",
		(unsigned long)save_bytes);
    }
  }
  if( !quiet ){
    fprintf(stdout, "SEND_CB complete\n");
  }
  else{
    fprintf(stdout, ".");
  }
  fflush(stdout);
  fflush(stderr);
  return(0);
}


int receive_cb (void *client_data, void *call_data, char *paramlist,
  char *buf, size_t len)
{
  XPA xpa = (XPA)call_data;
  char *s = (char *)client_data;
  char tbuf[SZ_LINE];
  char *errs[1];
  int ip;
  int got;

  if( !quiet )
  {
    fprintf(stdout, "RECEIVE_CB #%d: %s:%s %s (%s)\n",
    n++, xpa_class(xpa), xpa_name(xpa), xpa_method(xpa), s);
  }
  /* process param list */
  if( paramlist && *paramlist ){
    if( !quiet )
      fprintf(stdout, "\tparamlist: %s\n", paramlist);
    if( !strcmp(paramlist, "free") ){
      if( !quiet )
	fprintf(stdout, "Freeing xpa struct\n");
      XPAFree(xpa);
      return(0);
    }
    else if( !strcmp(paramlist, "exit") ){
      if( !quiet )
      { 	
        fprintf(stdout, "Exiting\n");
      }
      XPAFree(xpa1);
      
    }
    else if( !strcmp(paramlist, "Exit") ){
      if( !quiet )
	fprintf(stdout, "Exiting immediately\n");
      exit(0);
    }
    else if( !strncmp(paramlist, "error", 5) ){
      if( !quiet )
	fprintf(stdout, "Processing error: %s\n", &paramlist[6]);
      if( strlen(paramlist) > 6 )
	XPAError(xpa, &paramlist[6]);
      else
	XPAError(xpa, "intentional error from client");
      return(-1);
    }
    else if( !strcmp(paramlist, "wait") ){
      fprintf(stdout, "Press <CR> to continue ...");
      fgets(tbuf, SZ_LINE, stdin);
    }
    else if( !strcmp(paramlist, "poll") ){
repoll:
      fprintf(stdout, "Press 'q' to quit ...");
      got = XPAPoll (10000, 1);
      fprintf(stdout, " ... XPAPoll returns %d ...", got);
      fgets(tbuf, SZ_LINE, stdin);
      if( *tbuf != 'q' )
	goto repoll;
    }
    else if( !strncmp(paramlist, "fork ", 5) ){

      if( strlen(paramlist) > 5 ){
	fprintf(stdout, "fork command: %s\n", &paramlist[5]);
	/* child forks a command and exits */
	if(!(fork())){
	  system(&paramlist[5]);
	  /* should call _exit but this tests avoidance of atexit routine */
	  exit(0);
	}
      }

    }
    else if( !strncmp(paramlist, "xpaset", 6) ){
      ip = 0;
      word(paramlist, tbuf, &ip);
      if( word(paramlist, tbuf, &ip) ){
	if( !quiet )
	  fprintf(stdout, "calling XPASet(%s, \"%s\")\n",
		  tbuf, &(paramlist[ip]));
	got = XPASet(NULL, tbuf, &(paramlist[ip]), mode,
		     paramlist, strlen(paramlist), NULL, errs, 1);
	if( got == 0 ){
	  if( !quiet )
	    fprintf(stdout, "no XPA access points matched template %s\n",
		    tbuf);
	}
	else if( errs[0] != NULL ){
	  if( !quiet )
	    fprintf(stdout, "Error on xpaset to %s: %s\n", tbuf, errs[0]);
	  xfree(errs[0]);
	}
	else{
	  if( !quiet )
	    fprintf(stdout, "XPASet to %s successful\n", tbuf);
	}
      }
      return(0);
    }
  }

  /* reset save buffer */
  if( save_buf != NULL ){
    xfree(save_buf);
    save_buf = NULL;
  }
  save_bytes = 0;
  
  if( !quiet )
  {
    fprintf(stdout, "\tenter callback with buf: %lu bytes\n", 
      (unsigned long)len);
  }
  save_bytes = len;
  save_buf = (char *)xmalloc(len);
  memcpy(save_buf, buf, len);
  
  if( !quiet ){
    fprintf(stdout, "RECEIVE_CB complete\n");
  }
  else{
    fprintf(stdout, ".");
  }
  fflush(stdout);
  fflush(stderr);
  return(0);
}



int main (int argc, char **argv)
{

  char tbuf[SZ_LINE];
  char cmd[SZ_LINE];
  int c;
  int delay=0;

  /* Process switch arguments */
  /* Telescope server xpatel would be started without arguments */
  
  /* Arguments recognized are: */
  
  /*   d int -- sets delay int seconds after starting bkgd cmd */
  /*   f cmd -- starts cmd in background */
  /*   q  -- runs quietly */
   
  
  *cmd = '\0';
  while ((c = getopt(argc, argv, "d:f:q")) != -1)
  {
    switch(c)
    {
    case 'd':
      delay = atoi(optarg);
      break;
    case 'f':
      snprintf(cmd, SZ_LINE, "%s %s &\n", argv[0], optarg);
      break;
    case 'q':
      quiet = 1;
      break;
    }
  }

  /* Prepare to start server */

  if( optind >= argc )
  {
    strcpy(name, "tel");
  }
  else
  {
    strcpy(name, argv[optind]);
  }
  
  strcpy(xclass, name);
  cluc(xclass);

  /* Start the server */
    
  snprintf(tbuf, SZ_LINE, "%s", name);
  xpa1 = XPACmdNew(xclass, tbuf);
  if( xpa1 == NULL )
  {
    fprintf(stderr, "Could not start tel on xpa\n");
  }
  else
  {
    XPACmdAdd(xpa1, "cmd2", "and help for cmd2",
      send_cb, (void *)"cmd2", mode, 
      receive_cb, (void *)"cmd2", mode);
    XPACmdAdd(xpa1, "cmd1 xx yy", "help for cmd1 xx yy",
      send_cb, (void *)"cmd1 xx yy", mode, 
      receive_cb, (void *)"cmd1 xx yy", mode);
    XPACmdAdd(xpa1, "cmd1 xx", "help for cmd1 xx",
      send_cb, (void *)"cmd1 xx", mode, 
      receive_cb, (void *)"cmd1 xx", mode);
    XPACmdAdd(xpa1, "cmd1", NULL,
      send_cb, (void *)"cmd1", mode, 
      receive_cb, (void *)"cmd1", mode);
    fprintf(stdout, "Commands have been added to %s using method: %s\n", 
      xpa_name(xpa1), xpa_method(xpa1));
  }
    
    
  /* Start another background process if option -f cmd */
  
  if( *cmd != '\0' )
  {
    fprintf(stdout, "starting bkgd process: %s", cmd);
    system(cmd);
  }

  /* Delay if requested by option -d int  */
  
  if( delay )
  {
    fprintf(stdout, "starting delay of %d seconds ...", delay);
    XPASleep(delay*1000);
    fprintf(stdout, " done\n");
  }
  
  fflush(stdout);
  fflush(stderr);

  /* Start select loop and monitor for requests */
   
  fprintf(stdout, "\nEntering select loop ...\n");
  XPAMainLoop();
  goto done;
 

done:
  XPAFree(xpa1);

  /* Cleanup and exit */
  
  XPACleanup();
  if( save_buf ) xfree(save_buf);
  exit(0);
}
