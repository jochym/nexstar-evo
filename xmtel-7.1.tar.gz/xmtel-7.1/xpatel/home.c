int send_home_cb (void *client_data, void *call_data, char *paramlist,
  char **buf, size_t *len)
{
  char *s = (char *)client_data;
  XPA xpa = (XPA)call_data;
  char tbuf[SZ_LINE];
  
  /* Send the requested data */
  
  if ( homeflag == TRUE )
  {
    snprintf(tbuf, SZ_LINE, "%s", "on \n");
  }
  else
  {
    snprintf(tbuf, SZ_LINE, "%s", "off \n");
  }
 
  if( (xpa->send_mode & XPA_MODE_FILLBUF) )
  {
    send(xpa_datafd(xpa), tbuf, strlen(tbuf), 0);
    *len = 0;
    *buf = NULL;
  }
  /* Return the buffer and let xpa transmit it */
  else
  {
    *len = strlen(tbuf);
    *buf = (char *)xmalloc(*len);
    memcpy(*buf, tbuf, *len);
  }
  
  fflush(stdout);
  fflush(stderr);
  return(0);
}


int receive_home_cb (void *client_data, void *call_data, char *paramlist,
  char *buf, size_t len)
{
  XPA xpa = (XPA)call_data;
  char *s = (char *)client_data;
 

  /* Process paramlist */
  
  if( paramlist && *paramlist )
  {
    if( !strcmp(paramlist, "on") )
    {
      targetra = Map12(LSTNow() - homeha);
      targetdec = homedec
      targetra2 = targetra;
      targetdec2 = targetdec;
      Apparent(&targetra2,&targetdec2,-1);
      homeflag = TRUE;
     }
    else if( !strcmp(paramlist, "off") )
    {
      homeflag = FALSE;
    }
  }
  
  /* Reset save buffer */
  if( save_buf != NULL )
  {
    xfree(save_buf);
    save_buf = NULL;
  }
  save_bytes = len;
  save_buf = (char *)xmalloc(len);
  memcpy(save_buf, buf, len);

  fflush(stdout);
  fflush(stderr);
  return(0);
}
 
