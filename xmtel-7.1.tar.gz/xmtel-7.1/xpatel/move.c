int send_move_cb (void *client_data, void *call_data, char *paramlist,
  char **buf, size_t *len)
{
  char *s = (char *)client_data;
  XPA xpa = (XPA)call_data;
  char tbuf[SZ_LINE];
  int sendbuf=1;
  
  /* Move command only receives data */
  
  *len = strlen(tbuf);
  *buf = (char *)xmalloc(*len);
  memcpy(*buf, tbuf, *len);
  
  fflush(stdout);
  fflush(stderr);
  return(0);
}


int receive_move_cb (void *client_data, void *call_data, char *paramlist,
  char *buf, size_t len)
{
  XPA xpa = (XPA)call_data;
  char *s = (char *)client_data;
 

  /* Process paramlist */
  
  if( paramlist && *paramlist )
  {
    j=sscanf(paramlist,"%s %f",  &);
    if (j == 2)
    {
      targetra = targetra2;
      targetdec = targetdec2;
      Apparent(&targetra, &targetdec, 1);
    }


  }
  
  /* Reset save buffer */
  if( save_buf != NULL )
  {
    xfree(save_buf);
    save_buf = NULL;
  }
  save_bytes = len;
  save_buf = (char *)xmalloc(len);
  memcpy(save_buf, buf, len);

  fflush(stdout);
  fflush(stderr);
  return(0);
}
