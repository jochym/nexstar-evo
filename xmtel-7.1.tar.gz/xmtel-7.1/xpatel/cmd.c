int send_cmd_cb (void *client_data, void *call_data, char *paramlist,
  char **buf, size_t *len)
{
  char *s = (char *)client_data;
  XPA xpa = (XPA)call_data;
  char tbuf[SZ_LINE];
  int sendbuf=0;
  
  /* Callback provides */
  /*   cmd in string s */
  /*   arguments to cmd in string paramlist */

  /* Diagnostic entrance */
  if( !xpa_quiet )
  {
    fprintf(stdout, "tel send_cmd_cb started -- #%d: %s:%s %s (%s)\n",
    n++, xpa_class(xpa), xpa_name(xpa), xpa_method(xpa), s);
  }

  /* Process paramlist */
  
  if( paramlist && *paramlist )
  {
    if( !xpa_quiet )
    {
      fprintf(stdout, "\tparamlist: %s\n", paramlist);
    }
    if( !strcmp(paramlist, "test") )
    {
      fprintf(stdout, "test cmd send\n");
      return(0);
    }
  }

  /* Return information about this xpa */
  if( !sendbuf )
  {
    snprintf(tbuf, SZ_LINE,
       "class: %s\nname: %s\nmethod: %s\nsendian: %s\ncendian: %s\n",
       xpa_class(xpa), xpa_name(xpa), xpa_method(xpa),
       xpa_sendian(xpa), xpa_cendian(xpa));
  
    if( (xpa->send_mode & XPA_MODE_FILLBUF) )
    {
      send(xpa_datafd(xpa), tbuf, strlen(tbuf), 0);
      *len = 0;
      *buf = NULL;
      if( !xpa_quiet)
	fprintf(stdout, "\tcallback writes %d bytes to client\n",
	  (int)strlen(tbuf));
    }
    /* Return the buffer and let xpa transmit it */
    else
    {
      *len = strlen(tbuf);
      *buf = (char *)xmalloc(*len);
      memcpy(*buf, tbuf, *len);
      if( !xpa_quiet)
	fprintf(stdout, "\tcallback returns %d bytes to xpa handler\n",
	  (int)strlen(tbuf));
    }
  }
  /* Return the last buffer we were sent */
  else
  {
    if( (xpa->send_mode & XPA_MODE_FILLBUF) )
    {
      send(xpa_datafd(xpa), save_buf, save_bytes, 0);
      *len = 0;
      *buf = NULL;
      if( !xpa_quiet)
	fprintf(stdout, "\ttel cmd callback writes %lu bytes to client\n", 
	  (unsigned long)save_bytes);
    }
    /* Return the buffer and let xpa transmit it */
    else
    {
      *len = save_bytes;
      *buf = (char *)xmalloc(*len);
      memcpy(*buf, save_buf, *len);
      if( !xpa_quiet)
	fprintf(stdout, "\ttel cmd callback returns %lu bytes to xpa handler\n",
	  (unsigned long)save_bytes);
    }
  }
  
  /* Diagnostic exit */
  
  if( !xpa_quiet )
  {
    fprintf(stdout, "tel send_cmd_cb completed \n");
  }
  else
  {
    fprintf(stdout, ".");
  }
  fflush(stdout);
  fflush(stderr);
  return(0);
}


int receive_cmd_cb (void *client_data, void *call_data, char *paramlist,
  char *buf, size_t len)
{
  XPA xpa = (XPA)call_data;
  char *s = (char *)client_data;
 

  /* Callback provides */
  /*   cmd in string s */
  /*   arguments to cmd in string paramlist */

  /* Diagnostic entrance */
  if( !xpa_quiet )
  {
    fprintf(stdout, "tel receive_cmd_cb started -- #%d: %s:%s %s (%s)\n",
    n++, xpa_class(xpa), xpa_name(xpa), xpa_method(xpa), s);
  }
  
  /* Process paramlist */
  
  if( paramlist && *paramlist )
  {
    if( !xpa_quiet )
    {
      fprintf(stdout, "\tparamlist: %s\n", paramlist);
    }
    if( !strcmp(paramlist, "test") )
    {
      if( !xpa_quiet )
      {
	fprintf(stdout, "test cmd receive\n");
      }
      return(0);
    }
  }
  
  /* Reset save buffer */
  if( save_buf != NULL )
  {
    xfree(save_buf);
    save_buf = NULL;
  }
  save_bytes = 0;
  
  if( !xpa_quiet )
  {
    fprintf(stdout, "\ttel cmd callback with buf: %lu bytes\n", 
      (unsigned long)len);
  }
  save_bytes = len;
  save_buf = (char *)xmalloc(len);
  memcpy(save_buf, buf, len);
  
  /* Diagnostic exit */
  
  if( !xpa_quiet )
  {
    fprintf(stdout, "tel receive_cmd_cb completed\n");
  }
  else
  {
    fprintf(stdout, ".");
  }
  fflush(stdout);
  fflush(stderr);
  return(0);
}
