int send_move_cb (void *client_data, void *call_data, char *paramlist,
  char **buf, size_t *len)
{
  char *s = (char *)client_data;
  XPA xpa = (XPA)call_data;
  char tbuf[SZ_LINE];
  int sendbuf=1;
  
  /* Send the requested data */
  
 
  if( (xpa->send_mode & XPA_MODE_FILLBUF) )
  {
    send(xpa_datafd(xpa), tbuf, strlen(tbuf), 0);
    *len = 0;
    *buf = NULL;
  }
  /* Return the buffer and let xpa transmit it */
  else
  {
    *len = strlen(tbuf);
    *buf = (char *)xmalloc(*len);
    memcpy(*buf, tbuf, *len);
  }
  
  fflush(stdout);
  fflush(stderr);
  return(0);
}


int receive_move_cb (void *client_data, void *call_data, char *paramlist,
  char *buf, size_t len)
{
  XPA xpa = (XPA)call_data;
  char *s = (char *)client_data;
  char *movedir;
  double movestep;
  int j;

  /* Process paramlist */
  
  if( paramlist && *paramlist )
  {
    
    j=sscanf(paramlist,"%s %lf", movedir &movestep);
    
    /* Provides direction name and a step amount */
    /* Movestep is in seconds except for guide mode where it is pixels */
    
    if (j == 2)
    {
      if( !strcmp(movedir, "north") )
      {
        if (guideflag == TRUE)
        {
          ddec =  -1.0*movestep;
          dha = 0.0*movestep;
        }
        else
        {
          teldir=NORTH;
          StartSlew(teldir);
        }
      
      }
      else if ( !strcmp(movedir, "south")
      {
        if (guideflag == TRUE)
        {
          ddec = 1.0*movestep;
          dha = 0.0*movestep;
        }
        else
        {
          teldir=SOUTH;
          StartSlew(teldir);       
        }  
      
      
      }    
      else if ( !strcmp(movedir, "east")
      {
        if (guideflag == TRUE)
        {
          dha = 1.0*movestep;
          ddec = 0.0*movestep;
        }
        else
        {
          teldir=EAST;
          StartSlew(teldir);
        }

      
      }
      else if ( !strcmp(movedir, "west")
      {
        if (guideflag == TRUE)
        {
          dha =  -1.0*movestep;
          ddec = 0.0*movestep;
        }
        else
        {
          teldir=WEST;
          StartSlew(teldir);              
        }
      }
      
      if (guideflag == TRUE)
      {
              
        /* Update dynamic zero point for current guide center */
        
        modelha0 = Map12(LSTNow() - guidera);
        modeldec0 = guidedec;

        /* Change declination units from pixels to degrees */
        
        ddec = arcsecperpix*ddec/3600.;
        
        /* Add the declination correction to the permanent offsetdec in degrees */
        
        offsetdec = Map180(offsetdec + ddec);
       
        /* Change hour angle units from pixels to hours */
        
        dha = arcsecperpix*dha/54000.;

        /* Add the ha correction to the permanent offsetha in hours */

        offsetha = Map12(offsetha + dha);
                     
      }
      else
      {  
      
        /* Run for movestep seconds */
        
        usleep(movestep*1000000.);
        
        StopSlew(teldir);
        
        /* Wait for the telescope to come to rest */
        usleep(250000.*((double) telspd));
        
        /* Start tracking */
        StartTrack();

      }             
    }
  }  
  
  /* Reset save buffer */
  if( save_buf != NULL )
  {
    xfree(save_buf);
    save_buf = NULL;
  }
  save_bytes = len;
  save_buf = (char *)xmalloc(len);
  memcpy(save_buf, buf, len);

  fflush(stdout);
  fflush(stderr);
  return(0);
}
