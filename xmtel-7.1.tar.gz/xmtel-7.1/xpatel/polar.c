int send_polar_cb (void *client_data, void *call_data, char *paramlist,
  char **buf, size_t *len)
{
  char *s = (char *)client_data;
  XPA xpa = (XPA)call_data;
  char tbuf[SZ_LINE];
  
  
  /* Send the requested data */
  
  if (pmodel & POLAR)
  {
    snprintf(tbuf, SZ_LINE, "%s %lf %lf", "on",  polaraz, polaralt);
  }
  else
  {
    snprintf(tbuf, SZ_LINE, "%s %lf %lf", "off", polaraz, polaralt);
  }
   
  if( (xpa->send_mode & XPA_MODE_FILLBUF) )
  {
    send(xpa_datafd(xpa), tbuf, strlen(tbuf), 0);
    *len = 0;
    *buf = NULL;
  }
  /* Return the buffer and let xpa transmit it */
  else
  {
    *len = strlen(tbuf);
    *buf = (char *)xmalloc(*len);
    memcpy(*buf, tbuf, *len);
  }
  
  fflush(stdout);
  fflush(stderr);
  return(0);
}


int receive_polar_cb (void *client_data, void *call_data, char *paramlist,
  char *buf, size_t len)
{
  XPA xpa = (XPA)call_data;
  char *s = (char *)client_data;
  double tmpaz;
  double tmpdalt;
  char tmpcmd[SZ_LINE]; 

  /* Process paramlist */
  
  if( paramlist && *paramlist )
  {
    j=sscanf(paramlist,"%s %lf %lf", tmpcmd, &tmpaz, &tmpalt);
    if ((j == 3) && (tmpcmd == "on"))
    {
      pmodel = (pmodel | POLAR);
      polaraz = tmpaz;
      polaralt = tmpalt;
    }
    else if ((j == 3) && (tmpcmd == "off"))
    {
      pmodel = (pmodel & ~(POLAR));
      polaraz = tmpaz;
      polaralt = tmpalt;
    }
    else if ((j == 1) && (tmpcmd == "on"))
    {
      pmodel = (pmodel | POLAR);
    }
    else if ((j == 1) && (tmpcmd == "off"))
    {
      pmodel = (pmodel & ~(POLAR));      
    }
    else if ((j == 1) && (tmpcmd == "clear"))
    {
      pmodel = (pmodel & ~(POLAR));
      offsetha = 0.;
      offset = 0.;      
    }
           
  }
  
  /* Reset save buffer */
  if( save_buf != NULL )
  {
    xfree(save_buf);
    save_buf = NULL;
  }
  save_bytes = len;
  save_buf = (char *)xmalloc(len);
  memcpy(save_buf, buf, len);

  fflush(stdout);
  fflush(stderr);
  return(0);
}
