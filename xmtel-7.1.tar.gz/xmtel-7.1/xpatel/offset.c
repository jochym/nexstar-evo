int send_offset_cb (void *client_data, void *call_data, char *paramlist,
  char **buf, size_t *len)
{
  char *s = (char *)client_data;
  XPA xpa = (XPA)call_data;
  char tbuf[SZ_LINE];
  
  
  /* Send the requested data */
  
  if (pmodel & OFFSET)
  {
    snprintf(tbuf, SZ_LINE, "%s %lf %lf", "on",  offsetha, offsetdec);
  }
  else
  {
    snprintf(tbuf, SZ_LINE, "%s %lf %lf", "off", offsetha, offsetdec);
  }
   
  if( (xpa->send_mode & XPA_MODE_FILLBUF) )
  {
    send(xpa_datafd(xpa), tbuf, strlen(tbuf), 0);
    *len = 0;
    *buf = NULL;
  }
  /* Return the buffer and let xpa transmit it */
  else
  {
    *len = strlen(tbuf);
    *buf = (char *)xmalloc(*len);
    memcpy(*buf, tbuf, *len);
  }
  
  fflush(stdout);
  fflush(stderr);
  return(0);
}


int receive_offset_cb (void *client_data, void *call_data, char *paramlist,
  char *buf, size_t len)
{
  XPA xpa = (XPA)call_data;
  char *s = (char *)client_data;
  double tmpha;
  double tmpdec;
  char tmpcmd[SZ_LINE]; 

  /* Process paramlist */
  
  if( paramlist && *paramlist )
  {
    j=sscanf(paramlist,"%s %lf %lf", tmpcmd, &tmpha, &tmpdec);
    if ((j == 3) && (tmpcmd == "on"))
    {
      if ( (fabs(tmpha) <= 15.0) && (fabs(tmpdec) <= 1.0) )
      {
        offsetdec = tmpdec;
        offsetha = tmpha;
        pmodel = (pmodel | OFFSET);
      }      
    }
    else if ((j == 3) && (tmpcmd == "off"))
    {
      if ( (fabs(tmpha) <= 15.0) && (fabs(tmpdec) <= 1.0) )
      {
        offsetdec = tmpdec;
        offsetha = tmpha;
        pmodel = (pmodel & ~(OFFSET));
      }      
    }
    else if ((j == 1) && (tmpcmd == "on"))
    {
      pmodel = (pmodel | OFFSET);
    }
    else if ((j == 1) && (tmpcmd == "off"))
    {
      pmodel = (pmodel & ~(OFFSET));      
    }
    else if ((j == 1) && (tmpcmd == "target"))
    {
      tmpdec = targetdec - teldec; 
      tmpha =  Map12(telra - targetra);  
        
      if ( (fabs(tmpha) <= 15.0) && (fabs(tmpdec) <= 1.0) )
      {
        offsetdec = tmpdec;
        offsetha = tmpha;
        pmodel = (pmodel | OFFSET);
      }      
      
    }
    else if ((j == 1) && (tmpcmd == "clear"))
    {
      pmodel = (pmodel & ~(OFFSET));
      offsetha = 0.;
      offset = 0.;      
    }
           
  }
  
  /* Reset save buffer */
  if( save_buf != NULL )
  {
    xfree(save_buf);
    save_buf = NULL;
  }
  save_bytes = len;
  save_buf = (char *)xmalloc(len);
  memcpy(save_buf, buf, len);

  fflush(stdout);
  fflush(stderr);
  return(0);
}
