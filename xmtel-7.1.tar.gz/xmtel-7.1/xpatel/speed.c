int send_speed_cb (void *client_data, void *call_data, char *paramlist,
  char **buf, size_t *len)
{
  char *s = (char *)client_data;
  XPA xpa = (XPA)call_data;
  char tbuf[SZ_LINE];
  int sendbuf=1;
  
  /* Send the requested data */
  
  if ( telspd == SLEW )
  {
    snprintf(tbuf, SZ_LINE, "%s", "slew\n");
  }
  else if ( telspd == FIND )
  {
    snprintf(tbuf, SZ_LINE, "%s", "find\n");
  }
  else if ( telspd == FIND )
  {
    snprintf(tbuf, SZ_LINE, "%s", "center\n");
  }
  else if ( telspd == FIND )
  {
    snprintf(tbuf, SZ_LINE, "%s", "guide\n");
  }
     
  if( (xpa->send_mode & XPA_MODE_FILLBUF) )
  {
    send(xpa_datafd(xpa), tbuf, strlen(tbuf), 0);
    *len = 0;
    *buf = NULL;
  }
  /* Return the buffer and let xpa transmit it */
  else
  {
    *len = strlen(tbuf);
    *buf = (char *)xmalloc(*len);
    memcpy(*buf, tbuf, *len);
  }
  
  fflush(stdout);
  fflush(stderr);
  return(0);
}


int receive_speed_cb (void *client_data, void *call_data, char *paramlist,
  char *buf, size_t len)
{
  XPA xpa = (XPA)call_data;
  char *s = (char *)client_data;
 

  /* Process paramlist */
  
  if( paramlist && *paramlist )
  {
    if( !strcmp(paramlist, "slew") )
    {
      telspd = SLEW;
    }
    else if( !strcmp(paramlist, "find") )
    {
      telspd = FIND;
    }
    else if( !strcmp(paramlist, "center") )
    {
      telspd = CENTER;
    }
    else if( !strcmp(paramlist, "guide") )
    {
      telspd = GUIDE;
    }
  }
  
  /* Reset save buffer */
  if( save_buf != NULL )
  {
    xfree(save_buf);
    save_buf = NULL;
  }
  save_bytes = len;
  save_buf = (char *)xmalloc(len);
  memcpy(save_buf, buf, len);

  fflush(stdout);
  fflush(stderr);
  return(0);
}
