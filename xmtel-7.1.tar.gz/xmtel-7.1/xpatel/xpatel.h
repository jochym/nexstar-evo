/* -------------------------------------------------------------------------- */
/* -                   Astronomical Telescope Control                       - */
/* -                    XmTel XPA Server Header File                        - */
/* -                                                                        - */
/* -------------------------------------------------------------------------- */
/*                                                                            */
/* Copyright (c) 2014 John Kielkopf                                           */
/* kielkopf@louisville.edu                                                    */
/*                                                                            */
/* This file is part of XmTel.                                                */
/*                                                                            */
/* -------------------------------------------------------------------------- */
/*                                                                            */
/* This program is based on stest.c distributed with xpa version 2.1.5        */
/* XPA and stest are                                                          */
/* Copyright (c) 1999-2003 Smithsonian Astrophysical Observatory              */
/*                                                                            */
/* -------------------------------------------------------------------------- */
/*                                                                            */
/*                                                                            */
/*                                                                            */
/* September 16, 2014                                                         */
/*   Version: 1.0                                                             */
/*     From tel.h and xmtel.h in xmtel distribution 6.0                       */
/*                                                                            */
/* -------------------------------------------------------------------------- */
                                                                          


#ifndef FALSE
#define FALSE 0
#endif

#ifndef TRUE
#define TRUE 1
#endif


/* Configuration file */

#define CONFIGFILE "/usr/local/observatory/prefs/prefs.tel"

/* Reserve space for characters in file descriptors */

#define MAXPATHLEN  100

/* Defaults for site */

#define LONGITUDE      85.5300
#define LATITUDE       38.3334
#define ALTITUDE      230.0000
#define TEMPERATURE    20.0
#define PRESSURE      760.0
#define HOMEHA          -5.999
#define HOMEDEC         89.999
#define PARKHA          -5.999
#define PARKDEC         89.999
#define TELSERIAL     "/dev/ttyUSB0"
#define ARCSECPERPIX  0.54


/* Moore Observatory - Louisville, Kentucky USA */

/* #define LONGITUDE      85.5300 */
/* #define LATITUDE       38.3334 */
/* #define ALTITUDE      230.0000 */
/* #define TEMPERATURE    20.0    */
/* #define PRESSURE      760.0    */


/* Mt. Kent Observatgory - Toowoomba, Australia */

/* #define LONGITUDE     -151.855278   */
/* #define LATITUDE      -27.797778    */
/* #define ALTITUDE      682.00        */
/* #define TEMPERATURE    20.0         */
/* #define PRESSURE      760.0         */



