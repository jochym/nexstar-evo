int send_guide_cb (void *client_data, void *call_data, char *paramlist,
  char **buf, size_t *len)
{
  char *s = (char *)client_data;
  XPA xpa = (XPA)call_data;
  char tbuf[SZ_LINE];
  int sendbuf=1;
  
  /* Send the requested data */
  
  if ( guideflag == TRUE )
  {
    snprintf(tbuf, SZ_LINE, "%s", "on\n");
  }
  else
  {
    snprintf(tbuf, SZ_LINE, "%s", "off\n");
  }
 
  if( (xpa->send_mode & XPA_MODE_FILLBUF) )
  {
    send(xpa_datafd(xpa), tbuf, strlen(tbuf), 0);
    *len = 0;
    *buf = NULL;
  }
  /* Return the buffer and let xpa transmit it */
  else
  {
    *len = strlen(tbuf);
    *buf = (char *)xmalloc(*len);
    memcpy(*buf, tbuf, *len);
  }
  
  fflush(stdout);
  fflush(stderr);
  return(0);
}


int receive_guide_cb (void *client_data, void *call_data, char *paramlist,
  char *buf, size_t len)
{
  XPA xpa = (XPA)call_data;
  char *s = (char *)client_data;
 

  /* Process paramlist */
  
  if( paramlist && *paramlist )
  {
    if( !strcmp(paramlist, "on") )
    {
      if (!gotoflag)
      {
        if (!trackflag)
        {
          StartTrack();
          trackflag = TRUE;
        }
        GetTel(&telra, &teldec, pmodel);
        telha = Map12(LSTNow() - telra);     
        guidera = telra;
        guidedec = teldec;
        modelha0 = (LSTNow() - guidera);
        modeldec0 = guidedec;
        guideflag = TRUE;
        return(0);
      }
    }
    else if( !strcmp(paramlist, "off") )
    {
      guideflag = FALSE;
      return(0);
    }
  }
  
  /* Reset save buffer */
  if( save_buf != NULL )
  {
    xfree(save_buf);
    save_buf = NULL;
  }
  save_bytes = len;
  save_buf = (char *)xmalloc(len);
  memcpy(save_buf, buf, len);

  fflush(stdout);
  fflush(stderr);
  return(0);
}
