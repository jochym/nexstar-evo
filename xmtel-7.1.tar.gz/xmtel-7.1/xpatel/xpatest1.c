/* XPA send callback */

 int xpa_send_callback(void *xpa_send_data, void *xpa_call_data,
   char *xpa_paramlist, char **xpa_buf, size_t *xpa_len)
 {
   int xpa_noerror = 0;
   int xpa_error = -1;
   int xpa_state = 0;
   
   XPA xpa = (XPA)xpa_call_data;
   xpa_state = xpa_noerror;
   return(xpa_state);

    
/* XPA receive callback */    
  
 int xpa_rec_callback(void *xpa_rec_data, void *xpa_call_data,
   char *xpa_paramlist, char *xpa_buf, size_t xpa_len)
 {
   int xpa_noerror = 0;
   int xpa_error = -1;
   int xpa_state = 0;
   
   XPA xpa = (XPA)xpa_call_data;
   xpa_state = xpa_noerror;
   return(xpa_state);
 }

