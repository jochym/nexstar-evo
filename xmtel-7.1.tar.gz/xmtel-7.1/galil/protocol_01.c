/* -------------------------------------------------------------------------- */
/* -      Protocol for telescope control with a Galil motion controller     - */
/* -------------------------------------------------------------------------- */
/*                                                                            */
/* Copyright 2009-2014 John Kielkopf                                          */
/*                                                                            */
/* Distributed under the terms of the General Public License (see LICENSE)    */
/*                                                                            */
/* John Kielkopf (kielkopf@louisville.edu)                                    */
/*                                                                            */
/*                                                                            */
/* History:                                                                   */
/*                                                                            */
/* March 30, 2010                                                             */
/*   Version 1.0                                                              */
/*     Based on prior protocols                                               */
/*     Released                                                               */
/*                                                                            */
/*   Version 1.1                                                              */
/*     Revised sync returns                                                   */
/*                                                                            */
/* October 10, 2011                                                           */
/*   Version 2.3                                                              */
/*     Version number changed to match package                                */
/*     Added CenterGuide                                                      */
/*                                                                            */
/* January 29, 2012                                                           */
/*   Version 2.4                                                              */
/*     Updated for current xmtel                                              */
/*                                                                            */
/* March 28, 2014                                                             */
/*   Version 6.1                                                              */
/*     Version numbers now match most recent parent xmtel                     */
/*     Updated for current xmtel                                              */
/*     Modified for external routines for focus, rotate, environment          */
/*     Added tuning parameters to startup                                     */
/*     Restructured to match Planewave protocol                               */
/*     Allows for dual encoders                                               */


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <time.h>
#include <sys/time.h>
#include <sys/types.h>
#include <unistd.h>
#include <sys/stat.h>
#include <sys/ioctl.h>
#include <fcntl.h>
#include <termios.h>
#include <math.h>
#include "protocol.h"
#include "dmclnx.h"

#define NULL_PTR(x) (x *)0

#ifndef TRUE
#define TRUE 1
#endif

#ifndef FALSE
#define FALSE 0
#endif

/* System variables and prototypes */

/* Telescope and mounting commands that may be called externally */

/* Interface control */

void ConnectTel(void);
int  SyncTelEncoders(void);
void DisconnectTel(void);
int  CheckConnectTel(void);

/* Slew and track control */

void SetRate(int newrate);
void StartSlew(int direction);
void StopSlew(int direction);
void StartTrack(void);
void StopTrack(void);
void CenterGuide(double centerra, double centerdec, 
  int raflag, int decflag, int pmodel);
void FullStop(void);
void GetGuideTargets(int *ntarget, int *starget, int *etarget, int *wtarget);

/* Coordinates and time */

void GetTel(double *telra, double *teldec, int pmodel);
int  GoToCoords(double newRA, double newDec, int pmodel);
int  CheckGoTo(double desRA, double desDec, int pmodel);

/* Slew limits */

int  GetSlewStatus(void);
int  SetLimits(int limits);
int  GetLimits(int *limits);

/* Synchronizing */

int  SyncTelToUTC(double newutc);
int  SyncTelToLocation(double newlong, double newlat, double newalt);
int  SyncTelToLST(double newTime);


/* Instrumentation */

void Heater(int heatercmd);
void Fan(int fancmd);
void Focus(int focuscmd, int focusspd);
void Rotate(int rotatecmd, int rotatespd);
void GetFocus(double *telfocus);
void GetRotate(double *telrotate);
void GetTemperature(double *teltemperature);

/* External variables and shared code */

extern double LSTNow(void);
extern double UTNow(void);
extern double Map24(double hour);
extern double Map12(double hour);
extern double Map360(double degree);
extern double Map180(double degree);
extern double SiteLatitude, SiteLongitude;
extern int    telmount;
extern int    homenow;
extern double homeha;            
extern double homedec;           

extern void PointingFromTel (double *telra1, double *teldec1, 
  double telra0, double teldec0, int pmodel);

extern void PointingToTel (double *telra0, double *teldec0, 
  double telra1, double teldec1, int pmodel);
  
extern void EquatorialToHorizontal(double ha, double dec, double *az, double *alt);
extern void HorizontalToEquatorial(double az, double alt, double *ha, double *dec);  


/* Encoder calibration contants */

double mtrazmcal = MOTORAZMCOUNTPERDEG; 
double mtraltcal = MOTORALTCOUNTPERDEG;
double mntazmcal = MOUNTAZMCOUNTPERDEG;
double mntaltcal = MOUNTALTCOUNTPERDEG;


/* Global encoder counts */

int mtrazm = 0;
int mtralt = 0;
int mntazm = 0;
int mntalt = 0;


/* Global pointing angles derived from the encoder counts */

double mtrazmdeg = 0.;
double mtraltdeg = 0.;
double mntazmdeg = 0.;
double mntaltdeg = 0.;
 

/* Global rates */

int azrate = 0;
int altrate = 0;
int accelrate = 0;
int decelrate = 0;


/* Galil controller flags */

int galillimits = 0;           /* Set to 1 to turn on limits control */
int alttrackon = 0;            /* Set to 1 for altitude tracking by default */
int protocol_quiet = 0;        /* Set to 1 to limit diagnostic reporting */

/* Files */

FILE *fp_focus;
char *focusfile;

FILE *fp_temperature;
char *temperaturefile;

FILE *fp_rotate;
char *rotatefile;


/* Communications */

static int TelConnectFlag = FALSE;

/* Galil controller handle*/

HANDLEDMC galilmc = -1;  

/* Galil controller information structure */

CONTROLLERINFO galilinfo;

/* Galil controller return code */

long galilrc = 0;
  
 
/* End of prototype and variable definitions */

 
/* Report on telescope connection status */

int CheckConnectTel(void)
{
  if (TelConnectFlag == TRUE)
  {
    return TRUE;
  }
  else
  {
    return FALSE;
  }
}


/* Connect to the Galil ethernet interface */
/* Return without action if TelConnectFlag is TRUE */
/* Set TelConnectFlag TRUE on success */
/* Does not start tracking */

void ConnectTel(void)
{
  
  char sendstr[32] = "";
  char returnstr[32] = "";
  char galilipaddr[32];
  int limits, flag;
  int kd, kp, ki;
  int er, oe, tk, tl;
  double telra0, teldec0;
    
  if(TelConnectFlag != FALSE)
  {
    return;
  }
  
  strcpy (galilipaddr,GALILIP);
  
  /* Make the connection */

  memset(&galilinfo, '\0', sizeof(galilinfo));

  galilinfo.cbSize = sizeof(galilinfo);
  galilinfo.usModelID = MODEL_2100;
  galilinfo.fControllerType = ControllerTypeEthernet;
  galilinfo.ulTimeout = 1000;
  galilinfo.ulDelay = 5;
  strcpy(galilinfo.hardwareinfo.socketinfo.szIPAddress, galilipaddr);
  galilinfo.hardwareinfo.socketinfo.fProtocol = EthernetProtocolTCP;
 
  DMCInitLibrary();
  
  galilrc = DMCOpen(&galilinfo, &galilmc);
  if (galilrc)
  {
    fprintf(stderr,
      "The telescope controller at %s is not available ... \n", galilipaddr);
    return;
  }
  
  /* Get the model and serial number */
  
  strcpy(sendstr,"\x12\x16");
  galilrc = DMCCommand(galilmc, sendstr, returnstr, sizeof(returnstr));
  if (galilrc)
  {
    fprintf(stderr,"Telescope control is not responding #1 ...\n");
    return;
  }   
  fprintf(stderr,"Galil model number %s\n", returnstr);      
  
  strcpy(sendstr,"MG _BN");
  galilrc = DMCCommand(galilmc, sendstr, returnstr, sizeof(returnstr));
  if (galilrc)
  {
    fprintf(stderr,"Telescope control is not responding #2 ...\n");
    return;
  }

  fprintf(stderr,"Controller serial number %s\n", returnstr);      
   
  /* Set motor controller parameters */
  
  kd = GALILKD;
  kp = GALILKP;
  ki = GALILKI;
  er = GALILER;
  oe = GALILOE;
  tk = GALILTK;
  tl = GALILTL;
  
  sprintf(sendstr,"KD %d,%d", kd, kd);
  galilrc = DMCCommand(galilmc, sendstr, returnstr, sizeof(returnstr));
  if (galilrc)
  {
    fprintf(stderr,"Telescope control is not responding #3a ...\n");
    return;
  }
  sprintf(sendstr,"KP %d,%d", kp, kp);
  galilrc = DMCCommand(galilmc, sendstr, returnstr, sizeof(returnstr));
  if (galilrc)
  {
    fprintf(stderr,"Telescope control is not responding #3b ...\n");
    return;
  }  
  sprintf(sendstr,"KI %d,%d", ki, ki);
  galilrc = DMCCommand(galilmc, sendstr, returnstr, sizeof(returnstr));
  if (galilrc)
  {
    fprintf(stderr,"Telescope control is not responding #3d ...\n");
    return;
  }    
  sprintf(sendstr,"ER %d,%d", er, er);
  galilrc = DMCCommand(galilmc, sendstr, returnstr, sizeof(returnstr));
  if (galilrc)
  {
    fprintf(stderr,"Telescope control is not responding #3e ...\n");
    return;
  }    
  sprintf(sendstr,"OE %d,%d", oe, oe);
  galilrc = DMCCommand(galilmc, sendstr, returnstr, sizeof(returnstr));
  if (galilrc)
  {
    fprintf(stderr,"Telescope control is not responding #3f ...\n");
    return;
  }    
  sprintf(sendstr,"TK %d,%d", tk, tk);
  galilrc = DMCCommand(galilmc, sendstr, returnstr, sizeof(returnstr));
  if (galilrc)
  {
    fprintf(stderr,"Telescope control is not responding #3g ...\n");
    return;
  }    
  sprintf(sendstr,"TL %d,%d", tl, tl);
  galilrc = DMCCommand(galilmc, sendstr, returnstr, sizeof(returnstr));
  if (galilrc)
  {
    fprintf(stderr,"Telescope control is not responding #3h ...\n");
    return;
  }    

  fprintf(stderr,"Telescope motion controller initiated ...\n");
  
 
  /* Read and initialize limits management */
  
  flag = GetLimits(&limits);
  usleep(500000);

  /* Set mount type and home coordinates */
    
  if (telmount == GEM)
  {
    if (SiteLatitude < 0.)
    {
      homedec = -89.9999;
      homeha = 6.;
    }
    else
    {  
      homedec = 89.9999;
      homeha = -6.;
    }
    
    /* Tracking in declination turned off */    
    alttrackon = 0;
  }
  else if (telmount == EQFORK)
  {
    if (SiteLatitude < 0.)
    {
      homedec = 0.;
      homeha = 0.;
    }
    else
    {  
      homedec = 0.;
      homeha = 0.;
    }
    
    /* Tracking in declination turned off */
    alttrackon = 0;
  }
  else if (telmount == ALTAZ)
  {
    /* Set azimuth */
    homeha = 0.;    
    
    /* Set altitude */
    homedec = 0.; 
    
    /* Turn on tracking in altitude */
    alttrackon = 1.;
  }
  else
  {
    fprintf(stderr,"Telescope mounting must be GEM, EQFORK, or ALTAZ\n");
    return;
  }
  
  
  fprintf(stderr, "Synchronizing encoders ... \n");
  
  flag = SyncTelEncoders();
  if (flag != TRUE)
  {
    fprintf(stderr,"Initial encoder synchronization request failed \n");
    return;
  }
  
  /* Read encoders and confirm pointing */
  
  GetTel(&telra0, &teldec0, RAW);
   
  fprintf(stderr, "Local latitude: %lf\n", SiteLatitude);
  fprintf(stderr, "Local longitude: %lf\n", SiteLongitude);
  fprintf(stderr, "Local sidereal time: %lf\n", LSTNow()); 
  fprintf(stderr, "Mount type: %d\n", telmount);
  fprintf(stderr, "Mount now reading RA: %lf\n", telra0);
  fprintf(stderr, "Mount now reading Dec: %lf\n\n", teldec0);
  
  fprintf(stderr, "The telescope is ready ... \n\n");

  TelConnectFlag = TRUE;  
}

/* Assign and save slew and acceleration for use in StartSlew */
/* Galil rates are given in counts/sec and are saved in global variables */

void SetRate(int newrate)
{
  
  /* Default slewing at one degree per second */
  /* Note slew rates carry sign */
  /* Default acceleration is one degree per second */
  /* Acceleration and deceleration are always positive */
      
  altrate = (int) mtraltcal;
  azrate = (int) mtrazmcal;
  accelrate = abs(azrate);
  decelrate = abs(azrate);
    
  if(newrate == SLEW) 
  {
    altrate = 2*altrate;
    azrate = 2*azrate;
  }
  else if(newrate == FIND) 
  {
    altrate = altrate/2;
    azrate = azrate/2;
  }
  else if(newrate == CENTER) 
  {
    altrate = altrate/8;
    azrate = azrate/8;
  }
  else if(newrate == GUIDE) 
  {
    altrate = altrate/64;
    azrate = azrate/64;
  }

}
 

/* Start a slew in chosen direction at altrate or azrate */

void StartSlew(int direction)
{
  char sendstr[32];
  char returnstr[32];
  
  int nsign, ssign, esign,  wsign;
  int mtrntarget, mtrstarget, mtretarget, mtrwtarget;
  
  /* Define directions dynamically */
    
  GetGuideTargets(&mtrntarget, &mtrstarget, &mtretarget, &mtrwtarget);

  /* Direction signs for positive (n-s) and (w-e) targets */
  
  nsign = 1;
  ssign = -1;
  wsign = -1;
  esign = 1;
  
  /* Change signs if directions are different */
  
  if ( (mtrntarget - mtrstarget)< 0)
  {
    nsign = -1;
    ssign = 1;
  }
  if ( (mtrwtarget - mtretarget) < 0)
  {
    wsign = 1;
    esign = -1;
  }  

  /* Set the acceleration and deceleration */
  
  sprintf(sendstr,"AC %d,%d", accelrate, decelrate);
  
  galilrc = DMCCommand(galilmc, sendstr, returnstr, sizeof(returnstr));
  if (galilrc)
  {
    fprintf(stderr,"Telescope control is not responding #4 ...\n");
    return;
  }

  /* Use  the jog command for the chosen direction and rate */
  /* Alternatively use to goto command to spawn control to separate thread */
  /* Start the motion in that direction */

  if(direction == NORTH)
  {
        
    sprintf(sendstr,"JGB=%d", nsign*altrate); 
    galilrc = DMCCommand(galilmc, sendstr, returnstr, sizeof(returnstr));
    if (galilrc)
    {
      fprintf(stderr,"Telescope control is not responding #5 ...\n");
      return;
    }
    sprintf(sendstr,"BGB"); 
    galilrc = DMCCommand(galilmc, sendstr, returnstr, sizeof(returnstr));
    if (galilrc)
    {
      fprintf(stderr,"Telescope control is not responding #6 ...\n");
      return;
    }  
  
  }
  else if(direction == SOUTH)
  {
    sprintf(sendstr,"JGB=%d", ssign*altrate); 
    galilrc = DMCCommand(galilmc, sendstr, returnstr, sizeof(returnstr));
    if (galilrc)
    {
      fprintf(stderr,"Telescope control is not responding #7 ...\n");
      return;
    }
    sprintf(sendstr,"BGB"); 
    galilrc = DMCCommand(galilmc, sendstr, returnstr, sizeof(returnstr));
    if (galilrc)
    {
      fprintf(stderr,"Telescope control is not responding #8 ...\n");
      return;
    }

  }
  else if(direction == EAST)
  {
    sprintf(sendstr,"JGA=%d", esign*azrate); 
    galilrc = DMCCommand(galilmc, sendstr, returnstr, sizeof(returnstr));
    if (galilrc)
    {
      fprintf(stderr,"Telescope control is not responding #9 ...\n");
      return;
    }
    sprintf(sendstr,"BGA"); 
    galilrc = DMCCommand(galilmc, sendstr, returnstr, sizeof(returnstr));
    if (galilrc)
    {
      fprintf(stderr,"Telescope control is not responding #10 ...\n");
      return;
    }
  }
  else if(direction == WEST)
  {
    sprintf(sendstr,"JGA=%d", wsign*azrate); 
    galilrc = DMCCommand(galilmc, sendstr, returnstr, sizeof(returnstr));
    if (galilrc)
    {
      fprintf(stderr,"Telescope control is not responding #11 ...\n");
      return;
    }
    sprintf(sendstr,"BGA"); 
    galilrc = DMCCommand(galilmc, sendstr, returnstr, sizeof(returnstr));
    if (galilrc)
    {
      fprintf(stderr,"Telescope control is not responding #12 ...\n");
      return;
    }
  }
}


/* Stop the slew in chosen direction */

void StopSlew(int direction)
{
  char sendstr[32];
  char returnstr[32];
    
  if(direction == NORTH)
  {
    sprintf(sendstr,"ST B");
  }
  else if(direction == SOUTH)
  {
    sprintf(sendstr,"ST B");
  }
  else if(direction == EAST)
  {
    sprintf(sendstr,"ST A");
  }
  else if(direction == WEST)
  {
    sprintf(sendstr,"ST A");
  }
  galilrc = DMCCommand(galilmc, sendstr, returnstr, sizeof(returnstr));
  if (galilrc)
  {
    fprintf(stderr,"Telescope control is not responding #13 ...\n");
    return;
  }  

}

/* Close the connection to the telescope controller */

void DisconnectTel(void)
{
  if(TelConnectFlag == TRUE)
  {
    galilrc = DMCClose(galilmc);
    if (galilrc)
    {
      fprintf(stderr,"Telescope control is not responding #14 ...\n");
      return;
    } 
  }
  TelConnectFlag = FALSE;
}



/* Synchronize the  encoder systems */
/* Assumes precision mount encoder and settable motor encoder  */
/* Returns 1 if synchronization is within 15 counts in both axes */

int SyncTelEncoders(void)
{

  char sendstr[32];
  char returnstr[32];
    
  double nowra0, nowdec0;
  int mtrazmnew, mtraltnew;
      
  /* Zero points:                                                */
  /*   Alt-Az -- horizon north                                   */
  /*   Fork equatorial -- equator meridian                       */
  /*   German equatorial -- over the mount at the pole           */
  
  /* Signs:                                                      */
  /*   Dec or Alt -- increase from equator to pole and beyond    */ 
  /*     GEM dec sign is for west of pier looking east           */ 
  /*     GEM dec sign reverses when east of pier looking west    */
  /*   HA or Az   -- increase from east to west                  */

  /* Get the current pointing                                    */
  /* This sets the global mntazm and mntalt counters             */
    
  GetTel(&nowra0, &nowdec0, RAW);
  
  /* Assign the motor counts to match the mount counts           */
    
  mtrazmnew = ((double) mntazm) * mtrazmcal / mntazmcal;
  mtraltnew = ((double) mntalt) * mtraltcal / mntaltcal;
      
  /* Define controller position to be these counts */
  
  sprintf(sendstr,"DP %d,%d",mtrazmnew,mtraltnew);
  galilrc = DMCCommand(galilmc, sendstr, returnstr, sizeof(returnstr));
  if (galilrc)
  {
    fprintf(stderr,"Telescope control is not responding #15 ...\n");
    return(0);
  }
  fprintf(stderr,"Telescope motor encoders reset to \n");
  fprintf(stderr,"  Azimuth count:   %d\n", mtrazmnew);
  fprintf(stderr,"  Altitude count:  %d\n", mtraltnew); 
  
  /* Query the controller to update the counters  */
  
  GetTel(&nowra0, &nowdec0, RAW); 
  
  if ( (abs(mtrazm - mtrazmnew) > 15) || (abs(mtralt - mtraltnew) > 15) )
  {

    fprintf(stderr,"Telescope motor encoders outside tolerance \n");
    return(0);
  }

  return(1);
}


/* Read the motor and mount encoders                                  */
/* Global telmount which should be GEM for A200HR                     */
/* Save encoder counters in global variables                          */
/* Convert the counters to ha and dec                                 */
/* Use an NTP synchronized clock to find lst and ra                   */
/* Correct for the pointing model to find the true direction vector   */
/* Report the ra and dec at which the telescope is pointed            */


void GetTel(double *telra, double *teldec, int pmodel)
{  
   
  char sendstr[32];
  char returnstr[32];

  /* Celestial coordinates derived from the pointing angles */

  double telha0 = 0.;
  double teldec0 = 0.;
  double telra0 = 0.;
  double telra1 = 0.;
  double teldec1 = 0.;

  /* Query controller to tell us the x or azimuth position */

  strcpy(sendstr,"TPX");
  galilrc = DMCCommand(galilmc, sendstr, returnstr, sizeof(returnstr));
  if (galilrc)
  {
    fprintf(stderr,"Telescope control is not responding #16 ...\n");
    return;
  }
  mtrazm = atoi(returnstr);
  
  /* Query controller to tell us the y or altitude position */
  
  strcpy(sendstr,"TPY");
  galilrc = DMCCommand(galilmc, sendstr, returnstr, sizeof(returnstr));
  if (galilrc)
  {
    fprintf(stderr,"Telescope control is not responding #17 ...\n");
    return;
  }
  mtralt = atoi(returnstr); 

  /* Mount encoder reading would go here in a dual encoder system */
  
  mntazm = mtrazm;
  mntalt = mtralt; 
  
  /* Convert counts to degrees for all encoders */
  /* Scaling values of countperdeg are signed               */
  /* Pointing angles now meet the software sign convention  */
  
  mtrazmdeg = ( (double) mtrazm ) / mtrazmcal;
  mtraltdeg = ( (double) mtralt ) / mtraltcal;
  mntazmdeg = ( (double) mntazm ) / mntazmcal;
  mntaltdeg = ( (double) mntalt ) / mntaltcal;
  
  /* Transform mount pointing angles to ha, ra and dec             */
  /* Assume sign convention and zero point for various mount types */
  
  if (telmount == GEM)
  {
    if ( mntazmdeg == 0. ) 
    {
      if ( mntaltdeg < 0.)
      {
        telha0 = -6.;
        teldec0 = 90. + mntaltdeg;
      }
      else
      {
        telha0 = +6.;
        teldec0 = 90. - mntaltdeg;
      }
    }
    else if ( mntazmdeg == -90. )
    {
      if ( mntaltdeg < 0.)
      {
        telha0 = 0.;
        teldec0 = 90. + mntaltdeg;
      }
      else
      {
        telha0 = -12.;
        teldec0 = 90. - mntaltdeg;
      }    
    }
    else if ( mntazmdeg == 90. )
    {
      if ( mntaltdeg > 0.)
      {
        telha0 = 0.;
        teldec0 = 90. - mntaltdeg;
      }
      else
      {
        telha0 = -12.;
        teldec0 = 90. + mntaltdeg;
      }    
    }   
    else if ((mntazmdeg > -180. ) && (mntazmdeg < -90.))
    {
      teldec0 = 90. - mntaltdeg;
      telha0 = Map12(6. + mntazmdeg/15.);  
    }
    else if ((mntazmdeg > -90. ) && (mntazmdeg < 0.))
    {
      teldec0 = 90. - mntaltdeg;
      telha0 = Map12(6. + mntazmdeg/15.);  
    }    
    else if ((mntazmdeg > 0. ) && (mntazmdeg < 90.))
    {
      teldec0 = 90. + mntaltdeg;
      telha0 = Map12(-6. + mntazmdeg/15.);  
    }    
    else if ((mntazmdeg > 90. ) && (mntazmdeg < 180.))
    {
      teldec0 = 90. + mntaltdeg;
      telha0 = Map12(-6. + mntazmdeg/15.);  
    }   
    else
    {
      fprintf(stderr,"HA encoder out of range\n");      
      teldec0 = 0.;
      telha0 = 0.;
    }   
    
    /* Flip signs for the southern sky */
    
    if (SiteLatitude < 0.)
    {
      teldec0 = -1.*teldec0;
      telha0 = -1.*telha0;
    }
        
    telra0 = Map24(LSTNow() - telha0);
  }
    
  else if (telmount == EQFORK)
  {
    teldec0 = mntaltdeg;
    telha0 = Map12(mntazmdeg/15.);
    
    /* Flip signs for the southern sky */
    
    if (SiteLatitude < 0.)
    {
      teldec0 = -1.*teldec0;
      telha0 = -1.*telha0;
    }
        
    telra0 = Map24(LSTNow() - telha0);    
  }
  
  else if (telmount == ALTAZ)
  {
    HorizontalToEquatorial(mntazmdeg, mntaltdeg, &telha0, & teldec0);
    telha0 = Map12(telha0);
    telra0 = Map24(LSTNow() - telha0);   
  }

  else
  {
    fprintf(stderr,"Unknown mounting type\n");  
    *telra=0.;
    *teldec=0.;
    return;
  }
    
  /* Handle special case if not already treated where dec is beyond a pole */
  
  if (teldec0 > 90.)
  {
    teldec0 = 180. - teldec0;
    telra0 = Map24(telra0 + 12.);
  }
  else if (teldec0 < -90.)
  {
    teldec0 = -180. - teldec0;
    telra0 = Map24(telra0 + 12.);
  }
    
  /* Apply pointing model to the coordinates that are reported by the telescope */
  
  PointingFromTel(&telra1, &teldec1, telra0, teldec0, pmodel);
      
  /* Return corrected values */

  *telra=telra1;
  *teldec=teldec1;

  /* Diagnostics */

  /* fprintf(stderr,"mtraltdeg: %lf  mtrazmdeg: %lf\n", mtraltdeg, mtrazmdeg);  */

  /* fprintf(stderr,"mntaltdeg: %lf mntazmdeg: %lf\n", mntaltdeg, mntazmdeg);   */
      
  return;

}

/* Go to new celestial coordinates                                            */
/* Based on CenterGuide algorithm rather than controller goto function        */
/* Evaluate if target coordinates are valid                                   */
/* Test slew limits in altitude, polar, and hour angles                       */
/* Query if target is above the horizon                                       */
/* Return without action for invalid requests                                 */
/* Interrupt any slew sequence in progress                                    */
/* Check current pointing                                                     */
/* Find encoder readings required to point at target                          */
/* Repeated calls are required                                                */
/* Return 1 if slew in progress                                               */
/* Return 0 if slew is not in progress                                        */

int GoToCoords(double newra, double newdec, int pmodel)
{
  double telha, telra, teldec;
  double newha, newalt, newaz;
  double raerr, decerr;
  double totalslew;
  double tolra, toldec;

  newha = LSTNow() - newra;
  newha = Map12(newha);
  
  /* Convert HA and Dec to Alt and Az */
  /* Test for visibility              */
  
  EquatorialToHorizontal(newha, newdec, &newaz, &newalt);
  
  /* Check altitude limit */
  
  if (newalt < MINTARGETALT)
  {
    FullStop();
    StartTrack();
    fprintf(stderr,"Target is below the telescope horizon\n");
    return(0);
  }
     
  /* Get coordinates now */
  
  GetTel(&telra, &teldec, pmodel);
  
  telha = LSTNow() - telra;
  telha = Map12(telha);
  
  /* Recompute up to date target HA */
  
  newha = LSTNow() - newra;
  newha = Map12(newha);
    
  /* Find pointing errors in seconds of arc for both axes   */

  /* Allow for 24 hour ra wrap */
  
  raerr  = 15.*Map12(telra - newra);
    
  /* Allow for drift during 0.5 second reset to track rate at end of slew */
  /* This may need trimming for the polling or encoder reading times */
  
  raerr = raerr + 7.5/3600.;
  
  /* Inhibit goto in declination near the poles */
  
  if (fabs(teldec) < 89. )
  {
    decerr = (teldec - newdec);
  }
  else
  {
    decerr = 0.;
  }

  /* Re-read slew tolerances in seconds of arc */
  
  tolra = SLEWTOLRA;
  toldec = SLEWTOLDEC;
  
  /* Convert tolerances to degrees for use here */
  
  tolra = tolra/3600.;
  toldec = toldec/3600.;

  /* Within tolerance? */

  if ( ( fabs(raerr) < tolra ) && ( fabs(decerr) < toldec ) )
  {
    
    if (!protocol_quiet)
    {
      fprintf(stderr,"Slew completed with errors %lf %lf\n", raerr, decerr);
    } 
    
    /* Wait for sky to move to telescope */
    
    usleep(500000);
    
    /* Start tracking on target */
    
    FullStop();
    StartTrack();
    
    /* Inhibit user commands while system stabilizes */
    
    usleep(500000);
    
    /* Return flag indicating slew complete */
    
    return(0);
  }  
  
  /* Pointing out of tolerance.  Try again. */

  /* Check GEM mount basis                         */
  /* Change target if there is a meridian crossing */
  
  if ( telmount == GEM )
  {
    if ( telha*newha < 0. )
    {
      if ( newha > 0. )
      {
        newha = +0.1;
        newdec = SiteLatitude;
      }
      else
      {
        newha = -0.1;
        newdec = SiteLatitude;
      }
      fprintf(stderr,"HA: %f (Tel)  %f (Target)\n", telha, newha);
      fprintf(stderr,"Changing mount basis ...\n");
    }  
  }  
    

  /* Calculate a new rates based on errors  */
  /* Current code only allows same rate on both axes */
  /* Pointing errors are telescope position minus target position */
  
  totalslew = sqrt(raerr*raerr + decerr*decerr);
  if (totalslew > 5.)
  {
    SetRate(SLEW);   
  }
  else if (totalslew > 1.)
  {
    SetRate(FIND);    
  }
  else if (totalslew > 0.1)
  {
    SetRate(CENTER);
  }
  else
  {
    SetRate(GUIDE);
  }
  
  if (!protocol_quiet)
  {
    fprintf(stderr,"Slew continuing with errors %lf %lf\n", raerr, decerr);
  } 
 
  /* Slew in dec if needed */
  
  if (fabs(decerr) > toldec )
  {
    if (decerr > 0.)
    {
      StartSlew(SOUTH);
    }
    else
    {
      StartSlew(NORTH);
    }
  }
  else
  {
    /* Insure there are no motions in declination */
    
    FullStop();
  
  }  
  
  /* Always slew in RA because of sidereal drift during goto operation */
  /* Telescope is heading toward where the target will be */
  
  if (raerr > 0.)
  {
    StartSlew(WEST);
  }
  else
  {
    StartSlew(EAST);
  }
 
  /* A slew is in progress */

  fprintf(stderr,"A slew is in progress\n");
      
  return(1);
}

/* Check slew status and continue a slew to target           */
/* Return 0 if underway                                      */
/* Return 1 if done                                          */
/* This is the opposite logic of GoToCoords                  */

int CheckGoTo(double newra, double newdec, int pmodel)
{

  int status;

  status = GoToCoords(newra, newdec, pmodel);

  if (status == 1)
  {
    /* Slew is in progress */
    return(0);
  }
    
  return(1);
  
}  
  




int GetSlewStatus(void)
{
  char sendstr[32];
  char returnstr[32];
  int galilinmotion;

  /* Query azimuth drive first */
  
  sprintf(sendstr,"MG_BGX");
  galilrc = DMCCommand(galilmc, sendstr, returnstr, sizeof(returnstr));
  if (galilrc)
  {
    fprintf(stderr,"Telescope control is not responding #19 ...\n");
    return(0);
  }  
  
  galilinmotion = atoi(returnstr);
      
  if ( galilinmotion ) 
  {
     return(1);
  }
  
  /* Query altitude drive if azimuth drive is not slewing */
  
  sprintf(sendstr,"MG_BGY");
  galilrc = DMCCommand(galilmc, sendstr, returnstr, sizeof(returnstr));
  if (galilrc)
  {
    fprintf(stderr,"Telescope control is not responding #20 ...\n");
    return(0);
  } 
  
  galilinmotion = atoi(returnstr);

  if ( galilinmotion ) 
  {
     return(1);
  }

 return(0);
}


/* Coordinates and time */

/* Start sidereal tracking */

void StartTrack(void)
{
  
  char sendstr[32];
  char returnstr[32];
  
  double azsiderealrate; 
  double altsiderealrate;
    
  int trackazrate;
  int trackaltrate;
  int trackaccelrate;
  int trackdecelrate;
  
  /* Note that mtrazmcal is a double and may be signed */
  /* We allow for a different acceleration here than used for slewing */
  
  trackaccelrate = fabs(mtrazmcal);
  trackdecelrate = fabs(mtrazmcal);

  /* Set the acceleration and deceleration */
  
  sprintf(sendstr,"AC %d,%d", trackaccelrate, trackdecelrate);
  
  galilrc = DMCCommand(galilmc, sendstr, returnstr, sizeof(returnstr));
  if (galilrc)
  {
    fprintf(stderr,"Telescope control is not responding #21 ...\n");
    return;
  }  
  
  /* Set global floating point sidereal rates in counts/second */
  
  azsiderealrate = 1.00273879*15.*mtrazmcal/3600.; 
  altsiderealrate = 1.00273879*15.*mtraltcal/3600.;
  

  /* Test for southern hemisphere */
  /* Swap sign of drive rate if we're south of the equator */

  /* Note that for a system with 12000 quadrature counts per degree */
  /* the rate will be 1.00273879*50. counts per second */
  /* Solar rate will be exactly 50 cps */
  
  if ( SiteLatitude < 0. )
  {
    azsiderealrate = -1.*azsiderealrate;
  }
  
  if (telmount == GEM || telmount == EQFORK)
  {
    /* Applies only if not tracking in declination */
    
    trackazrate  = (int) azsiderealrate;
    trackaltrate = 0;
  }
  else if (telmount == ALTAZ)  
  {
     /* This code is incomplete and a placeholder */
     
     trackazrate  = (int) azsiderealrate;
     trackaltrate = (int) altsiderealrate;
  }
  else
  {
    trackazrate  = 0;
    trackaltrate = 0;
  }
  
  sprintf(sendstr,"JGA=%d", trackazrate); 
  galilrc = DMCCommand(galilmc, sendstr, returnstr, sizeof(returnstr));
  if (galilrc)
  {
    fprintf(stderr,"Telescope control is not responding #22 ...\n");
    return;
  }
  
  sprintf(sendstr,"BGA"); 
  galilrc = DMCCommand(galilmc, sendstr, returnstr, sizeof(returnstr));
  if (galilrc)
  {
    fprintf(stderr,"Telescope control is not responding #23 ...\n");
    return;
  }

  /* The following code section applies only if tracking in declination */
  
  if (alttrackon == 1)
  {

    sprintf(sendstr,"JGB=%d", trackaltrate); 
    galilrc = DMCCommand(galilmc, sendstr, returnstr, sizeof(returnstr));
    if (galilrc)
    {
      fprintf(stderr,"Telescope control is not responding #24 ...\n");
      return;
    }

    sprintf(sendstr,"BGB"); 
    galilrc = DMCCommand(galilmc, sendstr, returnstr, sizeof(returnstr));
    if (galilrc)
    {
      fprintf(stderr,"Telescope control is not responding #25 ...\n");
      return;
    }

  }

} 

/* Use high resolution encoder to improve tracking */

void CenterGuide(double centerra, double centerdec, 
  int raflag, int decflag, int pmodel)
{
}


/* Stop tracking motions with controlled deceleration */

void StopTrack(void)
{
  
  char sendstr[32];
  char returnstr[32];
    
  sprintf(sendstr,"ST A");

  galilrc = DMCCommand(galilmc, sendstr, returnstr, sizeof(returnstr));
  if (galilrc)
  {
    fprintf(stderr,"Telescope control is not responding #26 ...\n");
    return;
  }  

  if (alttrackon == 1)
  {
    sprintf(sendstr,"ST B");

    galilrc = DMCCommand(galilmc, sendstr, returnstr, sizeof(returnstr));
    if (galilrc)
    {
      fprintf(stderr,"Telescope control is not responding #26 ...\n");
      return;
    }
  }  

}


/* Get guide targets in motor encoder counts for different pointings */ 
/* Returns targets with correct sense on the sky for N, S, E, and W  */
/* With a GEM it follows pier side swap based on HA encoder reading  */

void GetGuideTargets(int *ntarget, int *starget, int *etarget, int *wtarget)
{
  double latitude, colatitude;
  int ntarget1, starget1, etarget1, wtarget1;
  
  latitude = fabs(SiteLatitude);
  colatitude = 90. - latitude;
  
  /* Depends on global mtrazmdeg and mtraltdeg set in GetTel            */
  /* First set limits for northern hemisphere                           */
  /* Then change assignments for southern hemisphere if needed          */
  
  /* Sign convention for mnt and  mtr degrees is:                       */
  /*   altdeg = 0 at the pole                                           */
  /*   azmdeg = 0 over the top of the GEM                               */
  /*   altdeg <0 going south from the pole for OTA west looking east    */
  /*   azmdeg <0 for rotation toward the east from above the GEM        */
  
  /* Parameters are set based on signed mtrazmcal and mtraltcal         */

  
  if (telmount == GEM)
  {
    /* Handle limits for different sides of the pier */
        
    if (mntazmdeg >= 0.)
    {
      /* Telescope west of pier pointed east  */
            
      wtarget1 = 100.*mtrazmcal;
      etarget1 = -10.*mtrazmcal;
      
      if (mntaltdeg <= 0.)
      {
        /* Telescope pointed between pole and south horizon */
                
        ntarget1 = 10.*mtraltcal;
        starget1 = -1.*(90. + colatitude)*mtraltcal;
      }
      else
      {
        /* Telescope pointed beyond the pole */
                
        ntarget1 = -1.*(90. + colatitude)*mtraltcal;
        starget1 = latitude*mtraltcal;
      }  
    }
    else
    {
      /* Telescope east of pier pointed west */
                  
      wtarget1 = 10.*mtrazmcal;
      etarget1 = -100.*mtrazmcal;
      
      if (mntaltdeg > 0.)
      {
        /* Telescope pointed between pole and south horizon */
        
        ntarget1 = -10.*mtraltcal;
        starget1 = (90. + colatitude)*mtraltcal;
      }
      else
      {
        /* Telescope pointed beyond the pole */
        
        ntarget1 = (90. + colatitude)*mtraltcal;
        starget1 = -1.*latitude*mtraltcal;
      } 
    }    
  }
  else if (telmount == EQFORK)
  { 
    /* Should be refined for specific installation */
    /* Here set to allow going  through fork to point under the pole */
         
    ntarget1 = 10.*mtraltcal;
    starget1 = -1.*(90. + colatitude)*mtraltcal;
    etarget1 = -100.*mtrazmcal;  
    wtarget1 = 100.*mtrazmcal;
  }
  else
  {
    /* Should be refined for specific installation */
    /* Here set to allow  going through azimuth 0 */
    
    ntarget1 = 90.*mtraltcal;
    starget1 = -90.*mtraltcal;
    etarget1 = -190.*mtrazmcal;  
    wtarget1 = 190.*mtrazmcal;  
  }

  if (SiteLatitude >= 0.)
  {
    /* Northern hemisphere */
    
    *ntarget = ntarget1;
    *starget = starget1;
    *etarget = etarget1;
    *wtarget = wtarget1;
  }
  else
  {
    /* Southern hemisphere */
    /* Counter directions are reversed */
    
    *ntarget = starget1;
    *starget = ntarget1;
    *etarget = wtarget1;
    *wtarget = etarget1;        
  }


  return;
}


/* Full stop with controlled deceleration for motions on both axes */

void FullStop(void)
{  
  char sendstr[32];
  char returnstr[32];

  sprintf(sendstr,"ST AB");
  galilrc = DMCCommand(galilmc, sendstr, returnstr, sizeof(returnstr));
  if (galilrc)
  {
    fprintf(stderr,"Telescope control is not responding #27 ...\n");
    return;
  } 
 
}


/* Set slew limits control off or on */

int SetLimits(int limits)
{
  
  if ( limits == TRUE )
  {
    fprintf(stderr,"Limits enabled\n");
    galillimits = TRUE; 
  
  }
  else
  {
    limits = FALSE;
    fprintf(stderr,"Limits disabled\n"); 
    galillimits = FALSE;  
  }
       
  return (galillimits);
}


/* Get status of slew limits control */

int GetLimits(int *limits)
{
  
  if ( galillimits == TRUE )
  {
    *limits = TRUE;
  }
  else
  {
    *limits = FALSE;
    galillimits = FALSE;
  }

  return (galillimits);
}
  

/* Set slew rate used by SetRate */

int SetSlewRate(int slewRate)
{
  fprintf(stderr,"Setting a fixed slew rate is not enabled\n");
  return 0;
}


/* Control the dew and drive heaters */

void Heater(int heatercmd)
{
  char cmdstr[256];
  sprintf(cmdstr,"setheater %d 1>/dev/null 2>/dev/null", heatercmd);
  system(cmdstr);   
  return;
}

/* Control the telescope fans */

void Fan(int fancmd)
{
  char cmdstr[256];
  sprintf(cmdstr,"setfan %d 1>/dev/null 2>/dev/null", fancmd);
  system(cmdstr);    
  return;
}


/* Adjust the focus using an external routine */
/* The routine will time out on its own and report through the status file */

void Focus(int focuscmd, int focusspd)
{
  char cmdstr[256];
  sprintf(cmdstr,"setfocus %d %d  1>/dev/null 2>/dev/null", focuscmd, focusspd);
  system(cmdstr);  
  return;
}


/* Report the current focus reading from the status file */

void GetFocus(double *telfocus)
{
  int nread;
  double current_focus;
  char cmdstr[256];
  sprintf(cmdstr,"getfocus 1>/dev/null 2>/dev/null");
  system(cmdstr);  
  
  focusfile = (char*) malloc (MAXPATHLEN);
  strcpy(focusfile,FOCUSFILE);
  fp_focus = fopen(focusfile, "r");
  if (fp_focus == NULL)
  {
    return;
  }
  
  nread = fscanf(fp_focus, "%lg", &current_focus);
  fclose(fp_focus);
  
  if (nread !=0)
  {
    *telfocus = current_focus;
  }
  
  return;  
}


/* Adjust the rotation */

void Rotate(int rotatecmd, int rotatespd)
{
  char cmdstr[256];
  sprintf(cmdstr,"setrotate %d %d  1>/dev/null 2>/dev/null", rotatecmd, rotatespd);
  system(cmdstr);
}

/* Report the rotation setting */

void GetRotate(double *telrotate)
{
  int nread;
  double current_rotate;
  char cmdstr[256];
  sprintf(cmdstr,"getrotate 1>/dev/null 2>/dev/null");
  system(cmdstr);  
  
  rotatefile = (char*) malloc (MAXPATHLEN);
  strcpy(rotatefile,ROTATEFILE);
  fp_rotate = fopen(rotatefile, "r");
  if (fp_rotate == NULL)
  {
    *telrotate = 0.;
    return;
  }
  
  nread = fscanf(fp_rotate, "%lg", &current_rotate);
  fclose(fp_rotate);
  
  if (nread !=0)
  {
    *telrotate = current_rotate;
  }
  
  return;  
}

/* Read and report the temperature */

void GetTemperature(double *teltemperature)
{
  int nread;
  double current_temperature = 20.;
  char cmdstr[256];
  sprintf(cmdstr,"gettemperature 1>/dev/null 2>/dev/null");
  system(cmdstr);  
  
  temperaturefile = (char*) malloc (MAXPATHLEN);
  strcpy(temperaturefile,TEMPERATUREFILE);
  fp_temperature = fopen(temperaturefile, "r");
  if (fp_temperature == NULL)
  {
    *teltemperature= 0.;
    return;
  }
  
  nread = fscanf(fp_temperature, "%lg", &current_temperature);
  fclose(fp_temperature);
  
  if (nread !=0)
  {
    *teltemperature = current_temperature;
  }
  

  *teltemperature = current_temperature;
  
  return;   
}
