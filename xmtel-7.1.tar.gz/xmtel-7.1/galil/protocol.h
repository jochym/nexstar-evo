/* -------------------------------------------------------------------------- */
/* -       Header for Galil command set telescope control                   - */
/* -------------------------------------------------------------------------- */
/*                                                                            */
/* Copyright 2009-2014 John Kielkopf                                          */
/* kielkopf@louisville.edu                                                    */
/*                                                                            */
/*                                                                            */
/* Date: June 20, 2014                                                        */
/* Version: 7.0                                                               */


/* Telescope status files mount points should not change on a Linux system */

#define FOCUSFILE "/usr/local/observatory/status/telfocus"
#define TEMPERATUREFILE "/usr/local/observatory/status/teltemperature"
#define ROTATEFILE "/usr/local/observatory/status/telrotate"
#define MAXPATHLEN 100

/* Set the following for your mount and controller */

/* IP address of the Galil controller */

#define GALILIP "192.168.0.70" 

/* Galil motion control servo gains assuming same values on both axes */
/* Note that motor rates are specified in encoder counts */

/* Values for Galil motors on the Wispi mount */

// #define GALILKD 1155 
// #define GALILKP 154
// #define GALILKI 7
// #define GALILER 2000  // Counts error maximum allowed 
// #define GALILOE 1     // Motors off on error
// #define GALILTK 4     // Torque maximum would use 1 for safety
// #define GALILTL 3     // Torque limit 3 volts 



/* Values for the Pittman motors on the modified Paramount */

#define GALILKD 100
#define GALILKP 20
#define GALILKI 1
#define GALILER 2000  // Counts error maximum allowed 
#define GALILOE 1     // Motors off on error
#define GALILTK 4     // Torque maximum would use 1 for safety
#define GALILTL 3     // Torque limit 3 volts 


/* Count scaling defines relationship of telescope pointing to encoder counts */
/* Signs relate sense of shaft rotation to encoder increment */
/* Galil encoder interface generates quadrature counts */
/* Quadrature counts are 4* the intrinsic count of the encoder */
/* Allow for dual encoders on both axes  */
/* By default make them identical */

/* Wispi mount */

/* The Galil motors on our system have 1000 counts per turn              */
/* They are geared to a 360 tooth/turn worm gear with 3:1 reduction      */
/* There are 3000 intrinsic counts per degree or 12000 quadrature counts */

/* #define MOTORALTCOUNTPERDEG  12000.     */    
/* #define MOTORAZMCOUNTPERDEG  -12000.    */
/* #define MOUNTALTCOUNTPERDEG  12000.     */    
/* #define MOUNTAZMCOUNTPERDEG  -12000.    */

/* Modified Paramount */

/* Paramount ME RA  gear:  576 tooth                                  */
/* Paramount ME Dec gear:  375 tooth                                  */

/* The Pittman motors have 1000 and 2000 intrinsic counts per turn    */
/* For N intrinsic counts per degree there are 4N quadrature counts   */
/* Dec is 4000 quadrature counts per turn                             */
/* RA  is 8000 quadrature counts per turn                             */
/* They are geared to a  worm gear with 10:1 reduction                */
/* The worm gears are different on the two axes                       */
/*   RA  is 576 tooth with                                            */
/*   Dec is 375 tooth with                                            */

#define MOTORALTCOUNTPERDEG  41666.666     
#define MOTORAZMCOUNTPERDEG   -128000
#define MOUNTALTCOUNTPERDEG  41666.666     
#define MOUNTAZMCOUNTPERDEG   -128000


/* Notes about Pittman motors on the Paramount */

/* Adequate slow slew rate is 128000 on RA and 64000 on Dec */
/* Use -128000 to slew west in RA */
/* Use -64000  to slew north with OTA on east side of pier in Dec */

       
/* Set this for maximum slew rate in degree/sec */

#define MAXSLEWRATE 4

/* Site parameters are not defined here.  */    

/* The difference between terrestrial and ephemeris time is determined */
/*   by the accumulated number of leapseconds at this moment.   */

/* UTC time correction  */
 
#define LEAPSECONDS    35.0

/* Important constant */

#define PI             3.14159265358


/* The following parameters are used internally to set speed and direction.  */
/* Do not change these values.                                               */

/* Slew motion speeds                                                        */

#define	GUIDE		1
#define	CENTER		2
#define	FIND		4
#define	SLEW		8
 
/* Slew directions                                                           */

#define	NORTH		1
#define	SOUTH		2
#define	EAST		4
#define	WEST		8

/* Focus commands                                                            */
/* Distance from the CCD to the focal plane                                  */
/* Direction is + from the CCD toward the sky                                */
/* Used by Focus(focuscmd, focusspd)                                         */

#define FOCUSSPD4       8   /* Fast    */
#define FOCUSSPD3       4   /* Medium  */
#define FOCUSSPD2       2   /* Slow    */
#define FOCUSSPD1       1   /* Precise */

#define FOCUSCMDOUT     1   /* CCD moves away from sky */
#define FOCUSCMDOFF     0   /* CCD does not move */
#define FOCUSCMDIN     -1   /* CCD moves toward the  sky */


/* Rotator commands                                                          */

#define ROTATESPDFAST       3   /* Fast set */
#define ROTATESPDSLOW       2   /* Slow set */
#define ROTATESPDSIDEREAL   1   /* Sidereal rate */
#define ROTATECMDCW         1   /* Camera rotates CW looking toward the sky */
#define ROTATECMDOFF        0   /* Camera does not rotate */
#define ROTATECMDCCW       -1   /* Camera rotates CCW looking toward the sky */


/* Fan commands                                                              */

#define FANCMDHIGH      2   /* Cooling fan on high speed */
#define FANCMDLOW       1   /* Cooling fan on low speed */
#define FANCMDOFF       0   /* Cooling fan off */


/* Dew heater commands                                                       */

#define HEATERCMDHIGH      2   /* dew heater on high */
#define HEATERCMDLOW       1   /* dew heater on low */
#define HEATERCMDOFF       0   /* dew heater off */


/* Pointing models (bit mapped and additive)                                 */

#define RAW       0      /* Unnmodified but assumed zero corrected */
#define OFFSET    1      /* Correct for target offset*/
#define REFRACT   2      /* Correct for atmospheric refraction */
#define POLAR     4      /* Correct for polar axis misalignment */ 
#define DYNAMIC   8      /* Correct for errors in real time */


/* Display epochs (selected with GUI button)                                 */

#define J2000    0      /* Epoch 2000.0 as entered or precessed without pm */
#define EOD      1      /* Epoch of date with pm if available  (default) */


/* Mounts                                                                    */

#define ALTAZ  0        /* Alt-azimuth mount with at least 2-axis tracking */ 
#define EQFORK 1        /* Equatorial fork */
#define GEM    2        /* German equatorial */


/* Slew tolerances in arcseconds */

#define SLEWTOLRA  60.       /* 60 arcseconds */
#define SLEWTOLDEC 60.       /* 60 arcseconds */


/* Old Galil slew values in degrees intentionally large */

/* SLEWTOLRA  0.006667  or  0.1/15 hour    or 24 seconds of time */
/* SLEWTOLDEC 0.1       or  0.1    degree  or  6 minutes of arc  */


/* Slew software limits  */

#define MINTARGETALT   10.   /* Minimum target altitude in degrees */


