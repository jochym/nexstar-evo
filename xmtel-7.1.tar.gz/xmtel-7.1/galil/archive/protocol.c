/* -------------------------------------------------------------------------- */
/* -      Protocol for telescope control with a Galil motion controller     - */
/* -------------------------------------------------------------------------- */
/*                                                                            */
/* Copyright 2009, 2010, 2011, 2012, 2013, 2014 John Kielkopf                 */
/*                                                                            */
/* Distributed under the terms of the General Public License (see LICENSE)    */
/*                                                                            */
/* John Kielkopf (kielkopf@louisville.edu)                                    */
/*                                                                            */
/*                                                                            */
/* History:                                                                   */
/*                                                                            */
/* March 30, 2010                                                             */
/*   Version 1.0                                                              */
/*     Based on prior protocols                                               */
/*     Released                                                               */
/*                                                                            */
/*   Version 1.1                                                              */
/*     Revised sync returns                                                   */
/*                                                                            */
/* October 10, 2011                                                           */
/*   Version 2.3                                                              */
/*     Version number changed to match package                                */
/*     Added CenterGuide                                                      */
/*                                                                            */
/* January 29, 2012                                                           */
/*   Version 2.4                                                              */
/*     Updated for current xmtel                                              */
/*                                                                            */
/* January 1, 2014                                                            */
/*   Version 6.1                                                              */
/*     Version numbers now match most recent parent xmtel                     */
/*     Updated for current xmtel                                              */
/*     Modified handling of external routines for focus, rotate, environment  */
/*                                                                            */


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <time.h>
#include <sys/time.h>
#include <sys/types.h>
#include <unistd.h>
#include <sys/stat.h>
#include <sys/ioctl.h>
#include <fcntl.h>
#include <termios.h>
#include <math.h>
#include "protocol.h"
#include "dmclnx.h"

#define NULL_PTR(x) (x *)0

#ifndef TRUE
#define TRUE 1
#endif

#ifndef FALSE
#define FALSE 0
#endif

/* System variables and prototypes */

/* Telescope and mounting commands that may be called externally */

/* Interface control */

void ConnectTel(void);
int  SetTelEncoders(double homeha, double homedec);
void DisconnectTel(void);
int  CheckConnectTel(void);

/* Slew and track control */

void SetRate(int newrate);
void StartSlew(int direction);
void StopSlew(int direction);
void StartTrack(void);
void CenterGuide(double centerra, double centerdec, 
  int raflag, int decflag, int pmodel);
void StopTrack(void);
void FullStop(void);

/* Coordinates and time */

void GetTel(double *telra, double *teldec, int pmodel);
int  GoToCoords(double newRA, double newDec, int pmodel);
int  CheckGoTo(double desRA, double desDec, int pmodel);

/* Slew limits */

int  GetSlewStatus(void);
int  SetLimits(int limits);
int  GetLimits(int *limits);


/* Instrumentation */

void Heater(int heatercmd);
void Fan(int fancmd);
void Focus(int focuscmd, int focusspd);
void Rotate(int rotatecmd, int rotatespd);
void GetFocus(double *telfocus);
void GetRotate(double *telrotate);
void GetTemperature(double *teltemperature);

/* External variables and shared code */

extern double LSTNow(void);
extern double UTNow(void);
extern double Map24(double hour);
extern double Map12(double hour);
extern double Map360(double degree);
extern double Map180(double degree);
extern double offsetra, offsetdec;
extern double SiteLatitude, SiteLongitude;
extern int    telmount;
extern int    homenow;
extern double homeha;            /* Home ha */
extern double homera;            /* Home ra derived from ha */
extern double homedec;           /* Home dec */ 

extern void PointingFromTel (double *telra1, double *teldec1, 
  double telra0, double teldec0, int pmodel);

extern void PointingToTel (double *telra0, double *teldec0, 
  double telra1, double teldec1, int pmodel);
  
extern void EquatorialToHorizontal(double ha, double dec, double *az, double *alt);
extern void HorizontalToEquatorial(double az, double alt, double *ha, double *dec);  


/* Local data */

static int azrate;                    /* Rate for slew request in StartSlew */
static int altrate;                   /* Rate for slew request in StartSlew */
static int accelrate;                 /* Acceleration rate */
static int decelrate;                 /* Deceleration rate */
static int slewphase = 0;             /* Slew sequence counter */
static double telencoderalt = 0.;     /* Global encoder angle updated by GetTel */
static double telencoderaz = 0.;      /* Global encoder angle updated by GetTel */
static double switchalt = 0.;         /* Global encoder angle of switch position */
static double switchaz = 0.;          /* Global encoder angle of switch position */

/* Axis calibration  */

static double altcountperdeg = ALTCOUNTPERDEG;
static double azcountperdeg  = AZCOUNTPERDEG;


/* Files */

FILE *fp_focus;
char *focusfile;

FILE *fp_temperature;
char *temperaturefile;

FILE *fp_rotate;
char *rotatefile;


/* Communications */

static int TelConnectFlag = FALSE;

/* Galil controller handle*/

HANDLEDMC galilmc = -1;  

/* Galil controller information structure */

CONTROLLERINFO galilinfo;

/* Galil controller return code */

long galilrc = 0;
  
 
/* End of prototype and variable definitions */

 
/* Report on telescope connection status */

int CheckConnectTel(void)
{
  if (TelConnectFlag == TRUE)
  {
    return TRUE;
  }
  else
  {
    return FALSE;
  }
}


/* Connect to the Galil ethernet interface */
/* Return without action if TelConnectFlag is TRUE */
/* Set TelConnectFlag TRUE on success */

void ConnectTel(void)
{
  
  char sendstr[32] = "";
  char returnstr[32] = "";
  char galilipaddr[32];
  int limits, flag;
  int kd, kp, ki;
    
  if(TelConnectFlag != FALSE)
  {
    return;
  }
  
  strcpy (galilipaddr,GALILIP);
  
  /* Make the connection */

  memset(&galilinfo, '\0', sizeof(galilinfo));

  galilinfo.cbSize = sizeof(galilinfo);
  galilinfo.usModelID = MODEL_2100;
  galilinfo.fControllerType = ControllerTypeEthernet;
  galilinfo.ulTimeout = 1000;
  galilinfo.ulDelay = 5;
  strcpy(galilinfo.hardwareinfo.socketinfo.szIPAddress, galilipaddr);
  galilinfo.hardwareinfo.socketinfo.fProtocol = EthernetProtocolTCP;
 
  DMCInitLibrary();
  
  galilrc = DMCOpen(&galilinfo, &galilmc);
  if (galilrc)
  {
    fprintf(stderr,
      "The telescope controller at %s is not available ... \n", galilipaddr);
    return;
  }
  
  /* Get the model and serial number */
  
  strcpy(sendstr,"\x12\x16");
  galilrc = DMCCommand(galilmc, sendstr, returnstr, sizeof(returnstr));
  if (galilrc)
  {
    fprintf(stderr,"Telescope control is not responding #1 ...\n");
    return;
  }   
  fprintf(stderr,"Galil model number %s\n", returnstr);      
  
  strcpy(sendstr,"MG _BN");
  galilrc = DMCCommand(galilmc, sendstr, returnstr, sizeof(returnstr));
  if (galilrc)
  {
    fprintf(stderr,"Telescope control is not responding #2a ...\n");
    return;
  }

  fprintf(stderr,"Controller serial number %s\n", returnstr);      
   
  /* Set motor gains */
  
  kd = GALILKD;
  kp = GALILKP;
  ki = GALILKI;
  
  sprintf(sendstr,"KD %d,%d", kd, kd);
  galilrc = DMCCommand(galilmc, sendstr, returnstr, sizeof(returnstr));
  if (galilrc)
  {
    fprintf(stderr,"Telescope control is not responding #2b ...\n");
    return;
  }
  sprintf(sendstr,"KP %d,%d", kp, kp);
  galilrc = DMCCommand(galilmc, sendstr, returnstr, sizeof(returnstr));
  if (galilrc)
  {
    fprintf(stderr,"Telescope control is not responding #2c ...\n");
    return;
  }  
  sprintf(sendstr,"KI %d,%d", ki, ki);
  galilrc = DMCCommand(galilmc, sendstr, returnstr, sizeof(returnstr));
  if (galilrc)
  {
    fprintf(stderr,"Telescope control is not responding #2d ...\n");
    return;
  }    

  /* Perform startup tests */

  flag = GetLimits(&limits);
  usleep(500000);
  limits = FALSE;
  flag = SetLimits(limits);
  usleep(500000);  
  flag = GetLimits(&limits);
  
  /* Set global switch angles for a GEM OTA over the pier pointing at pole   */
  /* They correspond to ha ~ -6 hr and dec ~ +90 deg for northern telescope  */
  /* They correspond to ha ~ +6 hr and dec ~ -90 deg for southern telescope  */
      
  switchaz = 1.; 
  switchalt = -1.0;
  
  /* Hardcoded defaults for homeha and homedec are overridden by prefs */
  /* GEM: over the pier pointing at the pole */
  /* EQFORK: pointing at the equator on the meridian */
  /* ALTAZ: level and pointing north */

  if ( homenow != TRUE )
  {
    if (telmount == GEM)
    {
      if (SiteLatitude < 0.)
      {
        homedec = -89.9999;
        homeha = 6.;
      }
      else
      {  
        homedec = 89.9999;
        homeha = -6.;
      }
    }
    else if (telmount == EQFORK)
    {
      if (SiteLatitude < 0.)
      {
        homedec = 0.;
        homeha = 0.;
      }
      else
      {  
        homedec = 0.;
        homeha = 0.;
      }
    }
    else if (telmount == ALTAZ)
    {
      /* Set azimuth */
      homeha = 0.;    
      
      /* Set altitude */
      homedec = 0.; 
    }
    else
    {
      fprintf(stderr,"Telescope mounting must be GEM, EQFORK, or ALTAZ\n");
      return;
    }
  } 
   

  fprintf(stderr, "Using initial HA: %lf\n", homeha);
  fprintf(stderr, "Using initial Dec: %lf\n",homedec); 
  
  flag = SetTelEncoders(homeha, homedec);
  if (flag != TRUE)
  {
    fprintf(stderr,"Initial telescope pointing request was out of range ... \n");
    return;
  }
   
  /* Read encoders and confirm pointing */
  
  GetTel(&homera, &homedec, RAW);
  
  fprintf(stderr, "Local latitude: %lf\n", SiteLatitude);
  fprintf(stderr, "Local longitude: %lf\n", SiteLongitude);
  fprintf(stderr, "Local sidereal time: %lf\n", LSTNow()); 
  fprintf(stderr, "Mount type: %d\n", telmount);
  fprintf(stderr, "Mount now reading RA: %lf\n", homera);
  fprintf(stderr, "Mount now reading Dec: %lf\n", homedec);
  
  fprintf(stderr, "The telescope is running ...\n\n");
  TelConnectFlag = TRUE;  
}

/* Assign and save slew and acceleration for use in StartSlew */
/* Galil rates are given in counts/sec */

void SetRate(int newrate)
{
  
  /* Default slewing at one degree per second */
  /* Note slew rates carry sign */
  /* Default acceleration is one degree per second */
  /* Acceleration and deceleration are always positive */
      
  azrate = (int) azcountperdeg;
  altrate = (int) altcountperdeg;
  accelrate = abs(azrate);
  decelrate = abs(azrate);
    
  if(newrate == SLEW) 
  {
    altrate = 4*altrate;
    azrate = 4*azrate;
  }
  else if(newrate == FIND) 
  {
    altrate = altrate/4;
    azrate = azrate/4;
  }
  else if(newrate == CENTER) 
  {
    altrate = altrate/16;
    azrate = azrate/16;
  }
  else if(newrate == GUIDE) 
  {
    altrate = altrate/64;
    azrate = azrate/64;
  }

}
 

/* Start a slew in chosen direction */

void StartSlew(int direction)
{
  char sendstr[32];
  char returnstr[32];
  
  /* Set the acceleration and deceleration */
  
  sprintf(sendstr,"AC %d,%d", accelrate, decelrate);
  
  galilrc = DMCCommand(galilmc, sendstr, returnstr, sizeof(returnstr));
  if (galilrc)
  {
    fprintf(stderr,"Telescope control is not responding #3 ...\n");
    return;
  }

  /* Set the jog command for the chosen direction and rate */
  /* Start the motion in that direction */

  if(direction == NORTH)
  {
    sprintf(sendstr,"JGB=%d", altrate); 
    galilrc = DMCCommand(galilmc, sendstr, returnstr, sizeof(returnstr));
    if (galilrc)
    {
      fprintf(stderr,"Telescope control is not responding #4 ...\n");
      return;
    }
    sprintf(sendstr,"BGB"); 
    galilrc = DMCCommand(galilmc, sendstr, returnstr, sizeof(returnstr));
    if (galilrc)
    {
      fprintf(stderr,"Telescope control is not responding #5 ...\n");
      return;
    }  
  
  }
  else if(direction == SOUTH)
  {
    sprintf(sendstr,"JGB=%d", -1*altrate); 
    galilrc = DMCCommand(galilmc, sendstr, returnstr, sizeof(returnstr));
    if (galilrc)
    {
      fprintf(stderr,"Telescope control is not responding #6 ...\n");
      return;
    }
    sprintf(sendstr,"BGB"); 
    galilrc = DMCCommand(galilmc, sendstr, returnstr, sizeof(returnstr));
    if (galilrc)
    {
      fprintf(stderr,"Telescope control is not responding #7 ...\n");
      return;
    }

  }
  else if(direction == EAST)
  {
    sprintf(sendstr,"JGA=%d", -1*azrate); 
    galilrc = DMCCommand(galilmc, sendstr, returnstr, sizeof(returnstr));
    if (galilrc)
    {
      fprintf(stderr,"Telescope control is not responding #8 ...\n");
      return;
    }
    sprintf(sendstr,"BGA"); 
    galilrc = DMCCommand(galilmc, sendstr, returnstr, sizeof(returnstr));
    if (galilrc)
    {
      fprintf(stderr,"Telescope control is not responding #9 ...\n");
      return;
    }
  }
  else if(direction == WEST)
  {
    sprintf(sendstr,"JGA=%d", azrate); 
    galilrc = DMCCommand(galilmc, sendstr, returnstr, sizeof(returnstr));
    if (galilrc)
    {
      fprintf(stderr,"Telescope control is not responding #10 ...\n");
      return;
    }
    sprintf(sendstr,"BGA"); 
    galilrc = DMCCommand(galilmc, sendstr, returnstr, sizeof(returnstr));
    if (galilrc)
    {
      fprintf(stderr,"Telescope control is not responding #11 ...\n");
      return;
    }
  }
}


/* Stop the slew in chosen direction */

void StopSlew(int direction)
{
  char sendstr[32];
  char returnstr[32];
    
  if(direction == NORTH)
  {
    sprintf(sendstr,"ST B");
  }
  else if(direction == SOUTH)
  {
    sprintf(sendstr,"ST B");
  }
  else if(direction == EAST)
  {
    sprintf(sendstr,"ST A");
  }
  else if(direction == WEST)
  {
    sprintf(sendstr,"ST A");
  }
  galilrc = DMCCommand(galilmc, sendstr, returnstr, sizeof(returnstr));
  if (galilrc)
  {
    fprintf(stderr,"Telescope control is not responding #12 ...\n");
    return;
  }  

}

/* Close the connection to the telescope controller */

void DisconnectTel(void)
{
  if(TelConnectFlag == TRUE)
  {
    galilrc = DMCClose(galilmc);
    if (galilrc)
    {
      fprintf(stderr,"Telescope control is not responding #13 ...\n");
      return;
    } 
  }
  TelConnectFlag = FALSE;
}


/* Set the encoder count for current ha and dec                           */
/* Requires access to global telmount                                     */
/* Returns +1 (TRUE) if operation is allowed and 0 (FALSE) otherwise      */

int SetTelEncoders(double setha, double setdec)
{

  char sendstr[32];
  char returnstr[32];
    
  /* Count registers */
  
  int azcount;
  int altcount;
    
  /* Temporary variables for altitude and azimuth in degrees */
  
  double altnow, aznow; 
  
  /* Temporary variables for real encoder readings in degrees */
  
  double encoderalt = 0.;
  double encoderaz = 0.;
  
  /* Test ha and dec for valid range */
  
  if ( setha > 6. || setha < -6. )
  {
    fprintf(stderr,"Telescope may be pointed outside valid HA range\n");
    fprintf(stderr,"It cannot be started safely using last known position\n");
    return(0);
  }
  
  if ( setdec > 90. || setdec < -90. )
  {
    fprintf(stderr,"Telescope may be pointed outside valid Dec range\n");
    fprintf(stderr,"It cannot be started safely using last known position\n");
    return(0);
  }
  
  /* Convert HA and Dec to Alt and Az */
  
  EquatorialToHorizontal(setha, setdec, &aznow, &altnow);
  
  if (altnow < 0.)
  {
    fprintf(stderr,"Telescope may be pointed below the horizon\n");
    fprintf(stderr,"It cannot be started safely using last known position\n");
    return(0);
  }
                
  /* Convert coordinates to counts                             */
  /* Zero points:                                              */
  /* Alt-Az -- horizon north                                   */
  /* Fork equatorial -- equator meridian                       */
  /* German equatorial -- over the mount at the pole           */
  /* Sign of encolder scales assumed:                          */
  /* Dec or Alt -- increase from equator to mount pole         */ 
  /* HA or Az   -- increase from east to west                  */
    
  if (telmount == GEM)
  {

    /* Flip signs if sited below the equator */
    
    if (SiteLatitude < 0.)
    {
      setdec = -1.*setdec;
      setha = -1.*setha;
    }
    
    /* Encoder az increases as this resigned ha increases */
    /* Zero point is with telescope over the pier pointed at pole */     
        
    if (setha == 0.)
    { 
      /* OTA looking at meridian */
      /* This is ambiguous unless we know which side of the pier it is on */
      /* Assume telescope was on the west side looking east */
      /*   and was moved to point to the meridian with the OTA west of pier */
      
      fprintf(stderr,"Warning: assuming OTA is west of pier.\n");
      encoderaz = 90.;
      encoderalt = setdec - 90.;
    }
    else if (setha == -6.)
    {
      /* OTA looking east */
      encoderaz = 0.;
      encoderalt = setdec - 90.;
    }
    else if (setha == 6.)
    {
      /* OTA looking west */
      encoderaz = 0.;
      encoderalt = 90. - setdec;
    }    
    else if ((setha > -12.) && ( setha < -6.))
    { 
      /* OTA east of pier looking below the pole */
      encoderaz = setha*15. + 90.;
      encoderalt = setdec - 90.;
    }
    else if ((setha > -6.) && ( setha < 0.))
    { 
      /* OTA west of pier looking east */
      encoderaz = setha*15. + 90.;
      encoderalt = setdec - 90.;
    }
    else if ((setha > 0.) && ( setha <= 6.))
    { 
      /*OTA east of pier looking west */
      encoderaz = setha*15. - 90.;
      encoderalt = 90. - setdec;
    }
    else if ((setha > 6.) && ( setha < 12.))
    { 
      /* OTA west of pier looking below the pole */
      encoderaz = setha*15. - 90.;
      encoderalt = 90. - setdec;
    }    
    else
    {
      fprintf(stderr,"German equatorial outside limits\n");
      return(0);      
    }

    encoderaz = encoderaz*azcountperdeg;
    encoderalt = encoderalt*altcountperdeg;            
  }
  else if (telmount == EQFORK)
  {
    
    /* Flip signs for the southern sky */
    
    if (SiteLatitude < 0.)
    {
      setdec = -1.*setdec;
      setha = -1.*setha;
    }

    if ((setha > -6.) && ( setha < 6.))
    { 
      encoderaz = setha*15.;
      encoderalt = setdec;
      encoderaz = encoderaz*azcountperdeg;
      encoderalt = encoderalt*altcountperdeg;       
    }
    else
    {
      fprintf(stderr,"Equatorial fork outside valid HA range\n");
      return(0);      
    }
  }  
  else if (telmount == ALTAZ)
  {
    encoderaz = aznow*azcountperdeg;
    encoderalt = altnow*altcountperdeg;
  }
  else
  {
    fprintf(stderr,"Unknown mount type\n");
    return(0);
  }   
    
  azcount = encoderaz;
  altcount = encoderalt;
  
  /* Define controller position to be these counts */
  
  sprintf(sendstr,"DP %d,%d",azcount,altcount);
  galilrc = DMCCommand(galilmc, sendstr, returnstr, sizeof(returnstr));
  if (galilrc)
  {
    fprintf(stderr,"Telescope control is not responding #14 ...\n");
    return(0);
  }
  fprintf(stderr,"Telescope encoders reset\n");  
  return(1);
}

/* Read the mount encoders                                            */
/* Requires access to global telmount                                 */
/* Save encoder angle readings in global telencoder variables         */
/* Convert the encoder readings to mounting ha and dec                */
/* Use an NTP synchronized clock to find lst and ra                   */
/* Correct for the pointing model to find the true direction vector   */
/* Report the ra and dec at which the telescope is pointed            */

void GetTel(double *telra, double *teldec, int pmodel)
{  
   
  char sendstr[32];
  char returnstr[32];
  int azcount = 0; 
  int altcount = 0;
  double encoderaz = 0.;
  double encoderalt = 0.;
  double telha0 = 0.;
  double teldec0 = 0.;
  double telra0 = 0.;
  double telra1 = 0.;
  double teldec1 = 0.;

  /* Query controller to tell us the x or azimuth position */

  strcpy(sendstr,"TPX");
  galilrc = DMCCommand(galilmc, sendstr, returnstr, sizeof(returnstr));
  if (galilrc)
  {
    fprintf(stderr,"Telescope control is not responding #15 ...\n");
    return;
  }
  azcount = atoi(returnstr);
  
  /* Query controller to tell us the y or altitude position */
  
  strcpy(sendstr,"TPY");
  galilrc = DMCCommand(galilmc, sendstr, returnstr, sizeof(returnstr));
  if (galilrc)
  {
    fprintf(stderr,"Telescope control is not responding #16 ...\n");
    return;
  }
  altcount = atoi(returnstr); 

  encoderaz = (double) azcount;
  encoderalt = (double) altcount;
  
  /* Convert counts to degrees for both azimuth and altitude encoders */
  
  encoderaz = encoderaz / azcountperdeg;
  encoderalt = encoderalt / altcountperdeg;
  
  /* Transform encoder readings to mount ha, ra and dec */
  /* GEM encoders zero for OTA over pier pointed at pole */
  
  if (telmount == GEM)
  {
    if ( encoderaz == 0. ) 
    {
      if ( encoderalt < 0.)
      {
        telha0 = -6.;
        teldec0 = 90. + encoderalt;
      }
      else
      {
        telha0 = +6.;
        teldec0 = 90. - encoderalt;
      }
    }
    else if ( encoderaz == -90. )
    {
      if ( encoderalt < 0.)
      {
        telha0 = 0.;
        teldec0 = 90. + encoderalt;
      }
      else
      {
        telha0 = -12.;
        teldec0 = 90. - encoderalt;
      }    
    }
    else if ( encoderaz == 90. )
    {
      if ( encoderalt > 0.)
      {
        telha0 = 0.;
        teldec0 = 90. - encoderalt;
      }
      else
      {
        telha0 = -12.;
        teldec0 = 90. + encoderalt;
      }    
    }   
    else if ((encoderaz > -180. ) && (encoderaz < -90.))
    {
      teldec0 = 90. - encoderalt;
      telha0 = Map12(6. + encoderaz/15.);  
    }
    else if ((encoderaz > -90. ) && (encoderaz < 0.))
    {
      teldec0 = 90. - encoderalt;
      telha0 = Map12(6. + encoderaz/15.);  
    }    
    else if ((encoderaz > 0. ) && (encoderaz < 90.))
    {
      teldec0 = 90. + encoderalt;
      telha0 = Map12(-6. + encoderaz/15.);  
    }    
    else if ((encoderaz > 90. ) && (encoderaz < 180.))
    {
      teldec0 = 90. + encoderalt;
      telha0 = Map12(-6. + encoderaz/15.);  
    }   
    else
    {
      fprintf(stderr,"German equatorial ha encoder out of range\n");      
      teldec0 = 0.;
      telha0 = 0.;
    }   
    
    /* Flip signs for the southern sky */
    
    if (SiteLatitude < 0.)
    {
      teldec0 = -1.*teldec0;
      telha0 = -1.*telha0;
    }
        
    telra0 = Map24(LSTNow() - telha0);
  }
    
  else if (telmount == EQFORK)
  {
    teldec0 = encoderalt;
    telha0 = Map12(encoderaz/15.);
    
    /* Flip signs for the southern sky */
    
    if (SiteLatitude < 0.)
    {
      teldec0 = -1.*teldec0;
      telha0 = -1.*telha0;
    }
        
    telra0 = Map24(LSTNow() - telha0);    
  }
  
  else if (telmount == ALTAZ)
  {
    HorizontalToEquatorial(encoderaz, encoderalt, &telha0, & teldec0);
    telha0 = Map12(telha0);
    telra0 = Map24(LSTNow() - telha0);   
  }

  else
  {
    fprintf(stderr,"Unknown mounting type\n");  
    *telra=0.;
    *teldec=0.;
    telencoderaz = 0.;
    telencoderalt = 0.;
    return;
  }
    
  /* Handle special case if not already treated where dec is beyond a pole */
  
  if (teldec0 > 90.)
  {
    teldec0 = 180. - teldec0;
    telra0 = Map24(telra0 + 12.);
  }
  else if (teldec0 < -90.)
  {
    teldec0 = -180. - teldec0;
    telra0 = Map24(telra0 + 12.);
  }
    
  /* Apply pointing model to the coordinates that are reported by the telescope */
  
  PointingFromTel(&telra1, &teldec1, telra0, teldec0, pmodel);
      
  /* Return corrected values */

  *telra=telra1;
  *teldec=teldec1;
  
  /* Update global encoder reading */
  
  telencoderaz =  encoderaz;
  telencoderalt = encoderalt;

  return;

}


/* Go to new celestial coordinates                                    */
/* Evaluate if target coordinates are valid                           */
/* Test slew limits in altitude, polar, and hour angles               */
/* Query if target is above the horizon                               */
/* Return without action for invalid requests                         */
/* Interrupt any slew sequence in progress                            */
/* Check current pointing                                             */
/* Find encoder readings required to point at target                  */
/* Set slewphase equal to number of slew segments needed              */
/* Begin next segment needed to reach target from current pointing    */
/* Repeated calls are required when more than one segment is needed   */
/* Return 1 if underway                                               */
/* Return 0 if done or not permitted                                  */

int GoToCoords(double newra, double newdec, int pmodel)
{
  char sendstr[32];
  char returnstr[32];
  int gotorate;
  int gotoaccelrate;
  int gotodecelrate;
  int azcount;
  int altcount;
  double newha, newalt, newaz;
  double newha0, newalt0, newaz0;
  double newra0, newdec0;
  double newra1, newdec1;
  double nowha0, nowra0, nowdec0;
  double encoderalt = 0.;
  double encoderaz = 0.;
     
  /* Stop all mount motion in preparation for a slew */
  
  FullStop();  

  /* Rate for GoToCoords is based on azimuth scaling */
  /* Note that azcountperdeg is a signed double */
  /* The rate in a go to request should be unsigned */
  
  gotorate = fabs(azcountperdeg);
  gotoaccelrate = gotorate;
  gotodecelrate = gotorate;

  /* Set the acceleration and deceleration */
  
  sprintf(sendstr,"AC %d,%d", gotoaccelrate, gotodecelrate);
  galilrc = DMCCommand(galilmc, sendstr, returnstr, sizeof(returnstr));
  if (galilrc)
  {
    fprintf(stderr,"Telescope did not accept goto acceleration  ...\n");
    return(0);
  }

  /* Select fast slew command if needed */
  /* Note:  set accelerations to avoid inertial load on the gear train */
  
  if( SLEWFAST )
  {
    gotorate = 4.*gotorate;
  }

  /* Set the speeds */
  
  sprintf(sendstr,"SP %d,%d", gotorate, gotorate);
  galilrc = DMCCommand(galilmc, sendstr, returnstr, sizeof(returnstr));
  if (galilrc)
  {
    fprintf(stderr,"Telescope did not accept goto rate ...\n");
    return(0);
  }
        
  newha = LSTNow() - newra;
  newha = Map12(newha);
  
  /* Convert HA and Dec to Alt and Az */
  /* Test for visibility              */
  
  EquatorialToHorizontal(newha, newdec, &newaz, &newalt);
  
  /* Check altitude limit */
  
  if (newalt < MINTARGETALT)
  {
    fprintf(stderr,"Target is below the telescope horizon ...\n");
    slewphase = 0;
    return(0);
  }
  
  /* Target request is valid */
  /* Find the best path to target */
    
  /* Mount coordinates for the target */
  
  newra1 = newra;
  newdec1 = newdec;
  PointingToTel(&newra0,&newdec0,newra1,newdec1,pmodel);  
  newha0 = LSTNow() - newra0;
  newha0 = Map12(newha0);
  EquatorialToHorizontal(newha0, newdec0, &newaz0, &newalt0);
  
  /* Get current mount coordinates */
  
  GetTel(&nowra0, &nowdec0, pmodel);
  nowha0 = LSTNow() - nowra0;
  nowha0 = Map12(nowha0);
          
  /* Prepare encoder counts for a new slew */

  /* German equatorial */

  if (telmount == GEM)
  {
    
    /* Flip signs for the southern sky */
    
    if (SiteLatitude < 0.)
    {
      newdec0 = -1.*newdec0;
      newha0 = -1.*newha0;
    }
    
    if ((newha0 >= -12.) && ( newha0 < -6.))
    { 
      slewphase = 1;
      encoderaz = newha0*15. + 180.;
      encoderalt = newdec0;
    }
    else if ((newha0 >= -6.) && ( newha0 <= 0.))
    { 
      slewphase = 1;
      encoderaz = newha0*15. + 180.;
      encoderalt = newdec0;
    }
    else if ((newha0 > 0.) && ( newha0 <= 6.))
    { 
      slewphase = 1;
      encoderaz = newha0*15.;
      encoderalt = 180. - newdec0;
    }
    else if ((newha0 > 6.) && ( newha0 <= 12.))
    { 
      slewphase = 1;
      encoderaz = newha0*15.;
      encoderalt = 180. - newdec0;
    }    
    else
    {
      fprintf(stderr,"German equatorial slew request error\n");
      return(0);      
    }

    if (newha0 == 0.)
    { 
      /* OTA looking at meridian */
      /* This is ambiguous unless we know which side of the pier it is on */
      /* Assume telescope was on the west side looking east */
      /*   and was moved to point to the meridian with the OTA west of pier */
      slewphase = 1;
      fprintf(stderr,"Warning: assuming OTA is west of pier.\n");
      encoderaz = 90.;
      encoderalt = newdec0 - 90.;
    }
    else if (newha0 == -6.)
    {
      /* OTA looking east */
      slewphase = 1;
      encoderaz = 0.;
      encoderalt = newdec0 - 90.;
    }
    else if (newha0 == 6.)
    {
      /* OTA looking west */
      slewphase = 1;
      encoderaz = 0.;
      encoderalt = 90. - newdec0;
    }    
    else if ((newha0 > -12.) && ( newha0 < -6.))
    { 
      /* OTA east of pier looking below the pole */
      slewphase = 1;
      encoderaz = newha0*15. + 90.;
      encoderalt = newdec0 - 90.;
    }
    else if ((newha0 > -6.) && ( newha0 < 0.))
    { 
      /* OTA west of pier looking east */
      slewphase = 1;
      encoderaz = newha0*15. + 90.;
      encoderalt = newdec0 - 90.;
    }
    else if ((newha0 > 0.) && ( newha0 <= 6.))
    { 
      /*OTA east of pier looking west */
      slewphase = 1;
      encoderaz = newha0*15. - 90.;
      encoderalt = 90. - newdec0;
    }
    else if ((newha0 > 6.) && ( newha0 < 12.))
    { 
      /* OTA west of pier looking below the pole */
      slewphase = 1;
      encoderaz = newha0*15. - 90.;
      encoderalt = 90. - newdec0;
    }    
    else
    {
      fprintf(stderr,"German equatorial slew request outside limits\n");
      return(0);      
    }

    /* Tests for safe slew based on encoder readings would go here */
        
    /* Test need for two-segment slew for changes of more than 90 degrees */
    
    if ((fabs(telencoderalt - encoderalt) > 90.1) || 
      (fabs(telencoderaz - encoderaz) > 90.1))
    {
      
      /* Slew request of more than 90 degrees on one axis */
      
      if ( fabs(telencoderalt) > 10. )
      {
        
        /* Telescope currently more than 10 degrees from the pole in dec */
        /* Set new target to switch position */
        
        encoderalt = switchalt;
        encoderaz = switchaz;
        slewphase = 2;
      }  
    }
            
    encoderalt = encoderalt*altcountperdeg;
    encoderaz = encoderaz*azcountperdeg;     
  }
  
  /* Equatorial fork */
  
  if (telmount == EQFORK)
  {
    slewphase = 1;
    encoderaz = newha0*15.;
    encoderalt = newdec0;

    /* Tests for safe slew based on encoder readings would go here */

    encoderalt = encoderalt*altcountperdeg;
    encoderaz = encoderaz*azcountperdeg;       
  }
  
  /* Alt-az fork */
  
  if (telmount == ALTAZ)
  {
    slewphase = 1;
    encoderaz = newaz0;
    encoderalt = newalt0;

    /* Tests for safe slew based on encoder readings would go here */

    encoderaz = encoderaz*azcountperdeg;
    encoderalt = encoderalt*altcountperdeg;
  }
        
  /* Convert encoder angle readings to encoder counter readings */
  /* Galil controller cleanly uses signed int for encoder reading */
  
  azcount = encoderaz;
  altcount = encoderalt;
  
  /* Send target counts for new RA/Azimuth */
  
  sprintf(sendstr,"PAX=%d",azcount); 
  galilrc = DMCCommand(galilmc, sendstr, returnstr, sizeof(returnstr));
  if (galilrc)
  {
    fprintf(stderr,"Telescope control is not responding #17a ...\n");
    return(0);
  }
  
  /* Send target counts for new Dec/Altitude */

  sprintf(sendstr,"PAY=%d",altcount); 
  galilrc = DMCCommand(galilmc, sendstr, returnstr, sizeof(returnstr));
  if (galilrc)
  {
    fprintf(stderr,"Telescope control is not responding #17b ...\n");
    return(0);
  }  
  
  /* Begin motion on both axes */
  
  sprintf(sendstr,"BGXY"); 
  galilrc = DMCCommand(galilmc, sendstr, returnstr, sizeof(returnstr));
  if (galilrc)
  {
    fprintf(stderr,"Telescope control is not responding #18 ...\n");
    return(0);
  }  
        
  /* A slew is in progress */

  return(1);
}

/* Low level check of slew status on both axes */
/* Advise using CheckGoTo in external applications */
/* Return a flag indicating whether a slew is now in progress */
/*   1 -- slew is in progress on either drive */
/*   0 -- slew not in progress for either drive */

int GetSlewStatus(void)
{
  char sendstr[32];
  char returnstr[32];
  int galilinmotion;

  /* Query azimuth drive first */
  
  sprintf(sendstr,"MG_BGX");
  galilrc = DMCCommand(galilmc, sendstr, returnstr, sizeof(returnstr));
  if (galilrc)
  {
    fprintf(stderr,"Telescope control is not responding #19 ...\n");
    return(0);
  }  
  
  galilinmotion = atoi(returnstr);
      
  if ( galilinmotion ) 
  {
     return(1);
  }
  
  /* Query altitude drive if azimuth drive is not slewing */
  
  sprintf(sendstr,"MG_BGY");
  galilrc = DMCCommand(galilmc, sendstr, returnstr, sizeof(returnstr));
  if (galilrc)
  {
    fprintf(stderr,"Telescope control is not responding #20 ...\n");
    return(0);
  } 
  
  galilinmotion = atoi(returnstr);

  if ( galilinmotion ) 
  {
     return(1);
  }

 return(0);
}


/* Test whether the destination was reached                  */
/* Initiate the next segment if slewphase is greater than 1  */
/* Reset slewphase when goto has finished a segment          */
/* Return value is                                           */
/*   0 -- goto in progress                                   */
/*   1 -- goto complete within tolerance                     */
/*   2 -- goto complete but outside tolerance                */

int CheckGoTo(double desRA, double desDec, int pmodel)
{
  double telra1, teldec1;
  double errorRA, errorDec, nowRA, nowDec;
  double tolra, toldec;

  /* Is the telescope slewing? */
    
  if ( GetSlewStatus() == 1 )
  {
    /* One or more axes remain in motion */
    /* Try again later */
    
    return(0);
  }
  
  /* Was this a two-phase slew? */
  
  if ( slewphase == 2 )
  {
        
    /* Reset the slew phase and continue to the destination */
    
    slewphase = 0;    
    
    /* Go to the original destination */
    /* GoToCoords will change slewphase to 1 */
        
    GoToCoords(desRA, desDec, pmodel);
        
    /* Return a flag indicating a new goto operation is in progress */
    
    return(0);
  }
  else if ( slewphase == 1 )
  {    
      
    /* No axes are moving. Insure that tracking is started again. */
    
    StartTrack();
    
    /* Where are we now? */
  
    GetTel(&nowRA, &nowDec, pmodel);

    /* Compare to destination with pre-defined tolerances */
     
    telra1 = desRA;
    teldec1 = desDec;
        
    /* RA slew tolerance in hours from reference in arcseconds */
    
    tolra = SLEWTOLRA;
    tolra = tolra / (3600. * 15.);
    
    /* Dec slew tolerance in degrees from reference in arcseconds */
    
    toldec = SLEWTOLDEC;
    toldec = toldec / 3600.;

    /* What is the absolute value of the pointing error? */
  
    /* Magnitude of RA pointing error in hours */
    
    errorRA = fabs(nowRA - telra1);
    
    /* Magnitude of Dec pointing error in degrees */
    
    errorDec = fabs(nowDec - teldec1);
  
    /* Compare and notify whether we are within tolerance */

    if( ( errorRA > tolra ) || ( errorDec > toldec ) )
    {
      /* Result of slew is outside acceptable tolerance */
      /* Signal the calling routine that another goto may be needed */
    
      slewphase = 0;
      return(2);
    }
  }    
  else
  {
    /* Unexpected slew phase */
    /* Reset and return success without a test */
    /* This should clear errors and enable another slew request from the UI */
    /* Better would be to flag an error but that might have unintended consequences */
  
    slewphase = 0;    
  } 
  return(1); 
}

/* Coordinates and time */


/* Start sidereal tracking                                                    */
/* StartTrack is aware of the latitude and will set the direction accordingly */
/* Call StartTrack at least once after the driver has the latitude            */

void StartTrack(void)
{
  
  char sendstr[32];
  char returnstr[32];
  double siderealrate;
  int trackazrate, trackaltrate;
  int trackaccelrate;
  int trackdecelrate;
  
  /* Note that azcountperdeg is a double and may be signed */
  /* We allow for a different acceleration here than used for slewing */
  
  trackaccelrate = fabs(azcountperdeg);
  trackdecelrate = fabs(azcountperdeg);

  /* Set the acceleration and deceleration */
  
  sprintf(sendstr,"AC %d,%d", trackaccelrate, trackdecelrate);
  
  galilrc = DMCCommand(galilmc, sendstr, returnstr, sizeof(returnstr));
  if (galilrc)
  {
    fprintf(stderr,"Telescope control is not responding #20 ...\n");
    return;
  }  
  
  /* Test for southern hemisphere */
  /* Swap sign of drive rate if we're south of the equator */
  
  siderealrate = 1.00273879*15.*azcountperdeg/3600.; 
  
  /* Note that for our test system with 12000 quadrature counts per degree */
  /* the rate will be 1.00273879*50. counts per second */
  /* Solar rate will be exactly 50 cps */
  
  if ( SiteLatitude < 0. )
  {
    siderealrate = -1.*siderealrate;
  }
  
  trackazrate = (int) siderealrate;
  trackaltrate = 0;

  sprintf(sendstr,"JGA=%d", trackazrate); 
  galilrc = DMCCommand(galilmc, sendstr, returnstr, sizeof(returnstr));
  if (galilrc)
  {
    fprintf(stderr,"Telescope control is not responding #21 ...\n");
    return;
  }
  sprintf(sendstr,"JGB=%d", trackaltrate); 
  galilrc = DMCCommand(galilmc, sendstr, returnstr, sizeof(returnstr));
  if (galilrc)
  {
    fprintf(stderr,"Telescope control is not responding #22 ...\n");
    return;
  }  
  sprintf(sendstr,"BGA"); 
  galilrc = DMCCommand(galilmc, sendstr, returnstr, sizeof(returnstr));
  if (galilrc)
  {
    fprintf(stderr,"Telescope control is not responding #23 ...\n");
    return;
  }
} 

/* Use high resolution encoder to improve tracking */

void CenterGuide(double centerra, double centerdec, 
  int raflag, int decflag, int pmodel)
{
}


/* Stop any azimuth motion including sidereal drive */

void StopTrack(void)
{
  
  char sendstr[32];
  char returnstr[32];
    
  sprintf(sendstr,"ST A");

  galilrc = DMCCommand(galilmc, sendstr, returnstr, sizeof(returnstr));
  if (galilrc)
  {
    fprintf(stderr,"Telescope control is not responding #24 ...\n");
    return;
  }  
}


/* Full stop */

void FullStop(void)
{  
  char sendstr[32];
  char returnstr[32];

  sprintf(sendstr,"AB");
  galilrc = DMCCommand(galilmc, sendstr, returnstr, sizeof(returnstr));
  if (galilrc)
  {
    fprintf(stderr,"Telescope control is not responding #25 ...\n");
    return;
  } 
}

/* Set slew limits control off or on */

int SetLimits(int limits)
{
  
  if ( limits == TRUE )
  {
    fprintf(stderr,"Limits enabled\n"); 
  
  }
  else
  {
    limits = FALSE;
    fprintf(stderr,"Limits disabled\n");   
  }
       
  return (limits);
}


/* Get status of slew limits control */

int GetLimits(int *limits)
{
  int galillimits;
  galillimits = 0;
  
  if ( galillimits == 1 )
  {
    *limits = 1;
  }
  else
  {
    *limits = 0;
  }

  return (galillimits);
}
  

/* Set slew speed limited by MAXSLEWRATE */

int SetSlewRate(int slewRate)
{
  fprintf(stderr,"Setting fixed slew rate not enabled.\n");
  return 0;
}


/* Control the dew and drive heaters */

void Heater(int heatercmd)
{
  char cmdstr[256];
  sprintf(cmdstr,"setheater %d 1>/dev/null 2>/dev/null", heatercmd);
  system(cmdstr);   
  return;
}

/* Control the telescope fans */

void Fan(int fancmd)
{
  char cmdstr[256];
  sprintf(cmdstr,"setfan %d 1>/dev/null 2>/dev/null", fancmd);
  system(cmdstr);    
  return;
}


/* Adjust the focus using an external routine */
/* The routine will time out on its own and report through the status file */

void Focus(int focuscmd, int focusspd)
{
  char cmdstr[256];
  sprintf(cmdstr,"setfocus %d %d  1>/dev/null 2>/dev/null", focuscmd, focusspd);
  system(cmdstr);  
  return;
}


/* Report the current focus reading from the status file */

void GetFocus(double *telfocus)
{
  int nread;
  double current_focus;
  char cmdstr[256];
  sprintf(cmdstr,"getfocus 1>/dev/null 2>/dev/null");
  system(cmdstr);  
  
  focusfile = (char*) malloc (MAXPATHLEN);
  strcpy(focusfile,FOCUSFILE);
  fp_focus = fopen(focusfile, "r");
  if (fp_focus == NULL)
  {
    return;
  }
  
  nread = fscanf(fp_focus, "%lg", &current_focus);
  fclose(fp_focus);
  
  if (nread !=0)
  {
    *telfocus = current_focus;
  }
  
  return;  
}


/* Adjust the rotation */

void Rotate(int rotatecmd, int rotatespd)
{
  char cmdstr[256];
  sprintf(cmdstr,"setrotate %d %d  1>/dev/null 2>/dev/null", rotatecmd, rotatespd);
  system(cmdstr);
}

/* Report the rotation setting */

void GetRotate(double *telrotate)
{
  int nread;
  double current_rotate;
  char cmdstr[256];
  sprintf(cmdstr,"getrotate 1>/dev/null 2>/dev/null");
  system(cmdstr);  
  
  rotatefile = (char*) malloc (MAXPATHLEN);
  strcpy(rotatefile,ROTATEFILE);
  fp_rotate = fopen(rotatefile, "r");
  if (fp_rotate == NULL)
  {
    *telrotate = 0.;
    return;
  }
  
  nread = fscanf(fp_rotate, "%lg", &current_rotate);
  fclose(fp_rotate);
  
  if (nread !=0)
  {
    *telrotate = current_rotate;
  }
  
  return;  
}

/* Read and report the temperature */

void GetTemperature(double *teltemperature)
{
  int nread;
  double current_temperature = 20.;
  char cmdstr[256];
  sprintf(cmdstr,"gettemperature 1>/dev/null 2>/dev/null");
  system(cmdstr);  
  
  temperaturefile = (char*) malloc (MAXPATHLEN);
  strcpy(temperaturefile,TEMPERATUREFILE);
  fp_temperature = fopen(temperaturefile, "r");
  if (fp_temperature == NULL)
  {
    *teltemperature= 0.;
    return;
  }
  
  nread = fscanf(fp_temperature, "%lg", &current_temperature);
  fclose(fp_temperature);
  
  if (nread !=0)
  {
    *teltemperature = current_temperature;
  }
  

  *teltemperature = current_temperature;
  
  return;   
}
