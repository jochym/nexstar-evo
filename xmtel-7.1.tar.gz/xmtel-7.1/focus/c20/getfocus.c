/* -------------------------------------------------------------------------- */
/* -             Get the Focus of a Planewave Hedric Focuser                - */
/* -------------------------------------------------------------------------- */
/*                                                                            */
/* Copyright 2010 John Kielkopf                                               */
/*                                                                            */
/* Distributed under the terms of the General Public License (see LICENSE)    */
/*                                                                            */
/* John Kielkopf (kielkopf@louisville.edu)                                    */
/*                                                                            */
/* Date: October 23, 2010                                                     */
/* Version: 1.0                                                               */
/*                                                                            */
/* History:                                                                   */
/*                                                                            */
/* October 23, 2010                                                           */
/*   Version 1.0                                                              */
/*     Released                                                               */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <time.h>
#include <sys/time.h>
#include <sys/types.h>
#include <unistd.h>
#include <sys/stat.h>
#include <sys/ioctl.h>
#include <fcntl.h>
#include <termios.h>
#include <math.h>
#include "hedrick.h"

#define NULL_PTR(x) (x *)0

#ifndef TRUE
#define TRUE 1
#endif

#ifndef FALSE
#define FALSE 0
#endif

/* Set the duration of the focus run from this command */

#define FOCUSTIME 1000000

/* Communications variables and routines for internal use */

int focuserportfd;
int focuserconnectflag = FALSE;

/* Focus commands */

int CheckConnectHedrickFocuser(void);
int ConnectHedrickFocuser(void);
int GetHedrickFocuser(double *telfocus);
int WriteHedrickFocus(double telfocus);
int DisconnectHedrickFocuser(void);


/* Serial port untilities */

typedef fd_set telfds;

int readn(int fd, char *ptr, int nbytes, int sec);
int writen(int fd, char *ptr, int nbytes);
int telstat(int fd,int sec,int usec);

/* Main program */

int main(int argc, char *argv[])
{
  int focuscmd, focusspd;
  char *testfocus;
  int flag;
  double telfocus;
  
  if (argc > 1) 
  { 
    printf("Usage: getfocus\n");
    printf("\n");
    printf("Read the Hedrick focuser \n");
    printf("Returns current setting in microns \n");
    printf("Updates observatory status \n");
    printf("\n");
    return(0);
  }

  flag = ConnectHedrickFocuser();
  if (flag == FALSE)
  {
    fprintf(stderr,"Cannot connect to focuser ...\n");
    return(1);
  }  
  GetHedrickFocuser(&telfocus);
  WriteHedrickFocus(telfocus);
  flag = DisconnectHedrickFocuser();
  return(0);
} 


/* Report on focuser connection status */

int CheckConnectHedrickFocuser(void)
{
  if (focuserconnectflag == TRUE)
  {
    return(TRUE);
  }
  else
  {
    return(FALSE);
  }
}

/* Connect to the focuser serial interface */
/* Returns without action if focusconnectflag is TRUE */
/* Sets focusconnectflag TRUE on success */

int ConnectHedrickFocuser(void)
{  
  struct termios tty;
  char focuserport[32];
  
  /* Packet to request version of azimuth motor driver */
  
  char sendstr[] = { 0x50, 0x01, 0x10, 0xfe, 0x00, 0x00, 0x00, 0x02 };
      
  /* Packet format:              */
  /*   preamble                  */
  /*   packet length             */
  /*   destination               */
  /*   message id                */
  /*   three message bytes       */
  /*   number of response bytes  */
   
  char returnstr[32];
  
  /* Packet format:              */
  /*   response bytes if any     */
  /*   #                         */
  
  int numRead;
  int limits, flag;
  
  if(focuserconnectflag != FALSE)
  {
    fprintf(stderr,"Focuser is already connected ... \n");
    return(0);
  }
  
  /* Make the connection         */
  
  /* focuserportfd = open("/dev/ttyS0",O_RDWR); */
  
  strcpy(focuserport,FOCUSERPORT);
  focuserportfd = open(focuserport,O_RDWR);
  if(focuserportfd == -1)
  {
    fprintf(stderr,"Focuser serial port is not available ... \n");
    focuserconnectflag = FALSE;
    return(0);
  }
  
  focuserconnectflag = TRUE;
  
  tcgetattr(focuserportfd,&tty);
  cfsetospeed(&tty, (speed_t) B9600);
  cfsetispeed(&tty, (speed_t) B9600);
  tty.c_cflag = (tty.c_cflag & ~CSIZE) | CS8;
  tty.c_iflag =  IGNBRK;
  tty.c_lflag = 0;
  tty.c_oflag = 0;
  tty.c_cflag |= CLOCAL | CREAD;
  tty.c_cc[VMIN] = 1;
  tty.c_cc[VTIME] = 5;
  tty.c_iflag &= ~(IXON|IXOFF|IXANY);
  tty.c_cflag &= ~(PARENB | PARODD);
  tcsetattr(focuserportfd, TCSANOW, &tty);

  /* Flush the input (read) buffer */

  tcflush(focuserportfd,TCIOFLUSH);
  
  return(1);
}



int GetHedrickFocuser(double *telfocus)
{
  
  /* Focus motor device ID 0x12 */
  /* MC_GET_POSITION is 0x01 */
  /* Bytes in response are 0x03 */
  
  char focusstr[] = { 0x50, 0x01, 0x12, 0x01, 0x00, 0x00, 0x00, 0x03 };
  char returnstr[2048];  
  int b0,b1,b2;
  int count;
  double focus, focusscale;
    
  /* Send the command */
  
  writen(focuserportfd,focusstr,8);    
  
  /* Read a response */

  readn(focuserportfd,returnstr,4,1);

  b0 = (unsigned char) returnstr[0];
  b1 = (unsigned char) returnstr[1];
  b2 = (unsigned char) returnstr[2];
  
  /* These counts roll over to 255 when the counter goes negative. */
  /* That is, 256*256*255 + 256*255 + 255 is -1 */
    
  count = 256*256*b0 + 256*b1 + b2;
  
  /* Use a scale which goes negative below zero */
  
  if (count > 8388608)
  {
    count = count - 16777217;
  }
    
  focus = count;
  
  /* Apply a conversion so that the focus scale comes out in decimal microns. */
  /* The constant FOCUSSCALE is defined in hedrick.h .                        */
  
  focusscale = FOCUSSCALE; 
  focus = focus/focusscale;     
  *telfocus = focus;
}


/* Write focus to stdout and to a system status file */

int WriteHedrickFocus(double telfocus)
{
  FILE* outfile;
  outfile = fopen("/usr/local/observatory/status/telfocus","w");
  if ( outfile == NULL )
  {
    fprintf(stderr,"Cannot update telfocus status file\n");
    return FALSE;
  }

  fprintf(stdout, "%lf\n", telfocus); 
  fprintf(outfile, "%lf\n", telfocus);      
  fclose(outfile);
  return TRUE;
}


/* Close serial connection to focuser and reset focuserconnectflag */

int DisconnectHedrickFocuser(void)
{  
  if(focuserconnectflag == TRUE)
  {
    close(focuserportfd);
    focuserconnectflag = FALSE;
    return(TRUE);
  }
  focuserconnectflag = FALSE;
  return(FALSE);
}


/* Serial port utilities */

int writen(fd, ptr, nbytes)
int fd;
char *ptr;
int nbytes;
{
  int nleft, nwritten;
  nleft = nbytes;
  while (nleft > 0) 
  {
    nwritten = write (fd, ptr, nleft);
    if (nwritten <=0 ) break;
    nleft -= nwritten;
    ptr += nwritten;
  }
  return (nbytes - nleft);
}

int readn(fd, ptr, nbytes, sec)
int fd;
char *ptr;
int nbytes;
int sec;
{
  int stat;
  int nleft, nread;
  nleft = nbytes;
  while (nleft > 0) 
  {
    stat = telstat(fd,sec,0);
    if (stat <=  0 ) break;
    nread  = read (fd, ptr, nleft);
    if (nread <= 0)  break;
    nleft -= nread;
    ptr += nread;
  }
  return (nbytes - nleft);
}


/* Examines the read status of a file descriptor.                       */
/* The timeout (sec, usec) specifies a maximum interval to              */
/* wait for data to be available in the descriptor.                     */
/* To effect a poll, the timeout (sec, usec) should be 0.               */
/* Returns non-negative value on data available.                        */
/* 0 indicates that the time limit referred by timeout expired.         */
/* On failure, it returns -1 and errno is set to indicate the error.    */

int telstat(fd,sec,usec)
register int fd, sec, usec;
{
  int ret;
  int width;
  struct timeval timeout;
  telfds readfds;

  memset((char *)&readfds,0,sizeof(readfds));
  FD_SET(fd, &readfds);
  width = fd+1;
  timeout.tv_sec = sec;
  timeout.tv_usec = usec;
  ret = select(width,&readfds,NULL_PTR(telfds),NULL_PTR(telfds),&timeout);
  return(ret);
}
