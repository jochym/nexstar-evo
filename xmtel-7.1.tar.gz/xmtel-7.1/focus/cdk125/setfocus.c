/* -------------------------------------------------------------------------- */
/* -              Set the Focus of a Planewave Hedric Focuser               - */
/* -------------------------------------------------------------------------- */
/*                                                                            */
/* Copyright 2010 John Kielkopf                                               */
/*                                                                            */
/* Distributed under the terms of the General Public License (see LICENSE)    */
/*                                                                            */
/* John Kielkopf (kielkopf@louisville.edu)                                    */
/*                                                                            */
/* Date: November 10, 2010                                                    */
/* Version: 1.1                                                               */
/*                                                                            */
/* History:                                                                   */
/*                                                                            */
/*   October 23, 2010                                                         */
/*   Version 1.0                                                              */
/*     Released for CDK20 prototype                                           */
/*                                                                            */
/*   November 10, 2010                                                        */
/*   Version 1.1                                                              */
/*     Updated to work with Planewave CDK125                                  */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <time.h>
#include <sys/time.h>
#include <unistd.h>
#include <fcntl.h>
#include <termios.h>

#include <sys/ioctl.h>
#include <sys/stat.h>
#include <sys/types.h>

#include "hedrick.h"


#define NULL_PTR(x) (x *)0

#ifndef TRUE
#define TRUE 1
#endif

#ifndef FALSE
#define FALSE 0
#endif


/* Communications variables and routines for internal use */

int focuserportfd;
int focuserconnectflag = FALSE;
static int focusdir = 1;

/* Focus commands */

int CheckConnectHedrickFocuser(void);
int ConnectHedrickFocuser(void);
int SetHedricFocuser(int focuscmd, int focusspd);
int GetHedrickFocuser(double *telfocus);
int WriteHedrickFocus(double telfocus);
int DisconnectHedrickFocuser(void);


/* Serial port untilities */

typedef fd_set telfds;

int readn(int fd, char *ptr, int nbytes, int sec);
int writen(int fd, char *ptr, int nbytes);
int telstat(int fd,int sec,int usec);

/* Main program */

int main(int argc, char *argv[])
{
  int focuscmd, focusspd;
  char *testfocus;
  int flag;
  int delay;
  double focustime;
  double telfocus;
  
  if (argc < 3) 
  { 
    printf("Usage: setfocus focuscmd focusspd [focustime]\n");
    printf("\n");
    printf("Adjust the Hedrick focuser and report current setting \n");
    printf("Runs for 100 milliseconds unless another time is entered \n");
    printf("\n");
    printf("Command: +1 (out)      0 (stop)  -1 (in)\n");
    printf("Speed:    1 (precise)  2 (slow)   3 (medium)  4 (fast)\n");
    printf("Time:     in milliseconds (optional)\n");
    printf("\n");
    return(0);
  }

  /* Focus speed values   */
  /*                      */
  /* Fast     4           */
  /* Medium   3           */
  /* Slow     2           */
  /* Precise  1           */
  
  /* Focus command values */
  /*                      */
  /* Out     +1           */
  /* In      -1           */
  /* Off      0           */



  focuscmd = strtod(argv[1],&testfocus);
  if ( (focuscmd < -1) || (focuscmd > 1) )
  {
    return(0);
  }
  focusspd = strtod(argv[2],&testfocus);
  if ( (focusspd < 0) || (focusspd > 4) )
  {
    return(0);
  }
  if (argc==4)
  {
    focustime = strtod(argv[3],&testfocus);
    focustime = 1000.*focustime;  
  }
  else
  {
    focustime = 100000.;
  }
  if (focustime < 10000.)
  {
    focustime = 10000.;
  }       
  else if (focustime > 20000000.)
  {
    focustime = 20000000.;
  }  
  flag = ConnectHedrickFocuser();
  if (flag == FALSE)
  {
    fprintf(stderr,"Cannot connect to focuser ...\n");
    return(1);
  }  
  usleep(100000);
  flag = SetHedrickFocuser(focuscmd, focusspd);
  delay = (int) (focustime);
  usleep(delay);
  flag = SetHedrickFocuser(0, focusspd);
  if (flag == FALSE)
  {
    fprintf(stderr,"Focuser does not respond to request ...\n");
  }  
  usleep(100000);
  GetHedrickFocuser(&telfocus);
  WriteHedrickFocus(telfocus);
  flag = DisconnectHedrickFocuser();
  return(0);
} 


/* Report on focuser connection status */

int CheckConnectHedrickFocuser(void)
{
  if (focuserconnectflag == TRUE)
  {
    return(TRUE);
  }
  else
  {
    return(FALSE);
  }
}

/* Connect to the focuser serial interface */
/* Returns without action if focusconnectflag is TRUE */
/* Sets focusconnectflag TRUE on success */

int ConnectHedrickFocuser(void)
{  
  struct termios tty;
  char focuserport[32];
  int b0, b1;
  
  /* Request focuser motor control version */
  
  char sendstr[] = { 0x50, 0x01, 0x12, 0xfe, 0x00, 0x00, 0x00, 0x02 };
      
  /* Packet format:              */
  /*   preamble                  */
  /*   packet length             */
  /*   destination               */
  /*   message id                */
  /*   three message bytes       */
  /*   number of response bytes  */

  char returnstr[] = { 0x00, 0x00, 0x00 };
  
  /* Packet format:              */
  /*   response bytes if any     */
  /*   0x23 = #                  */
  
  if(focuserconnectflag != FALSE)
  {
    fprintf(stderr,"Focuser is already connected ... \n");
    return(0);
  }
  
  /* Make the connection                        */
  
  /* focuserportfd = open("/dev/ttyS0",O_RDWR); */
  
  strcpy(focuserport,FOCUSERPORT);
  focuserportfd = open(focuserport,O_RDWR);
  if(focuserportfd == -1)
  {
    fprintf(stderr,"Focuser serial port is not available ... \n");
    focuserconnectflag = FALSE;
    return(0);
  }
  
  focuserconnectflag = TRUE;
  
  tcgetattr(focuserportfd,&tty);
  cfsetospeed(&tty, (speed_t) B9600);
  cfsetispeed(&tty, (speed_t) B9600);
  tty.c_cflag |=  CLOCAL | CS8 | CREAD;
  tcsetattr(focuserportfd, TCSANOW, &tty);

  /* Flush the input (read) buffer */

  tcflush(focuserportfd,TCIOFLUSH);
  
  /* Send the command */
  
  writen(focuserportfd,sendstr,8);    

  /* Read a response including the closing 0x23 */

  readn(focuserportfd,returnstr,3,1);

  b0 = (unsigned char) returnstr[0];
  b1 = (unsigned char) returnstr[1];
  
  /* Uncomment the following for diagnostic */
  
  fprintf(stderr,"Focuser version %d.%d\n",b0,b1); 
 
  return(1);
}


int SetHedrickFocuser(int focuscmd, int focusspd)
{
  char sendstr[] = { 0x50, 0x02, 0x12, 0x24, 0x01, 0x00, 0x00, 0x00 };
  char returnstr[2048];
  
  /* Set the speed */

  sendstr[4] = 0x08;

  if ( focusspd >= 4 )
  {
    sendstr[4] = 0x08;
  }
  
  if ( focusspd == 3 )
  {
    sendstr[4] = 0x06;
  }
  
  if ( focusspd == 2 )
  {
    sendstr[4] = 0x04;
  }
  
  if ( focusspd == 1 )
  {
    sendstr[4] = 0x02;
  }
    
  if ( focuscmd == -1 )
  {
    
    /* Run the focus motor in */
    
    /* Set the direction based on focusdir */
    
    if (focusdir > 0)
    {
      sendstr[3] = 0x25;
    }
    else
    {
      sendstr[3] = 0x24;
    }
            
    /* Send the command */
    writen(focuserportfd,sendstr,8);

    /* Wait up to a second for an acknowledgement */
    
    for (;;) 
    {
      if ( readn(focuserportfd,returnstr,1,1) ) 
      {
        if (returnstr[0] == '#') break;
      }
      else 
      { 
        fprintf(stderr,"No acknowledgement from focuser\n");
      }
    }      
  }
  
  if ( focuscmd == 1 )
  {  
    
    /* Run the focus motor out */

    /* Set the direction based on focusdir */
    
    if (focusdir > 0)
    {
      sendstr[3] = 0x24;
    }
    else
    {
      sendstr[3] = 0x25;
    }
        
    /* Send the command */
    writen(focuserportfd,sendstr,8);    

    /* Wait up to a second for an acknowledgement */
    
    for (;;) 
    {
      if ( readn(focuserportfd,returnstr,1,1) ) 
      {
        if (returnstr[0] == '#') break;
      }
      else 
      { 
        fprintf(stderr,"No acknowledgement from focus control\n");
      }
    }      
  }
   
  if ( focuscmd == 0 )
  {

    /* Set the speed to zero to stop the motion */
    
    sendstr[4] = 0x00;
    
    /* Send the command */
    writen(focuserportfd,sendstr,8);    

    /* Wait up to a second for an acknowledgement */
    
    for (;;) 
    {
      if ( readn(focuserportfd,returnstr,1,1) ) 
      {
        if (returnstr[0] == '#') break;
      }
      else 
      { 
      fprintf(stderr,"No acknowledgement from focuser\n");
      }
    }            
    
  }  
}

int GetHedrickFocuser(double *telfocus)
{
  
  /* Focus motor device ID 0x12     */
  /* MTR_GET_POSITION is 0x01       */
  /* Bytes in response are 0x03     */
  /* Closing response is 0x23 = '#' */
  
  char sendstr[] = { 0x50, 0x01, 0x12, 0x01, 0x00, 0x00, 0x00, 0x03 };
  char returnstr[] = { 0x00, 0x00, 0x00, 0x00 };  
  int b0,b1,b2;
  int count;
  double focus, focusscale;
    
  /* Send the command */
  
  writen(focuserportfd,sendstr,8);    
  
  /* Read a response including the closing  0x23 */

  readn(focuserportfd,returnstr,4,1);

  b0 = (unsigned char) returnstr[0];
  b1 = (unsigned char) returnstr[1];
  b2 = (unsigned char) returnstr[2];
  count = 256*256*b0 + 256*b1 + b2;
  
  /* Uncomment the following for diagnostics */
  
  /* fprintf(stderr, "%x %x %x\n", b0, b1, b2);  */
  /* fprintf(stderr, "256*256*%d + 256*%d + %d = %d\n", b0, b1, b2, count); */
      
  focus = count;
  
  /* Apply a conversion so that the focus scale comes out in decimal microns. */
  /* The constant FOCUSSCALE is defined in header file.                       */
  
  focusscale = FOCUSSCALE; 
  focus = focus/focusscale;     
  *telfocus = focus;
}


/* Write focus to stdout and to a system status file */

int WriteHedrickFocus(double telfocus)
{
  FILE* outfile;
  outfile = fopen("/usr/local/observatory/status/telfocus","w");
  if ( outfile == NULL )
  {
    fprintf(stderr,"Cannot update telfocus status file\n");
    return FALSE;
  }

  fprintf(stdout, "%.1f\n", telfocus); 
  fprintf(outfile, "%lf\n", telfocus);      
  fclose(outfile);
  return TRUE;
}


/* Close serial connection to focuser and reset focuserconnectflag */

int DisconnectHedrickFocuser(void)
{  
  if(focuserconnectflag == TRUE)
  {
    close(focuserportfd);
    focuserconnectflag = FALSE;
    return(TRUE);
  }
  focuserconnectflag = FALSE;
  return(FALSE);
}


/* Serial port utilities */

int writen(fd, ptr, nbytes)
int fd;
char *ptr;
int nbytes;
{
  int nleft, nwritten;
  nleft = nbytes;
  while (nleft > 0) 
  {
    nwritten = write (fd, ptr, nleft);
    if (nwritten <=0 ) break;
    nleft -= nwritten;
    ptr += nwritten;
  }
  return (nbytes - nleft);
}

int readn(fd, ptr, nbytes, sec)
int fd;
char *ptr;
int nbytes;
int sec;
{
  int stat;
  int nleft, nread;
  nleft = nbytes;
  while (nleft > 0) 
  {
    stat = telstat(fd,sec,0);
    if (stat <=  0 ) break;
    nread  = read (fd, ptr, nleft);
    if (nread <= 0)  break;
    nleft -= nread;
    ptr += nread;
  }
  return (nbytes - nleft);
}


/* Examines the read status of a file descriptor.                       */
/* The timeout (sec, usec) specifies a maximum interval to              */
/* wait for data to be available in the descriptor.                     */
/* To effect a poll, the timeout (sec, usec) should be 0.               */
/* Returns non-negative value on data available.                        */
/* 0 indicates that the time limit referred by timeout expired.         */
/* On failure, it returns -1 and errno is set to indicate the error.    */

int telstat(fd,sec,usec)
register int fd, sec, usec;
{
  int ret;
  int width;
  struct timeval timeout;
  telfds readfds;

  memset((char *)&readfds,0,sizeof(readfds));
  FD_SET(fd, &readfds);
  width = fd+1;
  timeout.tv_sec = sec;
  timeout.tv_usec = usec;
  ret = select(width,&readfds,NULL_PTR(telfds),NULL_PTR(telfds),&timeout);
  return(ret);
}
