/* -------------------------------------------------------------------------- */
/* -                   Astronomical Telescope Control                       - */
/* -                         XmTel Header File                              - */
/* -                        XPA Client for XmTel                            - */
/* -------------------------------------------------------------------------- */
/*                                                                            */
/* Copyright (c) 2009-2014 John Kielkopf                                      */
/* kielkopf@louisville.edu                                                    */
/*                                                                            */
/* This file is part of XmTel.                                                */
/*                                                                            */
/* Distributed under the terms of the MIT License (see LICENSE)               */ 
/*                                                                            */
/* Date: September 16, 2014                                                   */
/* Version: 7.0                                                               */

/* Important physical constants */

#ifndef PI
#define PI             3.14159265358
#endif

/* Useful values */

#ifndef FALSE
#define FALSE 0
#endif

#ifndef TRUE
#define TRUE 1
#endif

/* Status control */

#define STATUSON    1
#define STATUSOFF   0


/* User interface polling */

#define	POLLMS      200   /* Poll period, ms */

/* Menu flags */

#define OK         1     
#define CANCEL     2

/* Menu item identifiers */

#define NEWQUEUE        1
#define NEWLOG          2
#define NEWCONFIG       3
#define EXIT            4
#define EDITQUEUE       5 
#define EDITLOG         6 
#define EDITCONFIG      7
#define POINTOPTION1    8
#define POINTOPTION2    9
#define POINTOPTION4   10
#define POINTOPTION8   11
#define REFTARGET      12
#define REFCLEAR       14
#define REFDEFAULT     17
#define MODELEDIT      18
#define MODELCLEAR     19
#define MODELDEFAULT   22

/* Target input flags */

#define RA        1               
#define DEC       2               

/* Reserve space for characters in file descriptors */

#define MAXPATHLEN  100

/* Default log and queue files */

#define LOGFILE   "telescope.log"
#define QUEUEFILE "target.que"


/* Default log and queue editor e.g. nedit or gedit */

#define XMTEL_EDITOR  "nedit"


/* In xmtel1 and xpatel the following are defined in protocol.h */
/* They are needed here to ease building the user interface     */

/* Slew motion speeds */

#define	GUIDE		1
#define	CENTER		2
#define	FIND		4
#define	SLEW		8

/* Slew directions */

#define	NORTH		1
#define	SOUTH		2
#define	EAST		4
#define	WEST		8

/* Pointing models (bit mapped and additive) */

#define RAW       0      /* Unnmodified but assumed zero corrected */
#define OFFSET    1      /* Correct for target offset*/
#define REFRACT   2      /* Correct for atmospheric refraction */
#define POLAR     4      /* Correct for polar axis misalignment */ 
#define DYNAMIC   8      /* Correct for errors in real time */

/* Display epochs (selected with GUI button) */

#define J2000    0      /* Epoch 2000.0 as entered or precessed without pm */
#define EOD      1      /* Epoch of date with pm if available  (default) */

