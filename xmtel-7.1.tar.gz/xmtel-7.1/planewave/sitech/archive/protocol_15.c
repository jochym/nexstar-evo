/* -------------------------------------------------------------------------- */
/* -    Planewave A200HR mount with a Sidereal Technologies controller      - */
/* -------------------------------------------------------------------------- */
/*                                                                            */
/* Copyright 2011 John Kielkopf                                               */
/*                                                                            */
/* Distributed under the terms of the General Public License (see LICENSE)    */
/*                                                                            */
/* John Kielkopf (kielkopf@louisville.edu)                                    */
/*                                                                            */
/* Date: September 17, 2011                                                   */
/* Version: 1.0                                                               */
/*                                                                            */
/* History:                                                                   */
/*                                                                            */
/* September 17, 2011                                                         */
/*   Version 1.0                                                              */
/*     This version uses only the motor encoders                              */
/*     Use external programs for other motors or sensors                      */
/*       Focus -- setfocus and getfocus                                       */
/*       Rotation -- setrotate and getrotate                                  */
/*       Temperature -- setfan, setheater and gettemperature                  */
/*     Added CenterGuide function                                             */


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <time.h>
#include <sys/time.h>
#include <sys/types.h>
#include <unistd.h>
#include <sys/stat.h>
#include <sys/ioctl.h>
#include <fcntl.h>
#include <termios.h>
#include <math.h>
#include "protocol.h"

#define NULL_PTR(x) (x *)0

#ifndef TRUE
#define TRUE 1
#endif

#ifndef FALSE
#define FALSE 0
#endif

/* There are two classes of routines defined here:                            */

/*   XmTel commands allow generic access to the controller.                   */
/*   Sitech specific commands for hardware and data.                          */


/* System variables and prototypes */

/* Telescope and mounting commands that may be called externally */

/* Interface control */

void ConnectTel(void);
int  SyncTelEncoders(void);
void DisconnectTel(void);
int  CheckConnectTel(void);

/* Slew, track, and guide control */

void SetRate(int newrate);
void StartSlew(int direction);
void StopSlew(int direction);
void StartTrack(void);
void StopTrack(void);
void CenterGuide(double centerra, double centerdec, 
  int raflag, int decflag, int pmodel);
void FullStop(void);
void SetGuideTargets(void);

/* Coordinates */

void GetTel(double *telra, double *teldec, int pmodel);
int  GoToCoords(double newRA, double newDec, int pmodel);
int  CheckGoTo(double desRA, double desDec, int pmodel);

/* Slew limits */

int  GetSlewStatus(void);
int  SetLimits(int limits);
int  GetLimits(int *limits);

/* Synchronizing */

int  SyncTelOffsets(double newoffsetra, double newoffsetdec);
int  SyncTelToUTC(double newutc);
int  SyncTelToLocation(double newlong, double newlat, double newalt);
int  SyncTelToLST(double newTime);

/* Instrumentation */

void Heater(int heatercmd);
void Fan(int fancmd);
void Focus(int focuscmd, int focusspd);
void Rotate(int rotatecmd, int rotatespd);
void GetFocus(double *telfocus);
void GetRotate(double *telrotate);
void GetTemperature(double *teltemperature);

/* External variables and shared code */

extern double LSTNow(void);
extern double UTNow(void);
extern double Map24(double hour);
extern double Map12(double hour);
extern double Map360(double degree);
extern double Map180(double degree);
extern double offsetra, offsetdec;
extern double SiteLatitude, SiteLongitude;
extern int    telmount;
extern int    homenow;
extern double homeha;            
extern double homera;            
extern double homedec;           
extern char   telserial[32];     

extern void PointingFromTel (double *telra1, double *teldec1, 
  double telra0, double teldec0, int pmodel);

extern void PointingToTel (double *telra0, double *teldec0, 
  double telra1, double teldec1, int pmodel);
  
extern void EquatorialToHorizontal(double ha, double dec, double *az, double *alt);
extern void HorizontalToEquatorial(double az, double alt, double *ha, double *dec);  

/* Contants */

double mtrazmcal = MOTORAZMCOUNTPERDEG; 
double mtraltcal = MOTORALTCOUNTPERDEG;
double mntazmcal = MOUNTAZMCOUNTPERDEG;
double mntaltcal = MOUNTALTCOUNTPERDEG;


/* Global program parameters */

int slewrate;          
int slewphase = 0;     


/* Global encoder counts */

int mtrazm = 0;
int mtralt = 0;
int mntazm = 0;
int mntalt = 0;


/* Global pointing angles derived from the encoder counts */

double mtrazmdeg = 0.;
double mtraltdeg = 0.;
double mntazmdeg = 0.;
double mntaltdeg = 0.;
 

/* Global tracking parameters */

int azmtrackrate0   = 0;
int alttrackrate0   = 0;
int azmtracktarget  = 0;
int azmtrackrate    = 0;
int alttracktarget  = 0;
int alttrackrate    = 0;
int ntarget = 0;
int starget = 0;
int wtarget = 0; 
int etarget = 0;


/* Files */

FILE *fp_focus;
char *focusfile;

FILE *fp_temperature;
char *temperaturefile;

FILE *fp_rotate;
char *rotatefile;

 
/* Communications variables and routines for internal use */

static int TelPortFD;
static int TelConnectFlag = FALSE;

typedef fd_set telfds;

static int readn(int fd, char *ptr, int nbytes, int sec);
static int writen(int fd, char *ptr, int nbytes);
static int telstat(int fd,int sec,int usec);

/* End of prototype and variable definitions */



/* Report on telescope connection status */

int CheckConnectTel(void)
{
  if (TelConnectFlag == TRUE)
  {
    return TRUE;
  }
  else
  {
    return FALSE;
  }
}


/* Connect to the telescope serial interface */
/* Returns without action if TelConnectFlag is TRUE */
/* Sets TelConnectFlag TRUE on success */

void ConnectTel(void)
{  
  struct termios tty;    
  char sendstr[256] = "";
  char returnstr[256] = "";
  int numread;
  int limits, flag;
  double siderealrate;
  
  if (TelConnectFlag != FALSE)
  {
    return;
  }
  
  /* Software allows for different mount types but the A200HR requires "GEM" */
  /* GEM:    over the pier pointing at the pole                              */
  /* EQFORK: pointing at the equator on the meridian                         */
  /* ALTAZ:  level and pointing north                                        */

  if (telmount != GEM)
  {
    fprintf(stderr,"Request made to connect A200HR controller to the wrong mount type.");
    return;
  }
  else
  {
    fprintf(stderr, "On a cold start A200HR must be over the pier\n");
    fprintf(stderr, "  pointing at the pole.\n\n");
    fprintf(stderr, "We always read the precision encoder and \n"); 
    fprintf(stderr, "  set the motor encoders to match.\n");
  }
      
  /* Make the connection */
  
  /* On the Sidereal Technologies controller                                */
  /*   there is an FTDI USB to serial converter that appears as             */
  /*   /dev/ttyUSB0 on Linux systems without other USB serial converters.   */
  /*   The serial device is known to the program that calls this procedure. */
  
  /* TelPortFD = open("/dev/ttyUSB0",O_RDWR); */
  
  TelPortFD = open(telserial,O_RDWR);
  if (TelPortFD == -1)
  {
    fprintf(stderr,"A200HR serial port %s not available ... \n",telserial);
    return;
  }
  fprintf(stderr,"A200HR serial port opened ... \n");
  tcgetattr(TelPortFD,&tty);
  cfsetospeed(&tty, (speed_t) B19200);
  cfsetispeed(&tty, (speed_t) B19200);
  tty.c_cflag = (tty.c_cflag & ~CSIZE) | CS8;
  tty.c_iflag =  IGNBRK;
  tty.c_lflag = 0;
  tty.c_oflag = 0;
  tty.c_cflag |= CLOCAL | CREAD;
  tty.c_cc[VMIN] = 1;
  tty.c_cc[VTIME] = 5;
  tty.c_iflag &= ~(IXON|IXOFF|IXANY);
  tty.c_cflag &= ~(PARENB | PARODD);
  tcsetattr(TelPortFD, TCSANOW, &tty);

  /* Flush the input (read) buffer */

  tcflush(TelPortFD,TCIOFLUSH);

  /* Test connection by asking for firmware version    */
   
  strcpy(sendstr,"XV\r");
  
  writen(TelPortFD,sendstr,3);
  numread=readn(TelPortFD,returnstr,4,2);
  if (numread !=0 ) 
  {
    returnstr[numread] = '\0';
    fprintf(stderr,"Planewave A200HR\n");
    fprintf(stderr,"Sidereal Technology %s\n",returnstr);
    fprintf(stderr,"Telescope connected \n");  
    TelConnectFlag = TRUE;   
  }
  else
  {
    fprintf(stderr,"A200HR drive control did not respond\n");    
    return;
  }  

  /* Flush the input buffer */

  tcflush(TelPortFD,TCIOFLUSH);
  
  /* Set global tracking parameters */
        
  /* Test for hemisphere */
  /* Set targets for defaults */
 
  if ( SiteLatitude < 0. )
  {
    azmtracktarget = -90.*mtrazmcal;
    alttracktarget = -90.*mtraltcal;
  }
  else
  {
    azmtracktarget = 90.*mtrazmcal;
    alttracktarget = 90.*mtraltcal;
  }
  
  /* Set rates for defaults */
    
  azmtrackrate0 = AZMSIDEREALRATE;
  alttrackrate0 = ALTSIDEREALRATE;
  azmtrackrate = 0;
  alttrackrate = 0;
       
  /* Perform startup tests for slew limits if any */

  flag = GetLimits(&limits);
  usleep(500000);
  limits = FALSE;
  flag = SetLimits(limits);
  usleep(500000);  
  flag = GetLimits(&limits);
      
  flag = SyncTelEncoders();
  if (flag != TRUE)
  {
    fprintf(stderr,"Initial telescope pointing request was out of range ... \n");
    fprintf(stderr,"Cycle power, set telescope to home position, restart. \n");    
    return;
  }
  
  /* Pause for telescope controller to initialize */
   
  usleep(500000);
  
  /* Read encoders and confirm pointing */
  
  GetTel(&homera, &homedec, RAW);
  
  fprintf(stderr, "Local latitude: %lf\n", SiteLatitude);
  fprintf(stderr, "Local longitude: %lf\n", SiteLongitude);
  fprintf(stderr, "Local sidereal time: %lf\n", LSTNow()); 
  fprintf(stderr, "Mount type: %d\n", telmount);
  fprintf(stderr, "Mount motor encoder RA: %lf\n", homera);
  fprintf(stderr, "Mount motor encoder Dec: %lf\n", homedec);
  
  fprintf(stderr, "The telescope is on line ...\n\n");
    
  /* Flush the input buffer in case there is something left from startup */

  tcflush(TelPortFD,TCIOFLUSH);
  return;

}


/* Assign and save slewrate for use in StartSlew */

void SetRate(int newrate)
{
  if (newrate == SLEW) 
  {
    slewrate = 4000000; 
  }
  else if (newrate == FIND) 
  {
    slewrate = 400000;
  }
  else if (newrate == CENTER) 
  {
    slewrate = 100000;
  }
  else if (newrate == GUIDE) 
  {
    slewrate = 20000;
  }
  else
  {
    slewrate = 20000;
  }
  return;
}
 

/* Start a slew in chosen direction at slewrate */

void StartSlew(int direction)
{
  char slewcmd[32] = "";
  int nsend;
  int rate;
  
  rate = slewrate;
  
  /* Define directions                                       */
  /* Set here for GEM A200HR                                 */ 
  /* Northern hemisphere east of pier looking west           */
  /* These should be dynamically changed with pier side flip */
    
  SetGuideTargets();
  
  if (direction == NORTH)
  {
    sprintf(slewcmd,"X%dS%d\r",ntarget,rate);
    nsend = strlen(slewcmd);
  }
  else if (direction == EAST)
  {
    sprintf(slewcmd,"Y%dS%d\r",etarget,rate);
    nsend = strlen(slewcmd);
  }
  else if (direction == SOUTH)
  {
    sprintf(slewcmd,"X%dS%d\r",starget,rate);
    nsend = strlen(slewcmd);
  }
  else if (direction == WEST)
  {
    sprintf(slewcmd,"Y%dS%d\r",wtarget,rate);
    nsend = strlen(slewcmd);
  }
  else
  {
    return;
  }  

  writen(TelPortFD,slewcmd,nsend);
  
  fprintf(stderr,"Button press: %s \n",slewcmd);
  
  return;
   
}


/* Stop the slew in chosen direction */

void StopSlew(int direction)
{
  char slewcmd[32] = "";
  
  if (direction == NORTH)
  {
    sprintf(slewcmd,"XS0\r");
  }
  else if (direction == EAST)
  {
    sprintf(slewcmd,"YS0\r");
  }
  else if (direction == SOUTH)
  {
    sprintf(slewcmd,"XS0\r");
  }
  else if (direction == WEST)
  {
    sprintf(slewcmd,"YS0\r");
  }

  tcflush(TelPortFD,TCIOFLUSH);
  writen(TelPortFD,slewcmd,4);
  return;
}

void DisconnectTel(void)
{
  /* printf("DisconnectTel\n"); */
  if (TelConnectFlag == TRUE)
  {  
    close(TelPortFD);
  }
  TelConnectFlag = FALSE;
  return;
}


/* Synchronize the two encoder systems */
/* Returns 1 if synchronization is within 15 counts in both axes */

int SyncTelEncoders(void)
{

  char sendstr[32] = "";
  int nsend = 0;
  
  double nowra0, nowdec0;
  int mtrazmnew, mtraltnew;
      
  /* Zero points:                                                */
  /*   Alt-Az -- horizon north                                   */
  /*   Fork equatorial -- equator meridian                       */
  /*   German equatorial -- over the mount at the pole           */
  
  /* Signs:                                                      */
  /*   Dec or Alt -- increase from equator to pole and beyond    */ 
  /*     GEM dec sign is for west of pier looking east           */ 
  /*     GEM dec sign reverses when east of pier looking west    */
  /*   HA or Az   -- increase from east to west                  */

  /* Get the current pointing                                    */
  /* This sets the global telmntazm and telmntalt counters       */
    
  GetTel(&nowra0, &nowdec0, RAW);
  
  /* Assign the motor counts to match the mount counts           */
    
  mtrazmnew = ((double) mntazm) * mtrazmcal / mntazmcal;
  mtraltnew = ((double) mntalt) * mtraltcal / mntaltcal;
     
  /* Set the controller motor counters                           */
  
  tcflush(TelPortFD,TCIOFLUSH);
  sprintf(sendstr,"YF%d\r",mtrazmnew);
  nsend = strlen(sendstr);
  writen(TelPortFD,sendstr,nsend);
  
  usleep(100000);
  
  tcflush(TelPortFD,TCIOFLUSH);
  sprintf(sendstr,"XF%d\r",mtraltnew);
  nsend = strlen(sendstr);
  writen(TelPortFD,sendstr,nsend);
  
  usleep(100000);

  /* Query the controller to update the counters  */
  
  GetTel(&nowra0, &nowdec0, RAW); 
  
  if ( (abs(mtrazm - mtrazmnew) > 15) || (abs(mtralt - mtraltnew) > 15) )
  {
    return(0);
  }  

  return(1);
}


/* Read the motor and mount encoders                                  */
/* Global telmount which should be GEM for A200HR                     */
/* Save encoder counters in global variables                          */
/* Convert the counters to ha and dec                                 */
/* Use an NTP synchronized clock to find lst and ra                   */
/* Correct for the pointing model to find the true direction vector   */
/* Report the ra and dec at which the telescope is pointed            */

void GetTel(double *telra, double *teldec, int pmodel)
{  
   
  char sendstr[32] = "";
  char returnstr[32] = "";
  int numread;
   
  /* Celestial coordintes derived from the pointing angles */ 
 
  double telha0 = 0.;
  double teldec0 = 0.;
  double telra0 = 0.;
  double telra1 = 0.;
  double teldec1 = 0.;
  
  /* Buffers for decoding the binary packet */
  
  int b0, b1, b2, b3;

  /* Send an XXS command to the controller */
  /* Controller should return 20 bytes of information */

  strcpy(sendstr,"XXS\r");
  tcflush(TelPortFD,TCIOFLUSH);  
  writen(TelPortFD,sendstr,4);
  numread=readn(TelPortFD,returnstr,20,2);
  if (numread !=20)
  {
    fprintf(stderr,"Telescope control is not responding ...\n");
    fprintf(stderr,"Read %d / 20 bytes in GetTel data packet \n", numread);
    return;
  }

  /* Parse motor encoder readings from the response         */
  /* Caution that Sidtech 24 bit counters seem to ignore b0 */
  /* Little endian order                                    */
  
  
  /* Translate altitude packet to integers without sign */
  
  b0 = (unsigned char) returnstr[0];
  b1 = (unsigned char) returnstr[1];
  b2 = (unsigned char) returnstr[2];
  b3 = (unsigned char) returnstr[3];
  
  /* Compute an unsigned encoder count */
  
  mtralt = b1 + 256*b2 + 256*256*b3;

  /* Complement when sign bit set */

  if (mtralt > 8388608)
  {
    mtralt = -(16777217 - mtralt);
  }
       
  
  /* Translate azimuth packet to integers without sign */
   
  b0 = (unsigned char) returnstr[4];
  b1 = (unsigned char) returnstr[5];
  b2 = (unsigned char) returnstr[6];
  b3 = (unsigned char) returnstr[7];
     

  /* Compute an unsigned encoder count */

  mtrazm =  b1 + 256*b2 +256*256* b3;

  if (mtrazm > 8388608)
  {
    mtrazm = -(16777217 - mtrazm);
  }

          
  /* Translate mount altitude packet to integers without sign */
  
  b0 = (unsigned char) returnstr[8];
  b1 = (unsigned char) returnstr[9];
  b2 = (unsigned char) returnstr[10];
  b3 = (unsigned char) returnstr[11];
  
  /* Compute an unsigned encoder count */
  
  mntalt = b1 + 256*b2 + 256*256*b3;

  /* Complement when sign bit set */

  if (mntalt > 8388608)
  {
    mntalt = -(16777217 - mntalt);
  }   
  
  /* Translate mount azimuth packet to integers without sign */
   
  b0 = (unsigned char) returnstr[12];
  b1 = (unsigned char) returnstr[13];
  b2 = (unsigned char) returnstr[14];
  b3 = (unsigned char) returnstr[15];
     
  /* Compute an unsigned encoder count */

  mntazm =  b1 + 256*b2 +256*256* b3;

  if (mntazm > 8388608)
  {
    mntazm = -(16777217 - mntazm);
  }
        

  /* Convert counts to degrees for all encoders             */
  /* Scaling values of countperdeg are signed               */
  /* Pointing angles now meet the software sign convention  */
  
  mtrazmdeg = ( (double) mtrazm ) / mtrazmcal;
  mtraltdeg = ( (double) mtralt ) / mtraltcal;
  mntazmdeg = ( (double) mntazm ) / mntazmcal;
  mntaltdeg = ( (double) mntalt ) / mntaltcal;
  

  /* Report diagnostic of pointing angles */ 
  
  fprintf(stderr,"Motor azimuth:   %lf\n", mtrazmdeg);
  fprintf(stderr,"Motor altitude:  %lf\n", mtraltdeg);
  fprintf(stderr,"Mount azimuth:   %lf\n", mntazmdeg);
  fprintf(stderr,"Mount_altitude:  %lf\n", mntaltdeg);
  
  
  /* Transform mount pointing angles to ha, ra and dec             */
  /* Assume sign convention and zero point for various mount types */
  
  if (telmount == GEM)
  {
    if ( mntazmdeg == 0. ) 
    {
      if ( mntaltdeg < 0.)
      {
        telha0 = -6.;
        teldec0 = 90. + mntaltdeg;
      }
      else
      {
        telha0 = +6.;
        teldec0 = 90. - mntaltdeg;
      }
    }
    else if ( mntazmdeg == -90. )
    {
      if ( mntaltdeg < 0.)
      {
        telha0 = 0.;
        teldec0 = 90. + mntaltdeg;
      }
      else
      {
        telha0 = -12.;
        teldec0 = 90. - mntaltdeg;
      }    
    }
    else if ( mntazmdeg == 90. )
    {
      if ( mntaltdeg > 0.)
      {
        telha0 = 0.;
        teldec0 = 90. - mntaltdeg;
      }
      else
      {
        telha0 = -12.;
        teldec0 = 90. + mntaltdeg;
      }    
    }   
    else if ((mntazmdeg > -180. ) && (mntazmdeg < -90.))
    {
      teldec0 = 90. - mntaltdeg;
      telha0 = Map12(6. + mntazmdeg/15.);  
    }
    else if ((mntazmdeg > -90. ) && (mntazmdeg < 0.))
    {
      teldec0 = 90. - mntaltdeg;
      telha0 = Map12(6. + mntazmdeg/15.);  
    }    
    else if ((mntazmdeg > 0. ) && (mntazmdeg < 90.))
    {
      teldec0 = 90. + mntaltdeg;
      telha0 = Map12(-6. + mntazmdeg/15.);  
    }    
    else if ((mntazmdeg > 90. ) && (mntazmdeg < 180.))
    {
      teldec0 = 90. + mntaltdeg;
      telha0 = Map12(-6. + mntazmdeg/15.);  
    }   
    else
    {
      fprintf(stderr,"HA encoder out of range\n");      
      teldec0 = 0.;
      telha0 = 0.;
    }   
    
    /* Flip signs for the southern sky */
    
    if (SiteLatitude < 0.)
    {
      teldec0 = -1.*teldec0;
      telha0 = -1.*telha0;
    }
        
    telra0 = Map24(LSTNow() - telha0);
  }
    
  else if (telmount == EQFORK)
  {
    teldec0 = mntaltdeg;
    telha0 = Map12(mntazmdeg/15.);
    
    /* Flip signs for the southern sky */
    
    if (SiteLatitude < 0.)
    {
      teldec0 = -1.*teldec0;
      telha0 = -1.*telha0;
    }
        
    telra0 = Map24(LSTNow() - telha0);    
  }
  
  else if (telmount == ALTAZ)
  {
    HorizontalToEquatorial(mntazmdeg, mntaltdeg, &telha0, & teldec0);
    telha0 = Map12(telha0);
    telra0 = Map24(LSTNow() - telha0);   
  }

  else
  {
    fprintf(stderr,"Unknown mounting type\n");  
    *telra=0.;
    *teldec=0.;
    return;
  }
    
  /* Handle special case if not already treated where dec is beyond a pole */
  
  if (teldec0 > 90.)
  {
    teldec0 = 180. - teldec0;
    telra0 = Map24(telra0 + 12.);
  }
  else if (teldec0 < -90.)
  {
    teldec0 = -180. - teldec0;
    telra0 = Map24(telra0 + 12.);
  }
    
  /* Apply pointing model to the coordinates that are reported by the telescope */
  
  PointingFromTel(&telra1, &teldec1, telra0, teldec0, pmodel);
      
  /* Return corrected values */

  *telra=telra1;
  *teldec=teldec1;
      
  return;
}


/* Go to new celestial coordinates using motor encoders               */
/* Evaluate if target coordinates are valid                           */
/* Test slew limits in altitude, polar, and hour angles               */
/* Query if target is above the horizon                               */
/* Return without action for invalid requests                         */
/* Interrupt any slew sequence in progress                            */
/* Check current pointing                                             */
/* Find encoder readings required to point at target                  */
/* Set slewphase equal to number of slew segments needed              */
/* Begin next segment needed to reach target from current pointing    */
/* Repeated calls are required when more than one segment is needed   */
/* Return 1 if underway                                               */
/* Return 0 if done or not permitted                                  */

int GoToCoords(double newra, double newdec, int pmodel)
{
  char slewcmd[32] = "";
  int azcount;
  int altcount;
  double newha, newalt, newaz;
  double newha0, newalt0, newaz0;
  double newra0, newdec0;
  double newra1, newdec1;
  double nowha0, nowra0, nowdec0;
  double encoderalt = 0.;
  double encoderaz = 0.;
  int gotorate;
  int nsend = 0;
       
  gotorate = 2000000;
  
  /* Select fast slew command if needed */
  /* Note:  may place large inertial load on the gear train */
  
  if ( SLEWFAST )
  {
    gotorate = 2 * gotorate;
  }
        
  newha = LSTNow() - newra;
  newha = Map12(newha);
  
  /* Convert HA and Dec to Alt and Az */
  /* Test for visibility              */
  
  EquatorialToHorizontal(newha, newdec, &newaz, &newalt);
  
  /* Check altitude limit */
  
  if (newalt < MINTARGETALT)
  {
    fprintf(stderr,"Target is below the telescope horizon\n");
    slewphase = 0;
    return(0);
  }
  
  /* Target request is valid */
  /* Find the best path to target */
    
  /* Mount coordinates for the target */
  
  newra1 = newra;
  newdec1 = newdec;
  PointingToTel(&newra0,&newdec0,newra1,newdec1,pmodel);  
  newha0 = LSTNow() - newra0;
  newha0 = Map12(newha0);
  EquatorialToHorizontal(newha0, newdec0, &newaz0, &newalt0);

  /* Get current mount coordinates */
  
  GetTel(&nowra0, &nowdec0, RAW);
  nowha0 = LSTNow() - nowra0;
  nowha0 = Map12(nowha0);
          
  /* Prepare encoder counts for a new slew */

  /* German equatorial */

  if (telmount == GEM)
  {
    
    /* Flip signs for the southern sky */
    
    if (SiteLatitude < 0.)
    {
      newdec0 = -1.*newdec0;
      newha0 = -1.*newha0;
    }
    
    /* Parse by target HA */
    
    if (newha0 == 0.)
    { 
      /* OTA looking at meridian */
      /* This is ambiguous unless we know which side of the pier it is on */
      /* Assume telescope was on the west side looking east */
      /*   and was moved to point to the meridian with the OTA west of pier */
      slewphase = 1;
      fprintf(stderr,"Warning: assuming OTA is west of pier.\n");
      encoderaz = 90.;
      encoderalt = newdec0 - 90.;
    }
    else if (newha0 == -6.)
    {
      /* OTA looking east */
      slewphase = 1;
      encoderaz = 0.;
      encoderalt = newdec0 - 90.;
    }
    else if (newha0 == 6.)
    {
      /* OTA looking west */
      slewphase = 1;
      encoderaz = 0.;
      encoderalt = 90. - newdec0;
    }    
    else if ((newha0 > -12.) && ( newha0 < -6.))
    { 
      /* OTA east of pier looking below the pole */
      slewphase = 1;
      encoderaz = newha0*15. + 90.;
      encoderalt = newdec0 - 90.;
    }
    else if ((newha0 > -6.) && ( newha0 < 0.))
    { 
      /* OTA west of pier looking east */
      slewphase = 1;
      encoderaz = newha0*15. + 90.;
      encoderalt = newdec0 - 90.;
    }
    else if ((newha0 > 0.) && ( newha0 <= 6.))
    { 
      /*OTA east of pier looking west */
      slewphase = 1;
      encoderaz = newha0*15. - 90.;
      encoderalt = 90. - newdec0;
    }
    else if ((newha0 > 6.) && ( newha0 < 12.))
    { 
      /* OTA west of pier looking below the pole */
      slewphase = 1;
      encoderaz = newha0*15. - 90.;
      encoderalt = 90. - newdec0;
    }    
    else
    {
      fprintf(stderr,"German equatorial slew request outside limits\n");
      return(0);      
    }

    /* Tests for safe slew based on encoder readings would go here */
        
    /* Test need for two-segment slew for changes of more than 90 degrees */
    
    if ((fabs(mtraltdeg - encoderalt) > 90.1) || 
      (fabs(mtrazmdeg - encoderaz) > 90.1))
    {
      
      /* Slew request of more than 90 degrees on one axis */
      
      if ( fabs(mtraltdeg) > 10. )
      {
        
        /* Telescope currently more than 10 degrees from the pole in dec */
        /* Set new target to a standard switch position */
        
        encoderalt = -1.;
        encoderaz =   1.;
        slewphase = 2;
      }  
    }

    /* Test for safe GEM slew would go here */

  }
  
  /* Equatorial fork */
  
  if (telmount == EQFORK)
  {
    slewphase = 1;
    encoderaz = newha0*15.;
    encoderalt = newdec0;

    /* Test for safe EQFORK slew would go here */

  }
  
  /* Alt-az fork */
  
  if (telmount == ALTAZ)
  {
    slewphase = 1;
    encoderaz = newaz0;
    encoderalt = newalt0;

    /* Tests for safe ALTAZ slew would go here */

  }
        
  /* Convert encoder angle readings to target encoder counter readings */

  azcount = encoderaz/mtrazmcal;
  altcount = encoderalt/mtraltcal;
  
  /* Stop tracking motion and prior slews if any first */
  /* Delays added to allow controller to processes requests */
  
  /* Send mount to target */
  /* Note that A200HR assigns X to alt and Y to az */
 
  
  sprintf(slewcmd,"YN\r");
  tcflush(TelPortFD,TCIOFLUSH);
  writen(TelPortFD,slewcmd,3);
  
  usleep(100000);
  
  sprintf(slewcmd,"XN\r");
  tcflush(TelPortFD,TCIOFLUSH);
  writen(TelPortFD,slewcmd,3);
  
  usleep(100000);

  sprintf(slewcmd,"Y%dS%d\r",azcount,gotorate);
  nsend = strlen(slewcmd);
  tcflush(TelPortFD,TCIOFLUSH);
  writen(TelPortFD,slewcmd,nsend);
  
  usleep(100000);
    
  sprintf(slewcmd,"X%dS%d\r",altcount,gotorate);
  nsend = strlen(slewcmd);
  tcflush(TelPortFD,TCIOFLUSH);
  writen(TelPortFD,slewcmd,nsend);  
  
  /* A slew is in progress */

  return(1);
}

/* Low level check of slew status on both axes */
/* Advise using CheckGoTo in external applications */
/* Return a flag indicating whether a slew is now in progress */
/*   1 -- slew is in progress on either drive */
/*   0 -- slew not in progress for either drive */

int GetSlewStatus(void)
{
  char sendstr[32] = "";
  char returnstr[32] = "";
  int numread;
    
  /* Query azimuth "Y" drive first                           */
  /* Test for large velocity                                 */
  /* This will return 0 if the telescope is in tracking mode */
  
  sprintf(sendstr,"YS\r");
  tcflush(TelPortFD,TCIOFLUSH);
  writen(TelPortFD,sendstr,3);
  numread=readn(TelPortFD,returnstr,8,1);
  if (numread > 4)
  {
    return(1);
  }  
    
  /* Query altitude "X" drive if azimuth drive is not slewing */

  sprintf(sendstr,"XS\r");
  tcflush(TelPortFD,TCIOFLUSH);
  writen(TelPortFD,sendstr,3);
  numread=readn(TelPortFD,returnstr,8,1);
  if (numread > 4)
  {
    return(1);
  }
    
  return(0);
}


/* Test whether the destination was reached                  */
/* Initiate the next segment if slewphase is greater than 1  */
/* Reset slewphase when goto has finished a segment          */
/* Return value is                                           */
/*   0 -- goto in progress                                   */
/*   1 -- goto complete within tolerance                     */
/*   2 -- goto complete but outside tolerance                */

int CheckGoTo(double desRA, double desDec, int pmodel)
{
  double telra1, teldec1;
  double errorRA, errorDec, nowRA, nowDec;
  double tolra, toldec;

  /* Is the telescope slewing? */
    
  if ( GetSlewStatus() == 1 )
  {
    /* One or more axes remain in motion */
    /* Try again later */
    
    return(0);
  }
  
  /* Was this a two-phase slew? */
  
  if ( slewphase == 2 )
  {
        
    /* Reset the slew phase and continue to the destination */
    
    slewphase = 0;    
    
    /* Go to the original destination */
    /* GoToCoords will change slewphase to 1 */
        
    GoToCoords(desRA, desDec, pmodel);
        
    /* Return a flag indicating a new goto operation is in progress */
    
    return(0);
  }
  else if ( slewphase == 1 )
  {    
      
    /* No axes are moving. Insure that tracking is started again. */
    
    StartTrack();
    
    /* Where are we now? */
  
    GetTel(&nowRA, &nowDec, pmodel);

    /* Compare to destination with pre-defined tolerances */
     
    telra1 = desRA;
    teldec1 = desDec;
        
    /* RA slew tolerance in hours */
    
    tolra = SLEWTOLRA;
    
    /* Dec slew tolerance in degrees */
    
    toldec = SLEWTOLDEC;

    /* What is the absolute value of the pointing error? */
  
    /* Magnitude of RA pointing error in hours */
    
    errorRA = fabs(nowRA - telra1);
    
    /* Magnitude of Dec pointing error in degrees */
    
    errorDec = fabs(nowDec - teldec1);
  
    /* Compare and notify whether we are within tolerance */

    if ( ( errorRA > tolra ) || ( errorDec > toldec ) )
    {
      /* Result of slew is outside acceptable tolerance */
      /* Signal the calling routine that another goto may be needed */
    
      slewphase = 0;
      return(2);
    }
  }    
  else
  {
    /* Unexpected slew phase */
    /* Reset and return success without a test */
    /* This should clear errors and enable another slew request from the UI */
    /* Better would be to flag an error but that might have unintended consequences */
  
    slewphase = 0;    
  } 
  return(1); 
}

/* Coordinates and time */

/* Synchronize remote telescope to this ra-dec pair */
/* In this inteface simply update global offsets */

int SyncTelOffsets(double newoffsetra, double newoffsetdec)
{
  offsetra = newoffsetra;
  offsetdec = newoffsetdec;
  return 0;
}

/* Synchronize remote telescope to this UTC */

int SyncTelToUTC(double newutc)
{
  return 0;
}

/* Synchronize remote telescope to this observatory location  */

int SyncTelToLocation(double newlong, double newlat, double newalt)
{
  return 0;
}

/* Synchronize remote telescope to this local sidereal time  */

int SyncTelToLST(double newlst)
{
  return 0;
}

/* Start sidereal tracking on all axes at default rates      */
/* Can be generalized to triaxial tracking for alt-az mounts */
/* Rates are actively adjusted by CenterGuide and reset here */

void StartTrack(void)
{
  
  char slewcmd[32] = ""; 
  int nsend;

  SetGuideTargets();
  
  /* Default rates and targets should be set elsewhere to reasonable values */
  /* GuideTrack will update rates based on mount encoder readings           */
  /* A call to StartTrack will restore default rates                        */
  /* For an equatorial mount it sets                                        */
  /* RA at the sidereal rate and Dec off                                    */
  
  /* Tests of GEM basis go here with assignment of azmtracktarget           */   
  
  if (telmount != ALTAZ)
  {
  
    /* Start azimuth (RA) axis tracking at sidereal rate                    */
    /* Use the ASCII set velocity command for the azimuth (Y) axis          */
    
    azmtracktarget = wtarget;
    
    sprintf(slewcmd,"Y%dS%d\r",azmtracktarget,azmtrackrate0);  
    nsend = strlen(slewcmd);
    tcflush(TelPortFD,TCIOFLUSH);  
    writen(TelPortFD,slewcmd,nsend);
    
    usleep(100000);
    
    /* Turn off any altitude (Dec) axis tracking */
    
    sprintf(slewcmd,"XS0\r");  
    nsend = strlen(slewcmd);
    tcflush(TelPortFD,TCIOFLUSH);  
    writen(TelPortFD,slewcmd,nsend);  
    
  }
  else
  {  
    /* This branch would not be executed for an A200HR mount             */
    /* It may be useful for other applications of the Sidtech controller */
    /* Set the tracking rates and targets based on altitude and azimuth  */
        
    /* Code to start triaxial tracking goes here                         */
  }
  
  return;
} 


/* Maintain target center using mount encoders                       */
/* Adjust motor rates on both axes based on pointing model           */
/* Setting of pmodel should match that used to find reference center */

void CenterGuide(double centerra, double centerdec, 
  int raflag, int decflag, int pmodel)
{
  char slewcmd[32] = ""; 
  int nsend;
  double telra, teldec;
  double raerr, decerr;
  double rarate, decrate;
  double deltime;

  SetGuideTargets();
  
  deltime = 1.;
 
  /* Do nothing unless flags are set */
  
  if ((raflag == 0) && (decflag == 0))
  {
    return;
  }   
  
  /* Grab latest integer tracking rates in floating point */
  
  rarate = azmtrackrate0;
  decrate = alttrackrate0;

  /* Get the telescope coordinates now */
  
  GetTel(&telra, &teldec, pmodel);
    
  /* Update pointing errors in seconds of arc                 */
  /* Allow for 24 hour ra wrap and dec at the celestial poles */
  
  raerr  = 3600.*15.*Map12(telra - centerra);
  if (fabs(teldec) < 89. )
  {
    decerr = 3600.*(teldec - centerdec);
  }
  else
  {
    decerr = 0.;
  }
  
  /* Calculate new tracking rates based on these errors           */
  /* Assume a deltime second duration at this rate to correct the error */
  
  rarate = rarate + rarate*(raerr/15.)*(1./deltime));
  decrate =   decrate*(decerr/15.)*(1./deltime));
  
  azmtrackrate = (int) rarate;
  azmtracktarget = wtarget;
  if ( azmtrackrate < 0 )
  {
    azmtrackrate = 0;
  }
  
  alttrackrate = (int) decrate;
  alttracktarget = ntarget;
  if ( alttrackrate < 0 )
  {
    alttrackrate = - 1*altrackrate;
    alttracktarget = starget;  
  }
  
  /* Use the ASCII set velocity command for the azimuth (Y) axis */
    
  sprintf(slewcmd,"Y%dS%d\r",azmtracktarget,azmtrackrate);  
  nsend = strlen(slewcmd);
  tcflush(TelPortFD,TCIOFLUSH);  
  writen(TelPortFD,slewcmd,nsend);
  
  usleep(100000);
  
  /* Use the ASCII set velocity command for the altitude (X) axis */
  
  sprintf(slewcmd,"X%dS%d\r",alttracktarget,alttrackrate); 
  nsend = strlen(slewcmd);
  tcflush(TelPortFD,TCIOFLUSH);  
  writen(TelPortFD,slewcmd,nsend);  
        
  return;
}

/* Stop tracking */

void StopTrack(void)
{
  
  char slewcmd[32] = "";
  
  sprintf(slewcmd,"YN\r");
  tcflush(TelPortFD,TCIOFLUSH);
  writen(TelPortFD,slewcmd,3);
  
  if (telmount == ALTAZ)
  {
    usleep(100000);
    sprintf(slewcmd,"XN\r");
    tcflush(TelPortFD,TCIOFLUSH);
    writen(TelPortFD,slewcmd,3);  
  }
  
  return;
}


/* Set guide targets to match telescope on mount */

void SetGuideTargets(void)
{

  /* Add check of telescope encoders here */
  
  ntarget = 90.*mtraltcal;
  starget = -90.*mtraltcal;
  wtarget = 90.*mtrazmcal;
  etarget = -90.*mtrazmcal;

}


/* Full stop */

void FullStop(void)

{  
  char slewcmd[32] = "";
  
  sprintf(slewcmd,"XN\r");
  tcflush(TelPortFD,TCIOFLUSH);
  writen(TelPortFD,slewcmd,3);
  usleep(100000);
  sprintf(slewcmd,"YN\r");
  tcflush(TelPortFD,TCIOFLUSH);
  writen(TelPortFD,slewcmd,3);
  return;
}

/* Set slew limits control off or on */

int SetLimits(int limits)
{
  if ( limits == TRUE )
  {
    fprintf(stderr,"Limits enabled\n"); 
  
  }
  else
  {
    limits = FALSE;
    fprintf(stderr,"Limits disabled\n");   
  }
       
  return (limits);
}


/* Get status of slew limits control */

int GetLimits(int *limits)
{
  int sidtechlimits;
  sidtechlimits = 0;
  
  if ( sidtechlimits == 1 )
  {
    *limits = 1;
  }
  else
  {
    *limits = 0;
  }

  return (sidtechlimits);
}
  


/* Control the dew and drive heaters */

void Heater(int heatercmd)
{
  char cmdstr[256];
  sprintf(cmdstr,"setheater %d 1>/dev/null 2>/dev/null", heatercmd);
  system(cmdstr);   
  return;
}

/* Control the telescope fans */

void Fan(int fancmd)
{
  char cmdstr[256];
  sprintf(cmdstr,"setfan %d 1>/dev/null 2>/dev/null", fancmd);
  system(cmdstr);    
  return;
}


/* Adjust the focus using an external routine */
/* The routine will time out on its own and report through the status file */

void Focus(int focuscmd, int focusspd)
{
  char cmdstr[256];
  sprintf(cmdstr,"setfocus %d %d  1>/dev/null 2>/dev/null", focuscmd, focusspd);
  system(cmdstr);  
  return;
}


/* Report the current focus reading from the status file */

void GetFocus(double *telfocus)
{
  int nread;
  double current_focus;
  char cmdstr[256];
  sprintf(cmdstr,"getfocus 1>/dev/null 2>/dev/null");
  system(cmdstr);  
  
  focusfile = (char*) malloc (MAXPATHLEN);
  strcpy(focusfile,FOCUSFILE);
  fp_focus = fopen(focusfile, "r");
  if (fp_focus == NULL)
  {
    return;
  }
  
  nread = fscanf(fp_focus, "%lg", &current_focus);
  fclose(fp_focus);
  
  if (nread !=0)
  {
    *telfocus = current_focus;
  }
  
  return;  
}


/* Adjust the rotation */

void Rotate(int rotatecmd, int rotatespd)
{
  char cmdstr[256];
  sprintf(cmdstr,"setrotate %d %d  1>/dev/null 2>/dev/null", rotatecmd, rotatespd);
  system(cmdstr);
}

/* Report the rotation setting */

void GetRotate(double *telrotate)
{
  int nread;
  double current_rotate;
  char cmdstr[256];
  sprintf(cmdstr,"getrotate 1>/dev/null 2>/dev/null");
  system(cmdstr);  
  
  rotatefile = (char*) malloc (MAXPATHLEN);
  strcpy(rotatefile,ROTATEFILE);
  fp_rotate = fopen(rotatefile, "r");
  if (fp_rotate == NULL)
  {
    *telrotate = 0.;
    return;
  }
  
  nread = fscanf(fp_rotate, "%lg", &current_rotate);
  fclose(fp_rotate);
  
  if (nread !=0)
  {
    *telrotate = current_rotate;
  }
  
  return;  
}

/* Read and report the temperature */

void GetTemperature(double *teltemperature)
{
  int nread;
  double current_temperature = 20.;
  char cmdstr[256];
  sprintf(cmdstr,"gettemperature 1>/dev/null 2>/dev/null");
  system(cmdstr);  
  
  temperaturefile = (char*) malloc (MAXPATHLEN);
  strcpy(temperaturefile,TEMPERATUREFILE);
  fp_rotate = fopen(temperaturefile, "r");
  if (fp_temperature == NULL)
  {
    *teltemperature= 0.;
    return;
  }
  
  nread = fscanf(fp_temperature, "%lg", &current_temperature);
  fclose(fp_temperature);
  
  if (nread !=0)
  {
    *teltemperature = current_temperature;
  }
  

  *teltemperature = current_temperature;
  
  return;   
}


/* Time synchronization utilities */

/* Reset the telescope sidereal time */

int  SyncLST(double newTime)
{		
  fprintf(stderr,"XmTel uses computer time and site location only \n");
  return -1;
}


/*  Reset the telescope local time */

int  SyncLocalTime()
{
  fprintf(stderr,"XmTel uses computer time only \n");
  return -1;
}


/* Serial port utilities */

static int writen(fd, ptr, nbytes)
int fd;
char *ptr;
int nbytes;
{
  int nleft, nwritten;
  nleft = nbytes;
  while (nleft > 0) 
  {
    nwritten = write (fd, ptr, nleft);
    if (nwritten <=0 ) break;
    nleft -= nwritten;
    ptr += nwritten;
  }
  return (nbytes - nleft);
}

static int readn(fd, ptr, nbytes, sec)
int fd;
char *ptr;
int nbytes;
int sec;
{
  int stat;
  int nleft, nread;
  nleft = nbytes;
  while (nleft > 0) 
  {
    stat = telstat(fd,sec,0);
    if (stat <=  0 ) break;
    nread  = read (fd, ptr, nleft);
    if (nread <= 0)  break;
    nleft -= nread;
    ptr += nread;
  }
  return (nbytes - nleft);
}

/* Examines the read status of a file descriptor.                       */
/* The timeout (sec, usec) specifies a maximum interval to              */
/* wait for data to be available in the descriptor.                     */
/* To effect a poll, the timeout (sec, usec) should be 0.               */
/* Returns non-negative value on data available.                        */
/* 0 indicates that the time limit referred by timeout expired.         */
/* On failure, it returns -1 and errno is set to indicate the error.    */

static int telstat(fd,sec,usec)
register int fd, sec, usec;
{
  int ret;
  int width;
  struct timeval timeout;
  telfds readfds;

  memset((char *)&readfds,0,sizeof(readfds));
  FD_SET(fd, &readfds);
  width = fd+1;
  timeout.tv_sec = sec;
  timeout.tv_usec = usec;
  ret = select(width,&readfds,NULL_PTR(telfds),NULL_PTR(telfds),&timeout);
  return(ret);
}

