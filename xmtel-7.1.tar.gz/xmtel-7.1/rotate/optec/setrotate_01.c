/* -------------------------------------------------------------------------- */
/* -                         Pyxis Rotator Control                          - */
/* -------------------------------------------------------------------------- */
/*                                                                            */
/* Copyright 2010 John Kielkopf                                               */
/*                                                                            */
/* Distributed under the terms of the General Public License (see LICENSE)    */
/*                                                                            */
/* John Kielkopf (kielkopf@louisville.edu)                                    */
/*                                                                            */
/* Date: November 26, 2010                                                    */
/* Version: 1.0                                                               */
/*                                                                            */
/* History:                                                                   */
/*                                                                            */
/* November 26, 2010                                                          */
/*   Version 1.0                                                              */
/*     Released                                                               */


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <time.h>
#include <sys/time.h>
#include <unistd.h>
#include <fcntl.h>
#include <termios.h>

#include <sys/ioctl.h>
#include <sys/stat.h>
#include <sys/types.h>

#include "rotate.h"


#define NULL_PTR(x) (x *)0

#ifndef TRUE
#define TRUE 1
#endif

#ifndef FALSE
#define FALSE 0
#endif


/* Communications variables and routines for internal use */

static int rotatorportfd;
static int rotatorconnectflag = FALSE;

/*  commands */

int CheckConnectRotator(void);
int ConnectRotator(void);
int SetRotator(int rotatecmd, double angle);
int GetRotator(double *angle);
int WriteRotator(double angle);
int SetRotatorHome(void);
int DisconnectRotator(void);

/* Serial port utilities */

typedef fd_set telfds;

static int readn(int fd, char *ptr, int nbytes, int sec);
static int writen(int fd, char *ptr, int nbytes);
static int telstat(int fd,int sec,int usec);


/* Main program */

int main(int argc, char *argv[])
{
  double angle;
  int flag;
  int rotatecmd; 
  int delay;
  char *testrotate;

  if (argc != 3) 
  { 
    printf("\n");
    printf("Usage: setrotate cmd angle\n");
    printf("\n");
    printf("Set the rotator and report current angle \n");
    printf("\n");
    printf("Command:  4 (home)\n");
    printf("Command:  3 (sidereal)\n");
    printf("Command:  2 (cw)\n");
    printf("Command:  1 (ccw)\n");
    printf("Command:  0 (stop)\n"); 
    printf("\n");
    return(0);
  }
  
  
  rotatecmd = strtod(argv[1],&testrotate);
  if ( (rotatecmd < 0) || (rotatecmd > 4) )
  {
    return(0);
  }
  angle = strtod(argv[2],&testrotate);
  if ( (angle < 0.) || (angle > 359.999) )
  {
    return(0);
  }
  flag = ConnectRotator();
  if (flag == FALSE)
  {
    fprintf(stderr,"Cannot connect to rotator ...\n");
    return(0);
  }  
  SetRotator(rotatecmd, angle);
  GetRotator(&angle);
  WriteRotator(angle);
  flag = DisconnectRotator();
  return(0);
} 

/* Report on rotator connection status */

int CheckConnectRotator(void)
{
  if (rotatorconnectflag == TRUE)
  {
    return(TRUE);
  }
  else
  {
    return(FALSE);
  }
}


/* Connect to the rotator serial interface */
/* Sets rotatorconnectflag TRUE and returns TRUE on success */

int ConnectRotator(void)
{
  struct termios tty;
  char sendstr[32]; 
  char returnstr[32];
  char rotatorport[32];
  int numread;
  
  DisconnectRotator();
  
  /* Make the connection */

  strcpy(rotatorport,ROTATORPORT);
  rotatorportfd = open(rotatorport,O_RDWR);
  if(rotatorportfd == -1)
  {
    fprintf(stderr,"The rotator serial port not available ... \n");
    rotatorconnectflag = FALSE;
    return(0) ;
  }
  
  rotatorconnectflag = TRUE;
  
  tcgetattr(rotatorportfd,&tty);
  cfsetospeed(&tty, (speed_t) B19200);
  cfsetispeed(&tty, (speed_t) B19200);
  tty.c_cflag = (tty.c_cflag & ~CSIZE) | CS8;
  tty.c_iflag =  IGNBRK;
  tty.c_lflag = 0;
  tty.c_oflag = 0;
  tty.c_cflag |= CLOCAL | CREAD;
  tty.c_cc[VMIN] = 1;
  tty.c_cc[VTIME] = 5;
  tty.c_iflag &= ~(IXON|IXOFF|IXANY);
  tty.c_cflag &= ~(PARENB | PARODD);
  tcsetattr(rotatorportfd, TCSANOW, &tty);



  /* Flush the input (read) buffer */

  tcflush(rotatorportfd,TCIOFLUSH);
  
  /* Establish communications */
  
  strcpy(sendstr,"CCLINK\r");
  writen(rotatorportfd,sendstr,7);
  usleep(1000000);
  numread=readn(rotatorportfd,returnstr,1,2);
    
  if ( returnstr[0]!='!' )
  {
    /* Try again */
    
    writen(rotatorportfd,sendstr,7);
    usleep(1000000);
    numread=readn(rotatorportfd,returnstr,1,2);
    if ( returnstr[0]!='!' )
    {
      /* Cannot connect so give up and return */
    
      return(0);
    } 
  }
             
  rotatorconnectflag = TRUE;
      
  /* Flush the input buffer in case there is something left from startup */

  tcflush(rotatorportfd,TCIOFLUSH);

  return(1);
}

/* Home */

int SetRotatorHome(void)
{
  char sendstr[32];
  char returnstr[32];
  int flag;
  
  sprintf(sendstr,"CHOMES\r");
  writen(rotatorportfd,sendstr,7);
  
  fprintf(stderr,"Homing rotator ...\n");
  
  /* Look for 'F' completion of home cycle */
    
  flag = readn(rotatorportfd,returnstr,1,1);

  if ( returnstr[1] != 'F' ) 
  {
    /* Rotator did not home */
    
    fprintf(stderr,"Rotator did not find home.\n");
    return(1);       
  }
  return(0);
}

int SetRotator(int rotatecmd, double angle)
{
  
  /* Stop rotation */
  if (rotatecmd == 0)
  {
    return(1);
  }
  
  /* Rotate CCW */
  if (rotatecmd == 1)
  {
    SetRotatorDirection(0);
    SetRotatorAngle(angle);
    return(1);
  }
  
  /* Rotate CW */
  if (rotatecmd == 2)
  {
    SetRotatorDirection(1);
    SetRotatorAngle(angle);  
    return(1);
  }
  
  /* Run at sidereal rate */
  /* With Pyxis this requires a daemon to constantly step the angle */
  
  if (rotatecmd == 3)
  {
    fprintf(stderr,"Support for sidereal rate on Pyxis not yet implemented.\n");
    return(0);
  }
  
  /* Home the rotator */
  if (rotatecmd == 4)
  {
    SetRotatorHome();
    return(1);
  }  
  fprintf(stderr,"Unknown rotate command.\n");
  return(0);
}
    

/* Set rotator to selected angle */

int SetRotatorAngle(double angle)
{
  char sendstr[32];
  char returnstr[32];
  int rotatorangle = 0;
  int flag;

  if ((angle < 0.) || (angle > 359.999))
  {
    fprintf(stderr,"Position angle must be in the range 0 to 359.999 degrees.\n");
    return(0);
  }
  
  /* Pyxis uses integer angles */
  
  sprintf(sendstr,"CPA000\r");
  rotatorangle = (int) angle;
  
  /* The new position angle is entered as nnn degrees*/
  /* Pyxis accepts integer values from 000 to 359 */
  /* It requires left justified zeros as fill: 181 081 or 001 */
    
  sprintf(sendstr,"CPA%3d\r",rotatorangle);
  if (rotatorangle < 100)
  {
    sendstr[3] = '0';
  }
  if (angle < 10.)
  {
    sendstr[4] = '0';
  }  

  sendstr[6]='\r';
  flag = writen(rotatorportfd,sendstr,7);
  fprintf(stderr,"nsent=%d angle=%d\n",flag,rotatorangle);
  
  /* Wait for 'F' to indicate completion of request */

  for (;;) 
  {
    flag = readn(rotatorportfd,returnstr,1,1);
    fprintf(stderr,"nread=%d %x\n",flag,returnstr[0]);
    if (returnstr[0] == 'F') 
    {
      break;
    }  
  }   
  return(1);
}

/* Set rotator direction of motion */
/* Direction 0 is CCW and 1 is CW */

int SetRotatorDirection(int direction)
{
  char sendstr[32];
  char returnstr[32];

  if ((direction < 0) || (direction > 1))
  {
    return(0);
  }
    
  sprintf(sendstr,"CD0xxx\r");
  if (direction == 1)
  {
    sendstr[2] = '1';
  }
  writen(rotatorportfd,sendstr,7);

  return(1);
}


/* Return the current rotator angle */

int GetRotator(double *angle)
{
  char sendstr[32];
  char returnstr[32];
  int numread;
  int rotator_angle;

  sprintf(sendstr,"CGETPA\r");
  writen(rotatorportfd,sendstr,7);
  numread=readn(rotatorportfd,returnstr,1,1);
  returnstr[3] = '\0'; 
  sscanf(returnstr,"%d",&rotator_angle);
  *angle = rotator_angle;   
  return(1);
}


/* Close serial connection to  IFW and reset rotatorconnectflag */

int DisconnectRotator(void)
{
  if(rotatorconnectflag == TRUE)
  {
    close(rotatorportfd);
    rotatorconnectflag = FALSE;
    return(TRUE);
  }
  rotatorconnectflag = FALSE;
  return(FALSE);
}


/* Write rotator reading to stdout and to a system status file */

int WriteRotator(double angle)
{
  FILE* outfile;
  outfile = fopen("/usr/local/observatory/status/telrotate","w");
  if ( outfile == NULL )
  {
    fprintf(stderr,"Cannot update telrotate status file\n");
    return FALSE;
  }

  fprintf(stdout, "%.1f\n", angle); 
  fprintf(outfile, "%lf\n", angle);      
  fclose(outfile);
  return TRUE;
}


/* Serial port utilities */

static int writen(fd, ptr, nbytes)
int fd;
char *ptr;
int nbytes;
{
  int nleft, nwritten;
  nleft = nbytes;
  while (nleft > 0) 
  {
    nwritten = write (fd, ptr, nleft);
    if (nwritten <=0 ) break;
    nleft -= nwritten;
    ptr += nwritten;
  }
  return (nbytes - nleft);
}

static int readn(fd, ptr, nbytes, sec)
int fd;
char *ptr;
int nbytes;
int sec;
{
  int stat;
  int nleft, nread;
  nleft = nbytes;
  while (nleft > 0) 
  {
    stat = telstat(fd,sec,0);
    if (stat <=  0 ) break;
    nread  = read (fd, ptr, nleft);

/*  Diagnostic */    
    
/*    printf("readn: %d read\n", nread);  */

    if (nread <= 0)  break;
    nleft -= nread;
    ptr += nread;
  }
  return (nbytes - nleft);
}

/*
 * Examines the read status of a file descriptor.
 * The timeout (sec, usec) specifies a maximum interval to
 * wait for data to be available in the descriptor.
 * To effect a poll, the timeout (sec, usec) should be 0.
 * Returns non-negative value on data available.
 * 0 indicates that the time limit referred by timeout expired.
 * On failure, it returns -1 and errno is set to indicate the
 * error.
 */
static int telstat(fd,sec,usec)
register int fd, sec, usec;
{
  int ret;
  int width;
  struct timeval timeout;
  telfds readfds;

  memset((char *)&readfds,0,sizeof(readfds));
  FD_SET(fd, &readfds);
  width = fd+1;
  timeout.tv_sec = sec;
  timeout.tv_usec = usec;
  ret = select(width,&readfds,NULL_PTR(telfds),NULL_PTR(telfds),&timeout);
  return(ret);
}

