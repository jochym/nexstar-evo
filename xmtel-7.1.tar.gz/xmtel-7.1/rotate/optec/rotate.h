/* -------------------------------------------------------------------------- */
/* -                  Optec Pyxis Rotator Header File                       - */
/* -------------------------------------------------------------------------- */
/*                                                                            */
/* Copyright 2010 John Kielkopf                                               */
/*                                                                            */
/* Distributed under the terms of the General Public License (see LICENSE)    */
/*                                                                            */
/* John Kielkopf (kielkopf@louisville.edu)                                    */
/*                                                                            */
/* Date: November 25, 2010                                                    */
/* Version: 1.0                                                               */
/*                                                                            */
/* History:                                                                   */
/*                                                                            */
/* November 25, 2010                                                          */
/*   Version 1.0                                                              */
/*     Released                                                               */
                                                                         
/* Parameters for the Optec Pyxis rotator are defined here                    */

/* Serial port for rotator */



/* #define ROTATORPORT "/dev/ttyS0" */

#define ROTATORPORT "/dev/ttyUSB0"
