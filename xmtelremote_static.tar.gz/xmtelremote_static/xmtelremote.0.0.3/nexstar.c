/* -------------------------------------------------------------------------- */
/* -      Protocol for NexStar auxiliary command set telescope control      - */
/* -------------------------------------------------------------------------- */
/*                                                                            */
/* Copyright 2010 John Kielkopf                                               */
/*                                                                            */
/* Distributed under the terms of the General Public License (see LICENSE)    */
/*                                                                            */
/* John Kielkopf (kielkopf@louisville.edu)                                    */
/*                                                                            */
/* Date: August 21, 2010                                                      */
/* Version: 5.2.0                                                             */
/*                                                                            */
/* History:                                                                   */
/*                                                                            */
/* January 1, 2009                                                            */
/*   Version 1.0                                                              */
/*     Released                                                               */
/*                                                                            */
/* July 27, 2009                                                              */
/*   Version 1.1                                                              */
/*     Home position included                                                 */
/*                                                                            */
/* August 12, 2009                                                            */
/*   Version 1.2                                                              */
/*     Encoder count to alt and az mapping error fixed                        */
/*                                                                            */
/* October 28, 2009                                                           */
/*   Version 1.3                                                              */
/*     GEM alt encoder zero point changed                                     */
/*     Encoder count to ra/dec rewritten                                      */
/*                                                                            */
/* November 12, 2009                                                          */
/*   Version 1.3                                                              */
/*     Focus encoder count corrected                                          */
/*                                                                            */
/* November 14, 2009                                                          */
/*   Version 1.4                                                              */
/*     GEM alt encoder sign error fixed                                       */
/*     Focus encoder calibrated in microns                                    */
/*                                                                            */
/* November 14, 2009                                                          */
/*   Version 1.5                                                              */
/*     Fan control and temperature readout added                              */
/*                                                                            */
/* November 28, 2009                                                          */
/*   Version 1.6                                                              */
/*     Focus calibration moved to header file                                 */
/*                                                                            */
/* November 30, 2009                                                          */
/*   Version 1.7                                                              */
/*     Modified slew across meridian                                          */
/*                                                                            */
/* December 2, 2009                                                           */
/*   Version 1.8                                                              */
/*     Corrected reading on following east to west across meridian            */
/*                                                                            */
/* December 21, 2009                                                          */
/*   Version 1.9                                                              */
/*     Two phase slew modified near the pole                                  */
/*                                                                            */
/* August 11, 2010                                                            */
/*   Version 5.2.0                                                            */
/*     Bumped version number to match parent xmtel                            */
/*     Removed unused timer count from focus encoder routine                  */
/*     Changed SyncTelOffsets to return void                                  */
/*     Removed time sync routines that were not used                          */
/*     Corrected apparent error in GoToCoords where we had not set            */
/*       pmodel=RAW before asking for initial mount coordinates               */
/*     Added device option for serial port                                    */
/*                                                                            */
/* March 01, 2013                                                             */
/*	serial routines replaced
 	all code not related to protocol moved
 	header file split to "expose" only the protocol functions				  
 	SetTelEncoders renamed SetTel											  */
 	


#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>
#include <unistd.h>

#include <termios.h>

#include "nexstar.h"
#include "ttycom.h"
#include "algorithms.h"
#include "pointing.h"
#include "logging.h"

#define NULL_PTR(x) (x *)0

/* There are two classes of routines defined here:                            */

/*   XmTel commands to allow generic access to the controller.                */
/*   NexStar specific commands and data.                                      */


/* System variables and prototypes */
static int ttyread(int fd, char *buf);
static int ttywrite(int fd, const char * buffer, int nbytes);
static int getMountAck (char *sendstr, int sendlen);
static int getMountString(char *sendstr, int sendlen, char *returnstr, int expected);
static int tryMountAck (char *sendstr, int sendlen);
static int tryMountString(char *sendstr, int sendlen, char *returnstr, int expected);
static int GetSlewStatus(mount *mnt);

/* NexStar local data */
static int slewphase = 0;             			/* Slew sequence counter 									*/
static double telencoderalt = 0.;    			/* Global encoder angle updated by GetTel 					*/
static double telencoderaz = 0.;      			/* Global encoder angle updated by GetTel 					*/
static char trkRate[3] = {0xff, 0xff, 0x00}; 	/* Track speed default to sidereal 							*/

/* Set global switch angles for a GEM OTA over the pier pointing at pole   									*/
/* They correspond to ha ~ -6 hr and dec ~ +90 deg for northern telescope  									*/
/* They correspond to ha ~ +6 hr and dec ~ -90 deg for southern telescope  									*/
/* Non-zero values work better in goto routines on nexstar                									*/    
static double switchaz = 1.; 					/* Global encoder angle of switch position only used if GEM */
static double switchalt = -1.0;					/* Global encoder angle of switch position only used if GEM */

/* Communications variables and routines for internal use */
static int TelPortFD;
static int TelConnectFlag = FALSE;
static char strMsgLine[256];
static char ttyerrormsg[TTY_ERRMSG_SIZE];

#include "protocol.c"

/* Handcontroller auxiliary command interfacing notes                        */
/*                                                                           */
/* The command format for a connection through the hand controller is        */  
/*                                                                           */
/*   0x50          code requesting that the data pass through to the motors  */    
/*   msgLen        how many bytes including msgId  and valid data bytes      */
/*   destId        AUX command set destination number                        */
/*   msgId         AUX command set message number                            */
/*   data1-3       bytes of message data                                     */
/*   responseBytes number of bytes in response                               */
/*                                                                           */
/* For example, the command to get data from the focus motor is              */
/*                                                                           */
/*   focusCmd[8] = { 0x50, 0x01, 0x12, 0x01, 0x00, 0x00, 0x00, 0x03 }        */
 
/* Report on telescope connection status */
int CheckConnectTel(void)
{
  if (TelConnectFlag == TRUE)
  {
    return TRUE;
  }
  else
  {
    return FALSE;
  }
}


/* Connect to the telescope serial interface */
/* Returns without action if TelConnectFlag is TRUE */
/* Sets TelConnectFlag TRUE on success */
int ConnectTel(char *telserial)
{  
	/* Packet for simplest communication test */
	//char sendstr[] = { 0x4B, 0x58 }; //KX
	char sendstr[1] = { 0x56 }; //V
	char returnstr[RES_LEN];
	int err_code = 0;
	
	/* Send Packet (passthrough):  */
	/*   preamble                  */
	/*   packet length             */
	/*   destination               */
	/*   message id                */
	/*   three message bytes       */
	/*   number of response bytes  */

	/* Response Packet format:     */
	/*   response bytes if any     */
	/*   #                         */

	if(TelConnectFlag != TRUE)
	{
		/* Make the connection */
		if ((err_code = tty_connect(telserial, 9600, 8, 0, 1, &TelPortFD)) == TTY_OK)
		{
			sprintf(strMsgLine,"Port open %s\n", telserial);
			setMessage(strMsgLine);
			TelConnectFlag = TRUE;
			
			/* Some times a bonjour is needed */
			sprintf(strMsgLine,"Sendind a bonjour on %s\n", telserial);
			setMessage(strMsgLine);

			if (tryMountAck(sendstr, sizeof(sendstr)/sizeof(char)))
			{
				/* Test connectivity */
				if (tryMountString(sendstr, sizeof(sendstr)/sizeof(char), returnstr, 3))
				{
					sprintf(strMsgLine,"Got some lifesign on %s\n", telserial);
					//sprintf(strMsgLine,"%u %u %u %u %u %u\n", returnstr[0], returnstr[1], returnstr[2], returnstr[strlen(returnstr)- 1], strlen(returnstr));
					setMessage(strMsgLine);
					// We got some lifesign
					if (returnstr[2] == 0x23)
					{
						//We definitely have a mount, if not port and telconnectflag are set accordingly by getMountxxxx
						sprintf(strMsgLine,"Connected to serial port %s\n", telserial);
						setMessage(strMsgLine);
						TelConnectFlag = TRUE;
					}		
				} 
			}
			else
			{
				sprintf(strMsgLine,"Could not get Ack on bonjour\n");
				setMessage(strMsgLine);
			}
		}
		else
		{
			tty_error_msg(err_code, ttyerrormsg, TTY_ERRMSG_SIZE);
			setMessage(ttyerrormsg);
			sprintf(strMsgLine,"Serial port not available ... \n");
			setMessage(strMsgLine);
		}	
	}
	return(TelConnectFlag);
}

int CheckInfoTel(mount *mnt)
{
	/* Packet to request version of azimuth motor driver */  
	char sendstr[8] = { 0x50, 0x01, 0x10, 0xfe, 0x00, 0x00, 0x00, 0x02 };
	char sendtyp[1] = { 0x6D }; //m
	char sendver[1] = { 0x56 }; //V
	char returnstr[RES_LEN];
	int retval = 1;
	int model = 0;
	
	if (TelConnectFlag)
	{
		// Common par of feature list 
		mnt->modfeat[FLTRACK] = 1;
		mnt->modfeat[FLSITE] = 0;
		mnt->modfeat[FLGRATE] = 1;
		mnt->modfeat[FLPGUIDE] = 1;
		mnt->modfeat[FLFOCUS] = 1;
		mnt->modfeat[FLFAN] = 1;
		mnt->modfeat[FLHEATER] = 0;
		mnt->modfeat[FLROTAT] = 0;
		mnt->modfeat[FLRETIC] = 0;
		mnt->modfeat[FLMAXSLW] = 1;
		mnt->modfeat[FLLEVEL] = 0;
		// Hc version
		if (tryMountString(sendver, sizeof(sendver)/sizeof(char), returnstr, -1))
		{
			// Not all models return packet closing # so cannot use getMountString, must answer at once, though
			mnt->hcver[0] = returnstr[0];
			mnt->hcver[1] = returnstr[1];
			mnt->hcver[2] = '\0';
			sprintf(strMsgLine,"Hc protocol version %u.%u\n", returnstr[0], returnstr[1]);
			setMessage(strMsgLine);
		}
		else
		{
			mnt->hcver[0] = 0;
			mnt->hcver[1] = 0;
			mnt->hcver[2] = '\0';
			sprintf(strMsgLine,"Unrecognized mount\n");
			setMessage(strMsgLine);
			retval = 0;
		}

		if (retval)
		{
			// Mount type code
			if (tryMountString(sendtyp, sizeof(sendtyp)/sizeof(char), returnstr, 2))
			{
				//Celestron models return 2 bytes with closing #, other types don't. 
				//Not using getMountString to avoid excess waiting, due to timeout and retry.
				mnt->modcod[0] = returnstr[0];
				mnt->modcod[1] = '\0';
				model = (unsigned char) returnstr[0];
				if (model == 1)
				{
					sprintf(mnt->desc,"Celestron GPS Series");
					sprintf(strMsgLine,"Celestron GPS Series -%u-\n", model);
					if (!mnt->teltypefixed)
					{
						mnt->teltype = EQFORK;
					}
				}
				else if (model == 3)
				{
					sprintf(mnt->desc,"Celestron i-Series");
					sprintf(strMsgLine,"Celestron i-Series -%u-\n", model);
					if (!mnt->teltypefixed)
					{
						mnt->teltype = EQFORK;
					}
				}
				else if (model == 4)
				{
					sprintf(mnt->desc,"Celestron i-Series SE");
					sprintf(strMsgLine,"Celestron i-Series SE -%u-\n", model);
					if (!mnt->teltypefixed)
					{
						mnt->teltype = EQFORK;
					}
				}
				else if (model == 5)
				{
					sprintf(mnt->desc,"Celestron CGE");
					sprintf(strMsgLine,"Celestron CGE -%u-\n", model);
					if (!mnt->teltypefixed)
					{
						mnt->teltype = GEM;
					}
					//mnt->level = 1;
				}
				else if (model == 6)
				{
					sprintf(mnt->desc,"Celestron Advanced GT");
					sprintf(strMsgLine,"Celestron Advanced GT -%u-\n", model);
					if (!mnt->teltypefixed)
					{
						mnt->teltype = GEM;
					}
				}
				else if (model == 7)
				{
					sprintf(mnt->desc,"Celestron SLT");
					sprintf(strMsgLine,"Celestron SLT -%u-\n", model);
					if (!mnt->teltypefixed)
					{
						mnt->teltype = EQFORK;
					}
				}
				else if (model == 9)
				{
					sprintf(mnt->desc,"Celestron CPC");
					sprintf(strMsgLine,"Celestron CPC -%u-\n", model);
					if (!mnt->teltypefixed)
					{
						mnt->teltype = EQFORK;
					}
				}
				else if (model == 10)
				{
					sprintf(mnt->desc,"Celestron GT");
					sprintf(strMsgLine,"Celestron GT -%u-\n", model);
					if (!mnt->teltypefixed)
					{
						mnt->teltype = EQFORK;
					}
				}
				else if (model == 11)
				{
					sprintf(mnt->desc,"Celestron 4/5 SE");
					sprintf(strMsgLine,"Celestron 4/5 SE -%u-\n", model);
					if (!mnt->teltypefixed)
					{
						mnt->teltype = EQFORK;
					}
				}
				else if (model == 12)
				{
					sprintf(mnt->desc,"Celestron 6/8 SE");
					sprintf(strMsgLine,"Celestron 6/8 SE -%u-\n", model);
					if (!mnt->teltypefixed)
					{
						mnt->teltype = EQFORK;
					}
				}
				else
				{
					sprintf(mnt->desc,"Celestron mount %u", model);
					sprintf(strMsgLine,"Celestron mount -%u-\n", model);
					if (!mnt->teltypefixed)
					{
						mnt->teltype = EQFORK;
					}
				}
				setMessage(strMsgLine);
			}
			else
			{
				if (mnt->hcver[0] == 1)
				{
					// 1.x version
					mnt->modcod[0] = 10;
					mnt->modcod[1] = '\0';
					sprintf(mnt->desc,"Celestron GT");
					sprintf(strMsgLine,"Celestron GT (HC %u.%u)\n", mnt->hcver[0], mnt->hcver[1]);
					if (!mnt->teltypefixed)
					{
						mnt->teltype = EQFORK;
					}
				}
				else if (mnt->hcver[0] == 4 && mnt->hcver[1] == 16)
				{
					mnt->modfeat[FLRETIC] = 1;
					mnt->modfeat[FLLEVEL] = 1;
					mnt->modcod[0] = 5;
					mnt->modcod[1] = '\0';
					//mnt->level = 1;
					sprintf(mnt->desc,"Sphinx Sxd");
					sprintf(strMsgLine,"Sphinx Sxd (HC %u.%u)\n", mnt->hcver[0], mnt->hcver[1]);
					if (!mnt->teltypefixed)
					{
						mnt->teltype = GEM;
					}
				}
				else
				{
					mnt->modcod[0] = 99;
					mnt->modcod[1] = '\0';
					sprintf(mnt->desc,"Unknown mount");
					sprintf(strMsgLine,"Unknown mount (HC %u.%u)\nMaybe supported, if GEM, set tel.mount=2 in prefs.tel\n", mnt->hcver[0], mnt->hcver[1]);
					if (!mnt->teltypefixed)
					{
						mnt->teltype = EQFORK;
					}
				}
				setMessage(strMsgLine);
			}
			//fprintf(stderr, "mnt.modcod[0]: %u\n", mnt->modcod[0]);

			if (retval)
			{
				// Ra motor version version
				if (tryMountString(sendstr, sizeof(sendstr)/sizeof(char), returnstr, 3)) 
				{
					//sprintf(strMsgLine,"%u %u %u %u %u %u\n", returnstr[0], returnstr[1], returnstr[2], returnstr[strlen(returnstr)- 1], strlen(returnstr));
					if (returnstr[2] == 0x23)
					{
						// Celestron mount, motor firmware version
						mnt->motver[0] = returnstr[0];
						mnt->motver[1] = returnstr[1];
						mnt->motver[2] = '\0';					
						sprintf(strMsgLine,"Motors controller version %u.%u\n", returnstr[0], returnstr[1]);
					}
					else
					{
						sprintf(strMsgLine,"No response from motors controller (Unrecognized mount)\n");
						retval = 0;
					}
					setMessage(strMsgLine);
				}	
				else
				{
					/* Flush the input buffer */
					tcflush(TelPortFD,TCIOFLUSH);
					sprintf(strMsgLine,"No response from motors controller (Unrecognized mount -%u-)\n", model);
					retval = 0;
					setMessage(strMsgLine);
				}
			}
		}
	}
	else
	{
		retval = 0;
	}
	return(retval);
}

int CheckInitTel(mount *mnt)
{
	//int limits;
	int retval = 1;
	double tha = 0., tra = 0., tdec = 0.; 
	
	if (TelConnectFlag)
	{
		if (mnt->align)
		{
			if (GetTel(mnt, &tra, &tdec, RAW))
			{
				tha = Map12(LSTNow(mnt->SiteLongitude) - tra);
				sprintf(strMsgLine,"Mount now reading HA(RA): %lf(%lf)\n Mount now reading Dec: %lf\n", tha, tra, tdec);
				setMessage(strMsgLine);
				retval = 1;
			}
			else
			{
				retval = 0;
			}
		}
		else
		{
			retval = SetHomeNowTel(mnt);
		}
		/* Perform startup tests */
		if (mnt->telmode != GEM && retval)
		{
			#ifdef ISLIMITS
				/* Limit override is not allowed for 
				if (!GetLimits(&limits))
				{
					usleep(500000);
					limits = FALSE;
					if (!SetLimits(limits))
					{
						usleep(500000);  
						GetLimits(&limits);
					}
				}*/
			#endif
		}
		if (retval)
		{
			// Get guiderate
			GetGuideSpd(mnt, &mnt->guideratera, 0);
			GetGuideSpd(mnt, &mnt->guideratedec, 1);
		}
	}
	else
	{
		retval = 0;
	}
	return(retval);
}

int SetMountDefaultHome(mount *mnt)
{
	int retval = 1;
	if (!mnt->homefixed)
	{
		if (mnt->telmode == GEM)
		{
			if (mnt->SiteLatitude < 0.)
			{
				mnt->homedec = -89.9999;
				mnt->homeha = 6.;
			}
			else
			{  
				mnt->homedec = 89.9999;
				mnt->homeha = -6.;
			}
		}
		else if (mnt->telmode == EQFORK)
		{
			if (mnt->SiteLatitude < 0.)
			{
				mnt->homedec = 0.;
				mnt->homeha = 0.;
			}
			else
			{  
				mnt->homedec = 0.;
				mnt->homeha = 0.;
			}
		}
		else if (mnt->telmode == ALTAZ)
		{
			/* Set azimuth */
			mnt->homeha = 0.;    

			/* Set altitude */
			mnt->homedec = 0.; 
		}
		else
		{
			sprintf(strMsgLine,"SetMountDefaultHome: Telescope mounting must be GEM, EQFORK, or ALTAZ\n");
			setMessage(strMsgLine);
			retval = 0;
		}
	}
	if (!mnt->parkfixed)
	{
		mnt->parkha = mnt->homeha;
		mnt->parkdec = mnt->homedec;
	}
	return retval;
}

int SetHomeNowTel(mount *mnt)
{
	int retval = 1;
	double homeha= 0., homera = 0., homedec = 0.;
	char tmpHour[10];
	double tmpVal;

	if (TelConnectFlag)
	{
		/* Hardcoded defaults for homeha and homedec are overridden by prefs */
		/* GEM: over the pier pointing at the pole */
		/* EQFORK: pointing at the equator on the meridian */
		/* ALTAZ: level and pointing north */
		sprintf(strMsgLine, "Using initial HA(RA): %lf(%lf)\n", mnt->homeha, (Map24(LSTNow(mnt->SiteLongitude) - mnt->homeha)));
		setMessage(strMsgLine);
		sprintf(strMsgLine, "Using initial Dec: %lf\n",mnt->homedec); 
		setMessage(strMsgLine);

		if (SetTel(mnt, mnt->homeha, mnt->homedec))
		{
			mnt->offsetabsra = 0.;
			mnt->offsetabsdec = 0.;
			//fprintf(stderr,"offsetabsra : %f h\n", mnt->offsetabsra);
			//fprintf(stderr,"offsetabsdec: %f deg\n", mnt->offsetabsdec);
		}	
		else
		{
			sprintf(strMsgLine,"SetHomeNowTel: Error setting initial telescope pointing!\n");
			setMessage(strMsgLine);
			retval = 0;
		}
	
		if (retval)
		{
			homeha = mnt->homeha;
			homera = Map24(LSTNow(mnt->SiteLongitude) - homeha);
			homedec = mnt->homedec;
			/* Read encoders and confirm pointing */
			if (GetTel(mnt, &homera, &homedec, RAW))
			{
				homeha = Map12(LSTNow(mnt->SiteLongitude) - homera);
				sprintf(strMsgLine, "Local latitude: %lf\n", mnt->SiteLatitude);
				setMessage(strMsgLine);
				sprintf(strMsgLine, "Local longitude: %lf\n", mnt->SiteLongitude);
				setMessage(strMsgLine);
				tmpVal = Map24(LSTNow(mnt->SiteLongitude));
				dtodms(tmpHour, &tmpVal);
				sprintf(strMsgLine, "Local sidereal Time: %s\n", tmpHour);
				setMessage(strMsgLine);
				sprintf(strMsgLine, "Mount mode: %u\n", mnt->telmode);
				setMessage(strMsgLine);
				sprintf(strMsgLine, "Mount now reading HA(RA): %lf(%lf)\n", homeha, homera);
				setMessage(strMsgLine);
				sprintf(strMsgLine, "Mount now reading Dec: %lf\n", homedec);
				setMessage(strMsgLine);
			}
		}
	}
	else
	{
		retval = 0;
	}
	return retval;
}

/* Set mount mode */
int SetMountMode(mount *mnt, int newMode)
{
	if (newMode >= ALTAZ && newMode <= GEM)
	{
		mnt->telmode = newMode;
		SetMountDefaultHome(mnt);
	}
	sprintf(strMsgLine,"Mount Mode set to %u\n", mnt->telmode);
	setMessage(strMsgLine);	
	return(0);
}

/* Assign and save slewRate for use in StartSlew */
int SetRate(mount *mnt, int newRate)
{
	if (newRate >= GUIDE1 && newRate <= SLEW9)
	{
		mnt->telspd = newRate;
	}
	sprintf(strMsgLine,"Slew rate set to %u\n", (int) mnt->telspd);
	setMessage(strMsgLine);	
	return(0);
}
 
/* Assign and save track rate for use in StartTrack  */
/* If in tracking mode already wil be sent to the mount too  */
int SetTrkSpd(mount *mnt, double newRate)
{
	int retval = 0;
	int highbit = 0, midbit = 0, lowbit = 0;
	
	
	if (newRate == SIDEREAL)
	{
		trkRate[0] = 0xff;
		trkRate[1] = 0xff;
		trkRate[2] = 0x00;
		sprintf(strMsgLine,"Track rate set to sidereal\n");
		setMessage(strMsgLine);
	}
	else if (newRate == LUNAR)
	{
		trkRate[0] = 0xff;
		trkRate[1] = 0xfd;
		trkRate[2] = 0x00;
		sprintf(strMsgLine,"Track rate set to lunar\n");
		setMessage(strMsgLine);
	}
	else if (newRate == SOLAR)
	{
		trkRate[0] = 0xff;
		trkRate[1] = 0xfe;
		trkRate[2] = 0x00;
		sprintf(strMsgLine,"Track rate set to solar\n");
		setMessage(strMsgLine);
	}
	else if (newRate > 0)
	{
		newRate *= 4;
		//highbit = newRate / 65536; 
		//midbit  = (newRate - (highbit * 65536)) / 256;
		//lowbit  = newRate - (highbit * 65536) - (midbit * 256);
		highbit = newRate / 256; 
		midbit  = newRate - (highbit * 256);
		trkRate[0] = (unsigned char) highbit;
		trkRate[1] = (unsigned char) midbit;
		trkRate[2] = (unsigned char) lowbit;
		sprintf(strMsgLine,"Track rate set to %f arcseconds per second\n", (newRate / 4));
		setMessage(strMsgLine);
		//fprintf(stderr, "Set Trak [%u] [%u] [%u]\n", highbit, midbit, lowbit);
	}
	if (mnt->trkStatus > 0) //(mnt->trkStatus != mnt->trkActive)
	{
		if (StartTrack(mnt))
		{
			mnt->trkspd = newRate;
			retval = 1;
		}
	}
	return(retval);
}

int SetGuideSpd(mount *mnt, int val, int radec)
{
	int retval = 1;
	int sendbyte = 0;	
	char sendCmd[8] = { 0x50, 0x02, 0x10, 0x46, 0x00, 0x00, 0x00, 0x00 };
	
	sendbyte = (val * 256. / 100.) - 1.;
	sendCmd[4] = (unsigned char) sendbyte;
	
	if (TelConnectFlag)
	{
		if (radec == 1) 
		{
			sendCmd[2] = 0x11;
		}

		if (getMountAck(sendCmd, sizeof(sendCmd)/sizeof(char)))
		{
			retval = 1;		
			if (radec == 0) 
			{
				sprintf(strMsgLine,"Az controller rate set to %d sidereal\n", val);
			}
			else
			{
				sprintf(strMsgLine,"Alt controller guide rate set to %d sidereal\n", val);
			}
			setMessage(strMsgLine);
		}
		else
		{
			retval = 0;		
			if (radec == 0) 
			{
				sprintf(strMsgLine,"SetGuideSpd: No acknowledgement from Az motor control\n");
			}
			else
			{
				sprintf(strMsgLine,"SetGuideSpd: No acknowledgement from Alt motor control\n");
			}
			setMessage(strMsgLine);
		}
		//fprintf(stderr, "Set Trak [%u] [%u] [%u]\n", highbit, midbit, lowbit);
	}
	else
	{
		retval = 0;
	}
	return(retval);
}

int GetGuideSpd(mount *mnt, int *val, int radec)
{
	int retval = 1;
	int getval;
	char sendCmd[8] = { 0x50, 0x01, 0x10, 0x47, 0x00, 0x00, 0x00, 0x01 };
	char returnstr[RES_LEN];
		
	if (TelConnectFlag)
	{
		if (radec == 1) 
		{
			sendCmd[2] = 0x11;
		}

		if (getMountString(sendCmd, sizeof(sendCmd)/sizeof(char), returnstr, 2))
		{
			retval = 1;		

			/* Flush the input buffer */
			tcflush(TelPortFD,TCIOFLUSH);
			getval = (unsigned char) returnstr[0];

			getval = (getval +1) * 100. / 256.;
			*val = getval;	
		}
		else
		{
			retval = 0;		
			if (radec == 0) 
			{
				sprintf(strMsgLine,"GetGuideSpd: Error reading actual guide rate (Az)");
			}
			else
			{
				sprintf(strMsgLine,"GetGuideSpd: Error reading actual guide rate (Alt)");
			}
			setMessage(strMsgLine);
		}
	}
	else
	{
		retval = 0;
	}
	return(retval);
}

int GetGuideStep(void)
{
	return(1);
}


/* Start a slew in chosen direction at slewRate */
/* Use auxilliary NexStar command set through the hand control computer */
int StartSlew(mount *mnt, int direction)
{
	char slewCmd[8] = { 0x50, 0x02, 0x11, 0x24, 0x09, 0x00, 0x00, 0x00 };
	int retval = 0;

	if (TelConnectFlag)
	{
		/* If there's a slew in progress we need to cancel il properly and restore the tracking status*/  
		if (slewphase)
		{
			sprintf(strMsgLine, "Canceling the current goto operation\n");
			setMessage(strMsgLine);
			retval = FullStop(mnt);
			if(mnt->trkStatus != mnt->trkActive)
			{
				retval = SetTrack(mnt);
			}
			retval = 0;
		}
		else
		{
			if(direction == NORTH)
			{
				slewCmd[2] = 0x11; 
				slewCmd[3] = 0x24;
				slewCmd[4] = (int) mnt->telspd;
				sprintf(strMsgLine, "Slewing north\n");
			}
			else if(direction == EAST)
			{
				slewCmd[2] = 0x10; 
				slewCmd[3] = 0x25;
				slewCmd[4] = (int) mnt->telspd;
				sprintf(strMsgLine, "Slewing east\n");
			}
			else if(direction == SOUTH)
			{
				slewCmd[2] = 0x11; 
				slewCmd[3] = 0x25;
				slewCmd[4] = (int) mnt->telspd;
				sprintf(strMsgLine, "Slewing south\n");
			}
			else if(direction == WEST)
			{
				slewCmd[2] = 0x10; 
				slewCmd[3] = 0x24;
				slewCmd[4] = (int) mnt->telspd;
				sprintf(strMsgLine, "Slewing west\n");
			}

			if (getMountAck(slewCmd, sizeof(slewCmd)/sizeof(char)))
			{
				retval = 1;
				setMessage(strMsgLine);
			}
			else
			{
				retval = 0;
				if ((direction == NORTH) || (direction == SOUTH))
				{
					sprintf(strMsgLine,"StartSlew: No acknowledgement from Alt motor control\n");
				}
				else
				{
					sprintf(strMsgLine,"StartSlew: No acknowledgement from Az motor control\n");
				}
				setMessage(strMsgLine);
			}
		}
	}
	return(retval);   
}


/* Stop the slew in chosen direction */

int StopSlew(mount *mnt, int direction)
{
	char slewCmd[8] = { 0x50, 0x02, 0x11, 0x24, 0x00, 0x00, 0x00, 0x00 };
	int retval = 1;

	if (TelConnectFlag)
	{
		/* If there's a slew in progress we need to cancel il properly and restore the tracking status*/  
		if (slewphase)
		{
			sprintf(strMsgLine, "Canceling the current goto operation\n");
			setMessage(strMsgLine);		
			retval = FullStop(mnt);
			if(mnt->trkStatus != mnt->trkActive)
			{
				retval = SetTrack(mnt);
			}
			retval = 0;
		}
		if(retval)
		{
			if(direction == NORTH)
			{
				slewCmd[2] = 0x11; 
				slewCmd[3] = 0x24;
			}
			else if(direction == EAST)
			{
				slewCmd[2] = 0x10; 
				slewCmd[3] = 0x24;
			}
			else if(direction == SOUTH)
			{
				slewCmd[2] = 0x11; 
				slewCmd[3] = 0x24;
			}
			else if(direction == WEST)
			{
				slewCmd[2] = 0x10; 
				slewCmd[3] = 0x24;
			}

			/* Look for '#' acknowledgement of request*/
			if (getMountAck(slewCmd, sizeof(slewCmd)/sizeof(char)))
			{
				retval = 1;
				sprintf(strMsgLine,"Slew stopped\n");
				setMessage(strMsgLine);
			}
			else
			{
				retval = 0;
				if ((direction == NORTH) || (direction == SOUTH))
				{
					sprintf(strMsgLine,"StopSlew: No acknowledgement from Alt motor control\n");
				}
				else
				{
					sprintf(strMsgLine,"StopSlew: No acknowledgement from Az motor control\n");
				}
				setMessage(strMsgLine);
			}
		}
	}
	else
	{
		retval = 0;
	}
	return(retval);  
}

int DisconnectTel(mount *mnt)
{
	int err_code = 0;
	
	if (TelConnectFlag)
	{
		if(mnt->trkStatus == mnt->trkActive)
		{
			StopTrack(mnt);
		}
		if (tty_disconnect(TelPortFD) == 0)
		{
			TelConnectFlag = FALSE;
			sprintf(strMsgLine, "Telescope disconnected\n");
			setMessage(strMsgLine);
		}
		else
		{
			tty_error_msg(err_code, ttyerrormsg, TTY_ERRMSG_SIZE);
			setMessage(ttyerrormsg);
			sprintf(strMsgLine,"TTy disconnect failed... \n");
			setMessage(strMsgLine);
		}	
		
	}
	return(TelConnectFlag == FALSE);
}


/* Set the encoder count for current ha and dec                           */
/* Returns +1 (TRUE) if operation is allowed and 0 (FALSE) otherwise      */
int SetTel(mount *mnt, double setha, double setdec)
{
	/* Packet to set ha/azimuth drive  */
	char sendstr[8] = { 0x50, 0x04, 0x10, 0x04, 0x00, 0x00, 0x00, 0x00 };

	//double setra;

	/* Temporary variables for altitude and azimuth in degrees */
	double altnow, aznow; 

	/* Count registers */
	int azcount, azcount0, azcount1, azcount2;
	int altcount, altcount0, altcount1, altcount2; 
	int retval = 0; 

	/* Temporary variables for real encoder readings in degrees */
	double encoderalt = 0.;
	double encoderaz = 0.;

	if (TelConnectFlag)
	{
		// Get target Ra from Ha
		//setra = Map24(LSTNow(mnt->SiteLongitude) - setha);

		/* Test ha and dec for valid range */
		if ( setha > 12. || setha < -12. )
		{
			sprintf(strMsgLine,"SetTel: Telescope cannot be pointed outside valid HA range (%f)\n", setha);
			setMessage(strMsgLine);
			return(0);
		}

		if ( setdec >= 90. || setdec <= -90. )
		{
			sprintf(strMsgLine,"SetTel: Telescope cannot be pointed outside valid Dec range (%f)\n", setdec);
			setMessage(strMsgLine);
			return(0);
		}
					
		/* Check altitude limit 
		if (!ChkTarget(mnt, setra, setdec, RAW))
		{
			slewphase = 0;
			return(0);
		}
		*/

		/* Convert coordinates to counts                             */
		/* Zero points:                                              */
		/* Alt-Az -- horizon north                                   */
		/* Fork equatorial -- equator meridian                       */
		/* German equatorial -- over the mount at the pole           */
		/* Sign of encolder scales assumed:                          */
		/* Dec or Alt -- increase from equator to mount pole         */ 
		/* HA or Az   -- increase from east to west                  */
		/* Counts wrap signed 24-bit integer where 16777216 is 2^24  */
		if (mnt->telmode == GEM)
		{
			/* Flip signs if sited below the equator */
			if (mnt->SiteLatitude < 0.)
			{
				setdec = -1.*setdec;
				setha = -1.*setha;
			}

			/* Encoder az increases as this resigned ha increases */
			/* Zero point is with telescope over the pier pointed at pole */        
			if (setha == 0. && mnt->basis == 1)
			{ 
				/* OTA looking at meridian coming from East of Pier */
				/* It'll stay east of Pier */
				encoderaz = 90.;
				encoderalt = setdec - 90.;
			}
			else if (setha == 0. && mnt->basis == -1)
			{ 
				/* OTA looking at meridian coming from West of Pier */
				/* It'll stay West of Pier */
				encoderaz = -90.;
				encoderalt = 90. - setdec;
			}
			else if (setha == -6.)
			{
				/* OTA looking east */
				mnt->basis = -1;
				encoderaz = 0.;
				encoderalt = setdec - 90.;
			}
			else if (setha == 6.)
			{
				/* OTA looking west */
				mnt->basis = 1;
				encoderaz = 0.;
				encoderalt = 90. - setdec;
			}    
			else if ((setha > -12.) && ( setha < -6.))
			{ 
				/* OTA east of pier looking below the pole */
				mnt->basis = 1;
				encoderaz = setha*15. + 90.;
				encoderalt = setdec - 90.;
			}
			else if ((setha > -6.) && ( setha < 0.))
			{ 
				/* OTA west of pier looking east */
				mnt->basis = -1;
				encoderaz = setha*15. + 90.;
				encoderalt = setdec - 90.;
			}
			else if ((setha > 0.) && ( setha <= 6.))
			{ 
				/* OTA east of pier looking west */
				mnt->basis = 1;
				encoderaz = setha*15. - 90.;
				encoderalt = 90. - setdec;
			}
			else if ((setha > 6.) && ( setha < 12.))
			{ 
				/* OTA west of pier looking below the pole */
				mnt->basis = -1;
				encoderaz = setha*15. - 90.;
				encoderalt = 90. - setdec;
			}    
			else
			{
				sprintf(strMsgLine,"SetTel: German equatorial outside limits\n");
				setMessage(strMsgLine);
				return(0);      
			}

			//fprintf(stderr, "Set encoderaz : %f\n", encoderaz);
			//fprintf(stderr, "Set ecoderalt: %f\n", encoderalt);

			encoderaz = encoderaz * AZCOUNTPERDEG;
			azcount = encoderaz;
			encoderalt = encoderalt * ALTCOUNTPERDEG;
			altcount = encoderalt;

			azcount += 4194304;
			altcount += 4194304;
	
			if (azcount < 0)
			{
				azcount = 16777217 + azcount;
			}

			if (altcount < 0)
			{
				altcount = 16777217 + altcount;
			}

			//fprintf(stderr, "Set Azcount: %d\n", azcount);
			//fprintf(stderr, "Set Altcount: %d\n", altcount);
		}
		else if (mnt->telmode == EQFORK)
		{

			/* Flip signs for the southern sky */

			if (mnt->SiteLatitude < 0.)
			{
				setdec = -1.*setdec;
				setha = -1.*setha;
			}

			encoderaz = setha*15.;
			encoderalt = setdec;
			encoderaz = encoderaz*AZCOUNTPERDEG;
			encoderalt = encoderalt*ALTCOUNTPERDEG;       

			azcount = encoderaz;
			if (azcount < 0)
			{
				azcount = 16777217 + azcount;
			}

			altcount = encoderalt;
			if (altcount < 0)
			{
				altcount = 16777217 + altcount;
			}
		}  
		else if (mnt->telmode == ALTAZ)
		{
			/* Convert HA and Dec to Alt and Az */
			EquatorialToHorizontal(mnt->SiteLatitude, setha, setdec, &aznow, &altnow);

			encoderaz = aznow*AZCOUNTPERDEG;
			encoderalt = altnow*ALTCOUNTPERDEG;

			azcount = encoderaz;
			if (azcount < 0)
			{
				azcount = 16777217 + azcount;
			}

			altcount = encoderalt;
			if (altcount < 0)
			{
				altcount = 16777217 + altcount;
			}
		}
		else
		{
			sprintf(strMsgLine,"SetTel: Unknown mount type\n");
			setMessage(strMsgLine);
			return(0);
		}   

		//fprintf(stderr, "encaz: %f\nencalt: %f\n", encoderaz, encoderalt);

		/* Parse each of the 3 bytes of the counters */
		azcount0  = azcount  / 65536;
		azcount   = azcount  % 65536;
		azcount1  = azcount  / 256;
		azcount2  = azcount  % 256;
		altcount0 = altcount / 65536;
		altcount  = altcount % 65536;
		altcount1 = altcount / 256;
		altcount2 = altcount % 256;

		/* Set RA/Azimuth encoder to this position */
		sendstr[1] = 0x04;
		sendstr[2] = 0x10;
		sendstr[3] = 0x04;
		sendstr[4] = (unsigned short) azcount0;
		sendstr[5] = (unsigned short) azcount1;
		sendstr[6] = (unsigned short) azcount2;

		if (getMountAck(sendstr, sizeof(sendstr)/sizeof(char)))
		{
			/* Set Dec/Altitude encoder to this position */   
			sendstr[1] = 0x04;
			sendstr[2] = 0x11;
			sendstr[3] = 0x04;
			sendstr[4] = (unsigned short) altcount0;
			sendstr[5] = (unsigned short) altcount1;
			sendstr[6] = (unsigned short) altcount2;

			if (getMountAck(sendstr, sizeof(sendstr)/sizeof(char)))
			{
				//sprintf(strMsgLine, "SetTel: %u %u %u %u %u %u %u %u %u\n", azcount0, azcount1,azcount2,0,44,altcount0,altcount1,altcount2,0);
				//setMessage(strMsgLine);
				retval = 1;
			}
			else
			{
				sprintf(strMsgLine, "SetTel: cannot get Ack from Alt controller!\n");
				setMessage(strMsgLine);
			}
		}
		else
		{
			sprintf(strMsgLine, "SetTel: cannot get Ack from Az controller!\n");
			setMessage(strMsgLine);
		}  

		tcflush(TelPortFD, TCIOFLUSH);
	}
	return(retval);
}

/* Read the mount encoders                                            */
/* Requires access to global telmount                                 */
/* Save encoder angle readings in global telencoder variables         */
/* Convert the encoder readings to mounting ha and dec                */
/* Use an NTP synchronized clock to find lst and ra                   */
/* Correct for the pointing model to find the true direction vector   */
/* Report the ra and dec at which the telescope is pointed            */
int GetTel(mount *mnt, double *telra, double *teldec, int pmodel)
{  
   
	/* Packet preset to request HA/Azimuth counts */
	char sendstr[8] = { 0x50, 0x01, 0x10, 0x01, 0x00, 0x00, 0x00, 0x03 };
	char returnstr[RES_LEN];
	int azcount = 0; 
	int altcount = 0;
	double encoderaz = 0.;
	double encoderalt = 0.;
	double telha0 = 0.;
	double teldec0 = 0.;
	double telra0 = 0.;
	double telra1 = 0.;
	double teldec1 = 0.;
	int retval = 0;
	static int count0, count1, count2;

	
	if (TelConnectFlag)
	{
		/* Packet to request RA/Azimuth */
		sendstr[2] = 0x10;

		if (getMountString(sendstr, sizeof(sendstr)/sizeof(char), returnstr, 4))
		{
			count0 = (unsigned char) returnstr[0];
			count1 = (unsigned char) returnstr[1];
			count2 = (unsigned char) returnstr[2];
			azcount = 256*256*count0 + 256*count1 + count2;

			//fprintf(stderr, "Get encaz: %f\n", ((double) azcount));

			/* Packet to request Dec/Altitude */
			sendstr[2] = 0x11;

			if (getMountString(sendstr, sizeof(sendstr)/sizeof(char), returnstr, 4))
			{
				/* Flush the input buffer */
				tcflush(TelPortFD,TCIOFLUSH);

				count0 = (unsigned char) returnstr[0];
				count1 = (unsigned char) returnstr[1];
				count2 = (unsigned char) returnstr[2];
				altcount = 256*256*count0 + 256*count1 + count2;

				//fprintf(stderr, "Get encalt: %f\n", ((double) altcount));
				// Go on
				retval = 1;
			}
			else
			{
				/* Flush the input buffer */
				tcflush(TelPortFD,TCIOFLUSH);
				sprintf(strMsgLine,"GetTel: Error reading actual mount position (Alt)\n");
				setMessage(strMsgLine);
			}
		}
		else
		{
			/* Flush the input buffer */
			tcflush(TelPortFD,TCIOFLUSH);
			sprintf(strMsgLine,"GetTel: Error reading actual mount position (Az)\n");
			setMessage(strMsgLine);
		}
	
		if (retval)	
		{
			/* Transform encoder readings to mount ha, ra and dec */
			/* GEM encoders zero for OTA over pier pointed at pole */
			if (mnt->telmode == GEM)
			{
				//fprintf(stderr, "Get Azcount: %d\n", azcount);
				//fprintf(stderr, "Get Altcount: %d\n", altcount);

				if (azcount > 12582912)
				{
					azcount = -(16777217 - azcount);
				}   
				azcount -= 4194304;

				if (altcount > 12582912)
				{
					altcount = -(16777217 - altcount);
				}   
				altcount -= 4194304;

				encoderaz = (double) azcount;
				encoderalt = (double) altcount;

				/* Convert counts to degrees for both azimuth and altitude encoders */ 
				encoderaz = encoderaz / AZCOUNTPERDEG;
				encoderalt = encoderalt / ALTCOUNTPERDEG;

				//fprintf(stderr, "Get encoderaz : %f\n", encoderaz);
				//fprintf(stderr, "Get ecoderalt: %f\n", encoderalt);

				if ( encoderaz == 0. ) 
				{
					if ( encoderalt < 0.)
					{
						telha0 = -6.;
						teldec0 = 90. + encoderalt;
					}
					else
					{
						telha0 = +6.;
						teldec0 = 90. - encoderalt;
					}
				}
				else if ( encoderaz == -90. )
				{
					if ( encoderalt < 0.)
					{
						telha0 = 0.;
						teldec0 = 90. + encoderalt;
					}
					else
					{
						telha0 = -12.;
						teldec0 = 90. - encoderalt;
					}    
				}
				else if ( encoderaz == 90. )
				{
					if ( encoderalt > 0.)
					{
						telha0 = 0.;
						teldec0 = 90. - encoderalt;
					}
					else
					{
						telha0 = -12.;
						teldec0 = 90. + encoderalt;
					}    
				}   
				else if ((encoderaz > -180. ) && (encoderaz < -90.))
				{
					teldec0 = 90. - encoderalt;
					telha0 = Map12(6. + encoderaz/15.);  
				}
				else if ((encoderaz > -90. ) && (encoderaz < 0.))
				{
					teldec0 = 90. - encoderalt;
					telha0 = Map12(6. + encoderaz/15.);  
				}    
				else if ((encoderaz > 0. ) && (encoderaz < 90.))
				{
					teldec0 = 90. + encoderalt;
					telha0 = Map12(-6. + encoderaz/15.);  
				}    
				else if ((encoderaz > 90. ) && (encoderaz < 180.))
				{
					teldec0 = 90. + encoderalt;
					telha0 = Map12(-6. + encoderaz/15.);  
				}   
				else
				{
					sprintf(strMsgLine,"German equatorial ha encoder out of range\n");      
					setMessage(strMsgLine);
					teldec0 = 0.;
					telha0 = 0.;
				}   
	
				/* Flip signs for the southern sky */
				if (mnt->SiteLatitude < 0.)
				{
					teldec0 = -1.*teldec0;
					telha0 = -1.*telha0;
				}	
				telra0 = Map24(LSTNow(mnt->SiteLongitude) - telha0);

				//fprintf(stderr, "Get ra : %f\n", telra0);
				//fprintf(stderr, "Get ha : %f\n", telha0);
				//fprintf(stderr, "Get dec: %f\n", teldec0);
			}
	
			else if (mnt->telmode == EQFORK)
			{
				if (azcount > 8388608)
				{
					azcount = -(16777217 - azcount);
				}
				encoderaz = (double) azcount;

				if (altcount > 8388608)
				{
					altcount = -(16777217 - altcount);
				}   
				encoderalt = (double) altcount;

				/* Convert counts to degrees for both azimuth and altitude encoders */ 
				encoderaz = encoderaz / AZCOUNTPERDEG;
				encoderalt = encoderalt / ALTCOUNTPERDEG;

				teldec0 = encoderalt;
				telha0 = Map12(encoderaz/15.);

				/* Flip signs for the southern sky */
				if (mnt->SiteLatitude < 0.)
				{
					teldec0 = -1.*teldec0;
					telha0 = -1.*telha0;
				}

				telra0 = Map24(LSTNow(mnt->SiteLongitude) - telha0);    

				//fprintf(stderr, "Get ha : %f\n", telha0);
				//fprintf(stderr, "Get dec: %f\n", teldec0);
			}
			  
			else if (mnt->telmode == ALTAZ)
			{
				if (azcount > 8388608)
				{
					azcount = -(16777217 - azcount);
				}
				encoderaz = (double) azcount;

				if (altcount > 8388608)
				{
					altcount = -(16777217 - altcount);
				}   
				encoderalt = (double) altcount;

				/* Convert counts to degrees for both azimuth and altitude encoders */ 
				encoderaz = encoderaz / AZCOUNTPERDEG;
				encoderalt = encoderalt / ALTCOUNTPERDEG;
				HorizontalToEquatorial(mnt->SiteLatitude, encoderaz, encoderalt, &telha0, &teldec0);
				telha0 = Map12(telha0);
				telra0 = Map24(LSTNow(mnt->SiteLongitude) - telha0);   
			}

			else
			{
				sprintf(strMsgLine,"GetTel: Unknown mounting type\n");  
				setMessage(strMsgLine);
				*telra=0.;
				*teldec=0.;
				telencoderaz = 0.;
				telencoderalt = 0.;
				retval = 0;
			}
				
			if (retval)
			{
				/* Handle special case if not already treated where dec is beyond a pole */
				if (teldec0 > 90.)
				{
					teldec0 = 180. - teldec0;
					telra0 = Map24(telra0 + 12.);
				}
				else if (teldec0 < -90.)
				{
					teldec0 = -180. - teldec0;
					telra0 = Map24(telra0 + 12.);
				}

				/* Apply pointing model to the coordinates that are reported by the telescope */
				PointingFromTel(mnt, &telra1, &teldec1, telra0, teldec0, pmodel);

				//fprintf(stderr, "Get ra1: %f\n", telra1);
				//fprintf(stderr, "Get dec1: %f\n", teldec1);

				/* Return corrected values */
				*telra=telra1;
				*teldec=teldec1;

				/* Update global encoder reading */
				telencoderaz =  encoderaz;
				telencoderalt = encoderalt;

				//fprintf(stderr, "Telencoderaz: %f\n", telencoderaz);
				//fprintf(stderr, "Telencoderalt: %f\n", telencoderalt);

				/* all is well that ends well */
				retval = 1;
			}
		}
	}
	return(retval);
}


/* Go to new celestial coordinates                                    */
/* Evaluate if target coordinates are valid                           */
/* Test slew limits in altitude, polar, and hour angles               */
/* Query if target is above the horizon                               */
/* Return without action for invalid requests                         */
/* Interrupt any slew sequence in progress                            */
/* Check current pointing                                             */
/* Find encoder readings required to point at target                  */
/* Set slewphase equal to number of slew segments needed              */
/* Begin next segment needed to reach target from current pointing    */
/* Repeated calls are required when more than one segment is needed   */
/* Return 1 if underway                                               */
/* Return 0 if done or not permitted                                  */
int GoToCoords(mount *mnt, double newra, double newdec, int pmodel, int abspos)
{
	char sendstr[8] = { 0x50, 0x04, 0x10, 0x17, 0x00, 0x00, 0x00, 0x00 };
	int azcount= 0, azcount0, azcount1, azcount2;
	int altcount= 0, altcount0, altcount1, altcount2;
	int retval = 0; 
	double newha0, newalt0, newaz0;
	double newra0, newdec0;
	double newra1, newdec1;
	double nowra0, nowdec0;
	double encoderalt = 0.;
	double encoderaz = 0.;
	
	if (TelConnectFlag)
	{
		strcat(strMsgLine,"Setting up a goto slew to target\n"); 
		setMessage(strMsgLine);

		/* Mount coordinates for the target */
		newra1 = newra;
		newdec1 = newdec;
		if (!abspos)
		{
			PointingToTel(mnt, &newra0, &newdec0, newra1, newdec1, pmodel);  
		}
		else
		{
			newra0 = newra + mnt->offsetabsra;
			newdec0 = newdec - mnt->offsetabsdec;
		}
	
		newha0 = Map12(LSTNow(mnt->SiteLongitude) - newra0);

		/* Check altitude limit */
		if (!abspos)
		{
			/* Test ha and dec for valid range */
			if ( newha0 > 12. || newha0 < -12. )
			{
				sprintf(strMsgLine,"GoToCoords: Telescope cannot be pointed outside valid HA range (%f)\n", newha0);
				setMessage(strMsgLine);
				slewphase = 0;
				return(0);
			}

			if ( newdec0 >= 90. || newdec0 <= -90. )
			{
				sprintf(strMsgLine,"GoToCoords: Telescope cannot be pointed outside valid Dec range (%f)\n", newdec0);
				setMessage(strMsgLine);
				slewphase = 0;
				return(0);
			}
		
			if (!ChkTarget(mnt, newra0, newdec0, RAW))
			{
				slewphase = 0;
				return(0);
			}
		}

		//fprintf(stderr, "LST: %f\nGoto ra: %f\nGoto dec: %f\n",LSTNow(mnt->SiteLongitude), newra, newdec);
		//fprintf(stderr, "Goto appha: %f\nGoto appra: %f\nGoto appdec: %f\n",newha0, newra0, newdec0);

		/* Stop all mount motion in preparation for a slew */
		if (FullStop(mnt))
		{
			/* Get current mount coordinates */
			if (GetTel(mnt, &nowra0, &nowdec0, RAW))
			{					  
				/* German equatorial */
				if (mnt->telmode == GEM)
				{
					slewphase = 1;
					/* Flip signs for the southern sky */
					if (mnt->SiteLatitude < 0.)
					{
						newdec0 = -1.*newdec0;
						newha0 = -1.*newha0;
					}

					if (newha0 == 0. && mnt->basis == 1)
					{ 
						/* OTA looking at meridian coming from East of Pier */
						/* It'll stay east of Pier */
						encoderaz = 90.;
						encoderalt = newdec0 - 90.;
					}
					else if (newha0 == 0. && mnt->basis == -1)
					{ 
						/* OTA looking at meridian coming from West of Pier */
						/* It'll stay West of Pier */
						encoderaz = -90.;
						encoderalt = 90. - newdec0;
					}
					else if (newha0 == -6.)
					{
						/* OTA looking east */
						mnt->basis = -1;
						encoderaz = 0.;
						encoderalt = newdec0 - 90.;
					}
					else if (newha0 == 6.)
					{
						/* OTA looking west */
						mnt->basis = 1;
						encoderaz = 0.;
						encoderalt = 90. - newdec0;
					}    
					else if ((newha0 > -12.) && ( newha0 < -6.))
					{ 
						/* OTA east of pier looking below the pole */
						mnt->basis = 1;
						encoderaz = newha0*15. + 90.;
						encoderalt = newdec0 - 90.;
					}
					else if ((newha0 > -6.) && ( newha0 < 0.))
					{ 
						/* OTA west of pier looking east */
						mnt->basis = -1;
						encoderaz = newha0*15. + 90.;
						encoderalt = newdec0 - 90.;
					}
					else if ((newha0 > 0.) && ( newha0 < 6.))
					{ 
						/*OTA east of pier looking west */
						mnt->basis = 1;
						encoderaz = newha0*15. - 90.;
						encoderalt = 90. - newdec0;
					}
					else if ((newha0 > 6.) && ( newha0 < 12.))
					{ 
						/* OTA west of pier looking below the pole */
						mnt->basis = -1;
						encoderaz = newha0*15. - 90.;
						encoderalt = 90. - newdec0;
					}    
					else
					{
						sprintf(strMsgLine,"GoToCoords: German equatorial slew request outside limits\n");
						setMessage(strMsgLine);
						slewphase = 0;
						/* Since we're canceling the slew request we need to restore the tracking status */
						if(mnt->trkStatus != mnt->trkActive)
						{
							SetTrack(mnt);
						}
						return(0);      
					}

					/* Tests for safe slew based on encoder readings would go here */
	
					/* Test need for two-segment slew for changes of more than 90 degrees */
					//fprintf(stderr, "Goto Encoderaz: %f\n", encoderaz);
					//fprintf(stderr, "Goto Encoderalt: %f\n", encoderalt);
					//fprintf(stderr, "Distance encoder AZ: %f\nDistance encoder ALT: %f\n", fabs(telencoderaz - encoderaz), fabs(telencoderalt - encoderalt));
					if ((fabs(telencoderalt - encoderalt) > 90.1) || (fabs(telencoderaz - encoderaz) > 90.1))
					{

						/* Slew request of more than 90 degrees on one axis */
						//fprintf(stderr, "Encoder ALT: %f\n", telencoderalt);
						if ( fabs(telencoderalt) > 10. )
						{
							//fprintf(stderr, "Meridian Flip\n");

							/* Telescope currently more than 10 degrees from the pole in dec */
							/* Set new target to switch position */
							encoderalt = switchalt;
							encoderaz = switchaz;
							slewphase = 2;
							// First tranche is at full throttle
							if (!mnt->quietslew)
							{
								sendstr[3] = 0x02;
							}
						}  
						else
						{
							//fprintf(stderr, "Double speed goto (>90)\n");
							if (mnt->SiteLatitude < 0.)
							{
								encoderalt += 2 ;
								encoderaz += 2;
							}
							else
							{
								encoderalt -= 2 ;
								encoderaz -= 2;
							}
							slewphase = 2;
							// Long slew is done at full throttle
							if (!mnt->quietslew)
							{
								sendstr[3] = 0x02;
							}
						}
					}
					else if ((fabs(telencoderalt - encoderalt) > 30.1) || (fabs(telencoderaz - encoderaz) > 30.1))
					{
						//fprintf(stderr, "Double speed goto\n");
						if (mnt->SiteLatitude < 0.)
						{
							encoderalt += 2 ;
							encoderaz += 2;
						}
						else
						{
							encoderalt -= 2 ;
							encoderaz -= 2;
						}
						slewphase = 2;
						// Long slew is done at full throttle
						if (!mnt->quietslew)
						{
							sendstr[3] = 0x02;
						}
					}
			
					encoderaz = encoderaz * AZCOUNTPERDEG;     
					azcount = encoderaz;
					encoderalt = encoderalt * ALTCOUNTPERDEG;
					altcount = encoderalt;

					azcount += 4194304; 
					altcount += 4194304;

					if (azcount < 0)
					{
						azcount = 16777217 + azcount;
					}

					if (altcount < 0)
					{
						altcount = 16777217 + altcount;
					}
			
					//fprintf(stderr, "Goto Azcount: %d\n", azcount);
					//fprintf(stderr, "Goto Altcount: %d\n", altcount);
				}

				/* Equatorial fork */
				if (mnt->telmode == EQFORK)
				{
					slewphase = 1;
					encoderaz = newha0 * 15.;
					encoderalt = newdec0;

					/* Tests for safe slew based on encoder readings would go here */

					encoderalt = encoderalt * ALTCOUNTPERDEG;
					encoderaz = encoderaz * AZCOUNTPERDEG;
	
					azcount = encoderaz;
					if (azcount < 0)
					{
						azcount = 16777217 + azcount;
					}

					altcount = encoderalt;
					if (altcount < 0)
					{
						altcount = 16777217 + altcount;
					}
				}

				/* Alt-az fork */
				if (mnt->telmode == ALTAZ)
				{
					EquatorialToHorizontal(mnt->SiteLatitude, newha0, newdec0, &newaz0, &newalt0);
					
					slewphase = 1;
					encoderaz = newaz0;
					encoderalt = newalt0;

					/* Tests for safe slew based on encoder readings would go here */

					encoderaz = encoderaz*AZCOUNTPERDEG;
					encoderalt = encoderalt*ALTCOUNTPERDEG;
					altcount = encoderalt;
					azcount = encoderaz;
				}

				/* Convert encoder angle readings to encoder counter readings */
				/* Parse each of the 3 bytes of the counters */
				azcount0  = azcount  / 65536;
				azcount   = azcount  % 65536;
				azcount1  = azcount  / 256;
				azcount2  = azcount  % 256;
				altcount0 = altcount / 65536;
				altcount  = altcount % 65536;
				altcount1 = altcount / 256;
				altcount2 = altcount % 256;

				//fprintf(stderr, "Goto encaz: %f\nGoto encalt: %f\n", encoderaz, encoderalt);

				/* Prepare NexStar commands                  */
				/* Send command to go to new RA/Azimuth */
				sendstr[1] = 0x04;
				sendstr[2] = 0x10;
				//sendstr[3] = 0x17;
				sendstr[4] = (unsigned char) azcount0;
				sendstr[5] = (unsigned char) azcount1;
				sendstr[6] = (unsigned char) azcount2;

				if (getMountAck(sendstr, sizeof(sendstr)/sizeof(char)))
				{
					/* Send command to go to new Dec/Altitude */
					sendstr[1] = 0x04;
					sendstr[2] = 0x11;
					//sendstr[3] = 0x17;
					sendstr[4] = (unsigned char) altcount0;
					sendstr[5] = (unsigned char) altcount1;
					sendstr[6] = (unsigned char) altcount2;

					if (getMountAck(sendstr, sizeof(sendstr)/sizeof(char)))
					{
						/* A slew is in progress */
						retval = 1;
					}
					else
					{
						sprintf(strMsgLine,"GotoCoords: Cannot get a Ack from Alt controller on goto command!\nMount Stopped!\n");
						setMessage(strMsgLine);
						FullStop(mnt);
						/* Since we're canceling the slew request due to motor communication error, we do not restore the tracking status*/
					}
					tcflush(TelPortFD,TCIOFLUSH);
				}
				else
				{
					sprintf(strMsgLine,"GotoCoords: Cannot get a Ack from Az controller on goto command!\nMount Stopped!\n");
					setMessage(strMsgLine);
					FullStop(mnt);
					/* Since we're canceling the slew request due to motor communication error, we do not restore the tracking status*/
				}
			}
		}
	}
	return(retval);
}

/* Low level check of slew status on both axes */
/* Advise using CheckGoTo in external applications */
/* Return a flag indicating whether a slew is now in progress */
/*   1 -- slew is in progress on either drive */
/*   0 -- slew not in progress for either drive */

int GetSlewStatus(mount *mnt)
{
	char sendstr[8] = { 0x50, 0x01, 0x10, 0x13, 0x00, 0x00, 0x00, 0x01 };
	char returnstr[RES_LEN];
	int retval = 0;

	if (TelConnectFlag)
	{
		/* Query azimuth drive first */ 
		sendstr[2]=0x10;

		if (getMountString(sendstr, sizeof(sendstr)/sizeof(char), returnstr, 2)) 
		{
			if ( returnstr[0] == 0 ) 
			{
				retval = 1;
			}
			else
			{
				//Since ra is stopped already we restore tracking status to limit object ra slippery
				if((mnt->trkStatus != mnt->trkActive) && (slewphase == 1))
				{
					StartTrack(mnt);
				}
			}
			/* Query altitude drive if azimuth drive is not slewing */
			sendstr[2]=0x11;

			if (getMountString(sendstr, sizeof(sendstr)/sizeof(char), returnstr, 2)) 
			{
				if ( returnstr[0] == 0 ) 
				{
					retval = 1;
				}
			}
			else
			{
				sprintf(strMsgLine,"GetSlewStatus: Cannot get slew status from Alt controller\n");
				setMessage(strMsgLine);
				retval = 0;
			}
		}
		else
		{
			sprintf(strMsgLine,"GetSlewStatus: Cannot get slew status from Az controller\n");
			setMessage(strMsgLine);
			retval = 0;
		}
	}
	return(retval);
}


/* Test whether the destination was reached                  */
/* Initiate the next segment if slewphase is greater than 1  */
/* Reset slewphase when goto has finished a segment          */
/* Return value is                                           */
/*   0 -- goto in progress                                   */
/*   1 -- goto complete within tolerance                     */
/*   2 -- goto complete but outside tolerance                */

int CheckGoTo(mount *mnt, double desRA, double desDec, int pmodel, int abspos)
{
	double errorHA, errorDec, desHA, nowHA, nowRA, nowDec;
	double tolha, toldec;
	int retval = 0;

	if (TelConnectFlag)
	{
		/* Is the telescope slewing? */
		if ( GetSlewStatus(mnt) == 1 )
		{
			/* One or more axes remain in motion */
			/* Try again later */
			retval = 0;
		}
		else
		{
			/* Was this a two-phase slew? */
			if ( slewphase == 2 )
			{       
				/* Reset the slew phase and continue to the destination */
				slewphase = 0;    

				/* Go to the original destination */
				/* GoToCoords will change slewphase to 1 */  
				if (GoToCoords(mnt, desRA, desDec, pmodel, abspos))
				{
					/* Return a flag indicating a new goto operation is in progress */
					retval = 0;
				}
				else
				{
					retval = 2;	
				}
			}
			else if ( slewphase == 1 )
			{
				/* No axes are moving. Reset the slew flag. Insure that tracking is started again. */
				slewphase = 0;
				if(mnt->trkStatus != mnt->trkActive)
				{
					retval = SetTrack(mnt);
				}
				else
				{
					retval = 1;
				}

				if (retval)
				{
					/* Where are we now? */
					if (GetTel(mnt, &nowRA, &nowDec, pmodel))
					{
						/* need to compare HA in 0-24h form */
						desHA = (LSTNow(mnt->SiteLongitude) - desRA);
						nowHA = (LSTNow(mnt->SiteLongitude) - nowRA);

						// HA slew tolerance in hours 
						tolha = mnt->slewtolha;

						/* Dec slew tolerance in degrees */
						toldec = mnt->slewtoldec;

						/* What is the absolute value of the pointing error? */

						// Magnitude of HA pointing error in hours 
						errorHA = fabs(nowHA - desHA);
						if (errorHA >= 12.)
						{
							errorHA -= 12.;
						}

						/* Magnitude of Dec pointing error in degrees */
						errorDec = fabs(nowDec - desDec);

						// Compare and notify whether we are within tolerance 
						if( ( errorHA > tolha ) || ( errorDec > toldec ) )
						{
							//fprintf(stderr, "Error HA: %f\nErrorDec: %f\n", errorHA, errorDec);
							/* Result of slew is outside acceptable tolerance */
							/* Signal the calling routine that another goto may be needed */
							retval = 2;
						}
						else
						{
							/* Success */
							retval = 1;
						}
					}
					else
					{		
						retval = 2;
					}
				}
				else
				{		
					retval = 2;
				}

			}    
			else
			{
				/* Unexpected slew phase */
				/* Reset and return success without a test */
				/* This should clear errors and enable another slew request from the UI */
				/* Better would be to flag an error but that might have unintended consequences */
				/* It also apply when user stopped a goto with UI */
				slewphase = 0;
				retval = 1;    
			}
		} 
	}
	return(retval); 
}

/* Level scope (GEM) before align */
int LevelScope(mount *mnt, int ra, int dec)
{
	char sendstr[8] = { 0x50, 0x04, 0x10, 0x19, 0x00, 0x00, 0x00, 0x00 };
	int retval = 0; 

	if (TelConnectFlag)
	{
		sprintf(strMsgLine,"Begin level telescope\n");
		setMessage(strMsgLine);       

		/* Stop all mount motion in preparation for a slew */
		if (FullStop(mnt))
		{
			SetTrackStatus(mnt, 0);
			// Move mount a little to have consistent positioning 
			if (mnt->SiteLatitude < 0)
			{
				retval = StartSlew(mnt, WEST);
			}
			else
			{
				retval = StartSlew(mnt, EAST);
			}
			usleep(2500000.);
			if (retval) 
			{
				retval = StopSlew(mnt, EAST);
				usleep(2500000.);
			}
			if (retval)
			{
				slewphase = 1;
				if (ra && slewphase)
				{
					sprintf(strMsgLine,"Leveling RA\n");
					setMessage(strMsgLine); 
					/* Send command to go to new RA/Azimuth */
					sendstr[1] = 0x01;
					sendstr[2] = 0x10;
					sendstr[3] = 0x0b; //Level Scope (Ra/Azm) 

					if (getMountAck(sendstr, sizeof(sendstr)/sizeof(char)))
					{
						retval += ra;
					}
					else
					{
						sprintf(strMsgLine,"LevelScope: Cannot get a Ack from Az controller on goto command!\n");
						setMessage(strMsgLine);
						slewphase = 0;
					}
				}

				if (dec && slewphase)
				{
					sprintf(strMsgLine,"Leveling DEC\n");
					setMessage(strMsgLine); 
					/* Send command to go to new RA/Azimuth */
					sendstr[1] = 0x01;
					sendstr[2] = 0x11;
					sendstr[3] = 0x0b; //Level Scope (Dec/Alt) 
					//sendstr[3] = 0x19; //Seek Index (Dec/Alt) 

					if (getMountAck(sendstr, sizeof(sendstr)/sizeof(char)))
					{
						retval += dec;
					}
					else
					{
						sprintf(strMsgLine,"LevelScope: Cannot get a Ack from Alt controller on goto command!\n");
						setMessage(strMsgLine);
					}
				}
				if (retval < (ra + dec))
				{
					retval = 0;
				}
				else
				{
					retval = 1;
					sprintf(strMsgLine,"Level telescope in progress...\n");
					setMessage(strMsgLine);       
				}
			} 
		}
	}
	return(retval);
}

/* Check Level Done */
/* 0 In progress either ra or dec */
/* 1 Finished */
int CheckLevel(int ra, int dec)
{
	char sendstr[8] = { 0x50, 0x01, 0x10, 0x18, 0x00, 0x00, 0x00, 0x01 };
	char returnstr[RES_LEN];
	int retval = 0; 

	if (TelConnectFlag)
	{
		if (ra)
		{
			/* Send command to go to new RA/Azimuth */
			sendstr[1] = 0x01;
			sendstr[2] = 0x10;
			sendstr[3] = 0x18; 
			//sendstr[3] = 0x12; //Level done (Dec/Alt) 

			if (getMountString(sendstr, sizeof(sendstr)/sizeof(char), returnstr, 2))
			{
				//fprintf(stderr, "%x\n", returnstr[0]);
				if (returnstr[0] == 0) 
				{
					retval = 0;
				}
				else
				{
					sprintf(strMsgLine,"Level Done\nMount is stopped\n");
					setMessage(strMsgLine);
					retval += ra;
				}
			}
			else
			{
				sprintf(strMsgLine,"CheckLevel: Cannot get a response from Az controller on level command!\n");
				setMessage(strMsgLine);
				retval = 0;
			}
		}

		if (dec)
		{
			/* Send command to go to new Dec/Altitude */
			sendstr[1] = 0x01;
			sendstr[2] = 0x11;
			sendstr[3] = 0x12; //Level done (Dec/Alt) 
			//sendstr[3] = 0x18; //Is At Index (Ra/Azm) 

			if (getMountString(sendstr, sizeof(sendstr)/sizeof(char), returnstr, 2))
			{
				if (returnstr[0] == 0) 
				{
					retval = 0;
				}
				else
				{
					retval += dec;
				}
			}
			else
			{
				sprintf(strMsgLine,"CheckLevel: Cannot get a response from Alt controller on level command!\n");
				setMessage(strMsgLine);
				retval = 0;
			}
		}
		if (retval < (ra + dec))
		{
			retval = 0;
		}
		else
		{
			slewphase = 0;
		}
	}
	return(retval);
}


/* Update global offsets */
int SyncTelOffsets(mount *mnt, double newoffsetra, double newoffsetdec)
{
	mnt->offsetra = newoffsetra;
	mnt->offsetdec = newoffsetdec;
	return 1;
}

int SetTrack(mount *mnt)
{
	int retval = 0;
	
	if (TelConnectFlag)
	{
		if (mnt->trkStatus)
		{
			retval = StartTrack(mnt);
		}
		else
		{
			retval = StopTrack(mnt);
		}
	}
	return (retval);
}

/* Start sidereal tracking                                                    */
/* StartTrack is aware of the latitude and will set the direction accordingly */
/* Call StartTrack at least once after the driver has the latitude            */
int StartTrack(mount *mnt)
{
  
	char slewCmd[8] = { 0x50, 0x03, 0x10, 0x06, 0xff, 0x0ff, 0x00, 0x00 };
	int retval = 0;
	/* 0x50 is pass through code */
	/* 0x03 is number of data bytes including msgId */
	/* 0x10 is the destId for the ra drive, or 0x11 for declination */
	/* 0x06 is the msgId to set a positive drive rate */
	/* 0xff is the first of two data bytes for the sidereal drive rate */
	/* 0xff is the second of two data bytes for the sidereal drive rate */
	/* 0x00 is a null byte */
	/* 0x00 is a request to send no data back other than the # ack */


	if (TelConnectFlag)
	{
		/* Test for southern hemisphere */
		/* Set negative drive rate if we're south of the equator */
		if ( mnt->SiteLatitude < 0. )
		{
			slewCmd[3] = 0x07;
		}

		/* Apply trkSpeed user selection if any */
		slewCmd[4] = trkRate[0];
		slewCmd[5] = trkRate[1];
		slewCmd[6] = trkRate[2];

		if (getMountAck(slewCmd, sizeof(slewCmd)/sizeof(char)))
		{
			sprintf(strMsgLine,"Mount is tracking\n");
			setMessage(strMsgLine);
			mnt->trkActive = 1;
			retval = 1;
		}
		else
		{
			sprintf(strMsgLine,"StartTrack: No acknowledgement from telescope sidereal track on request\n");
			setMessage(strMsgLine);
		}  
	}
	return(retval);
} 


/* Stop tracking if it is running */
int StopTrack(mount *mnt)
{

	char slewCmd[8] = { 0x50, 0x03, 0x10, 0x06, 0x00, 0x00, 0x00, 0x00 };
	int retval = 0;

	/* 0x50 is pass through code */
	/* 0x03 is number of data bytes including msgId */
	/* 0x10 is the destId for the ra drive */
	/* 0x06 is the msgId to set a positive drive rate */
	/* 0x00 is the first of two data bytes for the drive rate */
	/* 0x00 is the second of two data bytes for the drive rate */
	/* 0x00 is a null byte */
	/* 0x00 is a request to send no data back other than the # ack */


	if (TelConnectFlag)
	{
		/* Test for southern hemisphere */
		/* Set negative drive rate if we're south of the equator */

		if ( mnt->SiteLatitude < 0. )
		{
			slewCmd[3] = 0x07;
		}  

		if (getMountAck(slewCmd, sizeof(slewCmd)/sizeof(char)))
		{
			sprintf(strMsgLine,"Mount stopped tracking\n");
			setMessage(strMsgLine);
			mnt->trkActive = 0;
			retval = 1;
		}
		else
		{
			sprintf(strMsgLine,"StopTrack: No acknowledgement from telescope sidereal track off request\n");
			setMessage(strMsgLine);
		}
	}
	return(retval);
}

/* Get tracking status */
int GetTrackStatus(mount *mnt)
{
	int retval = mnt->trkStatus;
	return(retval);
}

/* Get tracking active status */
int GetTrackActive(mount *mnt)
{
	int retval = mnt->trkActive;
	return(retval);
}

/* Set tracking status */
void SetTrackStatus(mount *mnt, int trk)
{
	mnt->trkStatus = trk;
	if (mnt->trkStatus)
	{
		sprintf(strMsgLine,"Setting up for active tracking\n");
	}
	else
	{
		sprintf(strMsgLine,"Setting up for inactive tracking\n");
	}
	setMessage(strMsgLine); 		
	return;
}

/* Full stop */
int FullStop(mount *mnt)
{  
	int retval = 0;

	if (TelConnectFlag)
	{
		sprintf(strMsgLine, "Stop all motion\n");
		setMessage(strMsgLine);  	
		/* Also Clear the slew flag */
		slewphase = 0;
		/* Stop AR */
		retval = retval + StopSlew(mnt, WEST);
		usleep(25000.);
		/* Stop DEC */
		retval = retval + StopSlew(mnt, NORTH);
		usleep(25000.);
		/* Stop tracking */
		retval = retval + StopTrack(mnt);
		usleep(25000.);
		if (retval)
		{
			sprintf(strMsgLine,"All motion stopped\n");
		}
		setMessage(strMsgLine);
	}
	return(retval);
}


#ifdef ISLIMITS
	/* Set slew limits control off or on */
	int SetLimits(int limits)
	{
		int b0;
		char limitCmd[8] = { 0x50, 0x02, 0x10, 0xef, 0x00, 0x00, 0x00, 0x00 };

		/* 0x50 is pass through code */
		/* 0x02 is number of data bytes including msgId */
		/* 0x10 is the destId for the RA drive */
		/* 0xef is the msgId to set hardstop limits state */
		/* 0x00 is the limits control data byte */
		/* 0x00 is the second null data byte */
		/* 0x00 is the third null data byte */
		/* 0x00 is a request to send no data back other than the # ack */

		if ( limits == TRUE )
		{
			limitCmd[4] = 0x01;  
			sprintf(strMsgLine,"Limits enabled\n"); 
			setMessage(strMsgLine);
		}
		else
		{
			sprintf(strMsgLine,"Limits disabled\n");   
			setMessage(strMsgLine);
		}

		if (getMountAck(limitCmd, sizeof(limitCmd)/sizeof(char)))
		{
			b0 = 0;
		}
		else
		{
			sprintf(strMsgLine,"SetLimits: No acknoledge for limits change\n");
			setMessage(strMsgLine);
			b0 = 1;
		} 
		return (b0);
	}


	/* Get status of slew limits control */
	int GetLimits(int *limits)
	{
		char inputstr[2048];
		int b0, b1;
		char limitCmd[8] = { 0x50, 0x01, 0x10, 0xee, 0x00, 0x00, 0x00, 0x01 };

		/* 0x50 is pass through code */
		/* 0x01 is number of data bytes including msgId */
		/* 0x10 is the destId for the RA drive */
		/* 0xee is the msgId to get hardstop limit state */
		/* 0x00 is the first null data byte */
		/* 0x00 is the second null data byte */
		/* 0x00 is the third null data byte */
		/* 0x01 is a request to send one byte data and # ack */
			 
		if (getMountString(limitCmd, sizeof(limitCmd)/sizeof(char), inputstr, 2))
		{
			/* Mask the bytes */
			b0 = (0x000EF & inputstr[0]);
			if ( b0 == 1 )
			{
				*limits = 1;
			}
			else
			{
				*limits = 0;
			}

			if (inputstr[1] == '#')
			{
				b1 = 0;
			}
			else
			{
				b1 = 1;
			}
		}
		else
		{
			sprintf(strMsgLine,"GetLimits: Cannot get limits status from mount\n");
			setMessage(strMsgLine);
			*limits = 0;
			b1 = 1;	
		}
		return (b1);
	}
#endif  

#ifdef ISHEATER
	/* Control the dew heater */
	int Heater(int heatercmd)
	{
		return(1);
	}
#endif

#ifdef ISFAN
	/* Control the OTA fans */
	int Fan(int fancmd)
	{
		char fanCmd[8] = { 0x50, 0x02, 0x13, 0x27, 0x00, 0x00, 0x00, 0x00 };
		int retval = 0;

		/* The CDK20 has one speed */
		/* This switch enables the fans without regard to speed */

		if (TelConnectFlag == TRUE)
		{
			if ( fancmd > FANCMDOFF )
			{
				fanCmd[4] = 0x01;
			} 

			if (tryMountAck(fanCmd, sizeof(fanCmd)/sizeof(char)))
			{
				retval = 1;
			}
			else
			{
				sprintf(strMsgLine,"Fan: No acknowledgement from fan control\n");
				setMessage(strMsgLine);
			}
		}
		else
		{
			sprintf(strMsgLine,"Fan: Telescope is not connected\n");
			setMessage(strMsgLine);
		}		
		return(retval);
	}
#endif

#ifdef ISFOCUS
	/* Adjust the focus */
	int Focus(int focuscmd, int focusspd)
	{
		char focusCmd[8] = { 0x50, 0x02, 0x12, 0x24, 0x01, 0x00, 0x00, 0x00 };
		static int focusflag;
		int retval = 0;

		if (TelConnectFlag == TRUE)
		{
			/* Set the speed */
			focusCmd[4] = 0x08;

			if ( focusspd >= FOCUSSPD4 )
			{
				focusCmd[4] = 0x08;
			}
			else if ( focusspd == FOCUSSPD3 )
			{
				focusCmd[4] = 0x06;
			}
			else if ( focusspd == FOCUSSPD2 )
			{
				focusCmd[4] = 0x04;
			}
			else if ( focusspd == FOCUSSPD1 )
			{
				focusCmd[4] = 0x02;
			}
		
			if ( focuscmd == FOCUSCMDIN )
			{
				sprintf(strMsgLine,"Focus moving in\n");
				/* Run the focus motor in */

				focusflag = -1;

				/* Set the direction */
				if (FOCUSDIR > 0)
				{
					focusCmd[3] = 0x25;
				}
				else
				{
					focusCmd[3] = 0x24;
				}
				
				if (tryMountAck(focusCmd, sizeof(focusCmd)/sizeof(char)))
				{
					setMessage(strMsgLine);
					retval = 1;
				}
				else
				{
					sprintf(strMsgLine,"Focus: No acknowledgement from focus control\n");
					setMessage(strMsgLine);
				}      
			}
			else if ( focuscmd == FOCUSCMDOUT )
			{  
				sprintf(strMsgLine,"Focus moving out\n");
				/* Run the focus motor out */

				focusflag = 1;

				/* Set the direction */
				if (FOCUSDIR > 0)
				{
					focusCmd[3] = 0x24;
				}
				else
				{
					focusCmd[3] = 0x25;
				}
		
				if (tryMountAck(focusCmd, sizeof(focusCmd)/sizeof(char)))
				{
					setMessage(strMsgLine);
					retval = 1;
				}
				else
				{
					sprintf(strMsgLine,"Focus: No acknowledgement from focus control\n");
					setMessage(strMsgLine);
				}      
			}
			else if ( focuscmd == FOCUSCMDOFF )
			{
				if (focusflag != 0)
				{
					strcat(strMsgLine,"Focus motion off\n");
					/* Focus is in motion */      
					/* Set the speed to zero to stop the motion */

					focusCmd[4] = 0x00;

					if (tryMountAck(focusCmd, sizeof(focusCmd)/sizeof(char)))
					{
						/* Reset focusflag */
						focusflag = 0;
						setMessage(strMsgLine);
						retval = 1;
					}
					else
					{
						sprintf(strMsgLine,"No acknowledgement from focus control\n");
						setMessage(strMsgLine);
					}
				}  
				else
				{			  
					/* Focus motion is flagged as stopped so there should be nothing to do */
				}  
			} 
		}  
		else
		{
			sprintf(strMsgLine,"Focus: Telescope is not connected\n");
			setMessage(strMsgLine);
		}		
		return(retval);
	}

	/* Report the current focus reading */
	int GetFocus(double *telfocus)
	{
		/* Focus motor device ID 0x12 */
		/* MC_GET_POSITION is 0x01 */
		/* Bytes in response are 0x03 */

		char focusCmd[8] = { 0x50, 0x01, 0x12, 0x01, 0x00, 0x00, 0x00, 0x03 };
		char returnstr[2048];  
		int b0,b1,b2;
		int count;
		double focus;
		int retval = 0;

		if (TelConnectFlag == TRUE)
		{
			if (tryMountString(focusCmd, sizeof(focusCmd)/sizeof(char), returnstr, 4))
			{
				b0 = (unsigned char) returnstr[0];
				b1 = (unsigned char) returnstr[1];
				b2 = (unsigned char) returnstr[2];

				/* These counts roll over to 255 when the counter goes negative. */
				/* That is, 256*256*255 + 256*255 + 255 is -1 */
				count = 256*256*b0 + 256*b1 + b2;

				/* Use a scale which goes negative below zero */
				if (count > 8388608)
				{
					count = count - 16777217;
				}

				focus = count;

				/* Apply a conversion so that the focus scale comes out in decimal microns. */
				/* The variable FOCUSSCALE is defined globally. */
				focus = focus / FOCUSSCALE;     
				*telfocus = focus;
				retval = 1;
			}
			else
			{
				sprintf(strMsgLine,"GetFocus: Could not get position from focus controller\n");
				setMessage(strMsgLine);
			}
		}
		else
		{
			sprintf(strMsgLine,"GetFocus: Telescope is not connected\n");
			setMessage(strMsgLine);
		}		
		return(retval);
	}

	/* Report the temperature */
	int GetTemperature(double *teltemperature)
	{	  
		char focusCmd[8] = { 0x50, 0x02, 0x12, 0x26, 0x00, 0x00, 0x00, 0x02 };
		char returnstr[2048];  
		int b0,b1;
		int count;
		double value;
		int retval = 0;

		if (TelConnectFlag == TRUE)
		{
			value = 0.;

			if (tryMountString(focusCmd, sizeof(focusCmd)/sizeof(char), returnstr, 3))
			{
				b0 = (unsigned char) returnstr[0];
				b1 = (unsigned char) returnstr[1];

				/* In the C20 the counts are left shifted by 4 bits */
				/* The total count comes in increments of 16 for a 12 bit sensor */

				/* These counts roll over to 255 when the counter goes negative. */
				/* That is, 256*255 + 255 is -1 */
				count = 256*b0 + b1;

				/* Use a scale which goes negative below zero */
				if (count > 32768)
				{
					count = count - 65537;
				}

				/* Apply the calibration for the Maxim DS18B20 sensor in the OTA */
				/* Right shift the bits to match the specification calibration */
				value = count/16;
				value = 0.0625 * value;

				/* Test for out of range as an indicator of sensor not present */
				/* Set an out of range value that is not annoying in a display */
				if ((value < -50 ) || (value > 50) )
				{
					value = 0.;
				} 
				*teltemperature = value; 
				retval = 1;
			}
			else
			{
				sprintf(strMsgLine,"GetTemperature: Could not get temperature from focus controller\n");
				setMessage(strMsgLine);
			}
		}
		else
		{
			sprintf(strMsgLine,"GetTemperature: Telescope is not connected\n");
			setMessage(strMsgLine);
		}  
		return(retval);
	}
#endif

/* Serial port utilities */
int ttywrite(int fd, const char * buffer, int nbytes)
{
	int err_code = 0, nbytes_written = 0;

	ttyerrormsg[0] = '\0';

	if ((err_code = tty_write(fd, buffer, nbytes, &nbytes_written)) != TTY_OK)
	{
		tty_error_msg(err_code, ttyerrormsg, TTY_ERRMSG_SIZE);
		setMessage(ttyerrormsg); 
	}
	return nbytes_written;
}

int ttyread(int fd, char *buf)
{
	int err_code = 0, nbytes_read = 0;

	// Clear string(s)
	ttyerrormsg[0] = '\0';
	buf[0] = '\0';
    if ((err_code = tty_read_section(fd, buf, 0x23, READ_TIME, &nbytes_read)) != TTY_OK)
    {
		tty_error_msg(err_code, ttyerrormsg, TTY_ERRMSG_SIZE);
		setMessage(ttyerrormsg); 
	}
	return nbytes_read;
}

int getMountAck (char *sendstr, int sendlen)
{
	char returnstr[RES_LEN];

	return (getMountString(sendstr, sendlen, returnstr, -1));
}

int getMountString(char *sendstr, int sendlen, char *returnstr, int expected)
{
	int retval = 0, nbytes_read = 0, err = 0, i = 0;

	if (TelConnectFlag == TRUE)
	{
		while (retval == 0)
		{
			/* Flush the input buffer */
			tcflush(TelPortFD,TCIOFLUSH);

			if (ttywrite(TelPortFD, sendstr, sendlen))
			{
				usleep(100000);
				nbytes_read = ttyread(TelPortFD, returnstr);
				if (nbytes_read == expected || expected == -1)
				{
					retval = 1;
					if (err)
					{
						err = 0;
						sprintf(strMsgLine, "getMountString: Ok.\n");
						setMessage(strMsgLine); 
					}
				}	
				else
				{
					err = 1;
					sprintf(strMsgLine, "getMountString: Attempt %d to read command reply, failed. Wait...\n", (i + 1));
					setMessage(strMsgLine); 
					usleep(1000000);
					i++;
				}	
			}
			else
			{
				err = 1;
				sprintf(strMsgLine, "getMountString: Attempt write command failed.\n");
				setMessage(strMsgLine); 
				usleep(1000000);
				i++;
			}
			if ((i % CMD_RETRY) == 0 && retval == 0)
			{
				if (!comfailCB())
				{
					break;
				}
			}
		}
		if (retval == 0)
		{
			// On total failure, telescope is not connected...
			TelConnectFlag = FALSE;
			sprintf(strMsgLine, "Telescope does not respond\nPort closed\n");
			setMessage(strMsgLine);
			close(TelPortFD);
		}
	}
	return(retval);
}

int tryMountAck (char *sendstr, int sendlen)
{
	char returnstr[RES_LEN];

	return (tryMountString(sendstr, sendlen, returnstr, -1));
}

int tryMountString(char *sendstr, int sendlen, char *returnstr, int expected)
{
	int retval = 0, nbytes_read = 0;

	if (TelConnectFlag == TRUE)
	{
		/* Flush the input buffer */
		tcflush(TelPortFD,TCIOFLUSH);

		if (ttywrite(TelPortFD, sendstr, sendlen))
		{
			usleep(100000);
			nbytes_read = ttyread(TelPortFD, returnstr);
			if (nbytes_read == expected || expected == -1)
			{
				retval = 1;
			}	
			else
			{
				sprintf(strMsgLine, "tryMountString: Attempt to read command reply, failed. \n");
				setMessage(strMsgLine); 
				usleep(1000000);
			}	
		}
		else
		{
			sprintf(strMsgLine, "tryMountString: Attempt write command failed.\n");
			setMessage(strMsgLine); 
			usleep(1000000);
		}
	}
	return(retval);
}



