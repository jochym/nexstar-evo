#include <stdio.h>
#include <math.h>
#include <signal.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <ctype.h>
#include <sys/stat.h>
#include <stdlib.h>

#include <Xm/Xm.h>
#include <Xm/Form.h>
#include <Xm/ToggleB.h>
#include <Xm/FileSB.h>
#include <Xm/PushB.h>
#include <Xm/Label.h>
#include <Xm/RowColumn.h> 
#include <Xm/CascadeB.h>
#include <Xm/MessageB.h>
#include <Xm/Separator.h>
#include <Xm/SelectioB.h>
#include <Xm/Text.h>
#include <Xm/List.h>
#include <Xm/ArrowBG.h>

#include "utils.h"

char * padl(char * strinput, size_t len, char * pad) 
{
	size_t lenstrinput = strlen(strinput);
	size_t lenpad = strlen(pad);
	size_t padlen;
	static char * padded;
	
	padded = (char*)realloc(padded, (lenstrinput + lenpad + 1));

	padlen = len - lenstrinput;
	
	if (padlen > 0)
	{
		/* prepare for first append of pad */
		padded = 0; 
		for(padlen += 1; padlen > 0; padlen--, padded += lenpad)
		{
			strncpy(padded, pad, lenpad);
		}
		strcat(padded, strinput);
	}
	else
	{
		strncpy(padded, strinput, len);
		padded[len] = '\0';
	}
	return padded;
}

char * padr(char * strinput, size_t len, char * pad) 
{
	size_t lenstrinput = strlen(strinput);
	size_t lenpad = strlen(pad);
	size_t padlen;
	static char * padded;
	
	padded = (char*)realloc(padded, (lenstrinput + lenpad + 1));
	
	padlen = len - lenstrinput;
	
	if (padlen > 0)
	{
		/* copy without '\0' */
		strncpy(padded, strinput, lenstrinput); 

		/* prepare for first append of pad */
		padded += lenstrinput; 
		for(padlen += 1; padlen > 0; padlen--, padded += lenpad)
		{
			strncpy(padded, pad, lenpad);
		}
		*padded = '\0';
	}
	else
	{
		strncpy(padded, strinput, len);
		padded[len] = '\0';
	}
	return padded;
}

char * mid(char * strinput, size_t start, size_t len)
{
	static char * dst;
	
	dst = (char*)realloc(dst, (len + 1));

	strncpy(dst, (strinput + start), len);
	dst[len] = '\0';
	return dst;
}

char * left(char * strinput, size_t len)
{
	static char * dst;
	dst = (char*)realloc(dst, (len + 1));

	strncpy(dst, strinput, len);
	dst[len + 1] = '\0';
	return dst;
}

char * right(char * strinput, size_t len)
{
	size_t index = (strlen(strinput) - len);
	size_t i;
	static char * dst;
	
	dst = (char*)realloc(dst, (len + 1));
	
	if (index > 0)
	{
		for(strinput += index, i = 0; i < len; i++, strinput++)
		{
			strncpy(dst, strinput, 1);
		}
		dst[len + 1] = '\0';
	}
	else
	{
		strcpy(dst, strinput);
	}	
	return dst;
}

char * replace(char *strbuf, const char *strold, const char *strnew) 
{
	static char *strret = NULL;
	char *p = NULL;
	char *posnews, *posold;
	size_t szold = strlen(strold);
	size_t sznew = strlen(strnew);
	size_t n = 1;

	if(!strbuf)
		return NULL;
	if(!strold || !strnew || !(p = strstr(strbuf, strold)))
		return strbuf;

	while(n > 0) 
	{
		if(!(p = strstr(p+1, strold)))
		{
			break;
		}
		n++;
	}
	strret = (char*)realloc(strret, (strlen(strbuf) - (n*szold) + (n*sznew) + 1));

	p = strstr(strbuf, strold);

	strncpy(strret, strbuf, (p-strbuf));
	strret[p-strbuf] = 0;
	posold = p+szold;
	posnews = strret+(p-strbuf);
	strcpy(posnews, strnew);
	posnews += sznew;

	while(n > 0) {
		if(!(p = strstr(posold, strold)))
		{
			break;
		}
		strncpy(posnews, posold, p-posold);
		posnews[p-posold] = 0;
		posnews += (p-posold);
		strcpy(posnews, strnew);
		posnews += sznew;
		posold = p+szold;
	}

	strcpy(posnews, posold);
	return strret;
}

size_t strcrspn( char * s1, char * s2 )
{
	char * ss1;
	char * sss1;
	char * sss2;
	size_t index = 0;

	if( *( s2 ) == '\0' )
	{
		return index;
	}

	ss1 = s1 + strlen( s1 );

	while( ss1 != s1 )
	{
		--ss1;

		for( sss1 = ss1, sss2 = s2; ; )
		{
			if( *( sss1++ ) != *( sss2++ ) )
			{
				break;
			}
			else if ( * sss2 == '\0' )
			{
				index = (ss1 - s1);
				return index;
			}
		}
	}

	return index;
} 

int file_exists (char * fileName)
{
	struct stat buf;
	int i = stat ( fileName, &buf );
	// File found
	if ( i == 0 )
	{
		return 1;
	}
	return 0;       
}

/* 
** AskUser() -- a generalized routine that asks the user a question 
** and returns the Yes/No response.
*/
int msgbox (Widget parent, char *question, int mode, char *title)
{
    static Widget       dialog;
    XmString            text, yes, no;
    static int          answer;
    void                response(Widget, XtPointer, XtPointer);

    if (!dialog) 
    {
		dialog = XmCreateQuestionDialog (parent, title, NULL, 0);
		XtAddCallback (dialog, XmNokCallback, __msgbox, (XtPointer) &answer);
		XtAddCallback (dialog, XmNcancelCallback, __msgbox, (XtPointer) &answer);
		//XtSetSensitive (XtNameToWidget (dialog, "Help"), False);
		XtUnmanageChild(XtNameToWidget (dialog, "Help"));
	}
	if (mode == 1)
	{
		yes = XmStringCreateLocalized ("Yes");
		no = XmStringCreateLocalized ("No");
	}
	else
	{
		yes = XmStringCreateLocalized ("Ok");
		no = XmStringCreateLocalized ("Cancel");
	}
	XtVaSetValues (dialog, XmNdialogStyle, XmDIALOG_FULL_APPLICATION_MODAL, XmNokLabelString, yes, XmNcancelLabelString, no, NULL);
	XmStringFree (yes);
	XmStringFree (no);

    answer = -1;    
    text = XmStringCreateLocalized (question);
    XtVaSetValues (dialog, XmNmessageString, text, NULL);
    XmStringFree (text);
    XtManageChild (dialog);
    /* while the user hasn't provided an answer, simulate main loop. 
    ** The answer changes as soon as the user selects one of the 
    ** buttons and the callback routine changes its value. 
    */
    while (answer == -1)
    {
        XtAppProcessEvent (XtWidgetToApplicationContext(parent), XtIMAll);
	}
    XtUnmanageChild (dialog);
    return answer;
}

int infobox (Widget parent, char *infotext, char *title)
{
    static Widget       dialog;
    XmString            text;
    static int          answer;
    void                response(Widget, XtPointer, XtPointer);

    if (!dialog) 
    {
		dialog = XmCreateQuestionDialog (parent, title, NULL, 0);
		XtAddCallback (dialog, XmNokCallback, __msgbox, (XtPointer) &answer);
		//XtSetSensitive (XtNameToWidget (dialog, "Help"), False);
		XtUnmanageChild(XtNameToWidget (dialog, "Help"));
		XtUnmanageChild(XtNameToWidget (dialog, "Cancel"));
		XtVaSetValues (dialog, XmNdialogStyle, XmDIALOG_FULL_APPLICATION_MODAL, NULL);
	}

    answer = -1;    
    text = XmStringCreateLocalized (infotext);
    XtVaSetValues (dialog, XmNmessageString, text, NULL);
    XmStringFree (text);
    XtManageChild (dialog);
    /* while the user hasn't provided an answer, simulate main loop. 
    ** The answer changes as soon as the user selects one of the 
    ** buttons and the callback routine changes its value. 
    */
    while (answer == -1)
    {
        XtAppProcessEvent (XtWidgetToApplicationContext(parent), XtIMAll);
	}
    XtUnmanageChild (dialog);
    return answer;
}

/* response() --The user made some sort of response to the
** question posed in AskUser(). Set the answer (client_data)
** accordingly and destroy the dialog.
*/
void __msgbox (Widget widget, XtPointer client_data, XtPointer call_data)
{
    int *answer = (int *) client_data;
    XmAnyCallbackStruct *cbs = (XmAnyCallbackStruct *) call_data;

    switch (cbs->reason) 
    {
        case XmCR_OK     : *answer = __YES;   break;
        case XmCR_CANCEL : *answer = __NO;    break;
        default          : return;
    }
}

/* ForceUpdate() -- a superset of XmUpdateDisplay() that ensures
** that a window's contents are visible before returning. 
** The monitoring of window states is necessary because an attempt to
** map a window is subject to the whim of the window manager, which can
** introduce a significant delay before the window is actually mapped
** and exposed. This function is intended to be called after XtPopup(), 
** XtManageChild() or XMapRaised(). Don't use it in other situations
** as it may sit and process other unrelated events until the widget
** becomes visible.
*/

/* The parameter widget must be visible before the function returns */
void ForceUpdate (Widget w)
{
    Widget             diashell, topshell;
    Window             diawindow, topwindow;
    XtAppContext       cxt = XtWidgetToApplicationContext (w);
    Display            *dpy;
    XWindowAttributes  xwa;
    XEvent             event;
    /* Locate the shell we are interested in */
    for (diashell = w; !XtIsShell (diashell);
        diashell = XtParent (diashell));
    /* Locate its primary window's shell (which may be the same) */
    for (topshell = diashell; !XtIsTopLevelShell (topshell);
        topshell = XtParent (topshell));
    /* If the dialog shell (or its primary shell window) is
    ** not realized, don't bother... nothing can possibly happen.
    */
    if (XtIsRealized (diashell) && XtIsRealized (topshell)) {
        dpy = XtDisplay (topshell);
        diawindow = XtWindow (diashell);
        topwindow = XtWindow (topshell);

        /* Wait for the dialog to be mapped.
        ** It's guaranteed to become so
        */
        while (XGetWindowAttributes (dpy, diawindow, &xwa) &&
                                    xwa.map_state != IsViewable) {
            /*...if the primary is (or becomes) unviewable or
            ** unmapped, it's probably iconic, and nothing will happen.
            */
            if (XGetWindowAttributes (dpy, topwindow, &xwa) &&
                                    xwa.map_state != IsViewable)
                break;
            /* we are guaranteed there will be an event of some kind. */
            XtAppNextEvent (cxt, &event);
            XtDispatchEvent (&event);
        }
    }
    /* The next XSync() will get an expose event. */
    XmUpdateDisplay (topshell);
}

