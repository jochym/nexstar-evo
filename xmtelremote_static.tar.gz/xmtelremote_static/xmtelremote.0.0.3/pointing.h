#ifndef POINTING_H
	#define POINTING_H
	/* -----------------------------------------------------------                */
	/* -         Protocol header for telescope control routines  -                */
	/* -----------------------------------------------------------                */
	/*                                                                            */

	/* Pointing models (bit mapped and additive)                                 */
	#define RAW       0      /* Unnmodified but assumed zero corrected */
	#define OFFSET    1      /* Correct for target offset*/
	#define REFRACT   2      /* Correct for atmospheric refraction */
	#define POLAR     4      /* Correct for polar axis misalignment */ 
	#define DECAXIS   8      /* Correct for non-orthogonal angle between axes */
	#define OPTAXIS  16      /* Correct for optical axis misalignment */
	#define FLEXURE  32      /* Correct for flexure */

	/* Prototypes */

	void   PointingFromTel (mount *mnt, double *telra1, double *teldec1, double telra0, double teldec0, int pmodel);
	void   PointingToTel (mount *mnt, double *telra0, double *teldec0, double telra1, double teldec1, int pmodel);
	void   Refraction(mount *mnt, double *ha, double *dec, int dirflag);
	void   Polar(mount *mnt, double *ha, double *dec, int dirflag);
	void   Decaxis(mount *mnt, double *ha, double *dec, int dirflag);
	void   Optaxis(mount *mnt, double *ha, double *dec, int dirflag);
	void   Flexure(mount *mnt, double *ha, double *dec, int dirflag);
#endif
