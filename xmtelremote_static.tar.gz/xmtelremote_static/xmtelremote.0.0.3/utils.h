#ifndef UTILS_H
	#define UTILS_H
	#define __YES 1
	#define __NO  0

	#define MSGOKCANCEL  0
	#define MSGYESNO     1

	char * padl(char * strinput, size_t padlen, char * pad);
	char * padr(char * strinput, size_t padlen, char * pad);
	char * mid(char * strinput, size_t start, size_t len);
	char * left(char * strinput, size_t len);
	char * right(char * strinput, size_t len);
	char * replace(char *strbuf, const char *strold, const char *strnew);

	size_t strcrspn(char * s1, char * s2);

	int msgbox (Widget parent, char *question, int mode, char *title);
	int infobox (Widget parent, char *infotext, char *title);
	void __msgbox (Widget widget, XtPointer client_data, XtPointer call_data);
	void ForceUpdate (Widget w);
#endif
