/* -                   Astronomical Telescope Control                    - */
/* -                       XMtelRemote User Interface                    - */
/* ----------------------------------------------------------------------- */
/* Based on the sterling work of mr. John Kielkopf                         */
/* Copyright (c) 2010 John Kielkopf                                        */
/* kielkopf@louisville.edu                                                 */
/* Copyright (c) 2012 Giampiero Spezzano                                   */
/* gspezzano@gmail.com                                                     */
/*                                                                         */
/* This file is part of XMtelRemote.                                       */
/*                                                                         */
/* Distributed under the terms of the General Public License (see LICENSE) */ 
/*                                                                         */
/* Date: June 16, 2010                                                     */
/* Version: 5.2.0                                                          */
/* Date: April 01, 2012                                                    */
/* Version: 0.0.1 - based on xmtel 5.2.0                                   */
/* Date: March 01, 2012                                                    */
/* Version: 0.0.2 - code rearranged for better protocol separation         */

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>
#include <unistd.h>

#include <time.h>
#include <fcntl.h>

#include <Xm/Xm.h>
#include <Xm/Protocols.h>
#include <Xm/Form.h>
#include <Xm/Separator.h>
#include <Xm/RowColumn.h> 
#include <Xm/Label.h>
#include <Xm/Text.h>
#include <Xm/TextF.h>
#include <Xm/PushB.h>
#include <Xm/ArrowBG.h>
#include <Xm/ToggleB.h>
#include <Xm/SpinB.h>
#include <Xm/List.h>
#include <Xm/FileSB.h>
#include <Xm/CascadeB.h>
#include <Xm/MessageB.h>
#include <Xm/SelectioB.h>

#include "algorithms.h"
#include "pointing.h"
#include "xmtelremote.h"
#include "utils.h"
#include "logging.h"
#include "gps.h"

XtAppContext context;
//XmStringCharSet char_set=XmSTRING_DEFAULT_CHARSET;
//XmStringCharSet char_set=XmFONTLIST_DEFAULT_TAG;

/* Widgets for the menu bar */
Widget menu_bar;
Widget file_menu;
Widget file_cascade;
Widget newqueue_item;
Widget newhistory_item;
Widget edit_cascade;
Widget editqueue_item;
Widget editlog_item;
Widget savequeue_item;
Widget savehistory_item;
Widget savestatus_item;
Widget exit_item;
Widget telescope_menu;
Widget telescope_cascade;
#ifdef ISLEVEL
	Widget tellevel_item;
#endif
Widget telpole_item;
Widget telsky_item;
Widget telpark_item;
#ifdef ISFOCUS
	Widget telfocus_item;
#endif
#ifdef ISFAN
	Widget telfan_item;
#endif
#ifdef ISHEATER
	Widget telheater_item;
#endif
Widget pointing_menu;
Widget pointing_cascade;
Widget p_options_toggle_1;
Widget p_options_toggle_2;
Widget p_options_toggle_4;
Widget p_options_toggle_8;
Widget p_options_toggle_16;
Widget p_options_toggle_32;
Widget p_options_toggle_64;
Widget setup_menu;
Widget setup_cascade;
Widget telsite_item;
Widget newconfig_item;
Widget editconfig_item;
Widget newhorizon_item;
Widget edithorizon_item;
Widget tools_menu;
Widget tools_cascade;
Widget toolshome_item;
Widget toolsmeridian_item;
Widget toolszenith_item;

/* Widgets for the panel */
Widget toplevel;
Widget toggle_slew;
Widget toggle_trak;
Widget faketab;
Widget label_slew;
Widget label_trak;
Widget dialog;
Widget button[4];
Widget command[CMD_BUTTONS];
Widget toggleS[2];
Widget toggle[9];
Widget toggleT[4];
Widget guidespin_box;
Widget guidespin;
Widget guidespin_r;
Widget guidespin_d;
Widget guidespin_lr;
Widget guidespin_ld;
Widget trkspin_box;
Widget trkspin;
Widget trkspin_d;
Widget trkspin_ld;
Widget trkspin_m;
Widget trkspin_lm;
Widget trkspin_s;
Widget trkspin_ls;
Widget toggleFT[3];
Widget opteqaz;
Widget form;
Widget sep_btns;
Widget sep_coords;
Widget sep_queue;

Widget txtserport;
Widget lblteldata;
Widget lblisalign;

Widget read_file;
Widget save_file;
Widget read_configfile;
Widget dlgskyalign;

Widget queue_area;
Widget history_area;
Widget message_area;
Widget radio_box;

#ifdef ISFOCUS
	/* Widgets for the focus panel */
	Widget focus_control;     
	Widget focus_in_button;
	Widget focus_out_button;
	Widget focus_ok_button;
	Widget focus_count_label;
	Widget focus_spd_radio_box;
	Widget focus_spd_toggle[4];
#endif

#ifdef ISFAN
	/* Widgets for the fan panel */
	Widget fan_control;     
	Widget fan_ok_button;
	Widget fan_spd_radio_box;
	Widget fan_spd_toggle[3];
#endif

#ifdef ISHEATER
	/* Widgets for the heater panel */
	Widget heater_control;     
	Widget heater_ok_button;
	Widget heater_pwr_radio_box;
	Widget heater_pwr_toggle[3];
#endif

/* Widgets for the Site(gps) panel */
Widget site_control;     
Widget site_gps_port;
Widget site_gps_connect;
Widget site_lblaux;
Widget site_Longitude;
Widget site_Longitude_n;
Widget site_Longitude_l;
Widget site_Latitude;
Widget site_Latitude_n;
Widget site_Latitude_l;
Widget site_Altitude;
Widget site_Altitude_l;
Widget site_Temperature;
Widget site_Temperature_l;
Widget site_Pressure;
Widget site_Pressure_l;
Widget site_apply;
Widget nvj_apply;
Widget site_TimeDifference;
Widget site_TimeDifference_l;
Widget site_timeapply;
Widget site_sep1;
Widget site_sep2;

/* Labels for the guide buttons top to bottom then left to right */
static int btn_name[4] = {
    XmARROW_UP,
    XmARROW_LEFT,
    XmARROW_RIGHT,
    XmARROW_DOWN
};

static int btn_pos[4][2] = {
    {274,  34},
    {210,  98},
    {339,  98},
    {274, 158}
};

/* Simple labels for the command area top to bottom, left to right */
static char cmd_name[CMD_BUTTONS][15] = {
    "Connect",
    "Track",  
    "Stop",
    "Slew",
    "Sleep",
    "Wake",
    "Sync",
    "Clear sync",
	"Mark Position",
	"Ra : 00:00:00",
	"Dec: 00:00:00",
	"Epoch: Now",
	"Mark Target",
	"Ra : 00:00:00",
	"Dec: 00:00:00",
	"Epoch: Now",
	"Test"
};

static int cmd_pos[CMD_BUTTONS][4] = {
    {136,  34, 75, 28},
    {276, 101, 62, 28},
    {276, 129, 62, 28},
    {215, 175, 55, 48},
    { 12, 200, 98, 28},
    { 12, 228, 98, 28},
    {110, 200, 98, 28},
    {110, 228, 98, 28},
    { 12, 262, 98, 28},
    {110, 262, 98, 28},
    {208, 262, 98, 28},
    {306, 262, 98, 28},
    { 12, 290, 98, 28},
    {110, 290, 98, 28},
    {208, 290, 98, 28},
    {306, 290, 98, 28},
    {344, 175, 55, 48}
};

/* Labels for the guide speed settings */
static char spd_name[][2] = {
    "9",
    "8",
    "7",
    "6",
    "5",
    "4",
    "3",
    "2",   
    "1"   
};

/* Labels for the tracking speed settings */
static char trk_name[][10] = {
    "Sidereal",
    "Lunar",
    "Solar",
    "Custom"
};

/* Labels for the tracking speed settings */
static char fakepanel_name[][10] = {
    "Queue",
	"History",
    "Status"
};

#ifdef ISFOCUS
	/* Labels for the focus speed settings */
	static char focus_spd_name[][12] = {
		 "Fast",
		 "Medium",
		 "Slow",
		 "Precise" 
	};   
#endif

#ifdef ISFAN
/* Labels for the fan speed settings */
static char fan_spd_name[][12] = {
     "High",
     "Low",
     "Off"
};
#endif

#ifdef ISHEATER
	/* Labels for the heater power settings */
	static char heater_pwr_name[][12] = {
		 "High",
		 "Low",
		 "Off"
	};
#endif

char strMsgLine[256];

/* Telescope / site variables */
mount   mnt;
gpsdata gps;

#ifdef ISFOCUS
	double telfocus;               /* Focuser position         */
	double teltemperature;         /* OTA temperature sensor   */
#endif
#ifdef ISROTATOR
	double telrotation;            /* Rotator angle            */ 
#endif

int display_telepoch=EOD;             	/* display epoch for telescope */
int display_targetepoch=EOD;          	/* display epoch for target  */
int showradec = RADEC;					//Show 1=Ra/Dec 0=Az/Alt
int pmodel=RAW;                       	/* pointing model default to raw data */
#ifdef ISFOCUS
	int focuscmd=FOCUSCMDOFF;             	/* Flag to indicate current focus activity */
	int focusspd=FOCUSSPD4;               	/* Flag to indicate current focus speed */
#endif
#ifdef ISFAN
	int fancmd=FANCMDOFF;                 	/* Flag to indicate fan state */
#endif
#ifdef ISHEATER
	int heatercmd=HEATERCMDOFF;           	/* Flag to indicate heater state */
#endif
                   
int tgtfield;                         	/* flag for target input */

int slewflag = FALSE;                 	/* slew progress flag */
int gotoflag = FALSE;                 	/* goto in progress flag */
#ifdef ISLEVEL
	int levelflag = FALSE;                	/* level progress flag */
#endif
int errflag = FALSE;                  	/* Communication error flag */
int hidepopup = FALSE;

/* Other Features, will honour header constant or the CONFIGFILE if available */
#ifdef ISFAN
	int fandisabled = 1;			/* Fan feature disabled */
#endif
#ifdef ISHEATER
	int heaterdisabled = 1;			/* Heater feature disabled */
#endif
#ifdef ISFOCUS
	int focusdisabled = 1;			/* Focus feature disabled */
#endif
int horizondisabled = 1;		/* Horizon disabled disabled */
int rpipedisabled = 0;			/* read pipe disabled */
int wpipedisabled = 0;			/* read pipe disabled */
int toolsmenudisabled = 0;      //Goods menu disabled
int autoconnect = 0;			//Telescope auto-connect on startup

/* Files */
int fd_fifo_in, fd_fifo_out;           	/* FIFO file descriptors */
int fifoinput;						   	/* FIFOIN AppInput reference */
static char fifo_in[MAXPATHLEN];       	/* Fifo in file name */
static char fifo_out[MAXPATHLEN];      	/* Fifo out file name */
static char *configfile;               	/* Configuration name */
static char *horizonfile;               /* Horizon name */
FILE *fp_file;                         	/* Generic file pointer      */

/* External commands */
static char editor[MAXPATHLEN];        	/* external queue and log editor */
static char * ptrhome;
static char defaultpath[MAXPATHLEN];

/* Buffers */
char buf[256];                         	/* general purpose character buffer */
char foo[256];                         	/* general purpose character buffer */

/* Queue */
int nqueue = 0;                        	/* number of entries in the queue */
int queuechoice = 0;                   	/* serial number of selected entry */

/* History */
/* The history catalog is a ring buffer starting at 0 for the first entry. */
/* There are nhistory entries in use (<=100). */
int nhistory = 0;                      	/* number of history entries (max 100) */
int last_history_saved = -1;           	/* location for last history saved */
int historychoice = 0;                 	/* serial number of selected entry in history list*/

/* Create the space for catalogs.  Must keep track not to overrun. */
/* Allow one extra entry and watch for maximum number in operations. */
/* History is indexed from 1 for first entry, so 0th entry is not used. */
catalog queue[QUEUELEN + 1];          	/* This holds the observing queue */
catalog history[HISTORYLEN + 1];       	/* This holds the observed hostory */
catalog target[1];                     	/* This holds the current target coordinates at eod*/
catalog telpos[1];                        	/* This holds the telescope coordinates at eod*/

/* End of global definitions */

int main(argc,argv)
	int argc; 
	char *argv[];
{

	// Get home directory once and for all
	ptrhome = getenv ("HOME");
	strcpy(defaultpath,ptrhome);
	
	// Initial telescope set
	reset_telescope();

	/* Create the toplevel shell */
	toplevel = XtAppInitialize(&context,"",NULL,0,&argc,argv, NULL,NULL,0);

	/* Define the defaults for log, queue, and current files */
	setOutput(1); /* 0 = Output to stderr, 1=Output to string, then to program */
	
	/* Set the default configuration file */
	configfile = (char *) malloc (MAXPATHLEN);
	strcpy(configfile, CONFIGFILE);

	/* Set the default horizon file */
	horizonfile = (char *) malloc (MAXPATHLEN);
	strcpy(horizonfile, HORIZONFILE);
	
	/* Read the configuration file and modify defaults as needed */
	set_init_config();
	read_config();
	reset_site();

	if (!errflag)
	{	
		/* Create Main Window */
		create_main_window();  

		/* Apply the configuration to the GUI */
		apply_config();
		log_status();
		
		/* Start the fifo communications first (eventually)*/
		/* Start XEphem after XmTel is running */
		if (!rpipedisabled || !wpipedisabled)
		{
			link_fifos();
		}
		setMessage("-----------------------------------\n");
		
		/* Service status display and slewing poll */
		poll_interval_id = XtAppAddTimeOut(context, poll_interval, poll_interval_handler, poll_interval_data_ptr); 
		
		//Autoconect eventually
		if (autoconnect)
		{
			commandCB(command[CMD_CONNECT], CMD_CONNECT, NULL);
		} 

		/* Start the user interface */
		XtRealizeWidget(toplevel);

		// The application close callback to manage the program end gracefully
		Atom wm_delete_window = XmInternAtom(XtDisplay(toplevel), "WM_DELETE_WINDOW", FALSE);
		XmAddWMProtocolCallback(toplevel, wm_delete_window, close_app_callback, NULL); 
		
		XtAppMainLoop(context);
	}
	else
	{
		printf("Error reading config file: '%s'\nExecution aborted.", configfile);
	}
	exit(0);
}

void set_init_config()
{
	// Set the defalt Disabled flag for goods menu
	toolsmenudisabled = TOOLSDISABLED;
	
	#ifdef ISFAN
		/* Set the default fan enable status */
		fandisabled = FANDISABLED;
	#endif
	
	#ifdef ISHEATER
		/* Set the default heater enable status */
		heaterdisabled = HEATERDISABLED;
	#endif
	
	#ifdef ISFOCUS
		/* Set the default focus enable status */
		focusdisabled = FOCUSDISABLED;
	#endif

	horizondisabled = HORIZONDISABLED;
	
	/* Set the default editor */
	strcpy(editor, XMTEL_EDITOR);

	/* Set the default pipe communication enable status */
	rpipedisabled = RPIPEDISABLED;
	wpipedisabled = WPIPEDISABLED;
	autoconnect = AUTOCONNECT;

	/* Set the default pipe file names */
	strcpy (fifo_in, READPIPE);                  
	strcpy (fifo_out, WRITEPIPE);                 
}
void close_app_callback(Widget w, XtPointer client_data, XtPointer call_data)
{
	if (mnt.tellink)
	{
		unlink_telescope();
	}
	
	exit(0);
	return;
}

/* Add an item into a menu in the menubar */  
Widget make_menu_item(item_name,client_data,menu)
	char *item_name;
	int client_data;
	Widget menu;
{
	int ac;
	Arg al[16];
	Widget item;

	ac = 0;
	XtSetArg(al[ac], XmNlabelString, XmStringCreateLocalized(item_name)); ac++;      
	item=XmCreatePushButton(menu,item_name,al,ac);
	XtManageChild(item);
	XtAddCallback (item,XmNactivateCallback,menuCB,(XtPointer) client_data);      
	XtSetSensitive(item,True);
	return(item);
}

/* Add a toggle item into a menu in the menubar */     
Widget make_menu_toggle(item_name,client_data,menu)
	char *item_name;
	int client_data;
	Widget menu;
{
	int ac;
	Arg al[16];
	Widget item;

	ac = 0;
	XtSetArg(al[ac], XmNlabelString, XmStringCreateLocalized(item_name)); ac++;      
	item=XmCreateToggleButton(menu,item_name,al,ac);
	XtManageChild(item);
	XtAddCallback (item,XmNvalueChangedCallback,menuCB,(XtPointer) client_data);      
	XtSetSensitive(item,True);
	return(item);
}

/* Creates a menu on the menu bar */
Widget make_menu(menu_name,menu_bar, menu_cascade)
	char *menu_name; 
	Widget menu_bar;
	Widget *menu_cascade;
{
	int ac;
	Arg al[16];
	Widget menu, cascade;
	
	ac=0;
	XtSetArg(al[ac], XmNborderWidth, 1); ac++;      
	XtSetArg(al[ac], XmNentryBorder, 1); ac++;      
	menu=XmCreatePulldownMenu(menu_bar,menu_name,al,ac);

	ac=0;
	XtSetArg(al[ac],XmNsubMenuId,menu);  ac++;
	XtSetArg(al[ac],XmNlabelString, XmStringCreateLocalized(menu_name)); ac++;
	cascade=XmCreateCascadeButton(menu_bar,menu_name,al,ac);      
	XtManageChild (cascade); 
	*menu_cascade = cascade;
	return(menu);
}

/* Create Main Window */
void create_main_window()
{
	Arg al[15];
	int ac;
	int x;
	
	// Note that locations of widgts are in pixels

	/* Set the default size of the window */ 
	ac=0;
	XtSetArg(al[ac],XmNwidth,415); ac++;
	XtSetArg(al[ac],XmNheight,560); ac++;
	XtSetArg(al[ac],XmNminWidth,415); ac++;
	XtSetArg(al[ac],XmNminHeight,460); ac++;
	XtSetValues(toplevel,al,ac);

	/* Create a form widget */
	ac=0;
	form=XmCreateForm(toplevel,"form",al,ac);
	XtManageChild(form);

	/* Create the menu bar and attach it to the form */
	ac=0;
	XtSetArg(al[ac],XmNtopAttachment,XmATTACH_FORM); ac++;
	XtSetArg(al[ac],XmNleftAttachment,XmATTACH_FORM); ac++;
	XtSetArg(al[ac],XmNrightAttachment,XmATTACH_FORM); ac++;
	menu_bar=XmCreateMenuBar(form,"menu_bar",al,ac);
	XtManageChild(menu_bar);
	
	/* Create text box for telescope connection */
	ac=0;
	XtSetArg(al[ac],XmNvalue, mnt.telport); ac++;
	XtSetArg(al[ac],XmNrecomputeSize, FALSE); ac++;
	XtSetArg(al[ac],XmNy, 34); ac++;
	XtSetArg(al[ac],XmNx, 16); ac++;
	XtSetArg(al[ac],XmNwidth, 120); ac++;
	XtSetArg(al[ac],XmNheight, 28); ac++;
	XtSetArg(al[ac], XmNmaxLength, 30); ac++;
	XtSetArg(al[ac], XmNmarginHeight, 3); ac++;
	txtserport = XmCreateTextField( form, "txtserial", al, ac);
	XtManageChild(txtserport);
	// mTextSetString (Widget text_w, char *value);
    //if (text = XmTextGetString (text_w)) {
    //    /* manipulate text in whatever way is necessary */
    //    ...
    //    /* free text or there will be a memory leak */
    //    XtFree (text);
    //}
	XtAddCallback (txtserport, XmNvalueChangedCallback, txtsetCB, NULL);

	/* Label for telescope model and info */
	ac=0;
	XtSetArg(al[ac],XmNlabelString, XmStringCreateLocalized("Not connected")); ac++;
	XtSetArg(al[ac],XmNrecomputeSize, FALSE); ac++;
	XtSetArg(al[ac],XmNy, 62); ac++;
	XtSetArg(al[ac],XmNx, 16); ac++;
	XtSetArg(al[ac],XmNwidth, 120); ac++;
	XtSetArg(al[ac],XmNheight, 22); ac++;
	XtSetArg(al[ac],XmNalignment,XmALIGNMENT_BEGINNING); ac++;
	XtSetArg(al[ac],XmNbackground,0); ac++;
	lblteldata=XmCreateLabel(form,"teldata",al,ac);
	XtManageChild(lblteldata); 

	/* Option for eq/az setting */
	ac=0;
	XtSetArg(al[ac],XmNy, 62); ac++;
	XtSetArg(al[ac],XmNx, 138); ac++;
	XtSetArg(al[ac],XmNwidth, 74); ac++;
	XtSetArg(al[ac],XmNheight, 22); ac++;
	XtSetArg(al[ac],XmNalignment,XmALIGNMENT_BEGINNING); ac++;
	XtSetArg(al[ac],XmNlabelString, XmStringCreateLocalized("Eq/Az")); ac++;
	opteqaz=XmCreateToggleButton(form,"toggle",al,ac);
	XtManageChild(opteqaz); 
	XtAddCallback (opteqaz, XmNvalueChangedCallback, opteqazCB, NULL);

	/* Label for tracking keypad */
	ac=0;
	XtSetArg(al[ac],XmNlabelString, XmStringCreateLocalized("Tracking")); ac++;
	XtSetArg(al[ac],XmNrecomputeSize, FALSE); ac++;
	XtSetArg(al[ac],XmNy, 90); ac++;
	XtSetArg(al[ac],XmNx, 16); ac++;
	XtSetArg(al[ac],XmNwidth, 79); ac++;
	XtSetArg(al[ac],XmNheight, 14); ac++;
	XtSetArg(al[ac],XmNborderWidth,1); ac++;
	XtSetArg(al[ac],XmNborderColor,0); ac++;
	label_trak=XmCreateLabel(form,"label",al,ac);
	XtManageChild(label_trak); 

	/* Create a radiobox widget for the trak toggles */
	ac = 0;
	XtSetArg(al[ac], XmNorientation,XmVERTICAL); ac++;
	XtSetArg(al[ac], XmNpacking, XmPACK_COLUMN); ac++;
	XtSetArg(al[ac], XmNnumColumns, 1);          ac++;
	XtSetArg(al[ac], XmNy,106); ac++; 
	XtSetArg(al[ac], XmNx,16); ac++; 
	XtSetArg(al[ac], XmNborderWidth,1); ac++;
	XtSetArg(al[ac], XmNborderColor,0); ac++;
	//XtSetArg(al[ac], XmNmarginHeight, 2); ac++;
	//XtSetArg(al[ac], XmNspacing, 0); ac++;
	XtSetArg(al[ac], XmNmarginHeight, 5); ac++;
	toggle_trak = XmCreateRadioBox(form, "togglebox", al, ac);
	XtManageChild (toggle_trak);

	/* Create tracking toggles */
	for (x=0; x<4; x++)
	{
		ac=0;
		XtSetArg(al[ac],XmNlabelString, XmStringCreateLocalized(trk_name[x])); ac++;
		XtSetArg(al[ac],XmNheight, 24); ac++;
		XtSetArg(al[ac], XmNrecomputeSize, FALSE); ac++;
		//XtSetArg(al[ac], XmNmarginHeight, 0); ac++;
		toggleT[x]=XmCreateToggleButton(toggle_trak,"toggle",al,ac);
		XtManageChild(toggleT[x]);
		XtAddCallback (toggleT[x], XmNvalueChangedCallback, trackCB, (XtPointer) x);
	}     
	XtUnmanageChild(toggleT[3]);
	
	// Custom tracking spinbox
	ac = 0;
	XtSetArg(al[ac], XmNorientation,XmHORIZONTAL); ac++;
	XtSetArg(al[ac], XmNpacking, XmPACK_COLUMN); ac++;
	XtSetArg(al[ac], XmNnumColumns, 1);          ac++;
	XtSetArg(al[ac], XmNy,195); ac++; 
	XtSetArg(al[ac], XmNx, 16); ac++; 
	XtSetArg(al[ac], XmNborderWidth,1); ac++;
	XtSetArg(al[ac], XmNborderColor,0); ac++;
	XtSetArg(al[ac], XmNmarginWidth, 5); ac++;
	XtSetArg(al[ac], XmNmarginHeight, 1); ac++;
	trkspin_box = XmCreateRadioBox(form, "trkspin_box", al, ac);
	//XtManageChild (trkspin_box);

	ac = 0;
	XtSetArg(al[ac], XmNmarginWidth, 1); ac++;
	XtSetArg(al[ac], XmNmarginHeight, 0); ac++;
	XtSetArg(al[ac], XmNarrowSize, 25); ac++;
	trkspin = XmCreateSpinBox (trkspin_box, "trkspin", al, ac);

	// Deg field 
    ac = 0;
	XtSetArg(al[ac],XmNheight, 26); ac++;
	XtSetArg(al[ac], XmNmarginHeight, 2); ac++;
    XtSetArg (al[ac], XmNspinBoxChildType, XmNUMERIC); ac++;
    XtSetArg (al[ac], XmNcolumns, 1);                  ac++;
    XtSetArg (al[ac], XmNeditable, FALSE);              ac++;
    XtSetArg (al[ac], XmNminimumValue, 0);             ac++;
    XtSetArg (al[ac], XmNmaximumValue, 2);             ac++;
    XtSetArg (al[ac], XmNposition, 0);                 ac++;
    XtSetArg (al[ac], XmNwrap, FALSE);                  ac++;
    trkspin_d = XmCreateTextField (trkspin, "trkspin_d", al, ac);
    XtManageChild (trkspin_d);

	// Deg label 
	ac=0;
	XtSetArg(al[ac],XmNlabelString, XmStringCreateLocalized("d")); ac++;
	XtSetArg(al[ac], XmNmarginWidth, 1); ac++;
	trkspin_ld = XmCreateLabel (trkspin, "", al, ac);
    XtManageChild (trkspin_ld);

	// Min field 
    ac = 0;
	XtSetArg(al[ac],XmNheight, 26); ac++;
	XtSetArg(al[ac], XmNmarginHeight, 2); ac++;
    XtSetArg (al[ac], XmNspinBoxChildType, XmNUMERIC); ac++;
    XtSetArg (al[ac], XmNcolumns, 2);                  ac++;
    XtSetArg (al[ac], XmNeditable, FALSE);              ac++;
    XtSetArg (al[ac], XmNminimumValue, 0);             ac++;
    XtSetArg (al[ac], XmNmaximumValue, 59);            ac++;
    XtSetArg (al[ac], XmNposition, 0);                 ac++;
    XtSetArg (al[ac], XmNwrap, TRUE);                  ac++;
    trkspin_m = XmCreateTextField (trkspin, "trkspin_m", al, ac);
    XtManageChild (trkspin_m);
    
	// Min label 
	ac=0;
	XtSetArg(al[ac],XmNlabelString, XmStringCreateLocalized("m")); ac++;
	XtSetArg(al[ac], XmNmarginWidth, 1); ac++;
	trkspin_lm = XmCreateLabel (trkspin, "", al, ac);
    XtManageChild (trkspin_lm);

	// Sec field 
    ac = 0;
	XtSetArg(al[ac],XmNheight, 26); ac++;
	XtSetArg(al[ac], XmNmarginHeight, 2); ac++;
    XtSetArg (al[ac], XmNspinBoxChildType, XmNUMERIC); ac++;
    XtSetArg (al[ac], XmNcolumns, 2);                  ac++;
    XtSetArg (al[ac], XmNeditable, FALSE);              ac++;
    XtSetArg (al[ac], XmNminimumValue, 0);             ac++;
    XtSetArg (al[ac], XmNmaximumValue, 59);            ac++;
    XtSetArg (al[ac], XmNposition, 15);                ac++;
    XtSetArg (al[ac], XmNwrap, TRUE);                  ac++;
    trkspin_s = XmCreateTextField (trkspin, "trkspin_s", al, ac);
    XtManageChild (trkspin_s);
    
	// Min label 
	ac=0;
	XtSetArg(al[ac],XmNlabelString, XmStringCreateLocalized("s ")); ac++;
	XtSetArg(al[ac], XmNmarginWidth, 1); ac++;
	trkspin_ls = XmCreateLabel (trkspin, "", al, ac);
    XtManageChild (trkspin_ls);

	XtManageChild (trkspin);
	XtAddCallback (trkspin, XmNmodifyVerifyCallback, trkspinVerifyCB, NULL);
	XtAddCallback (trkspin, XmNvalueChangedCallback, trkspinChangedCB, NULL);

	// Custom guiding spinbox
	ac = 0;
	XtSetArg(al[ac], XmNorientation,XmHORIZONTAL); ac++;
	XtSetArg(al[ac], XmNpacking, XmPACK_COLUMN); ac++;
	XtSetArg(al[ac], XmNnumColumns, 1);          ac++;
	XtSetArg(al[ac], XmNy,225); ac++; 
	XtSetArg(al[ac], XmNx,210); ac++; 
	XtSetArg(al[ac], XmNborderWidth,1); ac++;
	XtSetArg(al[ac], XmNborderColor,0); ac++;
	XtSetArg(al[ac], XmNmarginWidth, 5); ac++;
	XtSetArg(al[ac], XmNmarginHeight, 1); ac++;
	guidespin_box = XmCreateRadioBox(form, "guidespin_box", al, ac);
	XtManageChild (guidespin_box);

	ac = 0;
	XtSetArg(al[ac], XmNmarginWidth, 0); ac++;
	XtSetArg(al[ac], XmNmarginHeight, 0); ac++;
	XtSetArg(al[ac], XmNarrowSize, 25); ac++;
	guidespin = XmCreateSpinBox (guidespin_box, "guidespin", al, ac);

	// Ra label 
	ac=0;
	XtSetArg(al[ac],XmNlabelString, XmStringCreateLocalized("Ra")); ac++;
	XtSetArg(al[ac], XmNmarginWidth, 1); ac++;
	trkspin_ls = XmCreateLabel (guidespin, "", al, ac);
    XtManageChild (trkspin_ls);

	// % Ra field 
    ac = 0;
	XtSetArg(al[ac],XmNheight, 26); ac++;
	XtSetArg(al[ac], XmNmarginHeight, 2); ac++;
    XtSetArg (al[ac], XmNspinBoxChildType, XmNUMERIC); ac++;
    XtSetArg (al[ac], XmNcolumns, 4);                  ac++;
    XtSetArg (al[ac], XmNeditable, FALSE);              ac++;
    XtSetArg (al[ac], XmNminimumValue, GetGuideStep());             ac++;
    XtSetArg (al[ac], XmNmaximumValue, 101);             ac++;
    //XtSetArg (al[ac], XmNincrementValue, GetGuideStep());             ac++;
    XtSetArg (al[ac], XmNposition, GetGuideStep());                 ac++;
    XtSetArg (al[ac], XmNwrap, FALSE);                  ac++;
    guidespin_r = XmCreateTextField (guidespin, "guidespin_r", al, ac);
    XtManageChild (guidespin_r);

	// % Ra label 
	ac=0;
	XtSetArg(al[ac],XmNlabelString, XmStringCreateLocalized("Dec")); ac++;
	XtSetArg(al[ac], XmNmarginWidth, 1); ac++;
	trkspin_ls = XmCreateLabel (guidespin, "", al, ac);
    XtManageChild (trkspin_ls);

	// % Dec field 
    ac = 0;
	XtSetArg(al[ac],XmNheight, 26); ac++;
	XtSetArg(al[ac], XmNmarginHeight, 2); ac++;
    XtSetArg (al[ac], XmNspinBoxChildType, XmNUMERIC); ac++;
    XtSetArg (al[ac], XmNcolumns, 4);                  ac++;
    XtSetArg (al[ac], XmNeditable, FALSE);              ac++;
    XtSetArg (al[ac], XmNminimumValue, GetGuideStep());             ac++;
    XtSetArg (al[ac], XmNmaximumValue, 101);             ac++;
    //XtSetArg (al[ac], XmNincrementValue, GetGuideStep());             ac++;
    XtSetArg (al[ac], XmNposition, GetGuideStep());                 ac++;
    XtSetArg (al[ac], XmNwrap, FALSE);                  ac++;
    guidespin_d = XmCreateTextField (guidespin, "guidespin_d", al, ac);
    XtManageChild (guidespin_d);

	XtManageChild (guidespin);
	XtAddCallback (guidespin, XmNmodifyVerifyCallback, guidespinVerifyCB, NULL);
	XtAddCallback (guidespin, XmNvalueChangedCallback, guidespinChangedCB, NULL);

	/* Label for speed keypad */
	ac=0;
	XtSetArg(al[ac],XmNlabelString, XmStringCreateLocalized("Slew Speed")); ac++;
	XtSetArg(al[ac],XmNrecomputeSize, FALSE); ac++;
	XtSetArg(al[ac],XmNy, 90); ac++;
	XtSetArg(al[ac],XmNx, 101); ac++;
	XtSetArg(al[ac],XmNwidth, 105); ac++;
	XtSetArg(al[ac],XmNheight,14); ac++;
	XtSetArg(al[ac],XmNborderWidth,1); ac++;
	XtSetArg(al[ac],XmNborderColor,0); ac++;
	label_slew=XmCreateLabel(form,"label",al,ac);
	XtManageChild(label_slew); 

	/* Create a radiobox widget for the speed toggles */
	ac=0;
	XtSetArg(al[ac], XmNorientation, XmHORIZONTAL); ac++;
	XtSetArg(al[ac], XmNpacking, XmPACK_COLUMN); ac++;
	XtSetArg(al[ac], XmNnumColumns, 3);          ac++;
	XtSetArg(al[ac], XmNy, 106); ac++; 
	XtSetArg(al[ac], XmNx, 101); ac++; 
	XtSetArg(al[ac], XmNborderWidth,1); ac++;
	XtSetArg(al[ac], XmNborderColor,0); ac++;
	XtSetArg(al[ac], XmNmarginHeight, 5); ac++;
	toggle_slew=XmCreateRadioBox(form,"togglebox",al,ac);
	XtManageChild(toggle_slew);

	/* Create speed toggles */
	for (x=0; x<9; x++)
	{
		ac=0;
		XtSetArg(al[ac],XmNlabelString, XmStringCreateLocalized(spd_name[x])); ac++;
		XtSetArg(al[ac],XmNheight, 24); ac++;
		XtSetArg(al[ac], XmNrecomputeSize, FALSE); ac++;
		toggle[x]=XmCreateToggleButton(toggle_slew,"toggle",al,ac);
		XtManageChild(toggle[x]);
		XtAddCallback (toggle[x], XmNvalueChangedCallback, speedCB, (XtPointer) x);
	}     

	// Label for "is aligned" info
	ac=0;
	XtSetArg(al[ac],XmNlabelString, XmStringCreateLocalized("")); ac++;
	XtSetArg(al[ac],XmNrecomputeSize, FALSE); ac++;
	XtSetArg(al[ac],XmNy, 35); ac++;
	XtSetArg(al[ac],XmNx, 216); ac++;
	XtSetArg(al[ac],XmNwidth, 50); ac++;
	XtSetArg(al[ac],XmNheight, 44); ac++;
	XtSetArg(al[ac],XmNalignment,XmALIGNMENT_CENTER); ac++;
	XtSetArg(al[ac],XmNborderWidth,1); ac++;
	XtSetArg(al[ac],XmNborderColor,0); ac++;
	XtSetArg(al[ac], XmNframeChildType, XmFRAME_GENERIC_CHILD); ac++;
	lblisalign=XmCreateLabel(form,"isalign",al,ac);
	XtManageChild(lblisalign); 


	/* Set up the slew buttons, add event handlers, attach to form.*/	
	for (x=0; x<4; x++)
	{
		ac=0;
		XtSetArg(al[ac],XmNuserData, btn_name[x]); ac++;
		XtSetArg(al[ac],XmNy, btn_pos[x][1]); ac++;
		XtSetArg(al[ac],XmNx, btn_pos[x][0]); ac++;
		XtSetArg(al[ac],XmNwidth, 65); ac++;
		XtSetArg(al[ac],XmNheight, 65); ac++;
		XtSetArg(al[ac],XmNarrowDirection, btn_name[x]); ac++;
		XtSetArg(al[ac], XmNframeChildType, XmFRAME_GENERIC_CHILD); ac++;
		button[x]=XmCreateArrowButtonGadget(form,"label",al,ac);
		XtAddCallback (button[x], XmNarmCallback, buttonCB, (XtPointer) x);
		XtAddCallback (button[x], XmNdisarmCallback, buttonCB, (XtPointer) x);         
		XtManageChild(button[x]);
	}

	// Direction arrow reverse checks
	ac=0;
	XtSetArg(al[ac],XmNlabelString, XmStringCreateLocalized("N/S")); ac++;
	XtSetArg(al[ac],XmNrecomputeSize, FALSE); ac++;
	XtSetArg(al[ac],XmNy, 35); ac++;
	XtSetArg(al[ac],XmNx, 345); ac++;
	XtSetArg(al[ac],XmNwidth, 50); ac++;
	XtSetArg(al[ac],XmNheight, 21); ac++;
	XtSetArg(al[ac],XmNalignment,XmALIGNMENT_BEGINNING); ac++;
	XtSetArg(al[ac],XmNborderWidth,1); ac++;
	XtSetArg(al[ac],XmNborderColor,0); ac++;
	XtSetArg(al[ac], XmNframeChildType, XmFRAME_GENERIC_CHILD); ac++;
	toggleS[0]=XmCreateToggleButton(form,"toggle",al,ac);
	XtManageChild(toggleS[0]);
	XtAddCallback (toggleS[0], XmNvalueChangedCallback, swapCB, (XtPointer) 0);

	ac=0;
	XtSetArg(al[ac],XmNlabelString, XmStringCreateLocalized("E/W")); ac++;
	XtSetArg(al[ac],XmNrecomputeSize, FALSE); ac++;
	XtSetArg(al[ac],XmNy,57); ac++;
	XtSetArg(al[ac],XmNx, 345); ac++;
	XtSetArg(al[ac],XmNwidth, 50); ac++;
	XtSetArg(al[ac],XmNheight, 21); ac++;
	XtSetArg(al[ac],XmNalignment,XmALIGNMENT_BEGINNING); ac++;
	XtSetArg(al[ac],XmNborderWidth,1); ac++;
	XtSetArg(al[ac],XmNborderColor,0); ac++;
	XtSetArg(al[ac], XmNframeChildType, XmFRAME_GENERIC_CHILD); ac++;
	toggleS[1]=XmCreateToggleButton(form,"toggle",al,ac);
	XtManageChild(toggleS[1]);
	XtAddCallback (toggleS[1], XmNvalueChangedCallback, swapCB, (XtPointer) 1);

	/* Set up the command buttons and attach them to the form */
	for (x=0; x<CMD_BUTTONS; x++)   
	{
		ac=0;
		XtSetArg(al[ac],XmNlabelString, XmStringCreateLocalized(cmd_name[x])); ac++;
		XtSetArg(al[ac],XmNrecomputeSize, FALSE); ac++;
		XtSetArg(al[ac],XmNx, cmd_pos[x][0]); ac++;
		XtSetArg(al[ac],XmNy, cmd_pos[x][1]); ac++;
		XtSetArg(al[ac],XmNwidth, cmd_pos[x][2]); ac++;
		XtSetArg(al[ac],XmNheight, cmd_pos[x][3]); ac++;
		command[x]=XmCreatePushButton(form,"label",al,ac);
		XtManageChild(command[x]);
		XtAddCallback(command[x],XmNactivateCallback, commandCB,(XtPointer) x);
	}

	/* Queue area */ 
	/* Create a scrolled queue list widget and attach it to the form */
	ac=0;
	XtSetArg(al[ac], XmNtopAttachment, XmATTACH_FORM); ac++;
	XtSetArg(al[ac], XmNtopOffset, 360); ac++;
	XtSetArg(al[ac], XmNleftAttachment, XmATTACH_FORM); ac++;
	XtSetArg(al[ac], XmNleftOffset, 12); ac++;
	XtSetArg(al[ac], XmNrightAttachment, XmATTACH_FORM); ac++;
	XtSetArg(al[ac], XmNrightOffset, 12); ac++;
	XtSetArg(al[ac], XmNbottomAttachment, XmATTACH_FORM); ac++;
	XtSetArg(al[ac], XmNbottomOffset, 12); ac++;
	XtSetArg(al[ac],XmNscrollingPolicy,XmAUTOMATIC); ac++;
	XtSetArg(al[ac],XmNscrollBarDisplayPolicy,XmSTATIC); ac++;
	XtSetArg(al[ac],XmNscrollHorizontal, True); ac++;
	XtSetArg(al[ac],XmNscrollVertical, True); ac++;
	queue_area=XmCreateScrolledList(form,"queue_area",al,ac);
	XtManageChild(queue_area);
	XtAddCallback(queue_area,XmNdefaultActionCallback,selectqueueCB,NULL);
	XtAddCallback(queue_area,XmNbrowseSelectionCallback,selectqueueCB,NULL);

	/* History area */ 
	/* Create a scrolled queue list widget and attach it to the form */
	ac=0;
	XtSetArg(al[ac], XmNtopAttachment, XmATTACH_FORM); ac++;
	XtSetArg(al[ac], XmNtopOffset, 360); ac++;
	XtSetArg(al[ac], XmNleftAttachment, XmATTACH_FORM); ac++;
	XtSetArg(al[ac], XmNleftOffset, 12); ac++;
	XtSetArg(al[ac], XmNrightAttachment, XmATTACH_FORM); ac++;
	XtSetArg(al[ac], XmNrightOffset, 12); ac++;
	XtSetArg(al[ac], XmNbottomAttachment, XmATTACH_FORM); ac++;
	XtSetArg(al[ac], XmNbottomOffset, 12); ac++;
	XtSetArg(al[ac],XmNscrollingPolicy,XmAUTOMATIC); ac++;
	XtSetArg(al[ac],XmNscrollBarDisplayPolicy,XmSTATIC); ac++;
	XtSetArg(al[ac],XmNscrollHorizontal, True); ac++;
	XtSetArg(al[ac],XmNscrollVertical, True); ac++;
	history_area=XmCreateScrolledList(form,"history_area",al,ac);
	XtManageChild(history_area);
	XtAddCallback(history_area,XmNdefaultActionCallback,selecthistoryCB,NULL);
	XtAddCallback(history_area,XmNbrowseSelectionCallback,selecthistoryCB,NULL);

	/* message area*/
	/* Create a message widget and attach it to the form */
	ac=0;
	XtSetArg(al[ac], XmNtopAttachment, XmATTACH_FORM); ac++;
	XtSetArg(al[ac], XmNtopOffset, 360); ac++;
	XtSetArg(al[ac], XmNleftAttachment, XmATTACH_FORM); ac++;
	XtSetArg(al[ac], XmNleftOffset, 12); ac++;
	XtSetArg(al[ac], XmNrightAttachment, XmATTACH_FORM); ac++;
	XtSetArg(al[ac], XmNrightOffset, 12); ac++;
	XtSetArg(al[ac], XmNbottomAttachment, XmATTACH_FORM); ac++;
	XtSetArg(al[ac], XmNbottomOffset, 12); ac++;
	XtSetArg(al[ac], XmNeditable,False); ac++;
	XtSetArg(al[ac], XmNeditMode,XmMULTI_LINE_EDIT); ac++;
	XtSetArg(al[ac], XmNwordWrap, True); ac++;
	message_area=XmCreateScrolledText(form,"message_area",al,ac);
	XtManageChild(message_area);

	/* Create a radiobox widget for the FAKETAB toggles */
	ac = 0;
	XtSetArg(al[ac], XmNorientation,XmVERTICAL); ac++;
	XtSetArg(al[ac], XmNpacking, XmPACK_COLUMN); ac++;
	XtSetArg(al[ac], XmNnumColumns, 3);          ac++;
	XtSetArg(al[ac], XmNy, 325); ac++; 
	XtSetArg(al[ac], XmNx,  12); ac++; 
	XtSetArg(al[ac], XmNwidth, 228); ac++;
	XtSetArg(al[ac],XmNborderWidth,1); ac++;
	XtSetArg(al[ac],XmNborderColor,0); ac++;
	faketab = XmCreateRadioBox(form, "faketab", al, ac);
	XtManageChild (faketab);

	/* Create faketab toggles */
	for (x=0; x<3; x++)
	{
		ac=0;
		XtSetArg(al[ac],XmNlabelString, XmStringCreateLocalized(fakepanel_name[x])); ac++;
		toggleFT[x]=XmCreateToggleButton(faketab, "panel",al,ac);
		XtManageChild(toggleFT[x]);
		XtAddCallback (toggleFT[x], XmNvalueChangedCallback, faketabCB, (XtPointer) x);
	}     

	/* Set the faketab to the startup state */
	XmToggleButtonSetState (toggleFT[2], TRUE, FALSE);
	XtUnmanageChild(history_area);
	XtUnmanageChild(queue_area);

	/* Create a separator widget and attach it to the form */
	/* ac=0;
	XtSetArg(al[ac],XmNtopAttachment,XmATTACH_FORM); ac++;
	XtSetArg(al[ac],XmNtopOffset, 225); ac++;
	XtSetArg(al[ac],XmNrightAttachment,XmATTACH_FORM); ac++; 
	XtSetArg(al[ac],XmNleftAttachment,XmATTACH_FORM); ac++;  
	XtSetArg(al[ac],XmNbottomAttachment,XmATTACH_NONE); ac++;  
	sep_btns=XmCreateSeparator(form,"sep",al,ac);
	XtManageChild(sep_btns); */

	/* Create a separator widget and attach it to the form */
	ac=0;
	XtSetArg(al[ac],XmNtopAttachment,XmATTACH_FORM); ac++;
	XtSetArg(al[ac],XmNtopOffset, 257); ac++;
	XtSetArg(al[ac],XmNrightAttachment,XmATTACH_FORM); ac++; 
	XtSetArg(al[ac],XmNleftAttachment,XmATTACH_FORM); ac++;  
	XtSetArg(al[ac],XmNbottomAttachment,XmATTACH_NONE); ac++;      
	sep_coords=XmCreateSeparator(form,"sep",al,ac);
	XtManageChild(sep_coords);  

	/* Create a separator widget and attach it to the form */
	ac=0;
	XtSetArg(al[ac],XmNtopAttachment,XmATTACH_FORM); ac++;
	XtSetArg(al[ac],XmNtopOffset, 320); ac++;
	XtSetArg(al[ac],XmNrightAttachment,XmATTACH_FORM); ac++; 
	XtSetArg(al[ac],XmNleftAttachment,XmATTACH_FORM); ac++;  
	XtSetArg(al[ac],XmNbottomAttachment,XmATTACH_NONE); ac++;      
	sep_queue=XmCreateSeparator(form,"sep",al,ac);
	XtManageChild(sep_queue);   

	/* Create a prompt dialog for target input but leave it unmanaged */
	ac=0;
	XtSetArg(al[ac], XmNselectionLabelString, XmStringCreateLocalized("Enter coordinates: ")); ac++;
	XtSetArg(al[ac], XmNdialogTitle, XmStringCreateLocalized("Target")); ac++;
	dialog=XmCreatePromptDialog(toplevel,"dialog",al,ac);
	XtAddCallback(dialog, XmNokCallback, dialogCB, (XtPointer) OK);
	XtAddCallback(dialog, XmNcancelCallback, dialogCB, (XtPointer) CANCEL);
	XtAddCallback(XmSelectionBoxGetChild (dialog, XmDIALOG_TEXT), XmNmodifyVerifyCallback, dialogtextCB, NULL);
	XtAddCallback(XmSelectionBoxGetChild (dialog, XmDIALOG_TEXT), XmNmotionVerifyCallback, degmotionCB, NULL);
	XtUnmanageChild (XmSelectionBoxGetChild (dialog, XmDIALOG_HELP_BUTTON));

	/* Create a dialog to select file but leave it unmanaged */
	ac=0;
	XtSetArg(al[ac],XmNmustMatch,True); ac++;
	XtSetArg(al[ac],XmNautoUnmanage,False); ac++;
	read_file=XmCreateFileSelectionDialog(toplevel,"load file",al,ac);
	XtUnmanageChild(XmSelectionBoxGetChild(read_file, XmDIALOG_HELP_BUTTON));

	/* Create a dialog to select and read the queue but leave it unmanaged */
	ac=0;
	XtSetArg(al[ac],XmNmustMatch,True); ac++;
	XtSetArg(al[ac],XmNautoUnmanage,False); ac++;
	save_file=XmCreateFileSelectionDialog(toplevel,"save file",al,ac);
	XtVaSetValues(XmSelectionBoxGetChild(save_file, XmDIALOG_SELECTION_LABEL),XmNlabelString, XmStringCreateLocalized("New file name/path"), NULL);
	XtUnmanageChild(XmSelectionBoxGetChild(save_file, XmDIALOG_HELP_BUTTON));

	/* Create a dialog to select and read the configuration but leave it unmanaged */
	ac=0;
	XtSetArg(al[ac],XmNmustMatch,True); ac++;
	XtSetArg(al[ac],XmNautoUnmanage,False); ac++;
	read_configfile=XmCreateFileSelectionDialog(toplevel,"configfile",al,ac);
	XtAddCallback (read_configfile, XmNokCallback, readconfigCB, (XtPointer) OK);
	XtAddCallback (read_configfile, XmNcancelCallback, readconfigCB, (XtPointer) CANCEL);
	XtUnmanageChild(XmSelectionBoxGetChild(read_configfile, XmDIALOG_HELP_BUTTON));

	/* Create the menubar */
	create_menus(menu_bar);  

	/* Create unmanaged control panels */
	#ifdef ISFOCUS
		setup_focus(); 
	#endif
	#ifdef ISFAN
		setup_fan();
	#endif
	#ifdef ISHEATER
		setup_heater(); 
	#endif
	
	setup_site();
	
	/* Create Sky Align dialog */
	dlgskyalign = XmCreateInformationDialog(toplevel, "Sky Align", NULL, 0);
	XtUnmanageChild(XtNameToWidget (dlgskyalign, "Help"));

	// Default initial focus to...
	XtVaSetValues(form, XmNinitialFocus, command[CMD_CONNECT], NULL);

}

/* Create all the menubar menus */
void create_menus(Widget menu_bar)
{
	/* Create the file menu */
	file_menu        = make_menu("File",menu_bar, &file_cascade);
	newqueue_item    = make_menu_item("Load Queue",NEWQUEUE,file_menu);
	newhistory_item  = make_menu_item("Load History",NEWHISTORY,file_menu); 
	editqueue_item   = make_menu_item("Edit Queue",EDITQUEUE,file_menu);
	editlog_item     = make_menu_item("Edit History",EDITHISTORY,file_menu);
	savequeue_item   = make_menu_item("Save Queue",SAVEQUEUE,file_menu);
	savehistory_item = make_menu_item("Save History",SAVEHISTORY,file_menu); 
	savestatus_item  = make_menu_item("Save Status",SAVESTATUS,file_menu); 
	exit_item        = make_menu_item("Exit",EXIT,file_menu);

	/* Create the telescope pull-down menu */
	telescope_menu = make_menu("Telescope",menu_bar, &telescope_cascade);
	#ifdef ISLEVEL
		tellevel_item  = make_menu_item("Level", TELLEVEL, telescope_menu);
	#endif
	telpole_item   = make_menu_item("Pole align", TELPOLE, telescope_menu);
	telsky_item    = make_menu_item("Sky align", TELSKY, telescope_menu);
	telpark_item   = make_menu_item("Set to Park", TELPARK, telescope_menu);
	#ifdef ISFOCUS
		telfocus_item  = make_menu_item("Focus",TELFOCUS, telescope_menu);
	#endif
	#ifdef ISFAN
		telfan_item    = make_menu_item("Fan",TELFAN, telescope_menu);
	#endif
	#ifdef ISHEATER
		telheater_item = make_menu_item("Heater",TELHEATER, telescope_menu);
	#endif
	
	/* Create the pointing menu with toggle options*/
	pointing_menu       = make_menu("Pointing",menu_bar, &pointing_cascade);
	p_options_toggle_1  = make_menu_toggle("Offset",POINTOPTION1,pointing_menu);
	p_options_toggle_2  = make_menu_toggle("Refraction",POINTOPTION2,pointing_menu);
	p_options_toggle_4  = make_menu_toggle("Polar",POINTOPTION4,pointing_menu);
	p_options_toggle_8  = make_menu_toggle("Dec Axis",POINTOPTION8,pointing_menu);
	p_options_toggle_16 = make_menu_toggle("Optical Axis",POINTOPTION16,pointing_menu);
	p_options_toggle_32 = make_menu_toggle("Flexure",POINTOPTION32,pointing_menu);
	p_options_toggle_64 = make_menu_toggle("Use Horizon",POINTOPTION64,pointing_menu);

	// Create the setup menu
	setup_menu       = make_menu("Setup",menu_bar, &setup_cascade);
	telsite_item     = make_menu_item("Site", TELSITE, setup_menu);
	newconfig_item   = make_menu_item("Load Config", NEWCONFIG, setup_menu);
	editconfig_item  = make_menu_item("Edit Config", EDITCONFIG, setup_menu);
	newhorizon_item  = make_menu_item("Load Horizon", NEWHORIZON, setup_menu);
	edithorizon_item = make_menu_item("Edit Horizon", EDITHORIZON, setup_menu);

	// Create the tools menu
	tools_menu         = make_menu("Tools", menu_bar, &tools_cascade);
	toolshome_item     = make_menu_item("Goto Home", TOOLSMERIDIAN, tools_menu);
	toolsmeridian_item = make_menu_item("Goto Meridian", TOOLSMERIDIAN, tools_menu);
	toolszenith_item   = make_menu_item("Goto Zenith", TOOLSZENITH, tools_menu);
}

/* Faketab callback */
void faketabCB (w, client_data, call_data)
    Widget w;
    int client_data;
    XmToggleButtonCallbackStruct *call_data;
{
	//Arg al[10];
	//int ac;

	if (call_data->reason == XmCR_VALUE_CHANGED && call_data->set == XmSET)
	{
		/* Unmanage all faketabs */
		XtUnmanageChild(queue_area);
		XtUnmanageChild(history_area);
		XtUnmanageChild(message_area);
		/* Most dirty hack ever */
		//ac=0; 
		//XtSetArg(al[ac],XmNheight,680); ac++;
		//XtSetValues(toplevel,al,ac);				
		switch (client_data)
		{
			case TAB_QUEUE:
				/* Show Queue */ 
				XtManageChild(queue_area);
				break;				

			case TAB_HISTORY:
				/* Show Queue */ 
				XtManageChild(history_area);
				break;				

			case TAB_STATUS:
				/* Show Status */ 
				XtManageChild(message_area);
				break;
		}
		/* Most dirty hack ever */
		//ac=0; 
		//XtSetArg(al[ac],XmNheight,700); ac++;
		//XtSetValues(toplevel,al,ac);				
	}
}

/* Callback routine used for txtserial */
void txtsetCB (Widget txt, XtPointer client_data, XtPointer call_data)
{
	char* text;
    //XmTextVerifyCallbackStruct *cbs = (XmTextVerifyCallbackStruct *) call_data;

	if ((text = XmTextGetString(txt)))
	{
		strcpy(mnt.telport, text);
		XtFree (text);
	}		
}

/* Callback routines used for menubar */
void menuCB(w,client_data,call_data)
	Widget w;
	int client_data;
	XmAnyCallbackStruct *call_data;
{
	int doit = 0;
	
	/* if request for a queue file detected, then select a new queue file */
	if (client_data==NEWQUEUE)
	{
		/* make the queue selection dialog appear */
		XtRemoveAllCallbacks (read_file, XmNokCallback);
		XtRemoveAllCallbacks (read_file, XmNcancelCallback);
		XtAddCallback (read_file, XmNokCallback, readqueueCB, (XtPointer) OK);
		XtAddCallback (read_file, XmNcancelCallback, readqueueCB, (XtPointer) CANCEL);
		XtManageChild(read_file);    
	}
	
	/* if request for a new history file detected, then select a new log file */
	else if (client_data==NEWHISTORY)
	{
		/* make the log selection dialog appear */ 
		XtRemoveAllCallbacks (read_file, XmNokCallback);
		XtRemoveAllCallbacks (read_file, XmNcancelCallback);
		XtAddCallback (read_file, XmNokCallback, readhistoryCB, (XtPointer) OK);
		XtAddCallback (read_file, XmNcancelCallback, readhistoryCB, (XtPointer) CANCEL);
		XtManageChild(read_file);
	} 

	/* if request for a new configuration file detected, then select and read a new config file */
	else if (client_data==NEWCONFIG)
	{
		if (XtIsManaged(site_control))
		{
			if (msgbox(toplevel, "Site panel is open, accept values?", MSGOKCANCEL, "Question"))
			{
				gps.gpsvalid = 1;
				set_tel_site();
				XtUnmanageChild(site_control);
				doit = 1;
			}
		}
		else
		{
			doit = 1;
		}

		if (doit)
		{
			/* make the configuration selection dialog appear */
			XtRemoveAllCallbacks (read_configfile, XmNokCallback);
			XtRemoveAllCallbacks (read_configfile, XmNcancelCallback);
			XtAddCallback (read_configfile, XmNokCallback, readconfigCB, (XtPointer) OK);
			XtAddCallback (read_configfile, XmNcancelCallback, readconfigCB, (XtPointer) CANCEL);
			XtManageChild(read_configfile);
		}
	}     

	/* if request for a new configuration file detected, then select and read a new config file */
	else if (client_data==NEWHORIZON)
	{
		/* make the configuration selection dialog appear */
		XtRemoveAllCallbacks (read_configfile, XmNokCallback);
		XtRemoveAllCallbacks (read_configfile, XmNcancelCallback);
		XtAddCallback (read_configfile, XmNokCallback, readhorizonCB, (XtPointer) OK);
		XtAddCallback (read_configfile, XmNcancelCallback, readhorizonCB, (XtPointer) CANCEL);
		XtManageChild(read_configfile);
	}     

	/* if request to edit the queue is detected, then edit the queue file */
	else if (client_data==EDITQUEUE)
	{
		XtRemoveAllCallbacks (read_file, XmNokCallback);
		XtRemoveAllCallbacks (read_file, XmNcancelCallback);
		XtAddCallback (read_file, XmNokCallback, editqueueCB, (XtPointer) OK);
		XtAddCallback (read_file, XmNcancelCallback, editqueueCB, (XtPointer) CANCEL);
		XtManageChild(read_file);
	} 

	/* if request to edit log file detected, then edit the log file */
	else if (client_data==EDITHISTORY)
	{
		XtRemoveAllCallbacks (read_file, XmNokCallback);
		XtRemoveAllCallbacks (read_file, XmNcancelCallback);
		XtAddCallback (read_file, XmNokCallback, edithistoryCB, (XtPointer) OK);
		XtAddCallback (read_file, XmNcancelCallback, edithistoryCB, (XtPointer) CANCEL);
		XtManageChild(read_file);
	}

	/* if request to edit config file detected, then edit the config file */
	else if (client_data==EDITCONFIG)
	{
		XtRemoveAllCallbacks (read_configfile, XmNokCallback);
		XtRemoveAllCallbacks (read_configfile, XmNcancelCallback);
		XtAddCallback (read_configfile, XmNokCallback, editconfigCB, (XtPointer) OK);
		XtAddCallback (read_configfile, XmNcancelCallback, editconfigCB, (XtPointer) CANCEL);
		XtManageChild(read_configfile);
	}

	/* if request to edit horizon file detected, then edit the config file */
	else if (client_data==EDITHORIZON)
	{
		XtRemoveAllCallbacks (read_configfile, XmNokCallback);
		XtRemoveAllCallbacks (read_configfile, XmNcancelCallback);
		XtAddCallback (read_configfile, XmNokCallback, edithorizonCB, (XtPointer) OK);
		XtAddCallback (read_configfile, XmNcancelCallback, edithorizonCB, (XtPointer) CANCEL);
		XtManageChild(read_configfile);
	}

	/* if request for a save queue file detected */
	else if (client_data==SAVEQUEUE)
	{
		/* make the queue selection dialog appear */
		XtRemoveAllCallbacks (XmFileSelectionBoxGetChild(save_file, XmDIALOG_OK_BUTTON), XmNactivateCallback);
		XtRemoveAllCallbacks (save_file, XmNcancelCallback);
		XtAddCallback (XmFileSelectionBoxGetChild(save_file, XmDIALOG_OK_BUTTON), XmNactivateCallback, savequeueCB, (XtPointer) OK);
		XtAddCallback (save_file, XmNcancelCallback, savequeueCB, (XtPointer) CANCEL);
		XtManageChild(save_file);    
	}

	/* if request for a save history file detected */
	else if (client_data==SAVEHISTORY)
	{
		/* make the log selection dialog appear */ 
		XtRemoveAllCallbacks (XmFileSelectionBoxGetChild(save_file, XmDIALOG_OK_BUTTON), XmNactivateCallback);
		XtRemoveAllCallbacks (save_file, XmNcancelCallback);
		XtAddCallback (XmFileSelectionBoxGetChild(save_file, XmDIALOG_OK_BUTTON), XmNactivateCallback, savehistoryCB, (XtPointer) OK);
		XtAddCallback (save_file, XmNcancelCallback, savehistoryCB, (XtPointer) CANCEL);
		XtManageChild(save_file);    
	} 

	/* if exit detected, then save last location and exit cleanly */
	else if (client_data==EXIT) 
	{
		unlink_telescope();
		if (!rpipedisabled || !wpipedisabled)
		{
			unlink_fifos();
		}
		exit(0);
	}   

	#ifdef ISLEVEL
		// Request level telescope
		else if (client_data==TELLEVEL)
		{
			if (mnt.tellink) 
			{  
				level_telescope();
			} 
			else 
			{
				setMessage("Telescope is not connected\n"); 
			}
		}
	#endif
	     
	// Request pole align
	else if (client_data==TELPOLE)
	{
		if (mnt.tellink) 
		{  
			if (mnt.SiteLatitude > 0)
			{
				if (msgbox(toplevel, "Is Polaris visible?", 1, "Align"))
				{
					align_telescope_polaris(1);
				}
				else
				{
					align_telescope(1);
				}
			}
			else
			{
				if (msgbox(toplevel, "Is Sigma Ottantis visible?", 1, "Align"))
				{
					align_telescope_polaris(1);
				}
				else
				{
					align_telescope(1);
				}
			}
		} 
		else 
		{
			setMessage("Telescope is not connected\n"); 
		}
	}

	// Request sky align
	else if (client_data==TELSKY)
	{
		//test_align();
		if (mnt.tellink) 
		{  
			skyalign_telescope(1);
		} 
		else 
		{
			setMessage("Telescope is not connected\n"); 
		}
	}

	// Request goto park
	else if (client_data==TELPARK)
	{
		if (mnt.tellink) 
		{  
			fetch_telescope_coordinates();
			if (!errflag)
			{
				show_telescope_coordinates();
				if (!errflag)
				{
					mark_fifo_telescope();
					if (msgbox(toplevel, "Park telescope now?", 1, "Confirm goto") == 1)
					{
						set_target_park();
						show_target_coordinates();
						gotoflag = GoToCoords(&mnt, target[0].ra, target[0].dec, RAW, target[0].abspos);
						if (gotoflag == TRUE)
						{
							setMessage("Slew to target in progress\n");
						}
						else
						{
							setMessage("Slew to target not permitted\n");
						}						
					}
				}
			}
			if (errflag)
			{
				setMessage("Error setting target to park\n"); 
			}
			else
			{
				setMessage("Target set to park\n"); 
			}
		} 
		else 
		{
			setMessage("Telescope is not connected\n"); 
		}
	}

	else if (client_data==TELSITE)
	{
		if (gps.gpsvalid == 0)
		{
			// If we had no valid reads 
			reset_site();
			set_site();
		}
		/* make the site control appear */
		XtManageChild(site_control);    
	}               

	/* if telescope hardware request detected, then handle that here */
	#ifdef ISFOCUS
		else if (client_data==TELFOCUS)
		{
		/* make the focus control appear */
			XtManageChild(focus_control);    
		}               
	#endif

	#ifdef ISFAN
		else if (client_data==TELFAN)
		{
		/* Insert rotator user interface here */
			XtManageChild(fan_control);
		}
	#endif

	#ifdef ISHEATER
		else if (client_data==TELHEATER)
		{
		/* Insert rotator user interface here */
			XtManageChild(heater_control);
		}
	#endif		   

	/* Detect a change to the toggle for a pointing option */
	/* Check for the state of the option */
	/* Set pmodel using bitwise OR or bitwise AND NOT */

	/* if a change in pointing option is detected, then set pmodel */
	else if (client_data==POINTOPTION1)
	{
		if( XmToggleButtonGetState(p_options_toggle_1) )
		{
			pmodel=(pmodel | OFFSET);
		}
		else
		{
			pmodel=(pmodel & ~(OFFSET));
		}  
		fetch_telescope_coordinates();
		if (!errflag)
		{ 
			show_telescope_coordinates(); 
			mark_fifo_telescope();
		}
	} 
	  

	else if (client_data==POINTOPTION2)
	{
		if( XmToggleButtonGetState(p_options_toggle_2) )
		{
			pmodel=(pmodel | REFRACT);
		}
		else
		{
			pmodel=(pmodel & ~(REFRACT));
		}  
		fetch_telescope_coordinates(); 
		if (!errflag)
		{ 
			show_telescope_coordinates(); 
			mark_fifo_telescope();
		}
	}         

	else if (client_data==POINTOPTION4)
	{
		if( XmToggleButtonGetState(p_options_toggle_4) )
		{
			pmodel=(pmodel | POLAR);
		}
		else
		{
			pmodel=(pmodel & ~(POLAR));
		}  
		fetch_telescope_coordinates(); 
		if (!errflag)
		{ 
			show_telescope_coordinates(); 
			mark_fifo_telescope();
		}
	}         

	else if (client_data==POINTOPTION8)
	{
		if( XmToggleButtonGetState(p_options_toggle_8) )
		{
			pmodel=(pmodel | DECAXIS);
		}
		else
		{
			pmodel=(pmodel & ~(DECAXIS));
		}  
		fetch_telescope_coordinates(); 
		if (!errflag)
		{ 
			show_telescope_coordinates(); 
			mark_fifo_telescope();
		}
	}         

	else if (client_data==POINTOPTION16)
	{
		if( XmToggleButtonGetState(p_options_toggle_16) )
		{
			pmodel=(pmodel | OPTAXIS);
		}
		else
		{
			pmodel=(pmodel & ~(OPTAXIS));
		}  
		fetch_telescope_coordinates(); 
		if (!errflag)
		{ 
			show_telescope_coordinates(); 
			mark_fifo_telescope();
		}
	}         

	else if (client_data==POINTOPTION32)
	{
		if( XmToggleButtonGetState(p_options_toggle_32) )
		{
			pmodel=(pmodel | FLEXURE);
		}
		else
		{
			pmodel=(pmodel & ~(FLEXURE));
		}  
		fetch_telescope_coordinates(); 
		if (!errflag)
		{ 
			show_telescope_coordinates(); 
			if (!wpipedisabled)
			{
				mark_fifo_telescope();
			}
		}
	}         

	else if (client_data==POINTOPTION64)
	{
		if( XmToggleButtonGetState(p_options_toggle_64) )
		{
			mnt.modfeat[FLHORIZ] = 1;
			read_horizon();
			setMessage("Telescope horizon in use\n"); 
		}
		else
		{
			mnt.modfeat[FLHORIZ] = 0;
			setMessage("Telescope horizon not in use\n"); 
		}  
	}         

	// Request goto home
	else if (client_data==TOOLSHOME)
	{
		if (mnt.tellink) 
		{  
			fetch_telescope_coordinates();
			if (!errflag)
			{
				show_telescope_coordinates();
				if (!errflag)
				{
					mark_fifo_telescope();
					set_target_home();
					show_target_coordinates();             
				}
			}
			if (errflag)
			{
				setMessage("Error setting target to home\n"); 
			}
			else
			{
				setMessage("Target set to home\n"); 
			}
		} 
		else 
		{
			setMessage("Telescope is not connected\n"); 
		}
	}
	
	// Request goto meridian
	else if (client_data==TOOLSMERIDIAN)
	{
		if (mnt.tellink) 
		{  
			fetch_telescope_coordinates();
			if (!errflag)
			{
				show_telescope_coordinates();
				if (!errflag)
				{
					mark_fifo_telescope();
					set_target_meridian();
					show_target_coordinates();
				}
			}
			if (errflag)
			{
				setMessage("Error setting target to meridian\n"); 
			}
			else
			{
				setMessage("Target set to meridian\n"); 
			}
		} 
		else 
		{
			setMessage("Telescope is not connected\n"); 
		}
	}

	// Request goto zenith
	else if (client_data==TOOLSZENITH)
	{
		if (mnt.tellink) 
		{  
			fetch_telescope_coordinates();
			if (!errflag)
			{
				show_telescope_coordinates();
				if (!errflag)
				{
					mark_fifo_telescope();
					set_target_zenith();
					show_target_coordinates();
				}
			}
			if (errflag)
			{
				setMessage("Error setting target to zenith\n"); 
			}
			else
			{
				setMessage("Target set to zenith\n"); 
			}
		} 
		else 
		{
			setMessage("Telescope is not connected\n"); 
		}
	}

	/* else noop */   
	else if (client_data==CANCEL);
}

/* Create the unmanged site control panel */
void setup_site()
{
	Arg al[10];
	int ac;
	char value[32];

	ac=0;    
	XtSetArg(al[ac],XmNheight, 290); ac++;
	XtSetArg(al[ac],XmNwidth, 270); ac++;
	XtSetArg(al[ac],XmNautoUnmanage,False); ac++;
	XtSetArg(al[ac],XmNdialogTitle, XmStringCreateLocalized("Site")); ac++;
	site_control=XmCreateFormDialog(toplevel,"Site",al,ac);

	/* Create text box for gps serial port */
	ac=0;
	XtSetArg(al[ac],XmNvalue, gps.gpsport); ac++;
	XtSetArg(al[ac],XmNrecomputeSize, FALSE); ac++;
	XtSetArg(al[ac],XmNy, 34); ac++;
	XtSetArg(al[ac],XmNx, 16); ac++;
	XtSetArg(al[ac],XmNwidth, 120); ac++;
	XtSetArg(al[ac],XmNheight, 28); ac++;
	XtSetArg(al[ac], XmNmaxLength, 30); ac++;
	XtSetArg(al[ac], XmNmarginHeight, 3); ac++;
	site_gps_port = XmCreateTextField(site_control, "txtserial", al, ac);
	XtManageChild(site_gps_port);
	XtAddCallback(site_gps_port, XmNvalueChangedCallback, siteChangedCB, (XtPointer) GPSSERIAL);

	/* Create command button for gps connection */
	ac=0;
	XtSetArg(al[ac],XmNlabelString, XmStringCreateLocalized("Gps read")); ac++;
	XtSetArg(al[ac],XmNrecomputeSize, FALSE); ac++;
	XtSetArg(al[ac],XmNy, 34); ac++;
	XtSetArg(al[ac],XmNx, 136); ac++;
	XtSetArg(al[ac],XmNwidth, 120); ac++;
	XtSetArg(al[ac],XmNheight, 28); ac++;
	site_gps_connect = XmCreatePushButton(site_control,"connect", al, ac);
	XtManageChild(site_gps_connect);
	XtAddCallback(site_gps_connect, XmNactivateCallback, siteCB, (XtPointer) GPSCONNECT);

	/* Label for aux info */
	ac=0;
	XtSetArg(al[ac],XmNlabelString, XmStringCreateLocalized("")); ac++;
	XtSetArg(al[ac],XmNrecomputeSize, FALSE); ac++;
	XtSetArg(al[ac],XmNy, 62); ac++;
	XtSetArg(al[ac],XmNx, 16); ac++;
	XtSetArg(al[ac],XmNwidth, 240); ac++;
	XtSetArg(al[ac],XmNheight, 22); ac++;
	XtSetArg(al[ac],XmNalignment,XmALIGNMENT_BEGINNING); ac++;
	XtSetArg(al[ac],XmNbackground,0); ac++;
	site_lblaux = XmCreateLabel(site_control,"gpsauxdata",al,ac);
	XtManageChild(site_lblaux); 

	/* Create a separator widget and attach it to the form */
	ac=0;
	XtSetArg(al[ac],XmNtopAttachment,XmATTACH_FORM); ac++;
	XtSetArg(al[ac],XmNtopOffset, 90); ac++;
	XtSetArg(al[ac],XmNrightAttachment,XmATTACH_FORM); ac++; 
	XtSetArg(al[ac],XmNleftAttachment,XmATTACH_FORM); ac++;  
	XtSetArg(al[ac],XmNbottomAttachment,XmATTACH_NONE); ac++;  
	site_sep1=XmCreateSeparator(site_control,"sep1",al,ac);
	XtManageChild(site_sep1); 

	/* Label for latitude */
	ac=0;
	XtSetArg(al[ac],XmNlabelString, XmStringCreateLocalized("Longitude")); ac++;
	XtSetArg(al[ac],XmNrecomputeSize, FALSE); ac++;
	XtSetArg(al[ac],XmNy, 94); ac++;
	XtSetArg(al[ac],XmNx, 16); ac++;
	XtSetArg(al[ac],XmNwidth, 80); ac++;
	XtSetArg(al[ac],XmNheight, 28); ac++;
	XtSetArg(al[ac],XmNalignment,XmALIGNMENT_BEGINNING); ac++;
	site_Longitude_l = XmCreateLabel(site_control, "llongitude", al, ac);
	XtManageChild(site_Longitude_l); 

	/* Create text box for Longitude_n */
	sprintf(value, "%+010.5f", gps.SiteLongitude);
	ac=0;
	XtSetArg(al[ac],XmNvalue, value); ac++;
	XtSetArg(al[ac],XmNrecomputeSize, FALSE); ac++;
	XtSetArg(al[ac],XmNy, 94); ac++;
	XtSetArg(al[ac],XmNx, 96); ac++;
	XtSetArg(al[ac],XmNwidth, 80); ac++;
	XtSetArg(al[ac],XmNheight, 28); ac++;
	XtSetArg(al[ac], XmNmaxLength, 30); ac++;
	XtSetArg(al[ac], XmNmarginHeight, 3); ac++;
	site_Longitude_n = XmCreateTextField(site_control, "longitude_n", al, ac);
	XtManageChild(site_Longitude_n);
	XtAddCallback(site_Longitude_n, XmNmodifyVerifyCallback, siteCB, (XtPointer) GPSLONN);
	XtAddCallback(site_Longitude_n, XmNvalueChangedCallback, siteChangedCB, (XtPointer) GPSLONN);

	/* Create text box for Longitude */
	dtodms(value, &gps.SiteLongitude);
	if (value[0] == '-')
	{
		value[0] = 'W';
	}
	else
	{
		value[0] = 'E';
	}
	if (value[3] == ':')
	{
		memmove(value+2, value+1, 8); 
		value[1] = '0';
	}
	ac=0;
	XtSetArg(al[ac],XmNvalue, value); ac++;
	XtSetArg(al[ac],XmNrecomputeSize, FALSE); ac++;
	XtSetArg(al[ac],XmNy, 94); ac++;
	XtSetArg(al[ac],XmNx, 176); ac++;
	XtSetArg(al[ac],XmNwidth, 80); ac++;
	XtSetArg(al[ac],XmNheight, 28); ac++;
	XtSetArg(al[ac], XmNmaxLength, 30); ac++;
	XtSetArg(al[ac], XmNmarginHeight, 3); ac++;
	site_Longitude = XmCreateTextField(site_control, "longitude", al, ac);
	XtManageChild(site_Longitude);
	XtAddCallback(site_Longitude, XmNmodifyVerifyCallback, siteCB, (XtPointer) GPSLON);
	XtAddCallback(site_Longitude, XmNvalueChangedCallback, siteChangedCB, (XtPointer) GPSLON);
	XtAddCallback(site_Longitude, XmNmotionVerifyCallback, degmotionCB, NULL);

	/* Label for latitude */
	ac=0;
	XtSetArg(al[ac],XmNlabelString, XmStringCreateLocalized("Latitude")); ac++;
	XtSetArg(al[ac],XmNrecomputeSize, FALSE); ac++;
	XtSetArg(al[ac],XmNy, 124); ac++;
	XtSetArg(al[ac],XmNx, 16); ac++;
	XtSetArg(al[ac],XmNwidth, 80); ac++;
	XtSetArg(al[ac],XmNheight, 28); ac++;
	XtSetArg(al[ac],XmNalignment,XmALIGNMENT_BEGINNING); ac++;
	site_Latitude_l = XmCreateLabel(site_control, "llatitude", al, ac);
	XtManageChild(site_Latitude_l); 

	/* Create text box for Latitude_n */
	sprintf(value, "%+09.5f", gps.SiteLatitude);
	ac=0;
	XtSetArg(al[ac],XmNvalue, value); ac++;
	XtSetArg(al[ac],XmNrecomputeSize, FALSE); ac++;
	XtSetArg(al[ac],XmNy, 124); ac++;
	XtSetArg(al[ac],XmNx, 96); ac++;
	XtSetArg(al[ac],XmNwidth, 80); ac++;
	XtSetArg(al[ac],XmNheight, 28); ac++;
	XtSetArg(al[ac], XmNmaxLength, 30); ac++;
	XtSetArg(al[ac], XmNmarginHeight, 3); ac++;
	site_Latitude_n = XmCreateTextField(site_control, "latitude_n", al, ac);
	XtManageChild(site_Latitude_n);
	XtAddCallback(site_Latitude_n, XmNmodifyVerifyCallback, siteCB, (XtPointer) GPSLATN);
	XtAddCallback(site_Latitude_n, XmNvalueChangedCallback, siteChangedCB, (XtPointer) GPSLATN);

	/* Create text box for Latitude */
	dtodms(value, &gps.SiteLatitude);
	if (value[0] == '-')
	{
		value[0] = 'S';
	}
	else
	{
		value[0] = 'N';
	}
	ac=0;
	XtSetArg(al[ac],XmNvalue, value); ac++;
	XtSetArg(al[ac],XmNrecomputeSize, FALSE); ac++;
	XtSetArg(al[ac],XmNy, 124); ac++;
	XtSetArg(al[ac],XmNx, 176); ac++;
	XtSetArg(al[ac],XmNwidth, 80); ac++;
	XtSetArg(al[ac],XmNheight, 28); ac++;
	XtSetArg(al[ac], XmNmaxLength, 30); ac++;
	XtSetArg(al[ac], XmNmarginHeight, 3); ac++;
	site_Latitude = XmCreateTextField(site_control, "latitude", al, ac);
	XtManageChild(site_Latitude);
	XtAddCallback(site_Latitude, XmNmodifyVerifyCallback, siteCB, (XtPointer) GPSLAT);
	XtAddCallback(site_Latitude, XmNvalueChangedCallback, siteChangedCB, (XtPointer) GPSLAT);
	XtAddCallback(site_Latitude, XmNmotionVerifyCallback, degmotionCB, NULL);

	/* Label for Altitude */
	ac=0;
	XtSetArg(al[ac],XmNlabelString, XmStringCreateLocalized("Altitude (m)")); ac++;
	XtSetArg(al[ac],XmNrecomputeSize, FALSE); ac++;
	XtSetArg(al[ac],XmNy, 154); ac++;
	XtSetArg(al[ac],XmNx, 16); ac++;
	XtSetArg(al[ac],XmNwidth, 80); ac++;
	XtSetArg(al[ac],XmNheight, 28); ac++;
	XtSetArg(al[ac],XmNalignment,XmALIGNMENT_BEGINNING); ac++;
	site_Altitude_l = XmCreateLabel(site_control, "laltitude", al, ac);
	XtManageChild(site_Altitude_l); 

	/* Create text box for Altitude */
	sprintf(value, "%+07.1f", gps.SiteAltitude);
	ac=0;
	XtSetArg(al[ac],XmNvalue, value); ac++;
	XtSetArg(al[ac],XmNrecomputeSize, FALSE); ac++;
	XtSetArg(al[ac],XmNy, 154); ac++;
	XtSetArg(al[ac],XmNx, 96); ac++;
	XtSetArg(al[ac],XmNwidth, 80); ac++;
	XtSetArg(al[ac],XmNheight, 28); ac++;
	XtSetArg(al[ac], XmNmaxLength, 30); ac++;
	XtSetArg(al[ac], XmNmarginHeight, 3); ac++;
	site_Altitude = XmCreateTextField(site_control, "altitude", al, ac);
	XtManageChild(site_Altitude);
	XtAddCallback(site_Altitude, XmNmodifyVerifyCallback, siteCB, (XtPointer) GPSALT);
	XtAddCallback(site_Altitude, XmNvalueChangedCallback, siteChangedCB, (XtPointer) GPSALT);

	/* Label for Temperature */
	ac=0;
	XtSetArg(al[ac],XmNlabelString, XmStringCreateLocalized("Temp. (C)")); ac++;
	XtSetArg(al[ac],XmNrecomputeSize, FALSE); ac++;
	XtSetArg(al[ac],XmNy, 184); ac++;
	XtSetArg(al[ac],XmNx, 16); ac++;
	XtSetArg(al[ac],XmNwidth, 80); ac++;
	XtSetArg(al[ac],XmNheight, 28); ac++;
	XtSetArg(al[ac],XmNalignment,XmALIGNMENT_BEGINNING); ac++;
	site_Temperature_l = XmCreateLabel(site_control, "ltemperature", al, ac);
	XtManageChild(site_Temperature_l); 

	/* Create text box for Temperature */
	sprintf(value, "%+05.1f", gps.SiteTemperature);
	ac=0;
	XtSetArg(al[ac],XmNvalue, value); ac++;
	XtSetArg(al[ac],XmNrecomputeSize, FALSE); ac++;
	XtSetArg(al[ac],XmNy, 184); ac++;
	XtSetArg(al[ac],XmNx, 96); ac++;
	XtSetArg(al[ac],XmNwidth, 80); ac++;
	XtSetArg(al[ac],XmNheight, 28); ac++;
	XtSetArg(al[ac], XmNmaxLength, 30); ac++;
	XtSetArg(al[ac], XmNmarginHeight, 3); ac++;
	site_Temperature = XmCreateTextField(site_control, "temperature", al, ac);
	XtManageChild(site_Temperature);
	XtAddCallback(site_Temperature, XmNmodifyVerifyCallback, siteCB, (XtPointer) GPSTEMP);
	XtAddCallback(site_Temperature, XmNvalueChangedCallback, siteChangedCB, (XtPointer) GPSTEMP);

	/* Create command button for site apply */
	ac=0;
	XtSetArg(al[ac],XmNlabelString, XmStringCreateLocalized("Apply site")); ac++;
	XtSetArg(al[ac],XmNrecomputeSize, FALSE); ac++;
	XtSetArg(al[ac],XmNy, 184); ac++;
	XtSetArg(al[ac],XmNx, 176); ac++;
	XtSetArg(al[ac],XmNwidth, 80); ac++;
	XtSetArg(al[ac],XmNheight, 28); ac++;
	site_apply = XmCreatePushButton(site_control,"connect",al,ac);
	XtManageChild(site_apply);
	XtAddCallback(site_apply, XmNactivateCallback, siteCB, (XtPointer) GPSAPPLY);

	/* Label for Pressure */
	ac=0;
	XtSetArg(al[ac],XmNlabelString, XmStringCreateLocalized("Press. (mbar)")); ac++;
	XtSetArg(al[ac],XmNrecomputeSize, FALSE); ac++;
	XtSetArg(al[ac],XmNy, 214); ac++;
	XtSetArg(al[ac],XmNx, 16); ac++;
	XtSetArg(al[ac],XmNwidth, 80); ac++;
	XtSetArg(al[ac],XmNheight, 28); ac++;
	XtSetArg(al[ac],XmNalignment,XmALIGNMENT_BEGINNING); ac++;
	site_Pressure_l = XmCreateLabel(site_control, "lpressure", al, ac);
	XtManageChild(site_Pressure_l); 

	/* Create text box for Pressure */
	sprintf(value, "%+08.2f", gps.SitePressure);
	ac=0;
	XtSetArg(al[ac],XmNvalue, value); ac++;
	XtSetArg(al[ac],XmNrecomputeSize, FALSE); ac++;
	XtSetArg(al[ac],XmNy, 214); ac++;
	XtSetArg(al[ac],XmNx, 96); ac++;
	XtSetArg(al[ac],XmNwidth, 80); ac++;
	XtSetArg(al[ac],XmNheight, 28); ac++;
	XtSetArg(al[ac], XmNmaxLength, 30); ac++;
	XtSetArg(al[ac], XmNmarginHeight, 3); ac++;
	site_Pressure = XmCreateTextField(site_control, "pressure", al, ac);
	XtManageChild(site_Pressure);
	XtAddCallback(site_Pressure, XmNmodifyVerifyCallback, siteCB, (XtPointer) GPSPRESS);
	XtAddCallback(site_Pressure, XmNvalueChangedCallback, siteChangedCB, (XtPointer) GPSPRESS);

	/* Create command button for site apply */
	ac=0;
	XtSetArg(al[ac],XmNlabelString, XmStringCreateLocalized("Apply NVJ")); ac++;
	XtSetArg(al[ac],XmNrecomputeSize, FALSE); ac++;
	XtSetArg(al[ac],XmNy, 214); ac++;
	XtSetArg(al[ac],XmNx, 176); ac++;
	XtSetArg(al[ac],XmNwidth, 80); ac++;
	XtSetArg(al[ac],XmNheight, 28); ac++;
	nvj_apply = XmCreatePushButton(site_control,"connect",al,ac);
	XtManageChild(nvj_apply);
	XtAddCallback(nvj_apply, XmNactivateCallback, siteCB, (XtPointer) GPSNVJ);

	/* Create a separator widget and attach it to the form */
	ac=0;
	XtSetArg(al[ac],XmNtopAttachment,XmATTACH_FORM); ac++;
	XtSetArg(al[ac],XmNtopOffset, 246); ac++;
	XtSetArg(al[ac],XmNrightAttachment,XmATTACH_FORM); ac++; 
	XtSetArg(al[ac],XmNleftAttachment,XmATTACH_FORM); ac++;  
	XtSetArg(al[ac],XmNbottomAttachment,XmATTACH_NONE); ac++;  
	site_sep2=XmCreateSeparator(site_control,"sep2",al,ac);
	XtManageChild(site_sep2); 

	/* Label for TimeDifference */
	ac=0;
	XtSetArg(al[ac],XmNlabelString, XmStringCreateLocalized("Time diff.")); ac++;
	XtSetArg(al[ac],XmNrecomputeSize, FALSE); ac++;
	XtSetArg(al[ac],XmNy, 250); ac++;
	XtSetArg(al[ac],XmNx, 16); ac++;
	XtSetArg(al[ac],XmNwidth, 80); ac++;
	XtSetArg(al[ac],XmNheight, 28); ac++;
	XtSetArg(al[ac],XmNalignment,XmALIGNMENT_BEGINNING); ac++;
	site_TimeDifference_l = XmCreateLabel(site_control, "ltimediff", al, ac);
	XtManageChild(site_TimeDifference_l); 

	/* Create text box for TimeDifference */
	sprintf(value, "%+04d", gps.TimeDifference);
	ac=0;
	XtSetArg(al[ac],XmNvalue, value); ac++;
	XtSetArg(al[ac],XmNrecomputeSize, FALSE); ac++;
	XtSetArg(al[ac],XmNy, 250); ac++;
	XtSetArg(al[ac],XmNx, 96); ac++;
	XtSetArg(al[ac],XmNwidth, 80); ac++;
	XtSetArg(al[ac],XmNheight, 28); ac++;
	XtSetArg(al[ac], XmNmaxLength, 30); ac++;
	XtSetArg(al[ac], XmNmarginHeight, 3); ac++;
	site_TimeDifference = XmCreateTextField(site_control, "timediff", al, ac);
	XtManageChild(site_TimeDifference);
	XtAddCallback(site_TimeDifference, XmNmodifyVerifyCallback, siteCB, (XtPointer) GPSTDIFF);
	XtAddCallback(site_TimeDifference, XmNvalueChangedCallback, siteChangedCB, (XtPointer) GPSTDIFF);

	/* Create command button for time apply */
	ac=0;
	XtSetArg(al[ac],XmNlabelString, XmStringCreateLocalized("Apply time")); ac++;
	XtSetArg(al[ac],XmNrecomputeSize, FALSE); ac++;
	XtSetArg(al[ac],XmNy, 250); ac++;
	XtSetArg(al[ac],XmNx, 176); ac++;
	XtSetArg(al[ac],XmNwidth, 80); ac++;
	XtSetArg(al[ac],XmNheight, 28); ac++;
	site_timeapply = XmCreatePushButton(site_control,"connect",al,ac);
	XtManageChild(site_timeapply);
	XtAddCallback(site_timeapply, XmNactivateCallback, siteCB, (XtPointer) GPSTAPPLY);
}

void siteChangedCB(Widget txt, int client_data, XtPointer call_data)
{
	char* text;
	char value[32];
	static int doit = 1;

	if (doit)
	{
		if ((text = XmTextGetString(txt)))
		{
			switch (client_data)
			{
				case GPSSERIAL:
					strcpy(gps.gpsport, text);
					break;
				case GPSLONN:
					sscanf(text, "%lf", &gps.SiteLongitude);
					dtodms(value, &gps.SiteLongitude);
					if (value[0] == '-')
					{
						value[0] = 'W';
					}
					else
					{
						value[0] = 'E';
					}
					if (value[3] == ':')
					{
						memmove(value+2, value+1, 8); 
						value[1] = '0';
						value[10] = '\0';
					}
					doit = 0;
					XtVaSetValues (site_Longitude, XmNvalue, value, NULL);
					doit = 1;
					break;
				case GPSLON:
					if (text[0] == 'E')
					{
						text[0] = '+';
					}
					else
					{
						text[0] = '-';
					}
					dmstod(text, &gps.SiteLongitude);
					sprintf(value, "%+010.5f", gps.SiteLongitude);
					doit = 0;
					XtVaSetValues (site_Longitude_n, XmNvalue, value, NULL);
					doit = 1;
					break;
				case GPSLATN:
					sscanf(text, "%lf", &gps.SiteLatitude);
					dtodms(value, &gps.SiteLatitude);
					if (value[0] == '-')
					{
						value[0] = 'S';
					}
					else
					{
						value[0] = 'N';
					}
					doit = 0;
					XtVaSetValues (site_Latitude, XmNvalue, value, NULL);
					doit = 1;
					break;
				case GPSLAT:
					if (text[0] == 'N')
					{
						text[0] = '+';
					}
					else
					{
						text[0] = '-';
					}
					dmstod(text, &gps.SiteLatitude);
					sprintf(value, "%+09.5f", gps.SiteLatitude);
					doit = 0;
					XtVaSetValues (site_Latitude_n, XmNvalue, value, NULL);
					doit = 1;
					break;
				case GPSALT:
					sscanf(text, "%lf", &gps.SiteAltitude);
					break;
				case GPSTEMP:
					sscanf(text, "%lf", &gps.SiteTemperature);
					break;
				case GPSPRESS:
					sscanf(text, "%lf", &gps.SitePressure);
					break;
				case GPSTDIFF:
					sscanf(text, "%d", &gps.TimeDifference);
					break;
			}
		}
		XtFree (text);
	}
}

/* callback function for the target input box */
void siteCB(Widget txt, int client_data, XtPointer call_data)
{
	XmTextVerifyCallbackStruct *cbs = (XmTextVerifyCallbackStruct *) call_data;
	int pdir = 0, ndir = 0, col1 = 0, col2 = 0, maxl = 0, sep = 0;
	double timez = 0.;
	char cmd[256], tmp3[32];
	char *tmp1, *tmp2, *tmp4;
	static time_t systime, utctime;
	static struct tm * tmsys;
	static struct tm *tmutc;
	
	switch (client_data)
	{
		case GPSLONN:
			pdir = 43; 
			ndir = 45; 
			col1 = 4; 
			col2 = 4; 
			maxl = 10;
			sep  = 46;
			break;
		case GPSLATN:
			pdir = 43; 
			ndir = 45; 
			col1 = 3; 
			col2 = 3; 
			maxl = 9; 
			sep  = 46;
			break;
		case GPSLON:
			pdir = 69; 
			ndir = 87; 
			col1 = 4; 
			col2 = 7; 
			maxl = 10; 
			sep  = 58;
			break;
		case GPSLAT:
			pdir = 78; 
			ndir = 83; 
			col1 = 3; 
			col2 = 6; 
			maxl = 9; 
			sep  = 58;
			break;
		case GPSALT:
			pdir = 43; 
			ndir = 45; 
			col1 = 5; 
			col2 = 5; 
			maxl = 7; 
			sep  = 46;
			break;
		case GPSTEMP:
			pdir = 43; 
			ndir = 45; 
			col1 = 3; 
			col2 = 3; 
			maxl = 5; 
			sep  = 46;
			break;
		case GPSPRESS:
			pdir = 43; 
			ndir = 45; 
			col1 = 5; 
			col2 = 5; 
			maxl = 8; 
			sep  = 46;
			break;
		case GPSTDIFF:
			pdir = 43; 
			ndir = 45; 
			col1 = 999; 
			col2 = 999; 
			maxl = 4; 
			sep  = 46;
			break;
	}
	
	switch (client_data)
	{
		case GPSCONNECT:
			if (GpsConnect(gps.gpsport))
			{
				if (GetGPGGA(&gps))
				{
					setMessage("Got data from gps\n"); 
					if (gps.gpsvalid && gps.gpssats > 0)
					{
						setMessage("Gps position is valid\n");
						set_site();
					}
					else
					{
						setMessage("Gps position is not valid\n"); 	
					}
				}
				else
				{
					setMessage("Could not get data from gps\n"); 
				}
				GpsDisconnect();
			}
			break;
		
		case GPSLONN:
		case GPSLATN:
		case GPSLON:
		case GPSLAT:
		case GPSALT:
		case GPSTEMP:
		case GPSPRESS:
		case GPSTDIFF:
			if (cbs->text->ptr == NULL)
			{
				cbs->doit = FALSE;
			}
			else if (abs(cbs->endPos - cbs->startPos) > 1 && abs(cbs->endPos - cbs->startPos) < maxl)
			{
				cbs->doit = FALSE;
			}
			else if (cbs->text->length == 1 )
			{
				if (cbs->currInsert < maxl)
				{
					if (cbs->currInsert == 0)
					{
						if ((cbs->text->ptr[0] != 32) && (cbs->text->ptr[0] != ndir) && (cbs->text->ptr[0] != ndir + 32))
						{
							cbs->text->ptr[0] = pdir;
						}
						else
						{
							cbs->text->ptr[0] = ndir;
						}
					}
					else if ((cbs->currInsert == col1) || (cbs->currInsert == col2))
					{
						cbs->text->ptr[0] = sep;
					}
					else if ((cbs->currInsert == col1-1) || (cbs->currInsert == col2-1))
					{
						cbs->text->length = 2;
						cbs->text->ptr[1] = sep;
					}
					else
					{
						if ((cbs->text->ptr[0] >= 48) && (cbs->text->ptr[0] <= 57))
						{
							cbs->doit = TRUE;
						}
						else
						{
							cbs->doit = FALSE;
						}
				
					}
					cbs->startPos = cbs->currInsert;
					cbs->endPos = cbs->currInsert + cbs->text->length;
				}
				else 
				{
					cbs->doit = FALSE;
				}
			}
			//fprintf(stderr, "currInsert: %u\nnewInsert: %u\nText: %s\nstartPos: %u\nendPos: %u\n", cbs->currInsert, cbs->newInsert, cbs->text->ptr, cbs->startPos, cbs->endPos);
			break;
		case GPSAPPLY:
			// Even if manual set, and accepted, it's good.
			gps.gpsvalid = 1;
			set_tel_site();
			break;
		case GPSNVJ:
			tmp1 = XmTextGetString(site_Longitude);
			tmp1[0] = (tmp1[0] == 'E') ? '+' : '-';
			tmp1[7] = '\0';
			tmp2 = XmTextGetString(site_Latitude);
			tmp2[0] = (tmp2[0] == 'N') ? '+' : '-';
			tmp2[6] = '\0';
			systime = time(NULL);
			tmsys = localtime(&systime);
			tmutc = gmtime(&systime);
			utctime = mktime(tmutc);
			timez = round(difftime(systime, utctime) / 360.) / 10.;
			sprintf(tmp3, "%+.2f", timez);
			tmp4 = strchr(tmp3, '.');
			tmp4[0] = ':';
			sprintf(cmd, "LONG:%s LAT:%s TZ:%s DST:%d\n", tmp1, tmp2, tmp3, (tmsys->tm_isdst > 0));
			if (write(fd_fifo_out, cmd, strlen(cmd)) == -1)
			{
				setMessage("Error communicating site coordinates.\n");
			}
			XtFree(tmp1);
			XtFree(tmp2);
			break;
		case GPSTAPPLY:
			sprintf(cmd, "%s -t%d", XMTEL_TIMEFIX, gps.TimeDifference);
			if (system(cmd) != -1)
			{
				systime = time(NULL);
				tmsys = localtime(&systime);
				sprintf(strMsgLine, "Sytem time set to: %s\n", asctime(tmsys));
				// Since the time has changed main timer may be confused
				XtRemoveTimeOut(poll_interval_id);
				poll_interval_id = XtAppAddTimeOut(context, poll_interval, poll_interval_handler, poll_interval_data_ptr);
				gps.TimeDifference = 0;
				sprintf(cmd, "%+04d", gps.TimeDifference);
				XtVaSetValues (site_TimeDifference, XmNvalue, cmd, NULL);
			}
			else
			{
				sprintf(strMsgLine, "Could not set system time (%s)\nBe sure fixtime support program is there\nBe sure it has +xs permission\n", cmd);
			}
			setMessage( strMsgLine);		
			break;
	}
}



#ifdef ISFOCUS
	/* Create the unmanged focus control panel */
	void setup_focus()
	{
		Arg al[10];
		int ac;
		int x;
		EventMask mask;

		ac=0;    
		XtSetArg(al[ac],XmNheight,250); ac++;
		XtSetArg(al[ac],XmNwidth,250); ac++;
		XtSetArg(al[ac],XmNautoUnmanage,False); ac++;
		XtSetArg(al[ac],XmNdialogTitle,XmStringCreateLocalized("Focus")); ac++;
		focus_control=XmCreateFormDialog(toplevel,"Focus",al,ac);

		/* Create the focus speed radio box */
		ac=0;
		XtSetArg(al[ac],XmNorientation,XmVERTICAL); ac++;
		XtSetArg(al[ac],XmNtopAttachment,XmATTACH_POSITION); ac++;
		XtSetArg(al[ac],XmNtopPosition,12); ac++; 
		XtSetArg(al[ac],XmNleftAttachment,XmATTACH_POSITION); ac++;
		XtSetArg(al[ac],XmNleftPosition,5); ac++; 
		XtSetArg(al[ac],XmNrightAttachment,XmATTACH_POSITION); ac++;
		XtSetArg(al[ac],XmNrightPosition,36); ac++; 
		focus_spd_radio_box=XmCreateRadioBox(focus_control,"focus_spd_radio_box",al,ac);
		XtManageChild(focus_spd_radio_box);

		/* Create focus speed toggles in the radio box */
		for (x=0; x<4; x++)
		{
			ac=0;
			XtSetArg(al[ac],XmNlabelString, XmStringCreateLocalized(focus_spd_name[x])); ac++;
			focus_spd_toggle[x]=XmCreateToggleButton(focus_spd_radio_box, "focus_spd_toggle",al,ac);
			XtManageChild(focus_spd_toggle[x]);
			XtAddCallback (focus_spd_toggle[x], XmNvalueChangedCallback, focus_speedCB, (XtPointer) x);
		}
		
		/* Set the speed togglebutton to initial value of focusspd */
		XmToggleButtonSetState (focus_spd_toggle[0], True, False);

		/* Create the push buttons on the panel */
		ac=0;
		XtSetArg(al[ac],XmNleftAttachment, XmATTACH_POSITION); ac++;
		XtSetArg(al[ac],XmNleftPosition,40); ac++;
		XtSetArg(al[ac],XmNrightAttachment, XmATTACH_POSITION); ac++;
		XtSetArg(al[ac],XmNrightPosition,40+20); ac++;
		XtSetArg(al[ac],XmNtopAttachment, XmATTACH_POSITION); ac++;
		XtSetArg(al[ac],XmNtopPosition,24); ac++;
		XtSetArg(al[ac],XmNbottomAttachment, XmATTACH_POSITION); ac++;
		XtSetArg(al[ac],XmNbottomPosition,24+20); ac++;
		XtSetArg(al[ac],XmNlabelString, XmStringCreateLocalized("In")); ac++;
		focus_in_button = XmCreatePushButton(focus_control, "focus_in_button", al, ac); 
		mask = ButtonReleaseMask | ButtonPressMask;
		XtAddEventHandler(focus_in_button,mask,False,focusCB,(XtPointer) FOCUSIN);         
		XtManageChild(focus_in_button);

		ac=0;
		XtSetArg(al[ac],XmNleftAttachment, XmATTACH_POSITION); ac++;
		XtSetArg(al[ac],XmNleftPosition,70); ac++;
		XtSetArg(al[ac],XmNrightAttachment, XmATTACH_POSITION); ac++;
		XtSetArg(al[ac],XmNrightPosition,70+20); ac++;
		XtSetArg(al[ac],XmNtopAttachment, XmATTACH_POSITION); ac++;
		XtSetArg(al[ac],XmNtopPosition,24); ac++;
		XtSetArg(al[ac],XmNbottomAttachment, XmATTACH_POSITION); ac++;
		XtSetArg(al[ac],XmNbottomPosition,24+20); ac++;
		XtSetArg(al[ac],XmNlabelString, XmStringCreateLocalized("Out")); ac++;
		focus_out_button = XmCreatePushButton(focus_control, "focus_out_button", al, ac);
		mask = ButtonReleaseMask | ButtonPressMask;
		XtAddEventHandler(focus_out_button,mask,False,focusCB,(XtPointer) FOCUSOUT);
		XtManageChild(focus_out_button);

		ac=0;
		XtSetArg(al[ac],XmNrecomputeSize, FALSE); ac++;
		XtSetArg(al[ac],XmNleftAttachment, XmATTACH_POSITION); ac++;
		XtSetArg(al[ac],XmNleftPosition,55); ac++;
		XtSetArg(al[ac],XmNrightAttachment, XmATTACH_POSITION); ac++;
		XtSetArg(al[ac],XmNrightPosition,55+20); ac++;
		XtSetArg(al[ac],XmNtopAttachment, XmATTACH_POSITION); ac++;
		XtSetArg(al[ac],XmNtopPosition,55); ac++;
		XtSetArg(al[ac],XmNbottomAttachment, XmATTACH_POSITION); ac++;
		XtSetArg(al[ac],XmNbottomPosition,55+10); ac++;
		XtSetArg(al[ac],XmNlabelString, XmStringCreateLocalized("000000")); ac++;
		focus_count_label = XmCreateLabel(focus_control,"label", al, ac); 
		XtManageChild(focus_count_label);

		ac=0;
		XtSetArg(al[ac],XmNleftAttachment, XmATTACH_POSITION); ac++;
		XtSetArg(al[ac],XmNleftPosition,10); ac++;
		XtSetArg(al[ac],XmNrightAttachment, XmATTACH_POSITION); ac++;
		XtSetArg(al[ac],XmNrightPosition,10+20); ac++;
		XtSetArg(al[ac],XmNtopAttachment, XmATTACH_POSITION); ac++;
		XtSetArg(al[ac],XmNtopPosition,72); ac++;
		XtSetArg(al[ac],XmNbottomAttachment, XmATTACH_POSITION); ac++;
		XtSetArg(al[ac],XmNbottomPosition,72+10); ac++;
		XtSetArg(al[ac],XmNlabelString, XmStringCreateLocalized("OK")); ac++;
		focus_ok_button = XmCreatePushButton(focus_control,"focus_ok_button", al, ac); 
		mask = ButtonReleaseMask | ButtonPressMask;      
		XtAddEventHandler(focus_ok_button,mask,False, focusCB,(XtPointer) FOCUSOK);
		XtManageChild(focus_ok_button);
	}
#endif

#ifdef ISFAN
	/* Create the unmanaged fan control panel */
	void setup_fan()
	{
		Arg al[10];
		int ac;
		int x;
		EventMask mask;

		ac=0;    
		XtSetArg(al[ac],XmNheight,250); ac++;
		XtSetArg(al[ac],XmNwidth,250); ac++;
		XtSetArg(al[ac],XmNautoUnmanage,False); ac++;
		XtSetArg(al[ac],XmNdialogTitle,XmStringCreateLocalized("fan")); ac++;
		fan_control=XmCreateFormDialog(toplevel,"fan",al,ac);

		/* Create the fan speed radio box */
		ac=0;
		XtSetArg(al[ac],XmNorientation,XmVERTICAL); ac++;
		XtSetArg(al[ac],XmNtopAttachment,XmATTACH_POSITION); ac++;
		XtSetArg(al[ac],XmNtopPosition,12); ac++; 
		XtSetArg(al[ac],XmNleftAttachment,XmATTACH_POSITION); ac++;
		XtSetArg(al[ac],XmNleftPosition,5); ac++; 
		XtSetArg(al[ac],XmNrightAttachment,XmATTACH_POSITION); ac++;
		XtSetArg(al[ac],XmNrightPosition,36); ac++; 
		fan_spd_radio_box=XmCreateRadioBox(fan_control,"fan_spd_radio_box",al,ac);
		XtManageChild(fan_spd_radio_box);

		/* Create fan speed toggles in the radio box */
		for (x=0; x<3; x++)
		{
			ac=0;
			XtSetArg(al[ac],XmNlabelString, XmStringCreateLocalized(fan_spd_name[x])); ac++;
			fan_spd_toggle[x]=XmCreateToggleButton(fan_spd_radio_box, "fan_spd_toggle",al,ac);
			XtManageChild(fan_spd_toggle[x]);
			XtAddCallback (fan_spd_toggle[x], XmNvalueChangedCallback, fan_speedCB, (XtPointer) x);
		}     

		#ifdef LX200AST_H
			// Lx200 only has on/off speed
			XtUnmanageChild(fan_spd_toggle[1]);
		#endif
		#ifdef NEXSTAR_H
			// CDK20 only has on/off speed
			XtUnmanageChild(fan_spd_toggle[1]);
		#endif

		/* Set the speed togglebutton to initial value of fan speed */
		XmToggleButtonSetState (fan_spd_toggle[2], True, False);

		ac=0;
		XtSetArg(al[ac],XmNleftAttachment, XmATTACH_POSITION); ac++;
		XtSetArg(al[ac],XmNleftPosition,10); ac++;
		XtSetArg(al[ac],XmNrightAttachment, XmATTACH_POSITION); ac++;
		XtSetArg(al[ac],XmNrightPosition,10+20); ac++;
		XtSetArg(al[ac],XmNtopAttachment, XmATTACH_POSITION); ac++;
		XtSetArg(al[ac],XmNtopPosition,72); ac++;
		XtSetArg(al[ac],XmNbottomAttachment, XmATTACH_POSITION); ac++;
		XtSetArg(al[ac],XmNbottomPosition,72+10); ac++;
		XtSetArg(al[ac],XmNlabelString, XmStringCreateLocalized("OK")); ac++;
		fan_ok_button = XmCreatePushButton(fan_control,"fan_ok_button", al, ac); 
		mask = ButtonReleaseMask | ButtonPressMask;      
		XtAddEventHandler(fan_ok_button,mask,False, fanCB,(XtPointer) FANOK);
		XtManageChild(fan_ok_button);
	}
#endif

#ifdef ISHEATER
	/* Create the unmanaged heater control panel */
	void setup_heater()
	{
		Arg al[10];
		int ac;
		int x;
		EventMask mask;

		ac=0;    
		XtSetArg(al[ac],XmNheight,250); ac++;
		XtSetArg(al[ac],XmNwidth,250); ac++;
		XtSetArg(al[ac],XmNautoUnmanage,False); ac++;
		XtSetArg(al[ac],XmNdialogTitle,XmStringCreateLocalized("heater")); ac++;
		heater_control=XmCreateFormDialog(toplevel,"heater",al,ac);

		/* Create the heater power radio box */
		ac=0;
		XtSetArg(al[ac],XmNorientation,XmVERTICAL); ac++;
		XtSetArg(al[ac],XmNtopAttachment,XmATTACH_POSITION); ac++;
		XtSetArg(al[ac],XmNtopPosition,12); ac++; 
		XtSetArg(al[ac],XmNleftAttachment,XmATTACH_POSITION); ac++;
		XtSetArg(al[ac],XmNleftPosition,5); ac++; 
		XtSetArg(al[ac],XmNrightAttachment,XmATTACH_POSITION); ac++;
		XtSetArg(al[ac],XmNrightPosition,36); ac++; 
		heater_pwr_radio_box=XmCreateRadioBox(heater_control,"heater_pwr_radio_box",al,ac);
		XtManageChild(heater_pwr_radio_box);

		/* Create heater power toggles in the radio box */
		for (x=0; x<3; x++)
		{
			ac=0;
			XtSetArg(al[ac],XmNlabelString, XmStringCreateLocalized(heater_pwr_name[x])); ac++;
			heater_pwr_toggle[x]=XmCreateToggleButton(heater_pwr_radio_box, "heater_pwr_toggle",al,ac);
			XtManageChild(heater_pwr_toggle[x]);
			XtAddCallback (heater_pwr_toggle[x], XmNvalueChangedCallback, heater_powerCB, (XtPointer) x);
		}     

		/* Set the power togglebutton to initial value of heaterpwr */
		XmToggleButtonSetState (heater_pwr_toggle[2], True, False);

		ac=0;
		XtSetArg(al[ac],XmNleftAttachment, XmATTACH_POSITION); ac++;
		XtSetArg(al[ac],XmNleftPosition,10); ac++;
		XtSetArg(al[ac],XmNrightAttachment, XmATTACH_POSITION); ac++;
		XtSetArg(al[ac],XmNrightPosition,10+20); ac++;
		XtSetArg(al[ac],XmNtopAttachment, XmATTACH_POSITION); ac++;
		XtSetArg(al[ac],XmNtopPosition,72); ac++;
		XtSetArg(al[ac],XmNbottomAttachment, XmATTACH_POSITION); ac++;
		XtSetArg(al[ac],XmNbottomPosition,72+10); ac++;
		XtSetArg(al[ac],XmNlabelString, XmStringCreateLocalized("OK")); ac++;
		heater_ok_button = XmCreatePushButton(heater_control,"heater_ok_button", al, ac); 
		mask = ButtonReleaseMask | ButtonPressMask;      
		XtAddEventHandler(heater_ok_button,mask,False, heaterCB,(XtPointer) HEATEROK);
		XtManageChild(heater_ok_button);
	}
#endif

/* callback function for the target input box */
void dialogtextCB(Widget txt, XtPointer client_data, XtPointer call_data)
{
	XmTextVerifyCallbackStruct *cbs = (XmTextVerifyCallbackStruct *) call_data;
	
	if (cbs->text->ptr == NULL)
	{
		cbs->doit = FALSE;
	}
	else if (abs(cbs->endPos - cbs->startPos) > 1 && abs(cbs->endPos - cbs->startPos) < 9)
	{
		cbs->doit = FALSE;
	}
	else if (cbs->text->length == 1 )
	{
		if (cbs->currInsert < 9)
		{
			if (cbs->currInsert == 0)
			{
				if ((cbs->text->ptr[0] != 32) && (cbs->text->ptr[0] != 43) && (cbs->text->ptr[0] != 45))
				{
					cbs->text->ptr[0] = 43;
				}
			}
			else if ((cbs->currInsert == 3) || (cbs->currInsert == 6))
			{
				cbs->text->ptr[0] = 58;
			}
			else if ((cbs->currInsert == 2) || (cbs->currInsert == 5))
			{
				cbs->text->length = 2;
				cbs->text->ptr[1] = 58;
			}
			else
			{
				if ((cbs->text->ptr[0] >= 48) && (cbs->text->ptr[0] <= 57))
				{
					cbs->doit = TRUE;
				}
				else
				{
					cbs->doit = FALSE;
				}
				
			}
			cbs->startPos = cbs->currInsert;
			cbs->endPos = cbs->currInsert + cbs->text->length;
		}
		else 
		{
			cbs->doit = FALSE;
		}
	}
	//fprintf(stderr, "currInsert: %u\nnewInsert: %u\nText: %s\nstartPos: %u\nendPos: %u\n", cbs->currInsert, cbs->newInsert, cbs->text->ptr, cbs->startPos, cbs->endPos);
}

void degmotionCB(Widget txt, XtPointer client_data, XtPointer call_data)
{
	int prepos = 0, newpos = 0, dir = 0;
	XmTextVerifyCallbackStruct *cbs = (XmTextVerifyCallbackStruct *) call_data;
	
	prepos = cbs->newInsert;
	newpos = cbs->newInsert;
	dir = newpos - prepos;
	switch (newpos)
	{
		case 3:
			cbs->newInsert += dir;
			break;

		case 6:
			cbs->newInsert += dir;
			break;
	}
	//fprintf(stderr, "Position %u\n", (int) cbs->newInsert);	
}

void dialogCB(w,client_data,call_data)
	Widget w;
	int client_data;
	XmSelectionBoxCallbackStruct  *call_data;
{    
	char *s;
	int testflag = 0;
	double tmpra, tmpdec;
	time_t timebuf;
	char *gmtstr;

	switch (client_data)
	{
		case OK:
			/* Get new string value */
			s = XmStringUnparse (call_data->value, NULL, XmCHARSET_TEXT, XmCHARSET_TEXT, NULL, 0, XmOUTPUT_ALL);
			switch (tgtfield)
			{  
				case RA: 
					switch (display_targetepoch)
					{
					case J2000:
						/* Display Epoch 2000.0 coordinates.                                */
						/* If XEphem transfered proper motion, then the target coordinates  */
						/*   stored in XmTel include proper motion to the current date.     */
						/*   Coordinates including proper motion and precessed to 2000.0    */
						/*   will differ from an epoch 2000.0 catalog entry that            */
						/*   does not include proper motion to the current date.            */

						/* Convert current target coordinates to J2k 
						tmpra=target[0].ra;
						tmpdec=target[0].dec;        
						Apparent(&tmpra, &tmpdec, -1); */
						
						tmpra = target[0].j2kra;
						tmpdec = target[0].j2kdec;        
						/* Change ra to new J2k value */
						testflag = dmstod(s,&tmpra);
						tmpra = Map24(tmpra);
						if (testflag == 0) 
						{
							target[0].j2kra = tmpra;
							/* Set the new coordinates pair back to EOD */
							Apparent(&tmpra, &tmpdec, 1);
							target[0].ra = tmpra;
							target[0].dec = tmpdec;
						}
						break;

					case  EOD:
						/* Display EOD coordinates as saved in target[0].ra and target[0].dec. */
						testflag=dmstod(s,&tmpra);
						tmpra = Map24(tmpra);
						target[0].ra = tmpra;
						// Derive j2k coords
						tmpdec = target[0].dec;        
						Apparent(&tmpra, &tmpdec, -1);
						target[0].j2kra = tmpra;
						target[0].j2kdec = tmpdec;        
						break;
					}      
					target[0].mag = -9999.;
					target[0].jpmra = 0;
					target[0].jpmdec = 0;
					target[0].abspos = 0;

					if (testflag == 0) 
					{
						show_target_coordinates();
					}
					else
					{
						setMessage("Error converting input RA data to J2000\n");
					}
					break;

				case DEC: 
					switch (display_targetepoch)
					{
					case J2000:
						/* Display Epoch 2000.0 coordinates.                                */
						/* If XEphem transfered proper motion, then the target coordinates  */
						/*   stored in XmTel include proper motion to the current date.     */
						/*   Coordinates including proper motion and precessed to 2000.0    */
						/*   will differ from an epoch 2000.0 catalog entry that            */
						/*   does not include proper motion to the current date.            */

						/* Convert current target coordinates to J2k
						tmpra=target[0].ra;
						tmpdec=target[0].dec;        
						Apparent(&tmpra, &tmpdec, -1); */
						
						tmpra = target[0].j2kra;
						tmpdec = target[0].j2kdec; 						
						/* Change dec to new J2k value */
						testflag=dmstod(s,&tmpdec);
						tmpdec = Map90(tmpdec);
						if (testflag == 0) 
						{
							target[0].j2kdec = tmpdec;
							/* Set the new coordinates pair back to EOD */
							Apparent(&tmpra, &tmpdec, 1);
							target[0].ra = tmpra;
							target[0].dec = tmpdec;
						}
						break;

					case  EOD:
						/* Display EOD coordinates as saved in target[0].ra and target[0].dec. */
						testflag=dmstod(s,&tmpdec);
						tmpdec = Map90(tmpdec);
						target[0].dec = tmpdec;
						// Derive j2k coords
						tmpra = target[0].ra;
						Apparent(&tmpra, &tmpdec, -1);
						target[0].j2kra = tmpra;
						target[0].j2kdec = tmpdec;        
						break;
					}      
					target[0].mag = -9999.;
					target[0].jpmra = 0;
					target[0].jpmdec = 0;
					target[0].abspos = 0;					

					if (testflag == 0) 
					{
						show_target_coordinates();
					}
					else
					{
						setMessage("Error converting input DEC data to J2000\n");
					}
					break;
			}
			XtFree(s);
			time(&timebuf);
			gmtstr = asctime(gmtime(&timebuf));
			if (gmtstr[strlen(gmtstr) - 1] == '\n') 
			{	
				gmtstr[strlen(gmtstr) - 1]= '\0';
			}
			sprintf(target[0].name,"Personal %u | ", last_history_saved + 1);
			strcat(target[0].name, gmtstr);
			strcpy(target[0].desc, "f");
			break;

		case CANCEL:
			break;

	}
	XtUnmanageChild(w);
}

/* Callback function for the 9 speed toggle buttons */
void speedCB(w,client_data,call_data)
	Widget w;
	int client_data;
	XmToggleButtonCallbackStruct *call_data;
{
	int n;

	/* identify the button code*/
	n = client_data;
	if (call_data->reason == XmCR_VALUE_CHANGED && call_data->set == XmSET)
	{
		/* assign a speed code */
		switch (9 - n)
		{
			case 1:
				SetRate(&mnt, GUIDE1);
				break;
			case 2:
				SetRate(&mnt, GUIDE2);
				break;
			case 3:
				SetRate(&mnt, CENTER3);
				break;
			case 4:
				SetRate(&mnt, CENTER4);
				break;
			case 5:
				SetRate(&mnt, CENTER5);
				break;
			case 6:
				SetRate(&mnt, FIND6);
				break;
			case 7:
				SetRate(&mnt, FIND7);
				break;
			case 8:
				SetRate(&mnt, FIND8);
				break;
			case 9:
				SetRate(&mnt, SLEW9);
				break;
		}
	}
}

/* Callback function for the 4 speed toggle buttons */
void trackCB(w, client_data, call_data)
    Widget w;
    int client_data;
    XmToggleButtonCallbackStruct *call_data;
{
	
	if (client_data < 3)
	{
		XtUnmanageChild (trkspin_box);
		if (call_data->reason == XmCR_VALUE_CHANGED && call_data->set == XmSET)
		{
			/* assign a speed code */
			SetTrkSpd(&mnt, -1 * (client_data + 1));
		}
	}
	else if (client_data == 3)
	{
		XtManageChild (trkspin_box);
		apply_tracking_handler(NULL,NULL);
	}
}

void trkspinVerifyCB(w, client_data, call_data)
    Widget w;
    int client_data;
    XmSpinBoxCallbackStruct *call_data;
{
	int deg, min, sec;

	XtVaGetValues (trkspin_d, XmNposition, &deg, NULL);
	XtVaGetValues (trkspin_m, XmNposition, &min, NULL);
	XtVaGetValues (trkspin_s, XmNposition, &sec, NULL);
	
	if (call_data->widget == trkspin_s)
	{
		sec = call_data->position;
		if (sec == 0 && call_data->crossed_boundary && call_data->reason == XmCR_SPIN_NEXT)
		{
			min += 1;
			if (min > 59)
			{
				min -= 60;
				deg += 1;
				if (deg > 2)
				{
					call_data->doit = FALSE;
				}
			}
		}
		else if (sec == 59 && call_data->crossed_boundary && call_data->reason == XmCR_SPIN_PRIOR)
		{
			if (min > 0 || deg > 0)
			{
				min -= 1;
				if (min < 0)
				{
					min += 60;
					if (deg > 0)
					{
						deg -= 1;
					}
				}
			}
			else
			{
				call_data->doit = FALSE;
			}
		}
	}
	else if (call_data->widget == trkspin_m)
	{
		min = call_data->position;
		if (min == 0 && call_data->crossed_boundary && call_data->reason == XmCR_SPIN_NEXT)
		{
			deg += 1;
			if (deg > 2)
			{
				call_data->doit = FALSE;
			}
		}
		else if (min == 59 && call_data->crossed_boundary && call_data->reason == XmCR_SPIN_PRIOR)
		{
			deg -= 1;			
			if (deg < 0)
			{
				call_data->doit = FALSE;
			}
		}
	}
	else if (call_data->widget == trkspin_d)
	{
		deg = call_data->position;
		if (deg > 2 || deg < 0)
		{
			call_data->doit = FALSE;
		}
	}
	if (call_data->doit)
	{
		XtVaSetValues (trkspin_s, XmNposition, sec, NULL);
		XtVaSetValues (trkspin_m, XmNposition, min, NULL);
		XtVaSetValues (trkspin_d, XmNposition, deg, NULL);
	}
}

void trkspinChangedCB(w, client_data, call_data)
    Widget w;
    int client_data;
    XmSpinBoxCallbackStruct *call_data;
{
	/*
		typedef struct
		{
			int          reason;
			XEvent       *event;
			Widget       widget;
			Boolean      doit;
			int          position;
			XmString     value;
			Boolean      crossed_boundary;
		} XmSpinBoxCallbackStruct;
	*/
	int customstatus = 0;
	
	if (mnt.tellink) 
	{
		XtVaGetValues (toggleT[3], XmNset, &customstatus, NULL);
		if (customstatus == XmSET)
		{
			// If we're not in "custom" tracking status, just allow to set the value, but nothing is sent to the mount
			if (apply_tracking_id)
			{
				XtRemoveTimeOut(apply_tracking_id);
				apply_tracking_id = 0;
			}
			apply_tracking_id = XtAppAddTimeOut(context, 500, apply_tracking_handler, NULL);
		}
	}
	else 
	{
		setMessage("Telescope is not connected\n"); 
	}
}

void apply_tracking_handler(XtPointer client_data, XtIntervalId *client_id)
{
	int deg, min, sec, arcsecs;
	
	XtVaGetValues (trkspin_d, XmNposition, &deg, NULL);
	XtVaGetValues (trkspin_m, XmNposition, &min, NULL);
	XtVaGetValues (trkspin_s, XmNposition, &sec, NULL);
	arcsecs = sec + min * 60 + deg * 3600;

	SetTrkSpd(&mnt, arcsecs);
	apply_tracking_id = 0;
}  


void guidespinVerifyCB(w, client_data, call_data)
    Widget w;
    int client_data;
    XmSpinBoxCallbackStruct *call_data;
{
	int val;

	val = call_data->position;
	if (val == 0)
	{
		call_data->doit = FALSE;
	}
}

void guidespinChangedCB(w, client_data, call_data)
    Widget w;
    int client_data;
    XmSpinBoxCallbackStruct *call_data;
{
	/*
		typedef struct
		{
			int          reason;
			XEvent       *event;
			Widget       widget;
			Boolean      doit;
			int          position;
			XmString     value;
			Boolean      crossed_boundary;
		} XmSpinBoxCallbackStruct;
	*/
	int radec;
	int val;

	val = call_data->position;
	if (call_data->reason == XmCR_SPIN_NEXT)
	{
		val += (GetGuideStep()-1);
	}
	else if (call_data->reason == XmCR_SPIN_PRIOR)
	{
		val -= (GetGuideStep()-1);
		if (val < GetGuideStep())
		{
			val = GetGuideStep();
		}
	}
	if (call_data->widget == guidespin_r)
	{
		XtVaSetValues (guidespin_r, XmNposition, val, NULL);
		radec = 0;
	}
	else
	{
		XtVaSetValues (guidespin_d, XmNposition, val, NULL);
		radec = 1;
	}

	call_data->position += GetGuideStep();
	if (mnt.tellink) 
	{
		if (apply_guide_id)
		{
			XtRemoveTimeOut(apply_guide_id);
			apply_guide_id  = 0;
		}
		apply_guide_id = XtAppAddTimeOut(context, 500, apply_guide_handler, (XtPointer) radec);
	}
	else 
	{
		setMessage("Telescope is not connected\n"); 
	}
}

void apply_guide_handler(XtPointer client_data, XtIntervalId *client_id)
{
	int val = 0, radec;

	radec = (int) client_data;
	if (radec == 0)
	{
		XtVaGetValues (guidespin_r, XmNposition, &val, NULL);
	}
	else
	{
		XtVaGetValues (guidespin_d, XmNposition, &val, NULL);
	}

	SetGuideSpd(&mnt, val, radec);
	GetGuideSpd(&mnt, &val, radec);

	if (radec == 0)
	{
		mnt.guideratera = val;
		XtVaSetValues (guidespin_r, XmNposition, mnt.guideratera, NULL);
	}
	else
	{
		mnt.guideratedec = val;
		XtVaSetValues (guidespin_d, XmNposition, mnt.guideratedec, NULL);
	}
	
	apply_guide_id  = 0;
}  


/* Callback function for the 2 swap options */
void swapCB(w, client_data, call_data)
	Widget w;
	int client_data;
	XmToggleButtonCallbackStruct *call_data;
{
	XmString text;

	if (call_data->reason == XmCR_VALUE_CHANGED)
	{
		/* identify the button code*/
		switch (client_data)
		{
			case 1:
			if (call_data->set == XmSET)
			{
				text = XmStringCreateLocalized ("W/E");
				XtVaSetValues (w, XmNlabelString, text, NULL);	
				XmStringFree(text);
				XtVaSetValues (button[CMDWEST], XmNuserData, XmARROW_LEFT, NULL);	
				XtVaSetValues (button[CMDEAST], XmNuserData, XmARROW_RIGHT, NULL);					
			}
			else
			{
				text = XmStringCreateLocalized ("E/W");
				XtVaSetValues (w, XmNlabelString, text, NULL);	
				XmStringFree(text);
				XtVaSetValues (button[CMDWEST], XmNuserData, XmARROW_RIGHT, NULL);	
				XtVaSetValues (button[CMDEAST], XmNuserData, XmARROW_LEFT, NULL);					
			}
			break;

			case 0:
			if (call_data->set == XmSET)
			{
				text = XmStringCreateLocalized ("S/N");
				XtVaSetValues (w, XmNlabelString, text, NULL);	
				XmStringFree(text);
				XtVaSetValues (button[CMDNORTH], XmNuserData, XmARROW_DOWN, NULL);	
				XtVaSetValues (button[CMDSOUTH], XmNuserData, XmARROW_UP, NULL);					
			}
			else
			{
				text = XmStringCreateLocalized ("N/S");
				XtVaSetValues (w, XmNlabelString, text, NULL);	
				XmStringFree(text);
				XtVaSetValues (button[CMDNORTH], XmNuserData, XmARROW_UP, NULL);	
				XtVaSetValues (button[CMDSOUTH], XmNuserData, XmARROW_DOWN, NULL);					
			}
			break;
		}
	}
}


/* Callback function for the eq/az toggle button */
void opteqazCB(w, client_data, call_data)
    Widget w;
    int client_data;
    XmToggleButtonCallbackStruct *call_data;
{
	
	if (call_data->reason == XmCR_VALUE_CHANGED)
	{
		if (call_data->set == XmSET)
		{
			//Current eq type
			SetMountMode(&mnt, mnt.teltype);
		}
		else
		{
			SetMountMode(&mnt, ALTAZ);
		}
	}
}

/* Callback function for the 4 directions buttons. */
/* Called when one of the grid buttons is pressed. */
void buttonCB(Widget w, XtPointer client_data, XtPointer call_data)
{
	int n;
	XmArrowButtonCallbackStruct *cbs = (XmArrowButtonCallbackStruct *) call_data;
	XtVaGetValues (w, XmNuserData, &n, NULL);

			/*switch (n) 
			{
				// North
				case XmARROW_UP:
					fprintf(stderr, "North\n");
					break;

				// East
				case XmARROW_LEFT: 
					fprintf(stderr, "East\n");
					break;

				// West
				case XmARROW_RIGHT: 
					fprintf(stderr, "West\n");
					break;

				// South
				case XmARROW_DOWN:
					fprintf(stderr, "South\n");
					break;
			}*/

	
	if (mnt.tellink) 
	{  
		/* respond to the request */
		if (cbs->reason == XmCR_ARM)
		{
		
			switch (n) 
			{
				/* North */
				case XmARROW_UP:
					errflag = !StartSlew(&mnt, NORTH);
					if (!errflag)
					{
						slewflag = TRUE;
					}
					break;

				/* East */
				case XmARROW_RIGHT: 
					errflag = !StartSlew(&mnt, EAST);
					if (!errflag)
					{
						slewflag = TRUE;
					}
					break;

				/* West */
				case XmARROW_LEFT: 
					errflag = !StartSlew(&mnt, WEST);
					if (!errflag)
					{
						slewflag = TRUE;
					}
					break;

				/* South */
				case XmARROW_DOWN:
					errflag = !StartSlew(&mnt, SOUTH);
					if (!errflag)
					{
						slewflag = TRUE;
					}
					break;
			}
		}

		if (cbs->reason == XmCR_DISARM)
		{
			switch (n) 
			{
				/* North */
				case XmARROW_UP:
					errflag = !StopSlew(&mnt, NORTH);
					if (!errflag)
					{
						slewflag = FALSE;
					}
					break;

				/* East */
				case XmARROW_LEFT: 
					errflag = !StopSlew(&mnt, EAST);
					if (!errflag)
					{
						slewflag = FALSE;
					}
					break;

				/* West */
				case XmARROW_RIGHT: 
					errflag = !StopSlew(&mnt, WEST);
					if (!errflag)
					{
						slewflag = FALSE;
					}
					break;

				/* South */
				case XmARROW_DOWN:
					errflag = !StopSlew(&mnt, SOUTH);
					if (!errflag)
					{
						slewflag = FALSE;
					}
					break;
			}
		}
	} 
	else 
	{
		setMessage("Telescope is not connected\n"); 
	}
}

/* Callback function for the xx telescope command buttons */
void commandCB(w, client_data, call_data)
	Widget w;
	int client_data;
	XmAnyCallbackStruct *call_data;
{
   
	int cmd_number, answer = 0;

	/* identify the button */
	cmd_number=client_data;

	switch (cmd_number) 
	{
		/* Tracking on */
		case CMD_TRACK:
			if (mnt.tellink) 
			{  
				SetTrackStatus(&mnt, 1);
				errflag = !StartTrack(&mnt);
				if (errflag)
				{
					SetTrackStatus(&mnt, 0);
				}
			} 
			else 
			{
				setMessage("Telescope is not connected\n"); 
			}
			break; 
		  
		/* Stop all motion including tracking */
		case CMD_STOP: 
			if (mnt.tellink) 
			{  
				SetTrackStatus(&mnt, 0);
				errflag = !FullStop(&mnt);
			} 
			else 
			{
				setMessage("Telescope is not connected\n"); 
			}
			break; 

		/* Sleep the telescope */
		case CMD_SAVE: 
			if (mnt.tellink) 
			{  
				if (!mnt.align)
				{
					answer = msgbox(toplevel, "Mount looks like is not yet aligned\nSure you want to save position?", 1, "Warning");
				}
				else
				{
					answer = 1;
				}  
				if (answer)
				{
					if (save_coordinates(1))
					{
						if (mnt.modfeat[FLTRACK])
						{
							SetTrackStatus(&mnt, 0);
							if (FullStop(&mnt))
							{
								mnt.align = 0;
								setMessage("Telescope set to sleep\n");
							}
						}
					}
				}
			} 
			else 
			{
				setMessage("Telescope is not connected\n"); 
			}
			break;
		  
		/* Slew to target */
		case CMD_SLEW: 
			history_add();
			if (!strcmp(target[0].name, "Park"))
			{
				// Set for tracking inactive so that it stay parked after goto
				SetTrackStatus(&mnt, 0);
			}
			else
			{
				//Set for tracking active, it it was not
				SetTrackStatus(&mnt, 1);
			}  
			if (mnt.tellink) 
			{  
				slew_telescope(); 
			} 
			else 
			{
				setMessage("Telescope is not connected\n"); 
			}
			break;     

		/* Wake up the telescope */
		case CMD_RECALL: 
			if (mnt.tellink) 
			{
				if (mnt.align)
				{
					answer = msgbox(toplevel, "Mount looks like is aligned\nSure you want to reset position?", 1, "Warning");
				}
				else
				{
					answer = 1;
				}  
				if (answer)
				{
					if (recall_coordinates())
					{
						// telpos just reset from recall
						if (SetTel(&mnt, Map12(LSTNow(mnt.SiteLongitude) - telpos[0].ra), telpos[0].dec))
						{
							setMessage("Encoder position reset with saved data\nPlease confirm pointing with a sync on a known target\n");
							//mnt.align = 1;
							if (mnt.modfeat[FLTRACK])
							{
								SetTrackStatus(&mnt, 1);
								if (StartTrack(&mnt))
								{
									setMessage("Telescope awake from sleep\n");
								}
							}
							show_telescope_coordinates();
							mark_fifo_telescope();
						}
					}
				}
			} 
			else 
			{
				setMessage("Telescope is not connected\n"); 
			}
			break;

		/* Sync */
		case CMD_SYNC:
			if (mnt.tellink) 
			{  
				if (mnt.align)
				{
					// Mount is aligned, we'll set offsets
					reference_telescope_to_target(); 
					if (!errflag)
					{ 
						show_telescope_coordinates(); 
						mark_fifo_telescope();
					}
				}
				else
				{
					// Mount is not aligned, we'll do simplest align and check track status
					sync_telescope_to_target();
					if (!errflag)
					{
						mnt.align = 1;
						if (!mnt.trkActive)
						{
							if (StartTrack(&mnt))
							{
								SetTrackStatus(&mnt, 1);
							}
						}
						show_telescope_coordinates(); 
						mark_fifo_telescope();
					}
				}
			} 
			else 
			{
				setMessage("Telescope is not connected\n"); 
			}
			break;

		/* Align scope to pole*/
		case CMD_SPIRAL:
			break;

		/* Connect / disconnect telescope */
		case CMD_CONNECT:
			if (mnt.tellink) 
			{
				unlink_telescope();
			}
			else
			{
				if (XtIsManaged(site_control))
				{
					if (msgbox(toplevel, "Site panel is open, accept values?", MSGOKCANCEL, "Question"))
					{
						gps.gpsvalid = 1;
						set_tel_site();
						XtUnmanageChild(site_control);
						link_telescope();
					}
				}
				else
				{
					link_telescope();
				}
			}
			break;

		/* UnSync */
		case CMD_UNSYNC:
			if (mnt.tellink) 
			{
				if( (mnt.offsetra != 0.) || (mnt.offsetdec != 0.))
				{
					// If ther's an offset set, we reset
					reference_telescope_clear();
				}
				else if (mnt.align)
				{
					// If not and mont is aligned, we clear align.
					if (msgbox(toplevel, "Please confirm you really want to clear telescope sky model", 0, "Warning") == 1)
					{
						mnt.align = 0;
					}
				}  
				if (!errflag)
				{ 
					show_telescope_coordinates(); 
					mark_fifo_telescope();
				}
			} 
			else 
			{
				setMessage("Telescope is not connected\n"); 
			}
			break;

		/* Mark Telescope Position */
		case CMD_MARKTEL:
			if (mnt.tellink) 
			{
				fetch_telescope_coordinates(); 
				if (!errflag)
				{ 
					show_telescope_coordinates(); 
					mark_fifo_telescope();
				}
			} 
			else 
			{
				setMessage("Telescope is not connected\n"); 
			}
			break;

		/* Telescope Ra */
		case CMD_TELRA:
		/* Telescope Dec */
		case CMD_TELDEC:
			if (mnt.tellink) 
			{
				showradec = (showradec) ? AZALT : RADEC;
				display_telepoch = EOD;
				fetch_telescope_coordinates(); 
				if (!errflag)
				{ 
					show_telescope_coordinates(); 
				}
			} 
			else 
			{
				setMessage("Telescope is not connected\n"); 
			}
			break;

		/* Telescope Epoch */
		case CMD_TELEPCH:
			if (mnt.tellink) 
			{
				display_telepoch = (display_telepoch) ? EOD : J2000;
				fetch_telescope_coordinates();
				if (!errflag)
				{ 
					show_telescope_coordinates(); 
					mark_fifo_telescope();
				}
				else
				{
					/* Set value back */
					display_telepoch = (display_telepoch) ? EOD : J2000;
				}
			} 
			else 
			{
				setMessage("Telescope is not connected\n"); 
			}
			break;        

		/* Mark Target Position */
		case CMD_MARKTGT:
			mark_fifo_target();
			break;

		/* Telescope Ra */
		case CMD_GETRA:
			new_target_ra(); 
			break;

		/* Telescope Dec */
		case CMD_GETDEC:
			new_target_dec(); 
			break;

		/* Telescope Epoch */
		case CMD_TGTEPCH:
			display_targetepoch = (display_targetepoch) ? EOD : J2000;
			show_target_coordinates();
			break;

	}
}

/* Callback function for loading the history from file */
void readhistoryCB(w,client_data,call_data)
	Widget w;
	int client_data;
	XmAnyCallbackStruct *call_data; 
{
	char* tmpstr;
	XmFileSelectionBoxCallbackStruct *s = (XmFileSelectionBoxCallbackStruct *) call_data;

	/* do nothing if cancel is selected. */
	if (client_data!=CANCEL) 
	{
		/* get the filename from the file selection box */
		tmpstr = XmStringUnparse (s->value, NULL, XmCHARSET_TEXT, XmCHARSET_TEXT, NULL, 0, XmOUTPUT_ALL);

		/* Read the history into memory */
		sprintf(strMsgLine, "Reading %s\n", tmpstr);
		setMessage(strMsgLine);

		fp_file=fopen(tmpstr, "r");
		if ( !(fp_file == NULL) )
		{
			nhistory = read_edb_file(fp_file, history, nhistory);
			if (!errflag)
			{
				reload_list(history_area, history, nhistory);
				sprintf(strMsgLine,"File %s loaded, %u items parsed\n", tmpstr, nhistory);
				setMessage(strMsgLine);
			}
			fclose(fp_file);
		}
		else
		{
			sprintf(strMsgLine,"Error loading file %s\n", tmpstr);
			setMessage(strMsgLine);
		}
		XtFree(tmpstr);
	}
	XtUnmanageChild(read_file);
} 
 
/* Callback function for saving the history file */
void savehistoryCB(w,client_data,call_data)
	Widget w;
	int client_data;
	XmAnyCallbackStruct *call_data; 
{
	char* tmpstr;

	if (client_data==OK)
	{
		//XmDIALOG_SELECTION
		XtVaGetValues(XmFileSelectionBoxGetChild(save_file, XmDIALOG_TEXT), XmNvalue, &tmpstr, NULL);
		if (tmpstr[strlen(tmpstr) - 1] != 47)
		{
			// Filename is specified
			// Save the queue from memory /
			sprintf(strMsgLine,"Saving %s\n", tmpstr);
			setMessage(strMsgLine);

			fp_file=fopen(tmpstr, "w");
			if ( !(fp_file == NULL) )
			{
				if (write_edb_file(fp_file, history, nhistory))
				{
					sprintf(strMsgLine,"File %s saved, %u items\n", tmpstr, nhistory);
					setMessage(strMsgLine);
				}
				fclose(fp_file);
			}
			else
			{
				sprintf(strMsgLine,"Error saving file %s\n", tmpstr);
				setMessage(strMsgLine);
			}
			XtUnmanageChild(save_file);
		}
		else
		{
			infobox(toplevel, "Not a valid filename!\n", "Warning");
		}
		free(tmpstr);
	}
	else if (client_data==CANCEL)
	{
		XtUnmanageChild(save_file);
	}	
} 
 
void edithistoryCB(w,client_data,call_data)
	Widget w;
	int client_data;
	XmAnyCallbackStruct *call_data; 
{
	char* tmpstr;
	XmFileSelectionBoxCallbackStruct *s = (XmFileSelectionBoxCallbackStruct *) call_data;

	/* do nothing if cancel is selected. */
	if (client_data!=CANCEL) 
	{
		/* get the filename from the file selection box */
		tmpstr = XmStringUnparse (s->value, NULL, XmCHARSET_TEXT, XmCHARSET_TEXT, NULL, 0, XmOUTPUT_ALL);

		sprintf(strMsgLine, "Selected %s\n", tmpstr);
		setMessage( strMsgLine);
		strcpy(buf, editor);
		strcat(buf, " ");
		strcat(buf, tmpstr);
		if (system(buf) == -1)
		{
			sprintf(strMsgLine, "Error from %s\n", buf);
			setMessage( strMsgLine);		
		}
		XtFree(tmpstr);
	}
	XtUnmanageChild(read_file);
} 

/* Callback function for selecting the log file name */
void readconfigCB(w,client_data,call_data)
	Widget w;
	int client_data;
	XmAnyCallbackStruct *call_data;  
{
	XmFileSelectionBoxCallbackStruct *s = (XmFileSelectionBoxCallbackStruct *) call_data;

	/* Do nothing if cancel is selected. */
	if (client_data!=CANCEL) 
	{	
		/* Manage memory for file name */
		if(configfile != NULL)
		{
			XtFree(configfile);
			configfile = NULL;
		}

		/* Get the filename from the file selection box */
		configfile = XmStringUnparse (s->value, NULL, XmCHARSET_TEXT, XmCHARSET_TEXT, NULL, 0, XmOUTPUT_ALL);
		reset_telescope();
		set_init_config();
		read_config();
		reset_site();
		apply_config();
		log_status();
	}
	XtUnmanageChild(read_configfile);
} 

/* Callback function for selecting the log file name */
void readhorizonCB(w,client_data,call_data)
	Widget w;
	int client_data;
	XmAnyCallbackStruct *call_data;  
{
	XmFileSelectionBoxCallbackStruct *s = (XmFileSelectionBoxCallbackStruct *) call_data;

	/* Do nothing if cancel is selected. */
	if (client_data!=CANCEL) 
	{	
		/* Manage memory for file name */
		if(horizonfile != NULL)
		{
			XtFree(horizonfile);
			horizonfile = NULL;
		}

		/* Get the filename from the file selection box */
		horizonfile = XmStringUnparse (s->value, NULL, XmCHARSET_TEXT, XmCHARSET_TEXT, NULL, 0, XmOUTPUT_ALL);
		read_horizon();
	}
	XtUnmanageChild(read_configfile);
} 

void editconfigCB(w,client_data,call_data)
	Widget w;
	int client_data;
	XmAnyCallbackStruct *call_data;  
{
	XmFileSelectionBoxCallbackStruct *s = (XmFileSelectionBoxCallbackStruct *) call_data;

	/* Do nothing if cancel is selected. */
	if (client_data!=CANCEL) 
	{	
		/* Manage memory for file name */
		if(configfile != NULL)
		{
			XtFree(configfile);
			configfile = NULL;
		}

		/* Get the filename from the file selection box */
		configfile = XmStringUnparse (s->value, NULL, XmCHARSET_TEXT, XmCHARSET_TEXT, NULL, 0, XmOUTPUT_ALL);
		strcpy(buf, editor);
		strcat(buf, " ");
		strcat(buf, configfile);
		if (system(buf) == -1)
		{
			sprintf(strMsgLine, "Error from %s\n", buf);
			setMessage( strMsgLine);		
		}
	}
	XtUnmanageChild(read_configfile);
} 
    
void edithorizonCB(w,client_data,call_data)
	Widget w;
	int client_data;
	XmAnyCallbackStruct *call_data;  
{
	XmFileSelectionBoxCallbackStruct *s = (XmFileSelectionBoxCallbackStruct *) call_data;

	/* Do nothing if cancel is selected. */
	if (client_data!=CANCEL) 
	{	
		/* Manage memory for file name */
		if(horizonfile != NULL)
		{
			XtFree(horizonfile);
			horizonfile = NULL;
		}

		/* Get the filename from the file selection box */
		horizonfile = XmStringUnparse (s->value, NULL, XmCHARSET_TEXT, XmCHARSET_TEXT, NULL, 0, XmOUTPUT_ALL);
		strcpy(buf, editor);
		strcat(buf, " ");
		strcat(buf, horizonfile);
		if (system(buf) == -1)
		{
			sprintf(strMsgLine, "Error from %s\n", buf);
			setMessage( strMsgLine);		
		}
	}
	XtUnmanageChild(read_configfile);
} 
    
/* Callback function for selecting and reading the queue file  */
void readqueueCB(w,client_data,call_data)
	Widget w;
	int client_data;
	XmAnyCallbackStruct *call_data;
{
	char* tmpstr;
	XmFileSelectionBoxCallbackStruct *s = (XmFileSelectionBoxCallbackStruct *) call_data;

	/* Do nothing if cancel is selected. */
	if (client_data!=CANCEL)
	{
		/* Get the filename from the file selection box */
		tmpstr = XmStringUnparse (s->value, NULL, XmCHARSET_TEXT, XmCHARSET_TEXT, NULL, 0, XmOUTPUT_ALL);

		/* Read the queue into memory */
		sprintf(strMsgLine,"Reading %s\n", tmpstr);
		setMessage(strMsgLine);

		fp_file=fopen(tmpstr, "r");
		if ( !(fp_file == NULL) )
		{
			nqueue = read_edb_file(fp_file, queue, nqueue);
			if (!errflag)
			{
				reload_list(queue_area, queue, nqueue);
				sprintf(strMsgLine,"File %s loaded, %u items parsed\n", tmpstr, nqueue);
				setMessage(strMsgLine);
			}
			fclose(fp_file);
		}
		else
		{
			sprintf(strMsgLine,"Error loading file %s\n", tmpstr);
			setMessage(strMsgLine);
		}
		XtFree(tmpstr);
	}
	XtUnmanageChild(read_file);
}    

/* Callback function for saving the queue file  */
void savequeueCB(w,client_data,call_data)
	Widget w;
	int client_data;
	XmAnyCallbackStruct *call_data;
{
	char* tmpstr;

	if (client_data==OK)
	{
		//XmDIALOG_SELECTION
		XtVaGetValues(XmFileSelectionBoxGetChild(save_file, XmDIALOG_TEXT), XmNvalue, &tmpstr, NULL);
		if (tmpstr[strlen(tmpstr) - 1] != 47)
		{
			// Filename is specified
			// Save the queue from memory /
			sprintf(strMsgLine,"Saving %s\n", tmpstr);
			setMessage(strMsgLine);

			fp_file=fopen(tmpstr, "w");
			if ( !(fp_file == NULL) )
			{
				if (write_edb_file(fp_file, queue, nqueue))
				{
					sprintf(strMsgLine,"File %s saved, %u items\n", tmpstr, nqueue);
					setMessage(strMsgLine);
				}
				fclose(fp_file);
			}
			else
			{
				sprintf(strMsgLine,"Error saving file %s\n", tmpstr);
				setMessage(strMsgLine);
			}
			XtUnmanageChild(save_file);
		}
		else
		{
			infobox(toplevel, "Not a valid filename!\n", "Warning");
		}
		free(tmpstr);
	}
	else if (client_data==CANCEL)
	{
		XtUnmanageChild(save_file);
	}	
}    

void editqueueCB(w,client_data,call_data)
	Widget w;
	int client_data;
	XmAnyCallbackStruct *call_data;
{
	char* tmpstr;
	XmFileSelectionBoxCallbackStruct *s = (XmFileSelectionBoxCallbackStruct *) call_data;

	/* Do nothing if cancel is selected. */
	if (client_data!=CANCEL)
	{
		/* Get the filename from the file selection box */
		tmpstr = XmStringUnparse (s->value, NULL, XmCHARSET_TEXT, XmCHARSET_TEXT, NULL, 0, XmOUTPUT_ALL);

		sprintf(strMsgLine,"Selected %s\n", tmpstr);
		setMessage(strMsgLine);

		strcpy(buf, editor);
		strcat(buf, " ");
		strcat(buf, tmpstr);
		if (system(buf) == -1)
		{
			sprintf(strMsgLine, "Error from %s\n", buf);
			setMessage( strMsgLine);		
		}
		XtFree(tmpstr);
	}
	XtUnmanageChild(read_file);
}    

/* Callback function for selecting a queue entry */
void selectqueueCB(w,client_data,call_data)
    Widget w;
    XtPointer client_data;
    XtPointer call_data;
{
	XmListCallbackStruct *cbs = (XmListCallbackStruct *) call_data;

	/* If Double click on selected item */
	if (cbs->reason == XmCR_DEFAULT_ACTION)
	{
		/* Selection is indexed from 1 in XmList and from 0 in our list */
		queuechoice =  cbs->item_position - 1;    

		/* Diagnostic of the queue entry EOD coordinates                             */
		/*                                                                           */
		/*  printf(" #%u\n",queuechoice);                                            */
		/*  printf(" %s %s\n",queue[queuechoice].name,queue[queuechoice].desc);      */
		/*  printf(" ra: %lf  dec: %lf  mag: %lf\n\n",                               */
		/*    queue[queuechoice].ra,queue[queuechoice].dec,queue[queuechoice].mag);  */

		// Set Epoch to EOD
		if (display_targetepoch == J2000)
		{
			display_targetepoch = display_targetepoch + 1;
			display_targetepoch = display_targetepoch % 2;
		}

		strcpy(target[0].name, queue[queuechoice].name);
		strcpy(target[0].desc, queue[queuechoice].desc);
		target[0].ra = queue[queuechoice].ra;
		target[0].dec = queue[queuechoice].dec;
		target[0].j2kra = queue[queuechoice].j2kra;
		target[0].jpmra = queue[queuechoice].jpmra;
		target[0].j2kdec = queue[queuechoice].j2kdec;
		target[0].jpmdec = queue[queuechoice].jpmdec;
		target[0].mag = queue[queuechoice].mag;	
		target[0].abspos = queue[queuechoice].abspos;

		sprintf(strMsgLine, "Target recalled from queue %u\n", queuechoice);
		setMessage( strMsgLine);

		show_target_coordinates();
	}
}    

/* Callback function for selecting a history entry */
void selecthistoryCB(w,client_data,call_data)
    Widget w;
    XtPointer client_data;
    XtPointer call_data;
{
	XmListCallbackStruct *cbs = (XmListCallbackStruct *) call_data;

	/* If Double click on selected item */
	if (cbs->reason == XmCR_DEFAULT_ACTION)
	{
		/* Selection is indexed from 1 in XmList and from 0 in our list */
		historychoice =  cbs->item_position - 1;    

		/* Diagnostic of the queue entry EOD coordinates                             */
		/*                                                                           */
		/*  printf(" #%u\n",historychoice);                                            */
		/*  printf(" %s %s\n",queue[historychoice].name,queue[historychoice].desc);      */
		/*  printf(" ra: %lf  dec: %lf  mag: %lf\n\n",                               */
		/*    queue[historychoice].ra,queue[historychoice].dec,queue[historychoice].mag);  */

		// Set Epoch to EOD
		if (display_targetepoch == J2000)
		{
			display_targetepoch = display_targetepoch + 1;
			display_targetepoch = display_targetepoch % 2;
		}

		strcpy(target[0].name, history[historychoice].name);
		strcpy(target[0].desc, history[historychoice].desc);
		target[0].ra = history[historychoice].ra;
		target[0].dec = history[historychoice].dec;
		target[0].j2kra = history[historychoice].j2kra;
		target[0].jpmra = history[historychoice].jpmra;
		target[0].j2kdec = history[historychoice].j2kdec;
		target[0].jpmdec = history[historychoice].jpmdec;
		target[0].mag = history[historychoice].mag;	
		target[0].abspos = history[historychoice].abspos;	

		sprintf(strMsgLine, "Target recalled from history %u\n", historychoice);
		setMessage( strMsgLine);

		show_target_coordinates();
	}
}    

#ifdef ISFOCUS
	/* Callback function for control of telescope focus  */
	void focusCB(w,client_data,call_event)
		Widget w;
		int client_data;
		XEvent *call_event;
	{
		int n,dn,up;
		int et = call_event->type;
		int focuscmd;
			 
		/* Identify the command */
		n=client_data;

		/* Identify the focus action */
		dn = et == ButtonPress;
		up = et == ButtonRelease;     

		/* Check for button release on ok to return */
		if (up & (n == FOCUSOK))
		{
			XtUnmanageChild(focus_control);
			return;   
		}

		/* Handle the other buttons */
		if(dn)
		{
			switch (n) 
			{

				/* Focus in */
				case FOCUSIN: 
				focuscmd = FOCUSCMDIN;
				Focus(focuscmd,focusspd);
				break;

				/* Focus out  */
				case FOCUSOUT:
				focuscmd = FOCUSCMDOUT;
				Focus(focuscmd,focusspd);
				break;
			}
		}

		if(up)
		{
			focuscmd = FOCUSCMDOFF;
			Focus(focuscmd,focusspd);

			/* Wait for the focuser to come to rest */
			usleep(25000.);
			 
			/* Update the console message */

			/* Display current focus */
			show_focus();
		}
	}

	/* Callback function for the focus speed toggle buttons */
	void focus_speedCB(w,client_data,call_data)
		Widget w;
		int client_data;
		XmAnyCallbackStruct *call_data;
	{
		int n;

		/* Identify the button code*/
		n=client_data;
		 
		/* Assign a focus speed code */
		switch (n) 
		{
			/* Fast */
			case 0: 
				focusspd=FOCUSSPD4;
				setMessage("Focus speed set to fast\n");
				break; 
			   
			/* Medium */
			case 1: 
				focusspd=FOCUSSPD3;
				setMessage("Focus speed set to medium\n");
				break;
		
			/* Slow */
			case 2: 
				focusspd=FOCUSSPD2;
				setMessage("Focus speed set to slow\n");
				break; 
			 
			/* Precise */
			case 3: 
				focusspd=FOCUSSPD1;
				setMessage("Focus speed set to precise\n");
				break;  
		} 
	}
#endif

#ifdef ISFAN
	/* Callback function for control of telescope fan */
	void fanCB(w,client_data,call_event)
		Widget w;
		int client_data;
		XEvent *call_event;
	{
		int n,up;
		//int dn;
		int et = call_event->type;
			 
		/* Identify the command */
		n=client_data;

		/* Identify the fan action */
		//dn = et == ButtonPress;
		up = et == ButtonRelease;     

		/* Check for button release on ok to return */
		if (up & (n == FANOK))
		{
			XtUnmanageChild(fan_control);
			return;   
		}    
	}

	/* Callback function for the fan speed toggle buttons */
	void fan_speedCB(w,client_data,call_data)
		Widget w;
		int client_data;
		XmAnyCallbackStruct *call_data;
	{
		int n;

		/* Identify the button code*/
		n=client_data;
		 
		/* Assign a fan speed code */
		switch (n) 
		{
			/* High */
			case 0: 
				fancmd = FANCMDHIGH;
				setMessage("Fan speed set to high\n");
				Fan(fancmd);
				break; 
			   
			/* Low */
			case 1: 
				fancmd = FANCMDLOW;
				setMessage("Fan speed set to low\n");
				Fan(fancmd);
				break;
			  
			/* Off */
			case 2: 
				fancmd = FANCMDOFF;
				setMessage("Fan speed off\n");
				Fan(fancmd);
				break;            
		} 
	}
#endif

#ifdef ISHEATER
	/* Callback function for control of telescope heater */
	void heaterCB(w,client_data,call_event)
		Widget w;
		int client_data;
		XEvent *call_event;
	{
		int n,up;
		//int dn;
		int et = call_event->type;
			 
		/* Identify the command */ 
		n=client_data;

		/* Identify the heater action */  
		//dn = et == ButtonPress;
		up = et == ButtonRelease;     

		/* Check for button release on ok to return */
		if (up & (n == HEATEROK))
		{
			XtUnmanageChild(heater_control);
			return;   
		}    
	}

	/* Callback function for the heater speed toggle buttons */
	void heater_powerCB(w,client_data,call_data)
		Widget w;
		int client_data;
		XmAnyCallbackStruct *call_data;
	{
		int n;

		/* Identify the button code*/

		n=client_data;
		 
		/* Assign a heater speed code */

		switch (n) 
		{
			/* High */
			case 0: 
				heatercmd = HEATERCMDHIGH;
				setMessage("Heater power set to high\n");
				Heater(heatercmd);
				break; 
			   
			/* Low */
			case 1: 
				heatercmd = HEATERCMDLOW;
				setMessage("Heater power set to low\n");
				Heater(heatercmd);
				break;
			  
			/* Off */
			case 2: 
				heatercmd = HEATERCMDOFF;
				setMessage("Heater off\n");
				Heater(heatercmd);
				break;            
		} 
	}
#endif

/* Update message area of user interface */
void update_message()
{
	Arg al[15];
	int ac;
	char strProtocolMessage[4096];
	
	getMessage(strProtocolMessage);
    if (strlen(strProtocolMessage)) 
	{
		XmTextInsert(message_area, XmTextGetLastPosition(message_area),strProtocolMessage);
	}
	ac=0;
	XtSetArg(al[ac],XmNvalue, 0); ac++;
	XtSetValues(message_area, al, ac);
} 


/* Show telescope coordinates for telepoch in the button */
void show_telescope_coordinates()
{
	double tmpra, tmpdec, tmpha, tmpaz, tmpalt;
	XmString xmstr;
	Arg al[10];
	int ac;

	switch (display_telepoch)
	{	  
		case J2000:
			/* Display Epoch 2000.0 coordinates */      
			xmstr = XmStringCreateLocalized("Epoch: J2k");
			ac=0; 
			XtSetArg(al[ac],XmNlabelString,xmstr); ac++; 
			XtSetValues(command[CMD_TELEPCH],al,ac);
			tmpra=telpos[0].ra;
			tmpdec=telpos[0].dec;         
			Apparent(&tmpra,&tmpdec,-1);
			break;

		case  EOD:
			/* Display EOD coordinates */      
			xmstr = XmStringCreateLocalized("Epoch: Now");
			ac=0; 
			XtSetArg(al[ac],XmNlabelString,xmstr); ac++; 
			XtSetValues(command[CMD_TELEPCH],al,ac);
			tmpra=telpos[0].ra;
			tmpdec=telpos[0].dec; 
			break;
	}   

	tmpha = Map12(LSTNow(mnt.SiteLongitude) - tmpra);

	if (showradec)
	{
		strcpy(foo, "Ra :");
		dtodms(buf, &tmpra);
		strcat(foo, buf);
		xmstr = XmStringCreateLocalized(foo);
		ac=0;
		XtSetArg(al[ac],XmNlabelString,xmstr); ac++;
		XtSetValues(command[CMD_TELRA],al,ac);

		strcpy(foo, "Dec:");
		dtodms(buf, &tmpdec);
		strcat(foo, buf);
		xmstr = XmStringCreateLocalized(foo);
		ac=0;
		XtSetArg(al[ac],XmNlabelString,xmstr); ac++;
		XtSetValues(command[CMD_TELDEC],al,ac);    
	}
	else
	{
		/* Convert HA and Dec to Alt and Az */
		EquatorialToHorizontal(mnt.SiteLatitude, tmpha, tmpdec, &tmpaz, &tmpalt);
		strcpy(foo, "Az :");
		dtodms(buf, &tmpaz);
		if (buf[3] == ':')
		{
			buf[0] = '0';
			buf[9] = '\0';
		}
		else if (buf[4] == ':')
		{
			memmove(buf, buf+1, 9); 
			buf[1] = '0';
			buf[9] = '\0';
		}
		strcat(foo, buf);
		xmstr = XmStringCreateLocalized(foo);
		ac=0;
		XtSetArg(al[ac],XmNlabelString,xmstr); ac++;
		XtSetValues(command[CMD_TELRA],al,ac);

		strcpy(foo, "Alt:");
		dtodms(buf, &tmpalt);
		strcat(foo, buf);
		xmstr = XmStringCreateLocalized(foo);
		ac=0;
		XtSetArg(al[ac],XmNlabelString,xmstr); ac++;
		XtSetValues(command[CMD_TELDEC],al,ac);    
	}
	XmStringFree(xmstr);  
}  
  
/* Show target coordinates for targetepoch in the button */
void show_target_coordinates()
{
	double tmpra, tmpdec;
	XmString xmstr;
	Arg al[10];
	int ac;

	switch (display_targetepoch)
	{
	case J2000:
		/* Display Epoch 2000.0 coordinates.                                */
		/* If XEphem transfered proper motion, then the target coordinates  */
		/*   stored in XmTel include proper motion to the current date.     */
		/*   Coordinates including proper motion and precessed to 2000.0    */
		/*   will differ from an epoch 2000.0 catalog entry that            */
		/*   does not include proper motion to the current date.            */

		ac=0;      
		xmstr = XmStringCreateLocalized("Epoch: J2k");
		XtSetArg(al[ac],XmNlabelString,xmstr); ac++; 
		XtSetValues(command[CMD_TGTEPCH],al,ac);
		tmpra=target[0].ra;
		tmpdec=target[0].dec;        
		Apparent(&tmpra,&tmpdec,-1);
		break;

	case  EOD:
		/* Display EOD coordinates as saved in target[0].ra and target[0].dec. */
		xmstr = XmStringCreateLocalized("Epoch: Now");
		ac=0; 
		XtSetArg(al[ac],XmNlabelString,xmstr); ac++; 
		XtSetValues(command[CMD_TGTEPCH],al,ac);
		tmpra=target[0].ra;
		tmpdec=target[0].dec;          
		break;
	}      

	strcpy(foo, "Ra :");
	dtodms(buf, &tmpra);
	strcat(foo, buf);
	xmstr = XmStringCreateLocalized(foo);
	ac=0;
	XtSetArg(al[ac],XmNlabelString,xmstr); ac++;
	XtSetValues(command[CMD_GETRA],al,ac);   

	strcpy(foo, "Dec:");
	dtodms(buf, &tmpdec);
	strcat(foo, buf);
	xmstr = XmStringCreateLocalized(foo);
	ac=0;
	XtSetArg(al[ac],XmNlabelString,xmstr); ac++; 
	XtSetValues(command[CMD_GETDEC],al,ac);       

	XmStringFree(xmstr);
}  

void poll_interval_handler(XtPointer client_data_ptr, XtIntervalId *client_id) 
{    
	static time_t t0 = 0;
	time_t curtime = time((time_t *)NULL);
	int waslink = 0;
	
	//Confirm telescope is connected
	mnt.tellink=CheckConnectTel();
	
	if (mnt.tellink)
	{
		waslink = 1;
		//fprintf(stderr, "Timer\n");
		if (t0 == 0)
		{
			t0 = curtime;
		}
	
		#ifdef ISFOCUS
			/* Manage user inferface updates */ 
			if ( !focusdisabled )
			{
				show_temperature();
			}
		#endif
						
		if ( gotoflag == TRUE )
		{
			check_slew_status();
		}  
		#ifdef ISLEVEL
			else if ( levelflag == TRUE )
			{
				check_level_status();
			}
		#endif
		else if (slewflag == TRUE)
		{
			fetch_telescope_coordinates();
			if (!errflag)
			{
				if (mnt.align)
				{
					if (ChkTarget(&mnt, telpos[0].ra, telpos[0].dec, pmodel))
					{
						if (!ChkRaAxAngle(&mnt, telpos[0].ra, telpos[0].dec, pmodel))
						{
							FullStop(&mnt);
							fetch_telescope_coordinates();
						}
					}
					else
					{
						FullStop(&mnt);
						fetch_telescope_coordinates();
					}
				}
				show_telescope_coordinates(); 
				mark_fifo_telescope();
			}
		}
		else
		{
			if (mnt.align)
			{
				XtVaSetValues(lblisalign, XmNlabelString, XmStringCreateLocalized("Mount\nAligned"),NULL);
				if (curtime - t0 >= 30)
				{
					t0 = curtime;
					fetch_telescope_coordinates();
					if (!errflag)
					{
						save_coordinates(0);
						if (mnt.trkActive)
						{
							if (ChkTarget(&mnt, telpos[0].ra, telpos[0].dec, pmodel))
							{
								if (!ChkRaAxAngle(&mnt, telpos[0].ra, telpos[0].dec, pmodel))
								{
									StopTrack(&mnt);
								}
							}
							else
							{
								StopTrack(&mnt);								
							}
						}
						show_telescope_coordinates(); 
						mark_fifo_telescope();
					}
				}
			}
			else
			{
				XtVaSetValues(lblisalign, XmNlabelString, XmStringCreateLocalized("Mount\nNot\nAligned"),NULL);
			}
		}
	}
	else if (waslink)
	{
		waslink = 0;
		apply_config();
		if (mnt.trkActive)
		{
			setMessage("Warning: last tracking status was reported as ACTIVE\n");
		}
	}
	
	/* writes messages from the protocol and the gui to the message area */
	update_message();

	/* Start the timer again.  It will return to the handler after poll_interval. */
	poll_interval_id = XtAppAddTimeOut(context, poll_interval, poll_interval_handler, poll_interval_data_ptr);
}  

void hide_popup_handler(XtPointer client_data_ptr, XtIntervalId *client_id) 
{    
	XtUnmanageChild(dlgskyalign);
}  

/* Slew telescope to target coordinates, display coords, update message */
void slew_telescope()
{
	if (mnt.tellink) 
	{
		gotoflag = GoToCoords(&mnt, target[0].ra, target[0].dec, pmodel, target[0].abspos);
		if ( gotoflag == FALSE )
		{
			setMessage("Slew request is not permitted\n");
			if (mnt.trkStatus != mnt.trkActive)
			{
				SetTrack(&mnt);
			}  
		}
		else
		{
			setMessage("Slew to target in progress\n");
			/* Pause here to allow telescope CPU to process slew request */  
			usleep(500000.);
		}
	}
	else
	{
		setMessage("Telescope is not connected\n");
	}
	return;
}

void check_slew_status()
{
	static int attempt = 0;
	int testval = CheckGoTo(&mnt, target[0].ra, target[0].dec, pmodel, target[0].abspos);

	if (mnt.tellink) 
	{
		if ( testval < 1 )
		{
			gotoflag = TRUE;
		}
		else if ( testval == 1 )
		{ 
			gotoflag = FALSE;
			setMessage("Target acquired\n");
			if (mnt.trkStatus != mnt.trkActive)
			{
				SetTrack(&mnt);
			}
			// When the target is successfully acquired 
			// Save the position to file at glance, just in case
			if (mnt.align)
			{
				if (!save_coordinates(1))
				{
					setMessage("Warning: save position failed!\n");
				}
			}
		}
		else if (! target[0].abspos )
		{
			gotoflag = FALSE; 
			setMessage("Target outside tolerance\n");  
			if (mnt.trkStatus != mnt.trkActive)
			{
				SetTrack(&mnt);
			}
			if (attempt < 2)
			{
				usleep(1000000.);
				/*refining search */
				if (mnt.basis < 0)
				{
					testval = StartSlew(&mnt, WEST);
				}
				else
				{
					testval = StartSlew(&mnt, EAST);
				}
				usleep(2500000.);
				if (testval) 
				{
					testval = StopSlew(&mnt, EAST);
					usleep(1000000.);
					if (mnt.SiteLatitude < 0)
					{
						testval = StartSlew(&mnt, SOUTH);
					}
					else
					{
						testval = StartSlew(&mnt, NORTH);
					}
					usleep(2500000.);
					if (testval) 
					{
						testval = StopSlew(&mnt, NORTH);
						usleep(1000000.);
						if (GoToCoords(&mnt, target[0].ra, target[0].dec, pmodel, target[0].abspos))
						{
							attempt++;
							gotoflag = TRUE;
							setMessage("Slew refine\n"); 
						}
					}
				}
			}
			else
			{
				// Reset at giveup
				attempt = 0;
			}
		}   
		// Update telescope coordinates at every check
		fetch_telescope_coordinates(); 
		if (!errflag)
		{ 
			show_telescope_coordinates(); 
			mark_fifo_telescope();
		}
	}
	else
	{
		setMessage("Telescope is not connected\n");
	}
	return;
}         

#ifdef ISLEVEL
	/* Slew telescope to target coordinates, display coords, update message */
	void level_telescope()
	{
		if (mnt.tellink) 
		{
			if (mnt.modfeat[FLLEVEL])

			{
				levelflag = LevelScope(&mnt, 1, 0);
			}
			else
			{
				levelflag = LevelScope(&mnt, 1, 1);
			}
			if ( levelflag == FALSE )
			{
				errflag = TRUE;
			}
			else
			{
				mnt.align = 0;
				/* Pause here to allow telescope CPU to process level request */  
				usleep(200000.);
			}
		}
		else
		{
			setMessage("Telescope is not connected\n");
		}
		return;
	}

	void check_level_status()
	{
		//int testval;

		if (mnt.tellink) 
		{
			if (mnt.modfeat[FLLEVEL])
			{
				//	testval = CheckLevel(1, 0);
				//}
				//else
				//{
				//	testval = CheckLevel(1, 1);
				//}

				//if ( testval < 1 )
				//{
				//	levelflag = TRUE;
				//}
				//else 
				if (CheckLevel(1, 1))
				{ 
					levelflag = FALSE;
					if (msgbox(toplevel, "Confirm telescope is at home position", MSGOKCANCEL, "Home position")) 
					{
						//Home telescope
						if (SetHomeNowTel(&mnt))
						{
							setMessage("Encoder position reset on home position\n");
						}
					} 
				}
				else
				{
					levelflag = TRUE;
				}
			}
		}
		else
		{
			setMessage("Telescope is not connected\n");
		}
		return;
	}         
#endif

/* Init polar aling aid process */

void test_align()
{
	double   polaraz = 0., polaralt = 0., dltra = 0., dltdec = 0., dmatrix = 0., latrad = 0.;
	double   ref1ha =0., ref2ha = 0., ref1dec = 0., ref2dec = 0.;
	mount    tstmnt;

	tstmnt.homefixed = 0;
	tstmnt.parkfixed = 0;
	tstmnt.polarfixed = 0;
	tstmnt.teltype = GEM;
	tstmnt.telmode = GEM;
	
	tstmnt.homedec = -89.9999;
	tstmnt.homeha = 6.;
	tstmnt.basis = 1;
	tstmnt.parkha = tstmnt.homeha;
	tstmnt.parkdec = tstmnt.homedec;

	tstmnt.align = 0;
	tstmnt.polaraz = 0;
	tstmnt.polaraz = 0;
	tstmnt.offsetra = 0;
	tstmnt.offsetdec = 0;

	tstmnt.SiteLatitude = 42.666666667;
	tstmnt.SiteLongitude = 12.6667;

	dltra = -0.2*PI/180.;
	dltdec = -0.35*PI/180.;
	
	ref1ha = 3.*15.*PI/180.;
	ref2ha = 23.*15.*PI/180.;
	ref1dec = 48.*PI/180.;
	ref2dec = 45.*PI/180.;
	
	latrad = tstmnt.SiteLatitude*PI/180.;
	
	fprintf(stderr,"ref1ha  : %f rad, %f deg\n", ref1ha, ref1ha*12./PI);
	fprintf(stderr,"ref1dec : %f rad, %f deg\n", ref1dec, ref1dec*180./PI);
	fprintf(stderr,"ref2ha  : %f rad, %f deg\n", ref2ha, ref2ha*12./PI);
	fprintf(stderr,"ref2dec : %f rad, %f deg\n", ref2dec, ref2dec*180./PI);
	fprintf(stderr,"ErrRA   : %f rad\n", dltra);
	fprintf(stderr,"ErrDEC  : %f rad\n", dltdec);
	fprintf(stderr,"LatRad  : %f rad\n", latrad);

	dmatrix = cos(latrad) * (tan(ref1dec) + tan(ref2dec)) * (1. - cos(ref1ha - ref2ha));
	fprintf(stderr,"Dmatrix : %f\n", dmatrix);
	
	polaralt = 180. * ((dltra*cos(latrad)*(sin(ref2ha) - sin(ref1ha))/dmatrix) + (dltdec*-1.*cos(latrad)*(tan(ref1dec)*cos(ref1ha) - tan(ref2dec)*cos(ref2dec))/dmatrix))/PI;
	polaraz  = 180. * (dltra*(cos(ref1ha) - cos(ref2ha))/dmatrix + dltdec*(tan(ref2dec)*sin(ref2ha) - tan(ref1dec)*sin(ref1ha))/dmatrix)/PI;
		
	fprintf(stderr,"PolarAlt: %f deg\n", polaralt);
	fprintf(stderr,"PolarAz : %f deg\n", polaraz);
}

void align_telescope(int step)
{
	int answer = 0;
	double tmpra, tmpdec, polaraz = 0., polaralt = 0., dltra = 0., dltdec = 0., dmatrix = 0., latrad = 0.;
	double ref1ha =0., ref2ha = 0., ref1dec = 0., ref2dec = 0., telposra = 0., telposdec = 0.;
	double tgtra = Map24(LSTNow(mnt.SiteLongitude)), tgtdec = 0.;
	char tgtsra[64], tgtsdec[64];
	XmString text;
	char tgtmsg[512];
	static catalog reference1 = {.name = "", .desc = "f", .ra = 0, .dec = 0, .mag = 0, .j2kra = 0, .jpmra = 0, .j2kdec = 0, .jpmdec = 0, .abspos = 0}; 
	static catalog reference2 = {.name = "", .desc = "f", .ra = 0, .dec = 0, .mag = 0, .j2kra = 0, .jpmra = 0, .j2kdec = 0, .jpmdec = 0, .abspos = 0}; 
	
	if (mnt.tellink) 
	{
		// setup the dialog
		XtRemoveAllCallbacks (dlgskyalign, XmNokCallback);
		XtRemoveAllCallbacks (dlgskyalign, XmNcancelCallback);
		XtAddCallback (dlgskyalign, XmNokCallback, alignCB, (XtPointer) OK);
		XtAddCallback (dlgskyalign, XmNcancelCallback, alignCB, (XtPointer) CANCEL);					
		
		// For target hint
		if (mnt.SiteLatitude < 0)
		{
			tgtdec = (90 + mnt.SiteLatitude) / 2;
		}
		else
		{
			tgtdec = (mnt.SiteLatitude - 90) / 2;
		}		
		dtodms(tgtsra, &tgtra);
		dtodms(tgtsdec, &tgtdec);
		
		if (step == 1)
		{			
			if (mnt.align > 0) 
			{
				// We assume count from encoders it's not too far from where it should be
				// So we trust the "home position" originally set in previous sky align
				answer = msgbox(toplevel, "Telescope is aligned already\nThis will reset the sky model\nProceed?", MSGYESNO, "Align!");
			}
			else
			{
				// To be sure not to "hit" hardware switches, we need to confirm home position
				if (mnt.SiteLatitude > 0)
				{
					answer = msgbox(toplevel, "Confirm telescope is pointing North", MSGOKCANCEL, "Home position");
				}
				else
				{
					answer = msgbox(toplevel, "Confirm telescope is pointing South", MSGOKCANCEL, "Home position");
				}
				if (SetHomeNowTel(&mnt))
				{
					setMessage("Encoder position reset on home position\n");
				}
				else
				{
					answer = 0;
				}
			}	
			if (answer) 
			{  
				mnt.align = 0;
				mnt.polaraz = 0;
				mnt.polaraz = 0;
				mnt.offsetra = 0;
				mnt.offsetdec = 0;
				pmodel = RAW;
				answer = 0;
				infobox(toplevel, "For this procedure to give good results you should avoid:\n - Stars with similar HA (RA), have them more than 90 deg apart\n - Stars near to the celestial equator (Prefer 30 < Dec < 60)\n - Stars whose declination are close to negative each other.", "Caution!");
				// Set for tracking and start
				if (StartTrack(&mnt))
				{
					SetTrackStatus(&mnt, 1);
					text = XmStringCreateLocalized ("Slew telescope to first known visible target\nWait for telescope to acquire target\nCenter object in the FOV\nPress ok when done\n");
					XtVaSetValues (dlgskyalign, XmNmessageString, text, NULL);	
					XmStringFree (text);
					mnt.align = -2;
					XtManageChild(dlgskyalign);
				}
			}
		}
		else if (step == 2)
		{			
			sync_telescope_to_target();
			if (!errflag)
			{
				// Get the reference1 locally
				strcpy(reference1.name, target[0].name);
				strcpy(reference1.desc, target[0].desc);
				reference1.ra = target[0].ra;
				reference1.dec = target[0].dec;
				reference1.mag = target[0].mag;
				reference1.j2kra = target[0].j2kra;
				reference1.jpmra = target[0].jpmra;
				reference1.j2kdec = target[0].j2kdec;
				reference1.jpmdec = target[0].jpmdec;
				reference1.abspos = target[0].abspos; 

				fprintf(stderr,"ref1ra  : %f h\n", reference1.ra);
				fprintf(stderr,"ref1dec : %f deg\n", reference1.dec);

				text = XmStringCreateLocalized ("Slew telescope to second known visible target\nWait for telescope to acquire target\nCenter object in the FOV\nPress ok when done\n");
				XtVaSetValues (dlgskyalign, XmNmessageString, text, NULL);	
				XmStringFree (text);
				mnt.align = -3;
				XtManageChild(dlgskyalign);
			}
		}
		else if (step == 3)
		{			
			// Get the reference2 locally
			strcpy(reference2.name, target[0].name);
			strcpy(reference2.desc, target[0].desc);
			reference2.ra = target[0].ra;
			reference2.dec = target[0].dec;
			reference2.mag = target[0].mag;
			reference2.j2kra = target[0].j2kra;
			reference2.jpmra = target[0].jpmra;
			reference2.j2kdec = target[0].j2kdec;
			reference2.jpmdec = target[0].jpmdec;
			reference2.abspos = target[0].abspos; 
			
			fprintf(stderr,"ref2ra  : %f h\n", reference2.ra);
			fprintf(stderr,"ref2dec : %f deg\n", reference2.dec);

			// Calculations
			if (GetTel(&mnt, &telposra, &telposdec, RAW))
			{
				dltra   = ((telposra - reference2.ra)*15.*PI/180.);
				dltdec  = ((telposdec - reference2.dec)*PI/180.);
				ref1ha  = (reference1.ra - LSTNow(mnt.SiteLongitude))*15.*PI/180.;
				ref1dec = (reference1.dec *PI/180.);
				ref2ha  = (reference2.ra - LSTNow(mnt.SiteLongitude))*15.*PI/180.;
				ref2dec = (reference2.dec *PI/180.);
				latrad  = (mnt.SiteLatitude*PI/180.);
			
				dmatrix = cos(latrad) * (tan(ref1dec) + tan(ref2dec)) * (1. - cos(ref1ha - ref2ha));

				fprintf(stderr,"ref1ha  : %f rad\n", ref1ha);
				fprintf(stderr,"ref1ra  : %f h\n", Map24(LSTNow(mnt.SiteLongitude) - ref1ha*12./PI));
				fprintf(stderr,"ref1dec : %f rad, %f deg\n", ref1dec, ref1dec*180./PI);
				fprintf(stderr,"ref2ha  : %f rad, %f deg\n", ref2ha, ref2ha*12./PI);
				fprintf(stderr,"ref2ra  : %f h\n", Map24(LSTNow(mnt.SiteLongitude) - ref2ha*12./PI));
				fprintf(stderr,"ref2dec : %f rad, %f deg\n", ref2dec, ref2dec*180./PI);
				fprintf(stderr,"ErrRA   : %f rad\n", dltra);
				fprintf(stderr,"ErrDEC  : %f rad\n", dltdec);
				fprintf(stderr,"LatRad  : %f rad\n", latrad);
				fprintf(stderr,"Dmatrix : %f\n", dmatrix);
			
				if (fabs(dmatrix) < 0.01)
				{
					infobox(toplevel, "Determining pole align error was unsuccessful,\nfor this procedure to give good results you should avoid:\n - Stars with similar HA (RA), have them more than 90 deg apart\n - Stars near to the celestial equator (Prefer 30 < Dec < 60)\n - Stars whose declination are close to negative each other.", "Caution!");
					align_telescope(-1);
				}
				else
				{
					// We got a good star pair
					polaralt = 180. * ((dltra*cos(latrad)*(sin(ref2ha) - sin(ref1ha))/dmatrix) + (dltdec*-1.*cos(latrad)*(tan(ref1dec)*cos(ref1ha) - tan(ref2dec)*cos(ref2dec))/dmatrix))/PI;
					polaraz  = 180. * (dltra*(cos(ref1ha) - cos(ref2ha))/dmatrix + dltdec*(tan(ref2dec)*sin(ref2ha) - tan(ref1dec)*sin(ref1ha))/dmatrix)/PI;

					fprintf(stderr,"Polaraz : %f deg\n", polaraz);
					fprintf(stderr,"Polaralt: %f deg\n", polaralt);

					// Set temporary polar correction to get the goto to where the third target will be when sky model and true sky coordinates are the same
					mnt.polaraz  = polaraz;
					mnt.polaralt = polaralt;
					pmodel = POLAR;
					
					sprintf(tgtmsg, "Polar Az: %f'\nPolar Alt: %f'\nSlew telescope to third known visible target\nChoose it such that is near meridian (RA: %s) and Dec near %s\nWait for telescope to acquire correction position\nUse Alt/Az knobs to aim the telescope to the target\nPress ok when done\n", (polaraz * 60.), (polaralt * 60.), tgtsra, tgtsdec);

					text = XmStringCreateLocalized (tgtmsg);
					XtVaSetValues (dlgskyalign, XmNmessageString, text, NULL);	
					XmStringFree (text);
					mnt.align = -4;
					XtManageChild(dlgskyalign);
				}
			}
			else
			{
				infobox(toplevel, "Cannot read telescope position\nProcess aborted!", "Error");
				align_telescope(-1);
			}
		}
		else if (step == 4)
		{
			// get from telescope only for debugging purpouse
			GetTel(&mnt, &tmpra, &tmpdec, RAW);
			fprintf(stderr,"ref3ra  : %f h\n", target[0].ra);
			fprintf(stderr,"ref3dec : %f deg\n", target[0].dec);
			fprintf(stderr,"Pnt3ra  : %f h\n", tmpra);
			fprintf(stderr,"Pnt3dec : %f deg\n", tmpdec);

			// We reset the polar correction 
			mnt.polaraz = 0;
			mnt.polaraz = 0;
			mnt.offsetra = 0;
			mnt.offsetdec = 0;
			pmodel = RAW;

			// Sync the encoders on the target original coordinates
			sync_telescope_to_target();
			if (!errflag)
			{
				// Should be also sky aligned, doesn't it?
				mnt.align = 1;
			}	
			
			//Popup needs to be destroyed by a timer (destroy event not connected to the CB function)
			hide_popup_id = XtAppAddTimeOut(context, 100, hide_popup_handler, hide_popup_data_ptr);
		}
		else if (step == -1)
		{
			//Popup needs to be destroyed by a timer (destroy event not connected to the CB function)
			hide_popup_id = XtAppAddTimeOut(context, 100, hide_popup_handler, hide_popup_data_ptr);

			mnt.align = 0;
			mnt.polaraz = 0;
			mnt.polaraz = 0;
			mnt.offsetra = 0;
			mnt.offsetdec = 0;
			pmodel = RAW;
			if (FullStop(&mnt))
			{
				if(mnt.trkStatus != mnt.trkActive)
				{
					StartTrack(&mnt);
				}
				infobox(toplevel, "Pole align terminated!", "Pole align");
			}
		}
		
	}
	return;
}

void alignCB(Widget w, XtPointer client_data, XtPointer call_data)
{
    XmAnyCallbackStruct *cbs = (XmAnyCallbackStruct *) call_data;

    switch (cbs->reason) 
    {
        case XmCR_OK: 
         	align_telescope(abs(mnt.align));
        	break;
        
        case XmCR_CANCEL:
        	align_telescope(-1);
        	break;
        
    }
	return;
}

/* Init polar aling aid process */
void align_telescope_polaris(int step)
{
	int answer = 0;
	XmString text;
	double tmpra, tmpdec;
	// *datap = h + m/60. + s/3600.;
	//Polaris,,2:31:49.1,89:15:51,2.00,2000,0
	static catalog polaris = {.name = "Polaris", .desc = "f", .ra = 0, .dec = 0, .mag = 2.0, .j2kra = 2.530305556, .jpmra = 0, .j2kdec = 89.264166667, .jpmdec = 0, .abspos = 0}; 
	//Sigma Oct,,21:8:46.8,-88:57:23,5.45,2000,0
	static catalog sigott = {.name = "Sigma ottantis", .desc = "f", .ra = 0, .dec = 0, .mag = 5.45, .j2kra = 21.146333333, .jpmra = 0, .j2kdec = 88.956388889, .jpmdec = 0, .abspos = 0}; 
	static catalog reference = {.name = "", .desc = "f", .ra = 0, .dec = 0, .mag = 0, .j2kra = 0, .jpmra = 0, .j2kdec = 0, .jpmdec = 0, .abspos = 0}; 

	if (mnt.tellink) 
	{
		if (step == 1)
		{			
			// Current EOD coordinates for notable objects
			tmpra = polaris.j2kra;
			tmpdec = polaris.j2kdec;
			Apparent(&tmpra, &tmpdec, 1);
			polaris.ra = tmpra;
			polaris.dec = tmpdec;
			// Current EOD coordinates for notable objects
			tmpra = sigott.j2kra;
			tmpdec = sigott.j2kdec;
			Apparent(&tmpra, &tmpdec, 1);
			sigott.ra = tmpra;
			sigott.dec = tmpdec;

			// setup the dialog
			XtRemoveAllCallbacks (dlgskyalign, XmNokCallback);
			XtRemoveAllCallbacks (dlgskyalign, XmNcancelCallback);
			XtAddCallback (dlgskyalign, XmNokCallback, align_polarisCB, (XtPointer) OK);
			XtAddCallback (dlgskyalign, XmNcancelCallback, align_polarisCB, (XtPointer) CANCEL);					
			
			if (mnt.align > 0) 
			{
				// We assume count from encoders it's not too far from where it should be
				// So we trust the "home position" originally set in previous sky align
				answer = msgbox(toplevel, "Telescope is aligned already\nThis will reset the sky model\nPlease sky align again after this\nProceed?", MSGYESNO, "Align!");
			}
			else
			{
				// To be sure not to "hit" hardware switches, we need to confirm home position
				if (mnt.SiteLatitude > 0)
				{
					answer = msgbox(toplevel, "Confirm telescope is pointing North", MSGOKCANCEL, "Home position");
				}
				else
				{
					answer = msgbox(toplevel, "Confirm telescope is pointing South", MSGOKCANCEL, "Home position");
				}
				if (SetHomeNowTel(&mnt))
				{
					setMessage("Encoder position reset on home position\n");
				}
				else
				{
					answer = 0;
				}
			}	
			if (answer) 
			{  
				mnt.align = 0;
				mnt.polaraz = 0;
				mnt.polaraz = 0;
				mnt.offsetra = 0;
				mnt.offsetdec = 0;
				pmodel = RAW;
				answer = 0;
				// Set for tracking and start
				if (StartTrack(&mnt))
				{
					SetTrackStatus(&mnt, 1);
					text = XmStringCreateLocalized ("Slew telescope to a known visible target\nWait for telescope to acquire target\nCenter object in the FOV\nPress ok when done\n");
					XtVaSetValues (dlgskyalign, XmNmessageString, text, NULL);	
					XmStringFree (text);
					mnt.align = -2;
					XtManageChild(dlgskyalign);
				}
			}
		}
		else if (step == 2)
		{			
			sync_telescope_to_target();
			if (!errflag)
			{
				if (strlen(reference.name) == 0)
				{
					// Get the reference locally
					strcpy(reference.name, target[0].name);
					strcpy(reference.desc, target[0].desc);
					reference.ra = target[0].ra;
					reference.dec = target[0].dec;
					reference.mag = target[0].mag;
					reference.j2kra = target[0].j2kra;
					reference.jpmra = target[0].jpmra;
					reference.j2kdec = target[0].j2kdec;
					reference.jpmdec = target[0].jpmdec;
					reference.abspos = target[0].abspos; 
				}

				if (mnt.SiteLatitude > 0)
				{
					// Set up new target
					strcpy(target[0].name, polaris.name);
					strcpy(target[0].desc, polaris.desc);
					target[0].ra = polaris.ra;
					target[0].dec = polaris.dec;
					target[0].mag = polaris.mag;
					target[0].j2kra = polaris.j2kra;
					target[0].jpmra = polaris.jpmra;
					target[0].j2kdec = polaris.j2kdec;
					target[0].jpmdec = polaris.jpmdec;
					target[0].abspos = polaris.abspos; 				
				}
				else
				{
					// Set up new target
					strcpy(target[0].name, sigott.name);
					strcpy(target[0].desc, sigott.desc);
					target[0].ra = sigott.ra;
					target[0].dec = sigott.dec;
					target[0].mag = sigott.mag;
					target[0].j2kra = sigott.j2kra;
					target[0].jpmra = sigott.jpmra;
					target[0].j2kdec = sigott.j2kdec;
					target[0].jpmdec = sigott.jpmdec;
					target[0].abspos = sigott.abspos; 				
				}
				
				gotoflag = GoToCoords(&mnt, target[0].ra, target[0].dec, RAW, target[0].abspos);
				if (gotoflag == TRUE)
				{
					text = XmStringCreateLocalized ("Wait for telescope to acquire pole star\nUse Alt/Az knobs to correct pointing (50 to 75%)\nPress ok when done\n");
					XtVaSetValues (dlgskyalign, XmNmessageString, text, NULL);	
					XmStringFree (text);
					mnt.align = -3;
					XtManageChild(dlgskyalign);
				}
				else
				{
					align_telescope_polaris(-1);
					infobox(toplevel, "Error slewing to polaris\nProcess aborted!", "Error");
				}
			}
		}
		else if (step == 3)
		{
			// Set up new target
			strcpy(target[0].name, reference.name);
			strcpy(target[0].desc, reference.desc);
			target[0].ra = reference.ra;
			target[0].dec = reference.dec;
			target[0].mag = reference.mag;
			target[0].j2kra = reference.j2kra;
			target[0].jpmra = reference.jpmra;
			target[0].j2kdec = reference.j2kdec;
			target[0].jpmdec = reference.jpmdec;
			target[0].abspos = reference.abspos; 				

			gotoflag = GoToCoords(&mnt,target[0].ra, target[0].dec, RAW, target[0].abspos);
			if (gotoflag == TRUE)
			{
				text = XmStringCreateLocalized ("Telescope is slewing back to reference\nWait for telescope to acquire target\nCenter object in the FOV\nPress ok when done\n");
				XtVaSetValues (dlgskyalign, XmNmessageString, text, NULL);	
				XmStringFree (text);
				mnt.align = -2;
				XtManageChild(dlgskyalign);
			}
		}
		else if (step == -1)
		{
			// Exit from modeless popup
			// Cancel last goto eventually
			//Popup needs to be destroyed by a timer (destroy event not connected to the CB funtction)
			hide_popup_id = XtAppAddTimeOut(context, 100, hide_popup_handler, hide_popup_data_ptr);

			if (gotoflag == TRUE)
			{
				//Canceled during goto
				if (FullStop(&mnt))
				{
					if(mnt.trkStatus != mnt.trkActive)
					{
						StartTrack(&mnt);
					}
				}
			}			

			answer = msgbox(toplevel, "Was the align successful?", MSGYESNO, "Question");
			if (answer)
			{
				mnt.align = 1;
			}
			else
			{
				mnt.align = 0;
			}			

			mnt.polaraz = 0;
			mnt.polaraz = 0;
			mnt.offsetra = 0;
			mnt.offsetdec = 0;
			pmodel = RAW;
			
			infobox(toplevel, "Pole align terminated!", "Pole align");
		}
		// Update coordinates each step
		fetch_telescope_coordinates();
		if (!errflag)
		{
			show_telescope_coordinates();
			if (!errflag)
			{
				mark_fifo_telescope();
			}
		}		
	} 
	else 
	{
		setMessage("Telescope is not connected\n"); 
	}
	return;
}

void align_polarisCB(Widget w, XtPointer client_data, XtPointer call_data)
{
    XmAnyCallbackStruct *cbs = (XmAnyCallbackStruct *) call_data;

    switch (cbs->reason) 
    {
        case XmCR_OK: 
         	align_telescope_polaris(abs(mnt.align));
        	break;
        
        case XmCR_CANCEL:
        	align_telescope_polaris(-1);
        	break;
        
    }
	return;
}

/* Init polar aling aid process */
void skyalign_telescope(int step)
{
	int answer = 0;
	XmString text;
	
	// Just a brute force "sync" on the target.	
	if (mnt.tellink) 
	{
		if (step == 1)
		{
			// setup the dialog
			XtRemoveAllCallbacks (dlgskyalign, XmNokCallback);
			XtRemoveAllCallbacks (dlgskyalign, XmNcancelCallback);
			XtAddCallback (dlgskyalign, XmNokCallback, skyalignCB, (XtPointer) OK);
			XtAddCallback (dlgskyalign, XmNcancelCallback, skyalignCB, (XtPointer) CANCEL);					

			if (mnt.align > 0) 
			{
				answer = msgbox(toplevel, "Telescope is aligned already\nConfirm you want to align again?", 0, "Align!");
			}
			else
			{
				answer = 1;
			}	
			if (answer) 
			{  
				answer = 0;
				if (mnt.SiteLatitude > 0)
				{
					answer = msgbox(toplevel, "Confirm telescope is pointing North", 0, "Home position");
				}
				else
				{
					answer = msgbox(toplevel, "Confirm telescope is pointing South", 0, "Home position");
				}
				if (answer)
				{
					mnt.align = 0;
					answer = 0;
					if (SetHomeNowTel(&mnt))
					{
						setMessage("Encoder position reset on home position\n");
					}
					// Set for tracking and start
					if (StartTrack(&mnt))
					{
						SetTrackStatus(&mnt, 1);
 						text = XmStringCreateLocalized ("Slew telescope to a known visible target\nWait for telescope to acquire target\nCenter object in the FOV\nPress ok when done\n");
						XtVaSetValues (dlgskyalign, XmNmessageString, text, NULL);	
    					XmStringFree (text);
						mnt.align = -2;
						XtManageChild(dlgskyalign);
					}
				}
			}
		}
		else if (step == 2)
		{
			sync_telescope_to_target();
			if (!errflag)
			{
				mnt.align = 1;
				// Next Step
				//text = XmStringCreateLocalized ("Slew telescope to a second known visible target\nWait for telescope to acquire target\nCenter object in the FOV\nPress ok when done\n");
				//XmStringFree (text);
				//mnt.align = -3;
				//XtManageChild(dlgskyalign);
			}
			//Popup needs to be destroyed by a timer (destroy event not connected to the CB function)
			hide_popup_id = XtAppAddTimeOut(context, 100, hide_popup_handler, hide_popup_data_ptr);
		}
		else if (step == -1)
		{
			//Popup needs to be destroyed by a timer (destroy event not connected to the CB funtction)
			hide_popup_id = XtAppAddTimeOut(context, 100, hide_popup_handler, hide_popup_data_ptr);

			mnt.align = 0;
			if (FullStop(&mnt))
			{
				if(mnt.trkStatus != mnt.trkActive)
				{
					StartTrack(&mnt);
				}
				infobox(toplevel, "Sky align terminated!", "Sky align");
			}
		}
		// Update coordinates each step
		fetch_telescope_coordinates();
		if (!errflag)
		{
			show_telescope_coordinates();
			if (!errflag)
			{
				mark_fifo_telescope();
			}
		}
	}
	return;
}

void skyalignCB(Widget w, XtPointer client_data, XtPointer call_data)
{
    XmAnyCallbackStruct *cbs = (XmAnyCallbackStruct *) call_data;

    switch (cbs->reason) 
    {
        case XmCR_OK: 
        	skyalign_telescope(abs(mnt.align));
        	break;
        
        case XmCR_CANCEL:
        	skyalign_telescope(-1);
        	break;
        
    }
	return;
}

void reference_telescope_clear()
{
	double tmpoffsetra, tmpoffsetdec;

	if (mnt.tellink)
	{
		tmpoffsetra = mnt.offsetra;
		tmpoffsetdec = mnt.offsetdec;
		mnt.offsetra = 0.;
		mnt.offsetdec = 0.;
		SyncTelOffsets(&mnt, mnt.offsetra, mnt.offsetdec);

		/* Get the coordinates with other pointing corrections in place */
		fetch_telescope_coordinates();
		if (!errflag)
		{
			setMessage(	"New offsets: \n");
			setMessage( "RA: ");
			dtodms(strMsgLine,&mnt.offsetra); 
			setMessage( strMsgLine);
			setMessage("\n");
			setMessage( "Dec: ");
			dtodms(strMsgLine,&mnt.offsetdec); 
			setMessage( strMsgLine);
			setMessage("\n");  

			sprintf(strMsgLine,"Telescope: RA %lf  Dec %lf\n",telpos[0].ra, telpos[0].dec);
			setMessage( strMsgLine);
			sprintf(strMsgLine,"Target:    RA %lf  Dec %lf\n",target[0].ra, target[0].dec);
			setMessage( strMsgLine);
			sprintf(strMsgLine,"Offset:    RA %lf  Dec %lf\n",mnt.offsetra, mnt.offsetdec);
			setMessage( strMsgLine);

			// Reset the offset model flag too
			if( XmToggleButtonGetState(p_options_toggle_1) )
			{
				pmodel=(pmodel | OFFSET);
			}
		}
		else
		{
			/* Let's restore previous state in case of error */
			mnt.offsetra = tmpoffsetra;
			mnt.offsetdec = tmpoffsetdec; 
			SyncTelOffsets(&mnt, mnt.offsetra, mnt.offsetdec);
			setMessage("Error when getting telescope coordinates, clear sync aborted\n");
			setMessage("Original internal offsets remain in use.\n");
		}
	}
	else
	{
		setMessage("Telescope is not connected\n");
	}
	return;
}

void sync_telescope_to_target()
{
	if (mnt.tellink)
	{
		// We need the latest
		fetch_telescope_coordinates();
		if (!errflag)
		{
			// Also store / update offests for absolute positions like park and home
			mnt.offsetabsra += target[0].ra - telpos[0].ra;
			mnt.offsetabsdec += target[0].dec - telpos[0].dec;

			//fprintf(stderr,"offsetabsra : %f h\n", mnt.offsetabsra);
			//fprintf(stderr,"offsetabsdec: %f deg\n", mnt.offsetabsdec);

			errflag = !SetTel(&mnt, Map12(LSTNow(mnt.SiteLongitude) - target[0].ra), target[0].dec);
			if (!errflag)
			{
				setMessage("Encoder position reset on target\n");
				// This will also reset global telencoder variables in the protocol
				fetch_telescope_coordinates();
				show_telescope_coordinates();
			}
		}
		else 
		{
			setMessage("Could not read telescope position, sync aborted\n"); 
		}
	}
	else
	{
		setMessage("Telescope is not connected\n");
	}
}
/* Update reference to current target */

/* This is actually more complex than a simple offset correction if */
/* a pointing model is in place.  In that case, the offset should be */
/* to the base ra and dec reported by the telescope, taken such that */
/* the actual ra and dec with offset and pointing correction will */
/* agree with the reference target.  It will have to iterate to achieve */
/* this effect.  The simple difference here from the reported coordinates */
/* with other pointing model corrections still in place will impact */
/* the effect of the pointing model. */
void reference_telescope_to_target()          
{    
	double tmpoffsetra, tmpoffsetdec;

	if (mnt.tellink)
	{
		/* Turn off reference correction for a moment by setting offsets to zero */
		tmpoffsetra = mnt.offsetra;
		tmpoffsetdec = mnt.offsetdec;
		mnt.offsetra = 0.;
		mnt.offsetdec = 0.;
		SyncTelOffsets(&mnt, mnt.offsetra, mnt.offsetdec);

		/* Get the coordinates with other pointing corrections in place */
		fetch_telescope_coordinates();
		if (!errflag)
		{   
			/* Trap the very confusing errors that would happen in an offset */
			/* assigned across the poles. */
			if ( fabs(telpos[0].dec)> 85. )
			{
				mnt.offsetra = tmpoffsetra;
				mnt.offsetdec = tmpoffsetdec; 
				SyncTelOffsets(&mnt, mnt.offsetra, mnt.offsetdec);
				setMessage("Telescope reports a declination within 5 degrees of the poles.\n");
				setMessage("Original internal offsets remain in use.\n");
				return;
			}

			if (fabs(target[0].dec)> 85. )
			{
				mnt.offsetra = tmpoffsetra;
				mnt.offsetdec = tmpoffsetdec; 
				SyncTelOffsets(&mnt, mnt.offsetra, mnt.offsetdec);
				setMessage("Reference is not permitted to a target within 5 degrees of the poles.\n");
				setMessage("Original offsets remain in use.\n");
				return;
			} 

			/* Calculate new additive offsets */
			mnt.offsetra = target[0].ra - telpos[0].ra;
			mnt.offsetdec = target[0].dec - telpos[0].dec;

			/* Patch the common error across the 0h boundary */ 
			if (mnt.offsetra > 12.0)
			{
				mnt.offsetra = 24.0 - mnt.offsetra;
			}

			/* Check that the offsets are not too large */
			if (fabs(mnt.offsetdec) >= 15.0)
			{
				mnt.offsetdec = tmpoffsetdec;
				mnt.offsetra = tmpoffsetra;
				SyncTelOffsets(&mnt, mnt.offsetra, mnt.offsetdec);
				setMessage( "New offset in declination would be greater than 15 degrees.\n");
				setMessage( "Original offsets remain in use.\n");
				return;
			}

			if (fabs(mnt.offsetra) >= 1.0)
			{
				mnt.offsetdec = tmpoffsetdec;
				mnt.offsetra = tmpoffsetra;
				SyncTelOffsets(&mnt, mnt.offsetra, mnt.offsetdec);
				setMessage("New offset in right ascension would be greater than 1 hour.\n");
				setMessage("Original offsets remain in use.\n");
				return;
			} 

			SyncTelOffsets(&mnt, mnt.offsetra, mnt.offsetdec);
			setMessage(	"New offsets: \n");
			setMessage( "RA: ");
			dtodms(strMsgLine,&mnt.offsetra); 
			setMessage( strMsgLine);
			setMessage("\n");
			setMessage( "Dec: ");
			dtodms(strMsgLine,&mnt.offsetdec); 
			setMessage( strMsgLine);
			setMessage("\n");  

			sprintf(strMsgLine,"Telescope: RA %lf  Dec %lf\n",telpos[0].ra, telpos[0].dec);
			setMessage( strMsgLine);
			sprintf(strMsgLine,"Target:    RA %lf  Dec %lf\n",target[0].ra, target[0].dec);
			setMessage( strMsgLine);
			sprintf(strMsgLine,"Offset:    RA %lf  Dec %lf\n",mnt.offsetra, mnt.offsetdec);
			setMessage( strMsgLine);
		
			// Set to use the newly set values if not in use already
			//if( !XmToggleButtonGetState(p_options_toggle_1) )
			//{
			//	pmodel=(pmodel & ~(OFFSET));
			//}  
		
		}
		else
		{
			/* Let's restore previous state in case of error */
			mnt.offsetra = tmpoffsetra;
			mnt.offsetdec = tmpoffsetdec; 
			SyncTelOffsets(&mnt, mnt.offsetra, mnt.offsetdec);
			setMessage("Error when getting telescope coordinates, sync aborted\n");
			setMessage("Original internal offsets remain in use.\n");
		}
	}
	else
	{
		setMessage("Telescope is not connected\n");
	}
	return;
}

/* Update reference to zenith assuming the telescope is pointing there */
void reference_telescope_to_zenith()          
{    
	double tmpoffsetra, tmpoffsetdec;
	double zenithra, zenithdec;

	if (mnt.tellink)
	{
		/* Turn off reference correction for a moment by setting offsets to zero */
		tmpoffsetra = mnt.offsetra;
		tmpoffsetdec = mnt.offsetdec;
		mnt.offsetra = 0.;
		mnt.offsetdec = 0.;
		SyncTelOffsets(&mnt, mnt.offsetra, mnt.offsetdec);

		/* Get the coordinates with other pointing corrections in place */
		fetch_telescope_coordinates();
		if (!errflag)
		{ 
			zenithra = Map24(LSTNow(mnt.SiteLongitude));
			zenithdec = mnt.SiteLatitude;

			/* Calculate new additive offsets */
			mnt.offsetra = zenithra - telpos[0].ra;
			mnt.offsetdec = zenithdec - telpos[0].dec;

			/* Patch the common error across the 0h boundary */ 
			if (mnt.offsetra > 12.0)
			{
				mnt.offsetra = 24.0 - mnt.offsetra;
			}

			/* Check that the offsets are not too large */
			if (fabs(mnt.offsetdec) >= 15.0)
			{
				mnt.offsetdec = tmpoffsetdec;
				mnt.offsetra = tmpoffsetra;
				SyncTelOffsets(&mnt, mnt.offsetra, mnt.offsetdec);
				setMessage("New offset in declination would be greater than 15 degrees.\n");
				setMessage("Original offsets remain in use.\n");
				return;
			}

			if (fabs(mnt.offsetra) >= 1.0)
			{
				mnt.offsetdec = tmpoffsetdec;
				mnt.offsetra = tmpoffsetra;
				SyncTelOffsets(&mnt, mnt.offsetra, mnt.offsetdec);
				setMessage("New offset in right ascension would be greater than 1 hour.\n");
				setMessage("Original offsets remain in use.\n");
				return;
			} 

			SyncTelOffsets(&mnt, mnt.offsetra, mnt.offsetdec);
			setMessage("New offsets: \n");
			setMessage("RA: ");
			dtodms(strMsgLine,&mnt.offsetra); 
			setMessage( strMsgLine);
			setMessage("\n");
			setMessage("Dec: ");
			dtodms(strMsgLine,&mnt.offsetdec); 
			setMessage( strMsgLine);
			setMessage("\n");  


			sprintf(strMsgLine,"Telescope: RA %lf  Dec %lf\n", telpos[0].ra, telpos[0].dec);
			setMessage( strMsgLine);
			sprintf(strMsgLine,"Target:    RA %lf  Dec %lf\n", target[0].ra, target[0].dec);
			setMessage( strMsgLine);	
			sprintf(strMsgLine,"Offset:    RA %lf  Dec %lf\n", mnt.offsetra, mnt.offsetdec); 
			setMessage( strMsgLine);
		}
	}
	else
	{
		setMessage("Telescope is not connected\n");
	}
	return;
}

/* Export current telescope coordinates to XEphem */
void mark_fifo_telescope()     
{
	double tmpra, tmpdec;
	double rarad,decrad;
	char outbuf[101];
	int num;

	if (!wpipedisabled)
	{ 
		/* Recall the telescope's EOD coordinates */  
		tmpra=telpos[0].ra;
		tmpdec=telpos[0].dec;         

		/* Convert to 2000.0 */
		Apparent(&tmpra,&tmpdec,-1);   

		/* Convert to radians */
		rarad=tmpra*PI/12.;  
		decrad=tmpdec*PI/180.; 

		/* Send the values to the fifo */
		snprintf(outbuf,sizeof(outbuf),"RA:%9.6f Dec:%9.6f Epoch:2000.000\n", rarad,decrad);  
		if ((num = write(fd_fifo_out, outbuf, strlen(outbuf))) == -1)
		{
			setMessage("Error communicating telescope coordinates.\n");
		}
	}
}

/* Export current target coordinates to XEphem */
void mark_fifo_target()     
{
	double tmpra, tmpdec;
	double rarad,decrad;
	char outbuf[101]; 
	int num;
	
	if (!wpipedisabled)
	{
		/* Recall the telescope's EOD coordinates */
		tmpra=target[0].ra;
		tmpdec=target[0].dec;         

		/* Convert to Epoch 2000.0  coordinates */
		Apparent(&tmpra,&tmpdec,-1);   

		/* Convert to radians */
		rarad=tmpra*PI/12.;  
		decrad=tmpdec*PI/180.; 

		/* Send the values to the fifo */  
		snprintf(outbuf,sizeof(outbuf),"RA:%9.6f Dec:%9.6f Epoch:2000.000\n", rarad,decrad);  
		if ((num = write(fd_fifo_out, outbuf, strlen(outbuf))) == -1)
		{
			setMessage("Error communicating target coordinates.\n");
		}
	}
	else
	{
		setMessage("Input pipe is closed!\n");
	}
}

/* Read XEphem goto fifo and parse target coordinates */
void read_edb_fifo() 
{
	int i,k;
	char fifostr[121];
	char inbuf[2];

	/* A typical fixed target string is:                            */

	/* Regulus,f|M|B7,10:08:22.3, 11:58:02,  1.35,2000,0            */
	/* Name, type info, RA | pm, Dec | pm, Mag, Epoch, Identifier   */

	/* Examples from XEphem version 3.6.xx -- */
	/* Arcturus,f|V|K1,14:15:39.7|-1093, 19:10:57|-1998,-0.04,2000,0  */
	/* HD 124953,f|V|A8,14:16:04.2|43, 18:54:43|-28,5.98,2000,0       */
	/* Crt Delta-12,f|S|G8,11:19:20.5|-122,-14:46:43|208,3.56,2000,0  */
	/* GSC 0838-0788,f|S,10:32:32.4,  9:06:17,13.84,2000,0            */
	/* M67,f|O|T2, 8:51:24.0, 11:49:00,6.90,2000,1500|1500|0          */
	/* NGC 2539,f|O|T2, 8:10:36.9,-12:49:14,6.50,2000,900|900|0       */
	/* Venus,P                                                        */
	/* Will skip orbital objects for which XEphem does not pass RA and Dec */   

	/* Buffer is open in nowait mode there is no way to know...   */
	/* Read attemp will just return 0 bytes                       */

	/* Read the buffer */
	k=0;
	while(1) 
	{
		i = read(fd_fifo_in,inbuf,1);
		if(i != 1) 
		{
			fifostr[k]='\0';
			break;
		}
		if(k<120)
		{
			fifostr[k++]=inbuf[0];
		}
	}
	if (k>1) 
	{
		fifostr[k]='\0';
		if (strncmp(fifostr, "Park", 4) == 0)
		{
			//Park detected, we discard all the rest and calculate
			set_target_park();			
			setMessage("Read Park scope request from fifo\n");
		}
		else if (strncmp(fifostr, "Home", 4) == 0)
		{
			//Home detected, we discard all the rest and calculate
			set_target_home();			
			setMessage("Read goto Home position request from fifo\n");
		}
		else if (strncmp(fifostr, "Meridian", 8) == 0)
		{
			//Meridian detected, we discard all the rest and calculate
			set_target_meridian();			
			setMessage("Read goto Meridian request from fifo\n");
		}
		else if (strncmp(fifostr, "Zenith", 6) == 0)
		{
			//Zenith detected, we discard all the rest and calculate
			set_target_zenith();			
			setMessage("Read goto zenith request from fifo\n");
		}
		else
		{
			sprintf(strMsgLine, "Read %u row(s) from fifo\n ",read_edb_row(fifostr, target, -1) + 1);
			setMessage( strMsgLine);
		}
		queue_add();
		show_target_coordinates();
		// Immediate goto
		if (mnt.tellink)
		{
			commandCB(command[CMD_SLEW],CMD_SLEW,NULL);
		}
		else
		{
			setMessage("Telescope is not connected\n");
		}
	}
	else
	{
		setMessage( "No data to read in fifo\n");
	}
}

/* Write current target coordinates to history */
void history_add()           
{
	Arg al[10];
	int i, j, ac;
	char rastr[30], decstr[30], magstr[30];
	char tmpstr[251];

	/* Expand the buffer up to a maximum of 100 entries */
	if (nhistory < HISTORYLEN) 
	{
		nhistory++;
	}

	/* Increment the ring counter */
	last_history_saved++;

	/* Test for wraparound and reset history counters */
	if (last_history_saved > (HISTORYLEN - 1)) 
	{
		last_history_saved=0;
	}

	/* Save at the current telescope coordinates in the last_history location */
	strncpy(history[last_history_saved].name,target[0].name,79);
	strncpy(history[last_history_saved].desc,target[0].desc,79);
	history[last_history_saved].ra = target[0].ra;
	history[last_history_saved].dec = target[0].dec;
	history[last_history_saved].mag = target[0].mag;
	history[last_history_saved].j2kra = target[0].j2kra;
	history[last_history_saved].jpmra = target[0].jpmra;
	history[last_history_saved].j2kdec = target[0].j2kdec;
	history[last_history_saved].jpmdec = target[0].jpmdec;
	history[last_history_saved].abspos = target[0].abspos;

	/* Updates the list control */
	XmStringTable history_list = (XmStringTable) XtMalloc ( (nhistory + 1) * sizeof (XmString) ); 
	for (i=0; i <= nhistory ; i++)
	{
		if (strlen(history[i].name))
		{
			/* Convert in string format */
			dtodms(rastr, &history[i].ra);
			dtodms(decstr,&history[i].dec);
			if (history[i].mag > -9999.)
			{
				sprintf(magstr,"%.2f", history[i].mag);
			}
			else
			{
				strcpy(magstr," ");
			}

			strcpy(tmpstr, history[i].name);
			strcat(tmpstr, " ");
			strcat(tmpstr, history[i].desc);
			strcat(tmpstr, " ");
			strcat(tmpstr, rastr);
			strcat(tmpstr, " ");
			strcat(tmpstr, decstr);
			strcat(tmpstr, " ");
			strcat(tmpstr, magstr);
			strcat(tmpstr, " Now");
			for (j = strlen(tmpstr); j < 250; j++)
			{
				strcat(tmpstr, " ");
			}	
		}
		else
		{
			tmpstr[0]='\0';
		}
		history_list[i] = XmStringCreateLocalized (tmpstr); 
	}
	ac=0; 
	XtSetArg(al[ac],XmNitemCount, (nhistory + 1)); ac++; 
	XtSetArg(al[ac],XmNitems,history_list); ac++;
	XtSetValues(history_area,al,ac);  
	for (i = 0; i <= nhistory; i++)
	{
		XmStringFree(history_list[i]);
	}
	free(history_list);

	/* Some logging does not harm */
	sprintf(strMsgLine, "Coordinates added to history [%u]:\n", last_history_saved);
	setMessage( strMsgLine);
	strcpy(strMsgLine, "Name ");
	strcat(strMsgLine, history[last_history_saved].name);
	strcat(strMsgLine, "\n");
	setMessage( strMsgLine);
}

/* Write current target coordinates to history */
void queue_add()           
{
	Arg al[10];
	int i, j, ac;
	char rastr[30], decstr[30], magstr[30];
	char tmpstr[251];

	/* Expand the buffer up to a maximum of 10001 entries */
	if (nqueue < QUEUELEN) 
	{
		if (nqueue == -1)
		{
			nqueue++;
		}

		/* Save at the current telescope coordinates in the last location */
		strncpy(queue[nqueue].name,target[0].name,79);
		strncpy(queue[nqueue].desc,target[0].desc,79);
		queue[nqueue].ra = target[0].ra;
		queue[nqueue].dec = target[0].dec;
		queue[nqueue].mag = target[0].mag;
		queue[nqueue].j2kra = target[0].j2kra;
		queue[nqueue].jpmra = target[0].jpmra;
		queue[nqueue].j2kdec = target[0].j2kdec;
		queue[nqueue].jpmdec = target[0].jpmdec;
		queue[nqueue].abspos = target[0].abspos;

		/* Updates the list control */
		XmStringTable queue_list = (XmStringTable) XtMalloc ( (nqueue + 1) * sizeof (XmString) ); 
		for (i=0; i <= nqueue ; i++)
		{
			if (strlen(queue[i].name))
			{
				/* Convert in string format */
				dtodms(rastr, &queue[i].ra);
				dtodms(decstr,&queue[i].dec);
				if (queue[i].mag > -9999.)
				{
					sprintf(magstr,"%.2f", queue[i].mag);
				}
				else
				{
					strcpy(magstr, " ");
				}
				
				strcpy(tmpstr, queue[i].name);
				strcat(tmpstr, " ");
				strcat(tmpstr, queue[i].desc);
				strcat(tmpstr, " ");
				strcat(tmpstr, rastr);
				strcat(tmpstr, " ");
				strcat(tmpstr, decstr);
				strcat(tmpstr, " ");
				strcat(tmpstr, magstr);
				strcat(tmpstr, " Now");
				for (j = strlen(tmpstr); j < 250; j++)
				{
					strcat(tmpstr, " ");
				}	
			}
			else
			{
				tmpstr[0]='\0';
			}
			queue_list[i] = XmStringCreateLocalized (tmpstr); 
		}
		ac=0; 
		XtSetArg(al[ac],XmNitemCount, (nqueue + 1)); ac++; 
		XtSetArg(al[ac],XmNitems,queue_list); ac++;
		XtSetValues(queue_area,al,ac);  
		for (i = 0; i <= nqueue; i++)
		{
			XmStringFree(queue_list[i]);
		}
		free(queue_list);
		
		/* Some logging does not harm */
		sprintf(strMsgLine, "Coordinates added to queue [%u]:\n", nqueue);
		setMessage( strMsgLine);
		strcpy(strMsgLine, "Name ");
		strcat(strMsgLine, queue[nqueue].name);
		strcat(strMsgLine, "\n");
		setMessage( strMsgLine);

		/* increment list lenght pointer */
		nqueue++;
	}
}

/* Write current telescope coordinates to the xmtel coordfile file*/
int save_coordinates(int read)           
{
	int retval = 0;
	double telposra = 0., telposdec = 0.;
	
 	if (mnt.tellink)
 	{
	 	/* Write to file */
		if ((fp_file = fopen(COORDFILE, "w")) != NULL)
		{
			//Fresh reas just to be on the safe side
			if (read)
			{
				// Read data
				read = GetTel(&mnt, &telposra, &telposdec, pmodel);
			}
			else
			{
				// Use current
				read = 1;
				telposra = telpos[0].ra; 
				telposdec = telpos[0].dec;
			}
			if (read)
			{
				// This will write a line as follows
				// ha,dec
				// all values are double
				fprintf(fp_file,"%f,%f\n", Map12(LSTNow(mnt.SiteLongitude) - telposra), telposdec);
		
				fflush(fp_file);
				fclose(fp_file);
				sprintf(strMsgLine,"Save coordinates done to %s\n", COORDFILE);
				retval = 1;
			}
			else
			{
				sprintf(strMsgLine,"Error saving coordinates to %s\n(cannot read telescope position)\n", COORDFILE);	
			}
		}
		else
		{
			sprintf(strMsgLine,"Error saving coordinates to %s\n", COORDFILE);	
		}
		setMessage( strMsgLine);
	}
	else
	{
		setMessage("Telescope is not connected\n");
	}
	return retval;
}

/* Recall telescope coordinates from the coordfile file and add to xmtel history */
int recall_coordinates()           
{
	char rowstr[128];
	char fldstr[128], *end;	
	char *strrowptr=rowstr;
	int j,k;
	int retval = 0;
	
	if ((fp_file = fopen(COORDFILE, "r")) != NULL)
	{
		if (rowstr == fgets(rowstr, 128, fp_file))
		{
			k = strlen(rowstr);
			if ( k > 0)
			{
				rowstr[k]='\0';
				strrowptr=rowstr;
				j=strcspn(strrowptr,",");
				strncpy(fldstr, strrowptr, j);
				fldstr[j] = '\0';
				strrowptr = strrowptr + j + 1;
				telpos[0].ra = Map24(LSTNow(mnt.SiteLongitude) - strtod(fldstr, &end));
				strcpy(fldstr, strrowptr);
				telpos[0].dec = strtod(fldstr, &end);
				sprintf(strMsgLine,"Recall coordinates done from %s\n", COORDFILE);
			}
			retval = 1;
		}
		else
		{
			sprintf(strMsgLine,"Error reading coordinates file\n");
		}
	}
	else
	{
		sprintf(strMsgLine,"Error opening coordinates file\n");
	}
	setMessage(strMsgLine);
	return retval;
}

/* Write the edb file line by line */
int write_edb_file(FILE * fileptr, catalog *cat, int catlen)
{
	int retval = 1;
	int i = 1;

	if ( !(fileptr == NULL) )
	{
		/* Catlen is number of elements in the catalog */ 
		for (i = 0; i < catlen; i++)
		{
			if (!write_edb_row(fileptr, cat, i))
			{
				sprintf(strMsgLine, "Error writing file at item %u of %u\n", (i + 1), catlen);
				setMessage( strMsgLine);
				retval = 0;
			}
		}
		fflush(fileptr);
	}
	else
	{
		retval = 0;
	}
	//fprintf(stderr, "file %u", retval);
	return (retval);
}

int write_edb_row(FILE * fileptr, catalog *cat, int index)
{
	char rowstr[513];
	int retval = 1;

	
	if ( !(fileptr == NULL) )
	{
		/* Name, type info, RA | pm, Dec | pm, Mag, Epoch, */
		strcpy(rowstr, cat[index].name);
		strcat(rowstr, ",");
		strcat(rowstr, cat[index].desc);
		strcat(rowstr, ",");
		dtodms(buf, &cat[index].j2kra);
		strcat(rowstr, buf);
		if (cat[index].jpmra)
		{
			strcat(rowstr, "|");
			sprintf(buf, "%f", cat[index].jpmra);
			strcat(rowstr, buf);
		}
		strcat(rowstr, ",");
		dtodms(buf, &cat[index].j2kdec);
		strcat(rowstr, buf);
		if (cat[index].jpmdec)
		{
			strcat(rowstr, "|");
			sprintf(buf, "%f", cat[index].jpmdec);
			strcat(rowstr, buf);
		}
		strcat(rowstr, ",");
		if (cat[index].mag > -9999.)
		{
			sprintf(buf, "%f", cat[index].mag);
			strcat(rowstr, buf);
		}
		strcat(rowstr, ",");
		strcat(rowstr, "2000.0");
		strcat(rowstr, "\n");
		// Now write row to file
		if (fputs(rowstr, fileptr) < 0)
		{
			retval = 0;
		}
	}
	return (retval);
}

/* Read the queue line by line */
/* Parse the edb format */
int read_edb_file(FILE * fileptr, catalog *cat, int catlen)
{
	char rowstr[513];

	if ( !(fileptr == NULL) )
	{
		/* Queue is indexed from 0 so we start with -1 here */ 
		catlen = -1;
		while ( rowstr == fgets(rowstr, 250, fileptr) )
		{
			/* Diagnostic of coordinate string contents */  		                                                           
			//fprintf(stderr, "%u %s\n",catlen + 1, rowstr);
			//fprintf(stderr,"strlen  output is %u \n",strlen(rowstr)); 
			catlen = read_edb_row(rowstr, cat, catlen);
			 
		} 

		/* Increment catlen so that it now reads the number of entries to the queue */
		catlen++;

	}
	return catlen;
}

int read_edb_row(char *rowstr, catalog *cat, int catlen)
{
	char *strrowptr=rowstr;
	int i,j,k;
	double rahr,ramin,rasec;
	double decdeg,decmin,decsec;
	double tmpra,tmpdec,tmpepoch;
	double appra,appdec;
	double tmp_pm_ra=0.;
	double tmp_pm_dec=0.;
	double tmpmag;
	double tmpdat;

	/* If the buffer is not empty and not a comment then extract its parts */
	k=strlen(rowstr);
	if ( (k>1) && ( rowstr[0] != '#' ) ) 
	{
		/* Increment the counter for the number of queue entries */   
		catlen++;

		/* Prepare the string by overwriting the newline character at the end */     
		rowstr[k]='\0';
		strrowptr=rowstr;

		/* The name and description fields may have useful white space */     
		/* Identify the name field and copy it to the local queue */
		j=strcspn(strrowptr,",");
		strncpy(cat[catlen].name, strrowptr, j);
		cat[catlen].name[j] = '\0';
		strrowptr = strrowptr + j + 1;

		/* Diagnostic of the queue entry                              */
		//fprintf(stderr, "%u %s\n", catlen, cat[catlen].name);
	
		/* Identify the description field and copy it to the local queue */      
		j=strcspn(strrowptr,",");
		strncpy(cat[catlen].desc,strrowptr,j);
		cat[catlen].desc[j] = '\0';
		
		/* Diagnostic of the queue entry                              */
		//fprintf(stderr, "%u %s\n", catlen, cat[catlen].desc);

		/* Remove any white space as the entire string is copied on itself */
		i=0;
		j=0;
		while (i<=k)
		{
			if( rowstr[i]!=' ' )
			{
				rowstr[j]=rowstr[i];
				j++;
			}
			i++;
		}  

		/* Diagnostic of clean coordinate string contents */
		//fprintf(stderr, "Queue clean str: %s\n", rowstr);

		/* Set the pointer at the beginning of the clean string */
		strrowptr=rowstr;
		i=0;

		/* Skips the cleaned name and description fields */
		while(i<2)  
		{
			strrowptr=strchr(strrowptr,',');
			if(strrowptr==NULL) break;
			strrowptr++;
			i++;
		}
		/* Diagnostic of the queue entry                              */
		//fprintf(stderr, "counter on clean string %u\n", i);	

		/* Parsing will have proceeded to the RA field if this is an object */
		if(i==2)
		{ 
			/* Scan and save RA data in a temporary buffer -- epoch not yet read */ 
			/* Queue proper motion is in milliarcseconds per year */ 
			/* Our pm_ra is in seconds of time per year */
			tmpdat=0.;
			j=sscanf(strrowptr,"%lf:%lf:%lf|%lf", &rahr,&ramin,&rasec,&tmpdat);

			if(j>0) 
			{
				tmpra = rahr + ramin/60. + rasec/3600.;
				tmp_pm_ra=tmpdat/15000.;
			}				 
			/* Try to advance pointer to the Dec field */
			strrowptr=strchr(strrowptr,',');
			if(strrowptr != NULL)
			{
				strrowptr++;
				i++;
			}
		}
		/* Diagnostic of the queue entry                              */
		//fprintf(stderr, "tmpra %f tmppmra %f\n", tmpra, tmp_pm_ra);
		//fprintf(stderr, "counter on clean string %u\n", i);

		if(i==3)
		{  
			/* Now pointing at the Dec field so scan and save Dec data */
			/* Queue proper motion is in milliarcseconds per year */ 
			/* Our pm_dec is in seconds of arc per year */
			tmpdat=0.;
			j=sscanf(strrowptr,"%lf:%lf:%lf|%lf", &decdeg,&decmin,&decsec,&tmpdat);
			if(j>0) 
			{
				if(decdeg>0.)
				{
					tmpdec = decdeg + decmin/60. + decsec/3600.;
				}
				else
				{ 
					tmpdec = decdeg - decmin/60. - decsec/3600.;
				}
				tmp_pm_dec=tmpdat/1000.;
			}
			/* Try to advance pointer to the Magnitude field */
			strrowptr=strchr(strrowptr,',');
			if(strrowptr != NULL)
			{
				strrowptr++;
				i++;
			}	
		}
		/* Diagnostic of the queue entry                              */
		//fprintf(stderr, "tmpdec %f tmppmdec %f\n", tmpdec, tmp_pm_dec);
		//fprintf(stderr, "counter on clean string %u\n", i);

		if(i==4)
		{  
			/* Scan and save magnitude */ 
			j=sscanf(strrowptr,"%lf", &tmpmag);
			if(j>0) 
			{
				cat[catlen].mag=tmpmag;
			}
			else
			{
				cat[catlen].mag = -9999.;
			}
			/* Try to advance pointer to the Epoch field */
			strrowptr=strchr(strrowptr,',');
			if(strrowptr != NULL)
			{
				strrowptr++;
				i++;
			}
		}
		/* Diagnostic of the queue entry                              */
		//fprintf(stderr, "Mag %f\n", cat[catlen].mag);
		//fprintf(stderr, "counter on clean string %u\n", i); 

		if(i==5)
		{  
			/* Scan for Epoch */ 
			j=sscanf(strrowptr,"%lf", &tmpepoch);

			// Set aside original values.
			appra = tmpra;
			appdec = tmpdec;

			if(j>0) 
			{
				/* The queue entry epoch has been found */
				/* Apply proper motion to EOD */
				ProperMotion(tmpepoch, &appra, &appdec, tmp_pm_ra, tmp_pm_dec);        

				/* Find the apparent coordinates including */
				/*   precession, nutation, and stellar aberration for the EOD */
				if ((tmpepoch > 1999.99) && (tmpepoch < 2000.01)) 
				{
					/* Epoch 2000.0 coordinates apply */
					/* Find the apparent position of the object for EOD */         
					Apparent(&appra, &appdec, 1);
				}
				else 
				{
					/* Some other epoch applies.  Caution!!  */
					/* Set the epoch to 2000.0 and then proceed as before. */
					/* If coordinates are not FK5 this will not be accurate. */                   
					PrecessToEOD(tmpepoch, &appra, &appdec);
					PrecessToEpoch(2000.0, &appra, &appdec);
					
					// Also for tmp to store j2k (without pm)
					PrecessToEOD(tmpepoch, &tmpra, &tmpdec);
					PrecessToEpoch(2000.0, &tmpra, &tmpdec);

					/* Epoch 2000.0 coordinates now apply */
					/* Find the apparent position of the object for EOD */
					Apparent(&appra, &appdec, 1);
				}
							   
				/* Copy the temporary coordinates to the queue entry */         
			}
			else
			{
				/* No epoch was found so assume EOD coordinates */
				/* We need to derive j2k coordinates from EOD */		  
				PrecessToEpoch(2000.0, &tmpra, &tmpdec);
			}
			/* Copy the temporary coordinates to the queue entry */              
			cat[catlen].ra = appra;
			cat[catlen].dec = appdec;
			cat[catlen].j2kra = tmpra;
			cat[catlen].jpmra = tmp_pm_ra;
			cat[catlen].j2kdec = tmpdec;
			cat[catlen].jpmdec = tmp_pm_dec;
			cat[catlen].abspos = 0;
		}  

		/* Diagnostic of the queue entry                              */
		/*                                                            */
		/* fprintf(stderr, "Ra %f Dec%f\n", cat[catlen].ra, cat[catlen].dec); */
		/* fprintf(stderr," #%u\n",catlen);                                   */
		/* fprintf(stderr," %s %s\n",cat[catlen].name,cat[catlen].desc);  */
		/* fprintf(stderr," ra: %lf  dec: %lf  mag: %lf\n\n", cat[catlen].ra,cat[catlen].dec,cat[catlen].mag);   */
	}
	return catlen;
}

void reload_list(Widget list_area, catalog *cat, int catlen)
{
	Arg al[10];
	int ac;
	int i, j;
	char rastr[30], decstr[30], magstr[30];
	char tmpstr[251];
	XmStringTable items_list = (XmStringTable) XtMalloc ( catlen * sizeof (XmString) ); 

	for (i=0; i < catlen; i++)
	{
		if (strlen(cat[i].name))
		{
			/* Convert in string format */
			dtodms(rastr, &cat[i].ra);
			dtodms(decstr,&cat[i].dec);
			if (cat[i].mag > -9999.)
			{
				sprintf(magstr,"%.2f", cat[i].mag);
			}
			else
			{
				strcat(magstr, " ");
			}
	 
	 		strcpy(tmpstr, cat[i].name);
			strcat(tmpstr, " ");
			strcat(tmpstr, cat[i].desc);
			strcat(tmpstr, " ");
			strcat(tmpstr, rastr);
			strcat(tmpstr, " ");
			strcat(tmpstr, decstr);
			strcat(tmpstr, " ");
			strcat(tmpstr, magstr);
			strcat(tmpstr, " Now");
			for (j = strlen(tmpstr); j < 250; j++)
			{
				strcat(tmpstr, " ");
			}	
		}
		else
		{
			tmpstr[0]='\0';
		}
		items_list[i] = XmStringCreateLocalized (tmpstr); 
	}
	ac=0; 
	XtSetArg(al[ac],XmNitemCount,catlen); ac++; 
	XtSetArg(al[ac],XmNitems,items_list); ac++;
	XtSetValues(list_area,al,ac);  
	for (i = 0; i < catlen; i++)
	{
		XmStringFree(items_list[i]);
	}
	free(items_list);
	/* Most dirty hack ever */
	ac=0; 
	XtSetArg(al[ac],XmNheight,680); ac++;
	XtSetValues(toplevel,al,ac);				
	ac=0; 
	XtSetArg(al[ac],XmNheight,700); ac++;
	XtSetValues(toplevel,al,ac);				
}

/* Import current telescope coordinates */
void fetch_telescope_coordinates() 
{
	double tmpra, tmpdec;
	
	if (mnt.tellink)
	{
		errflag = !GetTel(&mnt, &telpos[0].ra, &telpos[0].dec, pmodel);
		if (!errflag)
		{
			//fprintf(stderr, "Fetch ra: %f dec: %f\n", telpos[0].ra, telpos[0].dec);
			telpos[0].mag = -9999.;			
			tmpra = telpos[0].ra;
			tmpdec = telpos[0].dec;
			Apparent(&tmpra, &tmpdec, -1);
			telpos[0].j2kra = tmpra;
			telpos[0].jpmra = 0;
			telpos[0].j2kdec = tmpdec;
			telpos[0].jpmdec = 0;
			telpos[0].abspos = 0;
		}
	}
	else
	{
		setMessage("Telescope is not connected\n");
	}
}

/* User input of target RA */
void new_target_ra() 
{
	int ac;
	Arg al[10];
	char s[256];
	double tmpra, tmpdec;

	tgtfield=RA;
	switch (display_targetepoch)
	{
	case J2000:
		/* Display Epoch 2000.0 coordinates.                                */
		/* If XEphem transfered proper motion, then the target coordinates  */
		/*   stored in XmTel include proper motion to the current date.     */
		/*   Coordinates including proper motion and precessed to 2000.0    */
		/*   will differ from an epoch 2000.0 catalog entry that            */
		/*   does not include proper motion to the current date.            */

		tmpra=target[0].ra;
		tmpdec=target[0].dec;        
		Apparent(&tmpra, &tmpdec, -1);
		dtodms(s,&tmpra);
		if (s[0] == 32)
		{
			s[0] = 43;
		} 
		ac=0;      
		XtSetArg(al[ac], XmNselectionLabelString, XmStringCreateLocalized("Enter J2k coordinates: ")); ac++;
		XtSetArg(al[ac],XmNtextString, XmStringCreateLocalized(s)); ac++;
		XtSetValues(dialog,al,ac);	
		XtManageChild(dialog);
		break;

	case  EOD:
		/* Display EOD coordinates as saved in target[0].ra and target[0].dec. */
		tmpra=target[0].ra;
		tmpdec=target[0].dec;        
		dtodms(s,&tmpra);
		if (s[0] == 32)
		{
			s[0] = 43;
		} 
		ac=0;
		XtSetArg(al[ac], XmNselectionLabelString, XmStringCreateLocalized("Enter coordinates: ")); ac++;
		XtSetArg(al[ac],XmNtextString, XmStringCreateLocalized(s)); ac++;
		XtSetValues(dialog,al,ac);	
		XtManageChild(dialog);
		break;
	}      
}

/* User input of target Dec */
void new_target_dec()
{
	int ac;
	Arg al[10];
	char s[256];
	double tmpra, tmpdec;

	tgtfield=DEC;
	switch (display_targetepoch)
	{
	case J2000:
		/* Display Epoch 2000.0 coordinates.                                */
		/* If XEphem transfered proper motion, then the target coordinates  */
		/*   stored in XmTel include proper motion to the current date.     */
		/*   Coordinates including proper motion and precessed to 2000.0    */
		/*   will differ from an epoch 2000.0 catalog entry that            */
		/*   does not include proper motion to the current date.            */

		tmpra=target[0].ra;
		tmpdec=target[0].dec;        
		Apparent(&tmpra, &tmpdec, -1);
		dtodms(s,&tmpdec);
		if (s[0] == 32)
		{
			s[0] = 43;
		} 
		ac=0;      
		XtSetArg(al[ac], XmNselectionLabelString, XmStringCreateLocalized("Enter J2k coordinates: ")); ac++;
		XtSetArg(al[ac],XmNtextString, XmStringCreateLocalized(s)); ac++;
		XtSetValues(dialog,al,ac);	
		XtManageChild(dialog);
		break;

	case  EOD:
		/* Display EOD coordinates as saved in target[0].ra and target[0].dec. */
		tmpra=target[0].ra;
		tmpdec=target[0].dec;        
		dtodms(s,&tmpdec);
		if (s[0] == 32)
		{
			s[0] = 43;
		} 
		ac=0;
		XtSetArg(al[ac], XmNselectionLabelString, XmStringCreateLocalized("Enter coordinates: ")); ac++;
		XtSetArg(al[ac],XmNtextString, XmStringCreateLocalized(s)); ac++;
		XtSetValues(dialog,al,ac);	
		XtManageChild(dialog);
		break;
	}      
}

#ifdef ISFOCUS
	/* Show telescope focus in microns relative to startup position */
	void show_focus(void)
	{
		XmString xmstr;
		Arg al[10];
		int ac;
		int telfocusmicrons;

		GetFocus(&telfocus);
		telfocusmicrons  = (int) telfocus;
		sprintf(buf, "%06d", telfocusmicrons);
		xmstr = XmStringCreateLocalized(buf);
		ac=0;
		XtSetArg(al[ac],XmNlabelString,xmstr); ac++;
		XtSetValues(focus_count_label,al,ac);
		XmStringFree(xmstr);
	}

	/* Show telescope temperature in Celsius in the message window */
	void show_temperature(void)
	{
		GetTemperature(&teltemperature);
		sprintf(strMsgLine,"Primary temperature %2.1f C\n",teltemperature);
		setMessage( strMsgLine);
	}    
#endif

/* Start telescope communications */
void link_telescope()
{
	if (ConnectTel(mnt.telport))
	{
		if (CheckInfoTel(&mnt))
		{
			#ifdef LX200AST_H
				if (mnt.motver[0] == '0')
				{
					//Disregard prefs.tel when this happens
					fandisabled = 1;
					heaterdisabled = 1;
					focusdisabled = 1;
				}
			#endif
			//sprintf(strMsgLine,"Telescope type: %u\n",mnt.teltype);
			//setMessage(strMsgLine);
			mnt.tellink=CheckConnectTel();
			apply_config();			

			if (CheckInitTel(&mnt))
			{
				/* Connection diagnostics displayed in message window and updated in menu */
				sprintf(strMsgLine,"The telescope is connected to %s\n",mnt.telport);
				setMessage( strMsgLine);
	
				/* Select the startup states already marked on the control panel */
				/* Set the slew speed togglebutton to the startup state */
				#ifndef LX200AST_H
					XmToggleButtonSetState (toggle[2], TRUE, TRUE);
					//SetRate(&mnt, FIND7);
				#else
					XmToggleButtonSetState (toggle[3], TRUE, TRUE);
					//SetRate(&mnt, FIND6);
				#endif

				/* Set the track speed togglebutton to the startup state */
				XmToggleButtonSetState (toggleT[0], TRUE, TRUE);
				//mnt.trkspd = SIDEREAL;
				//SetTrkSpd(&mnt, mnt.trkspd);
				
				XtVaSetValues (guidespin_r, XmNposition, mnt.guideratera, NULL);
				XtVaSetValues (guidespin_d, XmNposition, mnt.guideratedec, NULL);

				#ifdef ISFAN
					if (!fandisabled)
					{  
						Fan(fancmd);
					}
				#endif
				#ifdef ISHEATER
					if (!heaterdisabled)
					{
						Heater(heatercmd);
					}
				#endif
				#ifdef ISFOCUS
					if (!focusdisabled)
					{
						Focus(focuscmd,focusspd);
					}
				#endif
		
				/* Retrieve and display telescope pointing information */ 
				fetch_telescope_coordinates();
				if (!errflag)
				{ 
					target[0].ra = telpos[0].ra;
					target[0].dec = telpos[0].dec;
					target[0].mag = telpos[0].mag;  
					target[0].j2kra = telpos[0].j2kra;
					target[0].jpmra = telpos[0].jpmra;
					target[0].j2kdec = telpos[0].j2kdec;
					target[0].jpmdec = telpos[0].jpmdec;
					target[0].abspos = telpos[0].abspos;
					show_telescope_coordinates();
					mark_fifo_telescope();
					show_target_coordinates();

					/* Diagnostics to test software */
					TestAlgorithms(strMsgLine);
					setMessage( strMsgLine);
				}
			}
			else
			{
				/* Connection diagnostics displayed in message window and updated in menu */
				sprintf(strMsgLine,"Telescope init not fully ok\n");
				setMessage( strMsgLine);
			}
		}
		else
		{
			/* Connection diagnostics displayed in message window and updated in menu */
			if (CheckConnectTel())
			{
				sprintf(strMsgLine,"Closing connection\n");
				setMessage( strMsgLine);
				unlink_telescope();
			}
			else
			{
				sprintf(strMsgLine,"The telescope controller is not responding\n");
				setMessage( strMsgLine);
			}
		}
	}
	else
	{
		/* Connection diagnostics displayed in message window and updated in menu */
		sprintf(strMsgLine,"The telescope controller is not available on %s\n",mnt.telport);
		setMessage( strMsgLine);
	}
}

/* Stop telescope communications */
void unlink_telescope()          
{
	char *text;

	if (DisconnectTel(&mnt))
	{
		reset_telescope();
		set_init_config();
		read_config();
		if ((text = XmTextGetString (txtserport)))
		{
			strcpy(mnt.telport, text);
			XtFree (text);
		}		
		apply_config();
		log_status();	
	}
}

void apply_config(void)
{
	XmString xms;
	int ac;
	Arg al[10];
	char tmpstr[MAXPATHLEN];
	int j;

	if (mnt.tellink)
	{
		/* When telescope is connected read config is disabled */
		XtSetSensitive(newconfig_item, False);

		xms = XmStringCreateLocalized("Disconnect");
		XtVaSetValues (command[CMD_CONNECT], XmNlabelString, xms, NULL);
		XtSetSensitive(txtserport, False);
		XmStringFree(xms);

		//XtUnmanageChild(telsite_item);
		XtSetSensitive(telsite_item, False);		
	}
	else
	{
		/* When telescope is dis-connected read config is enabled */
		XtSetSensitive(newconfig_item, True);

		xms = XmStringCreateLocalized("Connect");
		XtVaSetValues (command[CMD_CONNECT], XmNlabelString, xms, NULL); 
		XtSetSensitive(txtserport,True);
		XtVaSetValues(txtserport, XmNvalue, mnt.telport, NULL);
		XmStringFree(xms);

		//XtManageChild(telsite_item);
		XtSetSensitive(telsite_item, True);

		if (mnt.modfeat[FLHORIZ])
		{
			sprintf(strMsgLine, "HorizonFile: %s\n", horizonfile);
			setMessage(strMsgLine);
		}
	}

	/* Disable buttons that are set to disabled */
	XmToggleButtonSetState (opteqaz, (mnt.teltype > 0), FALSE);		
	if (mnt.teltype == GEM)
	{
		XtSetSensitive(opteqaz,FALSE);
	}
	else if (mnt.teltypefixed)
	{
		XtSetSensitive(opteqaz,FALSE);
	}
	else 
	{
		XtSetSensitive(opteqaz,TRUE);
	}
	SetMountMode(&mnt, mnt.teltype);
	
	if (strlen(mnt.desc) > 0)
	{
		ac = 0;
		XtSetArg(al[ac],XmNlabelString, XmStringCreateLocalized(mnt.desc)); ac++;
		XtSetValues(lblteldata, al, ac);
	}
	else
	{
		ac = 0;
		XtSetArg(al[ac],XmNlabelString, XmStringCreateLocalized("Not connected")); ac++;
		XtSetValues(lblteldata, al, ac);
	}
	
	if (mnt.polarfixed)
	{
		XtUnmanageChild(telpole_item);
		XtUnmanageChild(telsky_item);
	}
	else
	{
		XtManageChild(telpole_item);
		XtManageChild(telsky_item);
	}
	
	#ifdef ISLEVEL
		if (mnt.modfeat[FLLEVEL]) 
		{
			XtManageChild(tellevel_item);
		}
		else
		{
			XtUnmanageChild(tellevel_item);
		}
	#endif	
	#ifdef ISFOCUS
		/* Disable menu items that are set to disabled */
		if ( focusdisabled  || !mnt.modfeat[FLFOCUS])
		{
			XtUnmanageChild(telfocus_item);
		} 
		else
		{
			XtManageChild(telfocus_item);
		}
	#endif
	#ifdef ISFAN
		if ( fandisabled || !mnt.modfeat[FLFAN])
		{
			XtUnmanageChild(telfan_item);
		} 
		else
		{
			XtManageChild(telfan_item);
		}
	#endif
	#ifdef ISHEATER
		if ( heaterdisabled || !mnt.modfeat[FLHEATER])
		{
			XtUnmanageChild(telheater_item);
		}
		else
		{
			XtManageChild(telheater_item);
		}
	#endif

	if (mnt.modfeat[FLHORIZ])
	{
		XmToggleButtonSetState(p_options_toggle_64, True, False);
	}
	else
	{
		XmToggleButtonSetState(p_options_toggle_64, False, False);
	}

	//if ()
	//{
	//	XtSetSensitive(command[CMD_SPIRAL], TRUE);
	//}
	//else
	//{
		XtSetSensitive(command[CMD_SPIRAL], FALSE);
	//}
	#ifndef LX200AST_H
		if (mnt.quietslew || !mnt.modfeat[FLMAXSLW])
		{
			XtSetSensitive(toggle[0], FALSE);
			XtSetSensitive(toggle[1], FALSE);
		}
		else
		{
			XtSetSensitive(toggle[0], TRUE);
			XtSetSensitive(toggle[1], TRUE);
		}
	#else
		// For LX200 the HC takes care of this once set
		XtSetSensitive(toggle[1], FALSE);
		XtSetSensitive(toggle[2], FALSE);
		XtSetSensitive(toggle[4], FALSE);
		XtSetSensitive(toggle[5], FALSE);
		XtSetSensitive(toggle[7], FALSE);
	#endif
	
	if (mnt.modfeat[FLTRACK])
	{
		XtSetSensitive(command[CMD_TRACK],TRUE);		
		XtSetSensitive(command[CMD_STOP],TRUE);
		xms = XmStringCreateLocalized("Sleep");
		XtVaSetValues (command[CMD_SAVE], XmNlabelString, xms, NULL); 
		xms = XmStringCreateLocalized("Wake");
		XtVaSetValues (command[CMD_RECALL], XmNlabelString, xms, NULL); 
		XmStringFree(xms);
		XtSetSensitive(toggleT[1], TRUE);
		XtSetSensitive(toggleT[2], TRUE);
	}
	else
	{
		XtSetSensitive(command[CMD_TRACK],FALSE);		
		XtSetSensitive(command[CMD_STOP],FALSE);
		xms = XmStringCreateLocalized("Save");
		XtVaSetValues (command[CMD_SAVE], XmNlabelString, xms, NULL); 
		xms = XmStringCreateLocalized("Recall");
		XtVaSetValues (command[CMD_RECALL], XmNlabelString, xms, NULL); 
		XmStringFree(xms);
		XtSetSensitive(toggleT[1], FALSE);
		XtSetSensitive(toggleT[2], FALSE);
	}
	
	if (mnt.modfeat[FLGRATE])
	{
		XtSetSensitive(guidespin_box,TRUE);				
	}
	else
	{
		XtSetSensitive(guidespin_box,FALSE);				
	}
	
	if (wpipedisabled)
	{
		XtSetSensitive(command[CMD_MARKTEL],FALSE);		
		XtSetSensitive(command[CMD_MARKTGT],FALSE);
	}
	
	//Calculate correct path if implicit user home is in use
	strcpy(defaultpath, replace(defaultpath, "~", ptrhome));

	/* Reset default open files dialogs */
	strcpy(tmpstr, defaultpath);
	sprintf(strMsgLine, "Queue/HistoryDir: %s\n", tmpstr);
	setMessage(strMsgLine);
	ac=0;
	XtSetArg(al[ac],XmNdirectory, XmStringCreateLocalized(tmpstr)); ac++;
	XtSetValues(read_file, al, ac);
	XtSetValues(save_file, al, ac);

	strcpy(configfile, replace(configfile, "~", ptrhome));
	j = strcrspn(configfile, "/");
	strncpy(tmpstr, configfile, j);
	tmpstr[j] = '\0';
	sprintf(strMsgLine, "ConfigDir: %s\n", tmpstr);
	setMessage(strMsgLine);
	sprintf(strMsgLine, "ConfigFile: %s\n", configfile);
	setMessage(strMsgLine);
	ac=0;
	XtSetArg(al[ac],XmNdirectory, XmStringCreateLocalized(tmpstr)); ac++;
	XtSetValues(read_configfile, al, ac);
	
	//Calculate correct path if implicit user home is in use
	strcpy(fifo_in, replace(fifo_in, "~", ptrhome));
	strcpy(fifo_out, replace(fifo_out, "~", ptrhome));

	if ( toolsmenudisabled )
	{
		XtUnmanageChild(tools_cascade);
	}
	else
	{
		XtManageChild(tools_cascade);
	}
}

void reset_telescope()
{
	int i = 0;
	
	// Initial telescope set
	strcpy(mnt.telport,TELSERIAL);     				/* Serial port if needed */
	mnt.tellink = FALSE;     						/* telescope connection flag */
	mnt.modcod[0] = '\0';
	reset_features();
	mnt.desc[0] = '\0';
	mnt.hcver[0] = '\0';
	mnt.motver[0] = '\0';
	mnt.teltype = TELTYPE;							/* See header */
	mnt.telmode = TELTYPE;							/* See header */
	mnt.telspd = FIND7;								/* drive speed */
	mnt.trkspd = SIDEREAL;							/* tracking speed */
	mnt.trkStatus = 0;								/* Track status, default to no tracking */
	mnt.trkActive = mnt.trkStatus;					/* Track status, default to no tracking */
	mnt.homeha = mnt.homeha;						/* Startup HA */
	mnt.homedec = mnt.homedec;						/* Startup Dec */
	mnt.homefixed = 0;								/* Disable tel type home default when set in pref file*/
	mnt.parkha = mnt.parkha;						/* Park telescope at this HA */
	mnt.parkdec = mnt.parkdec;						/* Park telescope at this Dec */
	mnt.parkfixed = 0;								/* Disable tel type park default when set in pref file*/
	mnt.offsetabsra = 0;								// Angular offsets for absolute positions
	mnt.offsetabsdec = 0;
	mnt.SiteLatitude = LATITUDE;        			/* Latitude in degrees + north */  
	mnt.SiteLongitude = LONGITUDE;      			/* Longitude in degrees + east */  
	mnt.SiteAltitude = ALTITUDE;        			/* Altitude in meters */
	mnt.SitePressure = PRESSURE;        			/* Atmospheric pressure in Torr */
	mnt.SiteTemperature = TEMPERATURE; 				/* Local atmospheric temperature in C */
	mnt.offsetra = 0.;
	mnt.offsetdec = 0.;
	mnt.polaraz = 0.;
	mnt.polaralt = 0.;
	mnt.polarfixed = 0;
	mnt.decaxis = 0.;
	mnt.optew = 0.;
	mnt.optns = 0.;
	mnt.flexure = 0.;
	mnt.slewtolha = SLEWTOLHA;
	mnt.slewtoldec = SLEWTOLDEC;
	mnt.slewtolfixed = 0;
	mnt.basis = 1;							/* Used in pointing.c for GEM flip meridian management Set in protocol.c according to goto*/
	mnt.level = 0;							/* Flag indicating mount has level function set to 0 if levelling is not supported in firmware  */
	mnt.align = 0;							/* Flag indicating mount has been sky sligned (negative values are the align process next step */
	mnt.quietslew = QUIETSLEW;				/* Flag for quiet, limited speed, slower slew */
	mnt.guideratera = 0;
	mnt.guideratedec = 0;
	
	// neutral horizon
	for (i = 0; i < 36; i++)
	{
		mnt.horizon[i][0] = i * 10; 
		mnt.horizon[i][1] = 0; 
		mnt.horizon[i][2] = 90; 
	}
	
	mnt.axralimits[0] = AXRALOW;			/* Ra axis rotation limit, also for GEM */
	mnt.axralimits[1] = AXRAHIGH;			/* Ra axis rotation limit, also for GEM */
	
	SetMountDefaultHome(&mnt);
}

void reset_features()
{
	/* Features enable multiflag */
	mnt.modfeat[FLTRACK] = 1;
	mnt.modfeat[FLSITE] = 1;
	mnt.modfeat[FLGRATE] = 1;
	mnt.modfeat[FLPGUIDE] = 1;
	mnt.modfeat[FLFOCUS] = 1;
	mnt.modfeat[FLFAN] = 1;
	mnt.modfeat[FLHEATER] = 1;
	mnt.modfeat[FLROTAT] = 1;
	mnt.modfeat[FLRETIC] = 1;
	mnt.modfeat[FLMAXSLW] = 1;
	mnt.modfeat[FLLEVEL] = 0;
	mnt.modfeat[FLHORIZ] = 0;
	mnt.modfeat[FLCLOSE] = '\0';
}

void reset_site()
{
	// Initial telescope set
	strcpy(gps.gpsport, mnt.telport);   			/* Serial port if needed */
	gps.gpslink = FALSE;     						/* telescope connection flag */
	gps.SiteLatitude = mnt.SiteLatitude;   			/* Latitude in degrees + north */  
	gps.SiteLongitude = mnt.SiteLongitude;      	/* Longitude in degrees + east */  
	gps.SiteAltitude = mnt.SiteAltitude;			/* Altitude in meters */
	gps.SitePressure = mnt.SitePressure;        	/* Atmospheric pressure in Torr */
	gps.SiteTemperature = mnt.SiteTemperature; 		/* Local atmospheric temperature in C */
	gps.gpsHDOP = 0;							    /* Horizontal DOP value */
	gps.gpsvalid = 0;								/* Flag for valid data received */
	gps.gpssats = 0;								/* Number of satellites used */		
	gps.gpsHDOPrating[0] = '\0';					/* Precision comment based on HDOP value */
}

void set_site()
{
	char value[64];
	
	strcpy(value, "Sat: ");
	sprintf(value+5, "%d ", gps.gpssats);
	strcat(value, "HDOP: ");
	strcat(value, gps.gpsHDOPrating);
	XtVaSetValues (site_lblaux, XmNlabelString, XmStringCreateLocalized(value), NULL);

	sprintf(value, "%+010.5f", gps.SiteLongitude);
	XtVaSetValues (site_Longitude_n, XmNvalue, value, NULL);
	sprintf(value, "%+09.5f", gps.SiteLatitude);
	XtVaSetValues (site_Latitude_n, XmNvalue, value, NULL);
	sprintf(value, "%+07.1f", gps.SiteAltitude);
	XtVaSetValues (site_Altitude, XmNvalue, value, NULL);
	sprintf(value, "%+04d", gps.TimeDifference);
	XtVaSetValues (site_TimeDifference, XmNvalue, value, NULL);
}

void set_tel_site()
{
	mnt.SiteLongitude = gps.SiteLongitude;
	mnt.SiteLatitude = gps.SiteLatitude;
	mnt.SiteAltitude = gps.SiteAltitude;
	mnt.SiteTemperature = gps.SiteTemperature;
	mnt.SitePressure = gps.SitePressure;
	setMessage("Site parameters reset as follows:\n");
	sprintf(strMsgLine,"Site longitude: %lf\n",mnt.SiteLongitude);
	setMessage(strMsgLine);
	sprintf(strMsgLine,"Site latitude: %lf\n",mnt.SiteLatitude);
	setMessage(strMsgLine);
	sprintf(strMsgLine,"Site altitude: %lf\n",mnt.SiteAltitude);
	setMessage(strMsgLine);
	sprintf(strMsgLine,"Site pressure: %lf\n",mnt.SitePressure);
	setMessage(strMsgLine);
	sprintf(strMsgLine,"Site temperature: %lf\n",mnt.SiteTemperature);
	setMessage(strMsgLine);
}

void log_status()
{
	char tmpHour[10];
	double tmpVal;
	
	setMessage( "-----------------------------------\n");
	sprintf(strMsgLine,"XMtelRemote version: %s\n", XMTEL2VER);
	setMessage( strMsgLine);
	setMessage("System status:\n");
	if (mnt.teltypefixed)
	{
		sprintf(strMsgLine,"Custom telescope mounting type: %u\n",mnt.teltype);
		setMessage(strMsgLine);
		sprintf(strMsgLine,"Custom telescope mounting mode: %u\n",mnt.telmode);
		setMessage(strMsgLine);
	}
	else
	{
		sprintf(strMsgLine,"Telescope mounting type: %u\n",mnt.teltype);
		setMessage(strMsgLine);
		sprintf(strMsgLine,"Telescope mounting mode: %u\n",mnt.telmode);
		setMessage(strMsgLine);
	}
	sprintf(strMsgLine,"Telescope serial port set to: %s\n",mnt.telport);
	setMessage(strMsgLine);
	if (mnt.homefixed)
	{
		sprintf(strMsgLine,"Custom home HA: %lf\n",mnt.homeha);
		setMessage(strMsgLine);
		sprintf(strMsgLine,"Custom home Dec: %lf\n",mnt.homedec);
		setMessage(strMsgLine);
	}
	else
	{
		sprintf(strMsgLine,"Home HA: %lf\n",mnt.homeha);
		setMessage(strMsgLine);
		sprintf(strMsgLine,"Home Dec: %lf\n",mnt.homedec);
		setMessage(strMsgLine);
	}
	if (mnt.parkfixed)
	{
		sprintf(strMsgLine,"Custom park HA: %lf\n",mnt.parkha);
		setMessage(strMsgLine);
		sprintf(strMsgLine,"Custom park Dec: %lf\n",mnt.parkdec);
		setMessage(strMsgLine);
	}
	else
	{
		sprintf(strMsgLine,"Park HA: %lf\n",mnt.parkha);
		setMessage(strMsgLine);
		sprintf(strMsgLine,"Park Dec: %lf\n",mnt.parkdec);
		setMessage(strMsgLine);
	}
	if (mnt.polarfixed)
	{
		sprintf(strMsgLine,"Custom polar azimuth: %lf\n",mnt.polaraz);
		setMessage(strMsgLine);
		sprintf(strMsgLine,"Custom polar altitude: %lf\n",mnt.polaralt);
		setMessage(strMsgLine);
	}
	else
	{
		sprintf(strMsgLine,"Polar azimuth: %lf\n",mnt.polaraz);
		setMessage(strMsgLine);
		sprintf(strMsgLine,"Polar altitude: %lf\n",mnt.polaralt);
		setMessage(strMsgLine);
	}
	if (mnt.modfeat[FLHORIZ])
	{
		sprintf(strMsgLine,"Telescope horizon in use: %s\n", horizonfile);
	}
	else
	{
		sprintf(strMsgLine,"Telescope horizon not in use\n");
	}
	setMessage(strMsgLine);
	sprintf(strMsgLine,"Ra axis limits: %+d to %+d\n", mnt.axralimits[0], mnt.axralimits[1]);
	setMessage(strMsgLine);
	sprintf(strMsgLine,"Offset in right ascension: %lf\n",mnt.offsetra);
	setMessage(strMsgLine);
	sprintf(strMsgLine,"Offset in declination: %lf\n",mnt.offsetdec);
	setMessage(strMsgLine);
	sprintf(strMsgLine,"Optical EW skew: %lf\n",mnt.optew);
	setMessage(strMsgLine);
	sprintf(strMsgLine,"Optical NS skew: %lf\n",mnt.optns);
	setMessage(strMsgLine);
	sprintf(strMsgLine,"OTA flexure: %lf\n",mnt.flexure);
	setMessage(strMsgLine);
	if (mnt.slewtolfixed)
	{
		sprintf(strMsgLine,"Custom slew HA tolerance: %lf\n",mnt.slewtolha);
		setMessage(strMsgLine);
		sprintf(strMsgLine,"Custom slew DEC tolerance: %lf\n",mnt.slewtoldec);
		setMessage(strMsgLine);
	}
	else
	{
		sprintf(strMsgLine,"Slew HA tolerance: %lf\n",mnt.slewtolha);
		setMessage(strMsgLine);
		sprintf(strMsgLine,"Slew DEC tolerance: %lf\n",mnt.slewtoldec);
		setMessage(strMsgLine);
	}
	sprintf(strMsgLine,"Quiet slew: %u\n",mnt.quietslew);
	setMessage(strMsgLine);
	sprintf(strMsgLine,"Site longitude: %lf\n",mnt.SiteLongitude);
	setMessage(strMsgLine);
	sprintf(strMsgLine,"Site latitude: %lf\n",mnt.SiteLatitude);
	setMessage(strMsgLine);
	sprintf(strMsgLine,"Site altitude: %lf\n",mnt.SiteAltitude);
	setMessage(strMsgLine);
	sprintf(strMsgLine,"Site pressure: %lf\n",mnt.SitePressure);
	setMessage(strMsgLine);
	sprintf(strMsgLine,"Site temperature: %lf\n",mnt.SiteTemperature);
	setMessage(strMsgLine);
	#ifdef ISFAN
		sprintf(strMsgLine,"Fan disable: %u\n",fandisabled);
		setMessage(strMsgLine);
	#endif		
	#ifdef ISHEATER
		sprintf(strMsgLine,"Heater disable: %u\n",heaterdisabled);
		setMessage(strMsgLine);
	#endif
	#ifdef ISFOCUS
		sprintf(strMsgLine,"Focus disable: %u\n",focusdisabled);
		setMessage(strMsgLine);
	#endif
	sprintf(strMsgLine,"Read pipe disable: %u\n",rpipedisabled);
	setMessage(strMsgLine);
	sprintf(strMsgLine,"Fifo path input: %s\n",fifo_in);
	setMessage(strMsgLine);
	sprintf(strMsgLine,"Write pipe disable: %u\n",wpipedisabled);
	setMessage(strMsgLine);
	sprintf(strMsgLine,"Fifo path output: %s\n",fifo_out);
	setMessage(strMsgLine);
	sprintf(strMsgLine,"Xmtel Editor: %s\n",editor);
	setMessage(strMsgLine);
	sprintf(strMsgLine,"Xmtel AutoConnect: %u\n",autoconnect);
	setMessage(strMsgLine);
	tmpVal = Map24(LSTNow(mnt.SiteLongitude));
	dtodms(tmpHour, &tmpVal);
	sprintf(strMsgLine, "Local Sidereal Time: %s\n", tmpHour);
	setMessage( strMsgLine);
	tmpVal = UTNow();
	dtodms(tmpHour, &tmpVal);
	sprintf(strMsgLine, "Local Universal Time: %s\n", tmpHour);
	setMessage( strMsgLine);
	sprintf(strMsgLine, "Julian date time: %f\n", JDNow());
	setMessage( strMsgLine);
	if (mnt.trkActive)
	{
		setMessage( "Mount is tracking\n");
	}
	else
	{
		setMessage( "Mount is stopped\n");
	}
	setMessage( "-----------------------------------\n\n");
}
       
/* Start fifo links */
void link_fifos()
{  
	if (!rpipedisabled)
	{
		sprintf(strMsgLine, "Opening pipe %s\n", fifo_in);
		setMessage( strMsgLine);
		fd_fifo_in = open(fifo_in, O_RDWR | O_NONBLOCK);
		setMessage( "Adding input event\n");
	  	fifoinput = XtAppAddInput (context, fd_fifo_in, (XtPointer)XtInputReadMask, read_edb_fifo, NULL);          
	}

	if (!wpipedisabled)
	{
		sprintf(strMsgLine, "Opening pipe %s\n", fifo_out);
		setMessage( strMsgLine);
		fd_fifo_out = open(fifo_out, O_RDWR | O_NONBLOCK);
	}
}


/* Stop fifo links */
void unlink_fifos()
{
	if (!rpipedisabled)
	{
		/* Dis-Connect to XEphem's goto fifo */
		setMessage( "Removing input event\n");
	  	//XtRemoveInput (fifoinput);    
		sprintf(strMsgLine, "Closing pipe %s\n", fifo_in);
		setMessage( strMsgLine);
	  	rpipedisabled = 1;
		close(fd_fifo_in);
	}
	if (!wpipedisabled)
	{
		sprintf(strMsgLine, "Closing pipe %s\n", fifo_out);
		setMessage( strMsgLine);
		wpipedisabled = 1;
		close(fd_fifo_out);  
	}
}

// Com aid
int  comfailCB()
{
	int retval = 0;
	XmString xms;
		
	if ((retval = msgbox(toplevel, "Telescope comunication has failed several times\nDo you want to retry?", MSGYESNO, "Com error!")) == 0)
	{
		xms = XmStringCreateLocalized("Re-Connect");
		XtVaSetValues (command[CMD_CONNECT], XmNlabelString, xms, NULL);
		XmStringFree(xms);
	}
	return (retval);
}

/* Read and parse the initial configuration file */
/* Will override defaults for                    */
/*                                               */
/*   mnt.polaraz                                 */
/*   mnt.polaralt                                */
/*   offsetra                                    */
/*   mnt.offsetdec                               */
/*   latitude                                    */
/*   longitude                                   */
/*   altitude                                    */
/*   pressure                                    */
/*   temperature                                 */
/*   mnt.parkha                                  */
/*   mnt.parkdec                                 */
/*   telport                                     */
void read_config(void)
{
	char configstr[121];
	char *configptr = configstr;
	int n;

	if (strlen(configfile))
	{
		fp_file = fopen(configfile, "r");

		if ( fp_file == NULL )
		{
			setMessage("New telescope configuration not found\n");
			setMessage("Using default telescope parameters\n");
			return;
		}
		else
		{
			setMessage("Telescope and site parameters redefined\n");
		}

		while ( configstr == fgets(configstr,80,fp_file) )
		{
			if (configstr[0] != '*')
			{
				configptr = strstr(configstr,"tel.mount");
				if ( configptr != NULL)
				{
					configptr = strstr(configstr,"=");
					if ( configptr != NULL)
					{
						configptr = configptr + 1;
						sscanf(configptr,"%u",&mnt.teltype);
						mnt.teltypefixed = 1;
					}
				}

				configptr = strstr(configstr,"tel.serial");
				if ( configptr != NULL)
				{
					configptr = strstr(configstr,"=");
					if ( configptr != NULL)
					{
						configptr = configptr + 1;
						strncpy(mnt.telport,configptr,30);
						n = strlen(mnt.telport);
						if (n>0)
						{
							mnt.telport[n-1]='\0';
						}  
					}
				}

				configptr = strstr(configstr,"tel.homeha");
				if ( configptr != NULL)
				{
					configptr = strstr(configstr,"=");
					if ( configptr != NULL)
					{
						configptr = configptr + 1;
						sscanf(configptr,"%lf",&mnt.homeha);
						mnt.homefixed = 1;
					}  
				}

				configptr = strstr(configstr,"tel.homedec");
				if ( configptr != NULL)
				{
					configptr = strstr(configstr,"=");
					if ( configptr != NULL)
					{
						configptr = configptr + 1;
						sscanf(configptr,"%lf",&mnt.homedec);
						mnt.homefixed = 1;
					}  
				}

				configptr = strstr(configstr,"tel.parkha");
				if ( configptr != NULL)
				{
					configptr = strstr(configstr,"=");
					if ( configptr != NULL)
					{
						configptr = configptr + 1;
						sscanf(configptr,"%lf",&mnt.parkha);
						mnt.parkfixed = 1;
					}  
				}

				configptr = strstr(configstr,"tel.parkdec");
				if ( configptr != NULL)
				{
					configptr = strstr(configstr,"=");
					if ( configptr != NULL)
					{
						configptr = configptr + 1;
						sscanf(configptr,"%lf",&mnt.parkdec);
						mnt.parkfixed = 1;
					}  
				}    

				configptr = strstr(configstr,"tel.polaraz");
				if ( configptr != NULL)
				{
					configptr = strstr(configstr,"=");
					if ( configptr != NULL)
					{
						configptr = configptr + 1;
						sscanf(configptr,"%lf",&mnt.polaraz);
						mnt.polarfixed = 1;
					}  
				}

				configptr = strstr(configstr,"tel.polaralt");
				if ( configptr != NULL)
				{
					configptr = strstr(configstr,"=");
					if ( configptr != NULL)
					{
						configptr = configptr + 1;
						sscanf(configptr,"%lf",&mnt.polaralt);      
						mnt.polarfixed = 1;
					}  
				} 

				configptr = strstr(configstr,"tel.optew");
				if ( configptr != NULL)
				{
					configptr = strstr(configstr,"=");
					if ( configptr != NULL)
					{
						configptr = configptr + 1;
						sscanf(configptr,"%lf",&mnt.optew);      
					}
				}         

				configptr = strstr(configstr,"tel.optns");
				if ( configptr != NULL)
				{
					configptr = strstr(configstr,"=");
					if ( configptr != NULL)
					{
						configptr = configptr + 1;
						sscanf(configptr,"%lf",&mnt.optns);      
					}
				} 

				configptr = strstr(configstr,"tel.flexure");
				if ( configptr != NULL)
				{
					configptr = strstr(configstr,"=");
					if ( configptr != NULL)
					{
						configptr = configptr + 1;
						sscanf(configptr,"%lf",&mnt.flexure);      
					}
				} 

				configptr = strstr(configstr,"tel.decaxis");
				if ( configptr != NULL)
				{
					configptr = strstr(configstr,"=");
					if ( configptr != NULL)
					{
						configptr = configptr + 1;
						sscanf(configptr,"%lf",&mnt.decaxis);
					}
				}

				configptr = strstr(configstr,"tel.slewtolha");
				if ( configptr != NULL)
				{
					configptr = strstr(configstr,"=");
					if ( configptr != NULL)
					{
						configptr = configptr + 1;
						sscanf(configptr,"%lf",&mnt.slewtolha);
						mnt.slewtolfixed = 1;
					}
				}

				configptr = strstr(configstr,"tel.slewtoldec");
				if ( configptr != NULL)
				{
					configptr = strstr(configstr,"=");
					if ( configptr != NULL)
					{
						configptr = configptr + 1;
						sscanf(configptr,"%lf",&mnt.slewtoldec);
						mnt.slewtolfixed = 1;
					}
				}

				configptr = strstr(configstr,"tel.quietslew");
				if ( configptr != NULL)
				{
					configptr = strstr(configstr,"=");
					if ( configptr != NULL)
					{
						configptr = configptr + 1;
						sscanf(configptr,"%u",&mnt.quietslew);
					}
				}

				configptr = strstr(configstr,"tel.horizonfile");
				if ( configptr != NULL)
				{
					configptr = strstr(configstr,"=");
			 		if ( configptr != NULL)
					{
						configptr = configptr + 1;
						strncpy(horizonfile,configptr,MAXPATHLEN);
						strcpy(horizonfile, replace(horizonfile, "\n", "\0"));

					}
				} 

				configptr = strstr(configstr,"tel.horizondisabled");
				if ( configptr != NULL)
				{
					configptr = strstr(configstr,"=");
					if ( configptr != NULL)
					{
						configptr = configptr + 1;
						sscanf(configptr,"%u",&horizondisabled);
					}
				} 

				configptr = strstr(configstr,"tel.axralimits");
				if ( configptr != NULL)
				{
					configptr = strstr(configstr,"=");
					if ( configptr != NULL)
					{
						configptr = configptr + 1;
						sscanf(configptr, "%d;%d", &mnt.axralimits[0], &mnt.axralimits[1]);
					}
				} 

				configptr = strstr(configstr,"site.longitude");
				if ( configptr != NULL)
				{
					configptr = strstr(configstr,"=");
					if ( configptr != NULL)
					{
						configptr = configptr + 1;
						sscanf(configptr,"%lf",&mnt.SiteLongitude);
					}
				} 

				configptr = strstr(configstr,"site.latitude");
				if ( configptr != NULL)
				{
					configptr = strstr(configstr,"=");
					if ( configptr != NULL)
					{
						configptr = configptr + 1;
						sscanf(configptr,"%lf",&mnt.SiteLatitude);
					}
				}

				configptr = strstr(configstr,"site.altitude");
				if ( configptr != NULL)
				{
					configptr = strstr(configstr,"=");
					if ( configptr != NULL)
					{
						configptr = configptr + 1;
						sscanf(configptr,"%lf",&mnt.SiteAltitude);
					}
				} 

				configptr = strstr(configstr,"site.pressure");
				if ( configptr != NULL)
				{
					configptr = strstr(configstr,"=");
					if ( configptr != NULL)
					{
						configptr = configptr + 1;
						sscanf(configptr,"%lf",&mnt.SitePressure);
					}
				} 

				configptr = strstr(configstr,"site.temperature");
				if ( configptr != NULL)
				{
					configptr = strstr(configstr,"=");
					if ( configptr != NULL)
					{
						configptr = configptr + 1;
						sscanf(configptr,"%lf",&mnt.SiteTemperature);
					}
				} 

				#ifdef ISFAN
					configptr = strstr(configstr,"fan.disabled");
					if ( configptr != NULL)
					{
						configptr = strstr(configstr,"=");
						if ( configptr != NULL)
						{
							configptr = configptr + 1;
							sscanf(configptr,"%u",&fandisabled);
						}
					} 
				#endif
				
				#ifdef ISHEATER
					configptr = strstr(configstr,"heater.disabled");
					if ( configptr != NULL)
					{
						configptr = strstr(configstr,"=");
						if ( configptr != NULL)
						{
							configptr = configptr + 1;
							sscanf(configptr,"%u",&heaterdisabled);
						}
					} 
				#endif

				#ifdef ISFOCUS
					configptr = strstr(configstr,"focus.disabled");
					if ( configptr != NULL)
					{
						configptr = strstr(configstr,"=");
						if ( configptr != NULL)
						{
							configptr = configptr + 1;
							sscanf(configptr,"%u",&focusdisabled);
						}
					} 
				#endif
				
				configptr = strstr(configstr,"toolsmenu.disabled");
				if ( configptr != NULL)
				{
					configptr = strstr(configstr,"=");
					if ( configptr != NULL)
					{
						configptr = configptr + 1;
						sscanf(configptr,"%u",&toolsmenudisabled);
					}
				} 
				
				configptr = strstr(configstr,"readpipe.disabled");
				if ( configptr != NULL)
				{
					configptr = strstr(configstr,"=");
					if ( configptr != NULL)
					{
						configptr = configptr + 1;
						sscanf(configptr,"%u",&rpipedisabled);
					}
				} 

				configptr = strstr(configstr,"readpipe.path");
				if ( configptr != NULL)
				{
					configptr = strstr(configstr,"=");
					if ( configptr != NULL)
					{
						configptr = configptr + 1;
						strncpy(fifo_in,configptr,MAXPATHLEN);
						strcpy(fifo_in, replace(fifo_in, "\n", "\0"));
					}
				} 

				configptr = strstr(configstr,"writepipe.disabled");
				if ( configptr != NULL)
				{
					configptr = strstr(configstr,"=");
					if ( configptr != NULL)
					{
						configptr = configptr + 1;
						sscanf(configptr,"%u",&wpipedisabled);
					}
				} 

				configptr = strstr(configstr,"writepipe.path");
				if ( configptr != NULL)
				{
					configptr = strstr(configstr,"=");
			 		if ( configptr != NULL)
					{
						configptr = configptr + 1;
						strncpy(fifo_out,configptr,MAXPATHLEN);
						strcpy(fifo_out, replace(fifo_out, "\n", "\0"));
					}
				} 

				configptr = strstr(configstr,"xmtel.editor");
				if ( configptr != NULL)
				{
					configptr = strstr(configstr,"=");
					if ( configptr != NULL)
					{
						configptr = configptr + 1;
						strncpy(editor,configptr,MAXPATHLEN);
						strcpy(editor, replace(editor, "\n", "\0"));
					}
				} 

				configptr = strstr(configstr,"xmtel.autoconnect");
				if ( configptr != NULL)
				{
					configptr = strstr(configstr,"=");
					if ( configptr != NULL)
					{
						configptr = configptr + 1;
						sscanf(configptr,"%u",&autoconnect);
					}
				} 

				configptr = strstr(configstr,"xmtel.defaultpath");
				if ( configptr != NULL)
				{
					configptr = strstr(configstr,"=");
					if ( configptr != NULL)
					{
						configptr = configptr + 1;
						strncpy(defaultpath,configptr,MAXPATHLEN);
						strcpy(defaultpath, replace(defaultpath, "\n", "\0"));
					}
				} 
			}
		}
		fclose(fp_file);
		errflag = FALSE;
		
		if (!horizondisabled)
		{
			mnt.modfeat[FLHORIZ] = 1;
			read_horizon();
			setMessage("Telescope horizon in use\n"); 			
		}
	}
	else
	{
		errflag= TRUE;
	}
}

void read_horizon(void)
{
	char configstr[121];
	char *configptr = configstr;
	int minh, maxh, i = 0;

	if (strlen(horizonfile))
	{
		fp_file = fopen(horizonfile, "r");

		if ( fp_file == NULL )
		{
			setMessage("Horizon configuration not found\nUsing default values\n");
			return;
		}
		else
		{
			setMessage("Telescope horizon loaded\n");
		}

		while ( configstr == fgets(configstr, 120, fp_file) )
		{
			if (configstr[0] != '*')
			{
				// This will reset only rows that are redefined
				sscanf(configptr,"%d,%d,%d", &i, &minh, &maxh);
				i /= 10;
				if (i > -1 && i < 36) 
				{
					mnt.horizon[i][1] = (minh > -1 && minh < 91) ? minh : 0; 
					mnt.horizon[i][2] = (maxh > -1 && maxh < 91) ? maxh : 90; 
				}
				//fprintf(stderr, "%d,%d,%d\n", mnt.horizon[i][0], mnt.horizon[i][1], mnt.horizon[i][2]);
			}
		}
		fclose(fp_file);
		errflag = FALSE;
	}
	else
	{
		errflag= TRUE;
	}
}

void set_target_park()
{
	double tmpra, tmpdec;
	
	strcpy(target[0].name,"Park");
	target[0].desc[0] = '\0';
	target[0].ra = Map24((LSTNow(mnt.SiteLongitude) - mnt.parkha));
	target[0].dec = mnt.parkdec;
	target[0].abspos = 1;
	tmpra = target[0].ra;
	tmpdec = target[0].dec;
	Apparent(&tmpra, &tmpdec, -1);
	target[0].j2kra = tmpra;
	target[0].jpmra = 0;						
	target[0].j2kdec = tmpdec;
	target[0].jpmdec = 0;						
	target[0].mag = -9999.;
	SetTrackStatus(&mnt, 0);
}

void set_target_home()
{
	double tmpra, tmpdec;
	
	strcpy(target[0].name, "Home");
	target[0].desc[0] = '\0';
	target[0].ra = Map24(LSTNow(mnt.SiteLongitude) - mnt.homeha);
	target[0].dec = mnt.homedec;
	target[0].abspos = 1;
	tmpra = target[0].ra;
	tmpdec = target[0].dec;
	Apparent(&tmpra, &tmpdec, -1);
	target[0].j2kra = tmpra;
	target[0].jpmra = 0;						
	target[0].j2kdec = tmpdec;
	target[0].jpmdec = 0;						
	target[0].mag = -9999.;						
}

void set_target_meridian()
{
	double tmpra, tmpdec;
	
	strcpy(target[0].name,"Meridian");
	target[0].desc[0] = '\0';
	target[0].ra = Map24(LSTNow(mnt.SiteLongitude));
	target[0].dec = 0; //telpos[0].dec;
	target[0].abspos = 0;
	tmpra = target[0].ra;
	tmpdec = target[0].dec;
	Apparent(&tmpra, &tmpdec, -1);
	target[0].j2kra = tmpra;
	target[0].jpmra = 0;						
	target[0].j2kdec = tmpdec;
	target[0].jpmdec = 0;						
	target[0].mag = -9999.;						
}

void set_target_zenith()
{
	double tmpra, tmpdec;
	
	strcpy(target[0].name,"Zenith");
	target[0].desc[0] = '\0';
	target[0].ra = Map24(LSTNow(mnt.SiteLongitude));
	target[0].dec = mnt.SiteLatitude;
	target[0].abspos = 0;
	tmpra = target[0].ra;
	tmpdec = target[0].dec;
	Apparent(&tmpra, &tmpdec, -1);
	target[0].j2kra = tmpra;
	target[0].jpmra = 0;						
	target[0].j2kdec = tmpdec;
	target[0].jpmdec = 0;						
	target[0].mag = -9999.;
}


