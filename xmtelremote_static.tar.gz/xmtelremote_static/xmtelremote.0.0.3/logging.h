#ifndef LOGGING_H
	#define LOGGING_H
	void getMessage(char *returnstr);
	void setMessage(char *setstr);
	void setOutput(int type);
#endif
