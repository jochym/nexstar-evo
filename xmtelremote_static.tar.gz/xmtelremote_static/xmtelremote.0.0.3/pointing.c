/*                                                                         */
/* Pointing Corrections for Telescope Control                              */
/*                                                                         */
/* Copyright 2008 John Kielkopf                                            */
/* kielkopf@louisville.edu                                                 */
/*                                                                         */
/* Distributed under the terms of the General Public License (see LICENSE) */
/*                                                                         */
/* Date: December 17, 2008                                                 */
/* Version: 1.3.2                                                          */
/*                                                                         */
/* History:                                                                */
/*                                                                         */
/*   March 26, 2006                                                        */
/*   Version 1.0                                                           */
/*                                                                         */
/*   June 16, 2007                                                         */
/*   Version 1.1                                                           */
/*   Included refraction routine here rather than in algorithms            */
/*   Modified structure to easily permit additional corrections            */
/*                                                                         */
/*   June 23, 2007                                                         */
/*   Version 1.2                                                           */
/*   Added correction for polar axis alignment                             */
/*   Requires external SiteLongitude and SiteLatitude                      */
/*   Requires external polaraz and polaralt                                */
/*                                                                         */
/*   August 25, 2008                                                       */
/*   Version 1.3 in development                                            */
/*   Offset correction implemented here rather than in main program        */
/*   Requires external offsetra and offsetdec                              */
/*                                                                         */
/*   September 12, 2008                                                    */
/*   Version 1.3 testing release                                           */
/*   Corrected equatorial-alt/az in algorithms package                     */
/*   Turned on for experimental testing in this released version:          */
/*     decaxis skew correction                                             */
/*     optical axis skew correction                                        */
/*     flexure correction                                                  */
/*   New: external parameter requirements                                  */
/*   Needed: procedure to define best parameters                           */
/*   Important: there will be errors here -- not all tested yet            */
/*                                                                         */
/*   September 27, 2008                                                    */
/*   Version 1.3                                                           */
/*   Offsets implemented in inditel and xmtel                              */
/*                                                                         */
/*   October 9, 2008                                                       */
/*   Version 1.3.1                                                         */     
/*   Corrected treatment of negative declinations near the pole            */
/*                                                                         */
/*   December 17, 2008                                                     */
/*   Version 1.3.2                                                         */     
/*   PointingFromTel roundoff error near pole trapped                      */
/*   PointingFromTel refraction implementation revised                     */
/*                                                                         */
/*   March 28, 2013                                                        */
/*   Changes to use pressure in mbar from mount structure                  */
/*                                                                         */
/* References:                                                             */
/*                                                                         */
/* Explanatory Supplement to the Astronomical Almanac                      */
/*  P. Kenneth Seidelmann, Ed.                                             */
/*  University Science Books, Mill Valley, CA, 1992                        */
/*                                                                         */
/* Astronomical Formulae for Calculators, 2nd Edition                      */
/*  Jean Meeus                                                             */
/*  Willmann-Bell, Richmond, VA, 1982                                      */
/*                                                                         */
/* Astronomical Algorithms                                                 */
/*  Jean Meeus                                                             */
/*  Willmann-Bell, Richmond, VA, 1991                                      */
/*                                                                         */
/* Telescope Control                                                       */
/*  Mark Trueblood and Russell Merle Genet                                 */
/*  Willmann-Bell, Richmond, VA, 1997                                      */
/*                                                                         */

#include <stdio.h>
#include <math.h>
#include "algorithms.h"
#include "pointing.h"

/* Telescope and observatory parameters */

/* Coordinate offsets: telescope coordinates + offset = real value */
/* If you point a telescope to ra,dec with offset turned on it will */
/*   really be pointing at ra+offsetra, dec+offsetdec */
/*   Offset correction is the last applied going from raw to target coordinates */
/*   It is the first applied going from target to raw pointing coordinates */

/* extern double offsetra;     Right ascension (hours) */
/* extern double offsetdec;     Declination (degrees) */

/* Mounting polar axis correction: from true pole to mount polar axis direction */
/* Parameter polaralt will be + if the mount is above the true pole */
/* Parmater polaraz will be + if the mount is east of the true pole */

/* extern double polaralt;      Altitude (degrees) */
/* extern double polaraz;       Azimuth (degrees) */

/* Mounting dec axis correction: from ideal axis to mount dec axis direction */

/* extern double decaxis;       Declination axis skew angle in degrees for + basis */
/* extern int    basis;          Flag indicating OTA flip for German mount */

/* Optical axis corrections: from mechanical axis to optical axis direction */

/* extern double optew;*/
/* extern double optns;*/

/* Flexure parameter is flexure in degrees for a 90 degree zenith distance */

/* extern double flexure;  */

/* Observatory coordinates */

/* extern double SiteLongitude;  */
/* extern double SiteLatitude;   */

/* Apply corrections to coordinates reported by the telescope */
/* Input telescope raw coordinates assumed zero corrected */
/* Return real coordinates corresponding to this raw point */
/* Implemented in order: polar, decaxis, optaxis, flexure, refract, offset */
/* Note that the order is reversed from that in PointingFromTel */

void PointingFromTel (mount *mnt, double *telra1, double *teldec1, double telra0, double teldec0, int pmodel)
{
	double tmpra, tmpha, tmpdec, tmplst;

	/* Find the LST for the pointing corrections and save it */
	/* Otherwise the lapsed time to do corrections affects the resultant HA and RA */

	tmplst = LSTNow(mnt->SiteLongitude);
	tmpra = telra0;
	tmpha = tmplst - tmpra;
	tmpha = Map12(tmpha);
	tmpdec = teldec0;
	  
	/* Correct for mounting misalignment */
	/* For dir = -1 returns the real pointing given the apparent pointing */

	if ( pmodel == (pmodel | POLAR) )
	{
		Polar( mnt, &tmpha,  &tmpdec, -1);
	} 

	/* Correct for dec axis not perpendicular to polar axis */
	/* For dir = -1 returns the real pointing given the apparent pointing */

	if ( pmodel == (pmodel | DECAXIS) )
	{
		Decaxis( mnt, &tmpha,  &tmpdec, -1);
	}  

	/* Correct for optical axis not coincident with mechanical axis  */
	/* For dir = -1 returns the real pointing given the apparent pointing */

	if ( pmodel == (pmodel | OPTAXIS) )
	{
		Optaxis( mnt, &tmpha,  &tmpdec, -1);
	} 

	/* Correct for OTA flexure  */
	/* For dir = -1 returns the real pointing given the apparent pointing */

	if ( pmodel == (pmodel | FLEXURE) )
	{
		Flexure( mnt, &tmpha,  &tmpdec, -1);
	} 

	/* Correct for atmospheric refraction */
	/* For dir = -1 returns the real pointing given the apparent pointing */

	if ( pmodel == (pmodel | REFRACT) )
	{
		Refraction( mnt, &tmpha,  &tmpdec, -1);
	}

	tmpra = tmplst - tmpha;

	/* Correct for offset */
	/* Offsets are defined as added to apparent pointing to give real pointing */

	if ( pmodel == (pmodel | OFFSET) )
	{
		tmpra = tmpra + mnt->offsetra;
		tmpdec = tmpdec + mnt->offsetdec;
	}

	/* Handle a case that has crossed the 24 hr mark */

	tmpra = Map24(tmpra);

	/* Handle a case that has gone over the south pole */
	/* Limit set to 0.0001 to avoid inadvertent trip on roundoff error */

	if (tmpdec < -90.0002)
	{
		tmpdec = -180. - tmpdec;
		tmpra = tmpra + 12.;
		Map24(tmpra); 
	}

	/* Handle a case that has gone over the north pole */  
	/* Limit set to 0.0002 to avoid inadvertent trip on roundoff error */

	if (tmpdec > 90.0002)
	{
		tmpdec = 180. - tmpdec;
		tmpra = tmpra + 12.;
		Map24(tmpra); 
	} 

	*telra1 = tmpra;
	*teldec1 = tmpdec;

	return;
}  


/* Apply corrections to find the apparent coordinates to send to the telescope */
/* Input real target coordinates */
/* Return apparent telescope coordinates to have it point at this target */
/* Implemented in order: offset, refract, flexure, optaxis, decaxis, polar */
/* Note that the order is reversed from that in PointingFromTel */

void PointingToTel (mount *mnt, double *telra0, double *teldec0, double telra1, double teldec1, int pmodel)
{
  double tmpra, tmpha, tmpdec, tmplst;
  
  tmpra = telra1;
  tmpdec = teldec1;

  /* Correct for offset */
  /* Offsets are defined as added to apparent pointing to give real pointing */
  
  if ( pmodel == (pmodel | OFFSET) )
  {
    tmpra = tmpra - mnt->offsetra;
    tmpdec = tmpdec - mnt->offsetdec;
  }  

   /* Save the LST for later use, find the HA for this LST and finish the model */

  tmplst = LSTNow(mnt->SiteLongitude);
  tmpha = tmplst - tmpra;
  tmpha = Map12(tmpha); 

   
  /* Correct for atmospheric refraction */
  /* For dir = +1 returns the apparent pointing given the real target pointing */
 
  if ( pmodel == (pmodel | REFRACT) )
  {
    Refraction( mnt, &tmpha,  &tmpdec, 1);
  }

  /* Correct for OTA flexure  */
  /* For dir = +1 returns the apparent pointing given the real pointing */
   
  if ( pmodel == (pmodel | FLEXURE) )
  {
    Flexure( mnt, &tmpha,  &tmpdec, 1);
  } 

  /* Correct for optical axis not coincident with mechanical axis  */
  /* For dir = +1 returns the apparent pointing given the real pointing */
   
  if ( pmodel == (pmodel | OPTAXIS) )
  {
    Optaxis( mnt, &tmpha,  &tmpdec, 1);
  } 

  /* Correct for dec axis not perpendicular to polar axis */
  /* For dir = +1 returns the apparent pointing given the real pointing */
  
  if ( pmodel == (pmodel | DECAXIS) )
  {
    Decaxis( mnt, &tmpha,  &tmpdec, 1);
  }  

  /* Correct for mounting misalignment */
  /* For dir = +1 returns the apparent pointing given the real pointing */
  
  if ( pmodel == (pmodel | POLAR) )
  {
    Polar( mnt, &tmpha,  &tmpdec, 1);
  } 
  
  tmpra = tmplst - tmpha;

  /* Handle a case that has crossed the 24 hr mark */
  
  tmpra = Map24(tmpra);
  
  /* Handle a case that has gone over the south pole */
  
  if (tmpdec < -90.)
  {
     tmpdec = -180. - tmpdec;
     tmpra = tmpra + 12.;
     Map24(tmpra); 
  }
  
  /* Handle a case that has gone over the north pole */  
  
  if (tmpdec > 90.)
  {
     tmpdec = 180. - tmpdec;
     tmpra = tmpra + 12.;
     Map24(tmpra); 
  } 
       
  *telra0 = tmpra;
  *teldec0 = tmpdec;

  return;
}  


/* Correct ha and dec for atmospheric refraction 
 *
 * Call this in the form Refraction(&ha,&dec,dirflag)
 *
 * Input: 
 *   Pointers to ha and dec 
 *   Integer dirflag >=0 for add (real to apparent)
 *   Integer dirflag <0  for subtract (apparent to real)
 *   Valid above 15 degrees.  Below 15 degrees uses 15 degree value.
 *   Global local barometric SitePressure (Torr) 
 *   Global local air temperature SiteTemperature (C) 
 * Output:
 *   In place pointers to modified ha and dec 
 */

void Refraction(mount *mnt, double *ha, double *dec, int dirflag)
{
  double altitude, azimuth, dalt, arg;
  double hourangle, declination;
  double pressure = mnt->SitePressure / 4. * 3.; //From mbar to Torr used internally

  /* Calculate the change in apparent altitude due to refraction */
  /* Uses 15 degree value for altitudes below 15 degrees */

  /* Real to apparent */
  /* Object appears to be higher due to refraction */
  
  hourangle = *ha;
  declination = *dec;
  EquatorialToHorizontal(mnt->SiteLatitude, hourangle, declination, &azimuth, &altitude);

  if (dirflag >= 0)
  {  
    if (altitude >= 15.)
    {
      arg = (90.0 - altitude)*PI/180.0;
      dalt = tan(arg);
      dalt = 58.276 * arg - 0.0824 * arg * arg * arg;
      dalt = dalt / 3600.;
      dalt = dalt * (pressure/(760.*1.01))*(283./(273.+mnt->SiteTemperature));
    }
   else
    {
      arg = (90.0 - 15.0)*PI/180.0;
      dalt = tan(arg);
      dalt = 58.276 * arg - 0.0824 * arg * arg * arg;
      dalt = dalt / 3600.;
      dalt = dalt * (pressure/(760.*1.01))*(283./(273.+mnt->SiteTemperature));
    }
    altitude = altitude + dalt;
  }
  
  /* Apparent to real */
  /* Object appears to be higher due to refraction */
  
  else if (dirflag < 0)
  {
    if (altitude >= 15.)
    {
      arg = (90.0 - altitude)*PI/180.0;
      dalt = tan(arg);
      dalt = 58.294 * arg - 0.0668 * arg * arg * arg;
      dalt = dalt / 3600.;
      dalt = dalt * (pressure/(760.*1.01))*(283./(273.+mnt->SiteTemperature));
    }
   else
    {
      arg = (90.0 - 15.0)*PI/180.0;
      dalt = tan(arg);
      dalt = 58.294 * arg - 0.0668 * arg * arg * arg;
      dalt = dalt / 3600.;
      dalt = dalt * (pressure/(760.*1.01))*(283./(273.+mnt->SiteTemperature));
    }

    altitude = altitude - dalt;
  }
   HorizontalToEquatorial(mnt->SiteLatitude, azimuth, altitude, &hourangle, &declination);
  *ha = hourangle;
  *dec = declination; 
}

/* Allow for known polar alignment parameters 
 *
 * Call this in the form Polar(&ha,&dec,dirflag)
 *
 * Input: 
 *   Pointers to ha and dec 
 *   Integer dirflag >=0  real to apparent
 *   Integer dirflag <0   apparent to real
 * Output:
 *   In place pointers to modified ha and dec 
 * Requires:
 *   SiteLatitude in degrees
 *   polaralt polar axis altitude error in degrees
 *   polaraz  polar axis azimuth  error in degrees
 */

void Polar(mount *mnt, double *ha, double *dec, int dirflag)
{
  double hourangle, declination;
  double da, db;
  double epsha, epsdec;
  double latitude;
  
  /* Make local copies of input */
  
  hourangle = *ha;
  declination = *dec;  
  da = mnt->polaraz;
  db = mnt->polaralt;
  latitude = mnt->SiteLatitude;
  
  /* Convert to radians for the calculations */
   
  hourangle = hourangle*PI/12.;
  declination = declination*PI/180.;
  da = da*PI/180.;
  db = db*PI/180.; 
  latitude = latitude*PI/180.; 
  
  /* Evaluate the corrections in radians for this ha and dec */
  /* Sign check:  on the meridian at the equator */
  /*   epsha goes as -da */
  /*   epsdec goes as +db */
  /*   polaraz and polaralt signed + from the true pole to the mount pole */
    
  epsha = db*tan(declination)*sin(hourangle) - da*(sin(latitude) - tan(declination)*cos(hourangle)*cos(latitude));
  epsdec = db*cos(hourangle) - da*sin(hourangle)*cos(latitude);    
    
  /* Real to apparent */
  
  if (dirflag >= 0)
  {  
    hourangle = hourangle + epsha;
    declination = declination + epsdec;
  }
  
  /* Apparent to real */
  
  else if (dirflag < 0)
  {
    hourangle = hourangle - epsha;
    declination = declination - epsdec;
  }

  /* Convert from radians to hours for ha and degrees for declination */

  hourangle = hourangle*12./PI;
  declination = declination*180./PI;
  
  /* Check for range and adjust to -90 -> +90 and 0 -> 24  */
 
  if (declination > 90. ) 
  {
    declination = 180. - declination;
    hourangle = hourangle + 12.;
  }
   if (declination < -90. ) 
  {
    declination = -180. - declination;
    hourangle = hourangle + 12.;
  }  

  hourangle = Map24(hourangle);         
  *ha = hourangle;
  *dec = declination;
}


/* Allow for known declination axis skew  
 *
 * Call this in the form Decaxis(&ha,&dec,dirflag)
 *
 * Based on:
 *   Trueblood and Genet page 125
 * Input: 
 *   Pointers to ha and dec 
 *   Integer dirflag >=0  real to apparent
 *   Integer dirflag <0   apparent to real
 * Output:
 *   In place pointers to modified ha and dec 
 * Requires global values:
 *   decskew(decaxis) = declination axis skew angle in degrees
 *   basis = +1 for looking to the west from the east side
 *     and  -1 for looking from the east to the west side
 *  
 * Cautionary note:
 *   The sign of the skew correction changes when a German equatorial 
 *   is flipped across the meridian: basis parameter flags this flip.
 *   Set decskew(decaxis) value and sign for basis = +1; 
 */

void Decaxis(mount *mnt, double *ha, double *dec, int dirflag)
{
  double hourangle, declination;
  double da, dsign;
  double epsha, epsdec;
  
  /* Make local copies of input */
  
  hourangle = *ha;
  declination = *dec;  
  dsign = mnt->basis;
  da = dsign*mnt->decaxis;
  
  /* Note about the basis                                                      */
  /* We use a global flag to indicate a flip of the OTA/mounting               */
  /* By our own convention a +1 basis is the one with the OTA east of the pier */
  /*   looking to the west (e.g. to + HA)                                      */
  /*   and a -1 basis is with the OTA on the west side of the pier looking to  */
  /*   the east (e.g. to - HA)                                                 */
  /* The basis flag should be set by the telescope control software to alert   */
  /*   pointing algorithms of a flip of the OTA                                */
  /* In a fork mounting you may safely set basis = 1 and ignore the flip       */
  /*   unless the telescope is allowed to rotate through the fork arms         */
  
  /* Convert to radians for the calculations */
   
  hourangle = hourangle*PI/12.;
  declination = declination*PI/180.;
  da = da*PI/180.;
  
  /* Evaluate the corrections in radians for this ha and dec */
  
  epsha = da*sin(declination);
  epsdec = da*epsha;
      
  /* Real to apparent */
  
  if (dirflag >= 0)
  {  
    hourangle = hourangle + epsha;
    declination = declination + epsdec;
  }
  
  /* Apparent to real */
  
  else if (dirflag < 0)
  {
    hourangle = hourangle - epsha;
    declination = declination - epsdec;
  }

  /* Convert from radians to hours for ha and degrees for declination */

  hourangle = hourangle*12./PI;
  declination = declination*180./PI;
  
  /* Check for range and adjust to -90 -> +90 and 0 -> 24  */
 
  if (declination > 90. ) 
  {
    declination = 180. - declination;
    hourangle = hourangle + 12.;
  }
   if (declination < -90. ) 
  {
    declination = -180. - declination;
    hourangle = hourangle + 12.;
  }  
  hourangle = Map24(hourangle);         
  
  /* Return modified ha and dec */
  
  *ha = hourangle;
  *dec = declination;
}


/* Allow for known optical axis skew  
 *
 * Call this in the form Optaxis(&ha,&dec,dirflag)
 *
 * Based on:
 *   Trueblood and Genet page 127
 * Input: 
 *   Pointers to ha and dec 
 *   Integer dirflag >=0  real to apparent
 *   Integer dirflag <0   apparent to real
 * Output:
 *   In place pointers to modified ha and dec 
 * Requires global values:
 *   optew = optical axis east-west skew angle in degrees
 *   optns = optical axis north-south skew angle in degrees
 *   basis = +1 for looking to the west from the east side
 *     and  -1 for looking from the east to the west side
 *  
 * Cautionary note:
 *   The sign of the skew corrections change when a German equatorial 
 *   is flipped across the meridian: basis parameter flags this flip.
 *   Set both skew value and sign for basis = +1;
 *   On a flip across the meridian the telescope is rotated 180 degrees
 *   NS and EW directions on the sky are changed in sign 
 *
 * Regarding NS correction:
 *   optns affects only the dec and is a constant correction.
 *   optns = 0. when the axes are zeroed from a starfield on startup. 
 */

void Optaxis(mount *mnt, double *ha, double *dec, int dirflag)
{
  double hourangle, declination;
  double da, db, dsign;
  double epsha = 0.;
  double epsdec = 0.;
  
  /* Make local copies of input */
  
  hourangle = *ha;
  declination = *dec;  
  dsign = mnt->basis;
  da = mnt->optew*dsign;
  db = mnt->optns*dsign;
  
  /* Reminder about optns: it gives a constant dec correction                  */
  /*   Simplest to set to zero and let encoder reference handle it             */
  /*   Otherwise it interacts with a zero offset of the encoder.               */  
  
  /* Note about the basis                                                      */
  /* We use a global flag to indicate a flip of the OTA/mounting               */
  /* By our own convention a +1 basis is the one with the OTA east of the pier */
  /*   looking to the west (e.g. to + HA)                                      */
  /*   and a -1 basis is with the OTA on the west side fo the peir looking to  */
  /*   the east (e.g. to - HA)                                                 */
  /* The basis flag should be set by the telescope control software to alert   */
  /*   pointing algorithms of a flip of the OTA                                */
  /* In a fork mounting you may safely set basis = 1 and ignore the flip       */
  /*   unless the telescope is allowed to rotate through the fork arms         */
  
  /* Convert to radians for the calculations */
   
  hourangle = hourangle*PI/12.;
  declination = declination*PI/180.;
  da = da*PI/180.;
  db = db*PI/180.;
  
  /* Evaluate the ha correction in radians for this dec */
  
  if (fabs(90. - declination) > 0.5)
  {
    /* Not needed at the pole */
    epsha = da/cos(declination);
  } 

  /* The dec correction is constant.  */
  /* Set optns = 0. to ignore. */
  
  epsdec = db;
      
  /* Real to apparent */
  
  if (dirflag >= 0)
  {  
    hourangle = hourangle + epsha;
    declination = declination + epsdec;
  }
  
  /* Apparent to real */
  
  else if (dirflag < 0)
  {
    hourangle = hourangle - epsha;
    declination = declination - epsdec;
  }

  /* Convert from radians to hours for ha and degrees for declination */

  hourangle = hourangle*12./PI;
  declination = declination*180./PI;
  
  /* Check for range and adjust to -90 -> +90 and 0 -> 24  */
 
  if (declination > 90. ) 
  {
    declination = 180. - declination;
    hourangle = hourangle + 12.;
  }
   if (declination < -90. ) 
  {
    declination = -180. - declination;
    hourangle = hourangle + 12.;
  }  
  hourangle = Map24(hourangle);         
  
  /* Return modified ha and dec */
  
  *ha = hourangle;
  *dec = declination;
  
}

/* Allow for known OTA flexure
 *
 * Call this in the form Flexure(&ha,&dec,dirflag)
 *
 * Based on:
 *   Trueblood and Genet page 128
 * Input: 
 *   Pointers to ha and dec 
 *   Integer dirflag >=0  real to apparent
 *   Integer dirflag <0   apparent to real
 * Output:
 *   In place pointers to modified ha and dec 
 * Requires global value:
 *   flexure = optical axis flexure at 90 degree zenith distance (degrees)
 *   SiteLatitude = latitude in degrees
 *  
 * Cautionary notes:
 *   This is very crude, but it might help to give arcsecond pointing.
 *   It does not allow for mount flexure directly, but if determined
 *   empirically, mount flexure may be part of it.
 *   It would probably be worthwhile to replace this with an empirical 
 *   fitting for a function of both H and Z based on an analysis of
 *   pointing residuals with other corrections in place.
 * 
 */  

void Flexure(mount *mnt, double *ha, double *dec, int dirflag)
{
  double hourangle, declination;
  double azimuth, altitude;
  double da,dalt;
  
  /* Make local copies of input */
  
  hourangle = *ha;
  declination = *dec;
  da = mnt->flexure;  
  
  /* Behaves qualitatively like refraction but with opposite sign */
  /* Correction dalt is how much lower the OTA is aimed than the mount is pointed */

  EquatorialToHorizontal(mnt->SiteLatitude, hourangle, declination, &azimuth, &altitude);
  dalt = -da*cos(altitude*PI/180.);
  
  /* Real to apparent */
  
  if (dirflag >= 0)
  {  
    altitude = altitude + dalt;
  }
  
  /* Apparent to real */
  
  else if (dirflag < 0)
  {
    altitude = altitude - dalt;
  }
  HorizontalToEquatorial(mnt->SiteLatitude, azimuth, altitude, &hourangle, &declination);
  *ha = hourangle;
  *dec = declination;
}
