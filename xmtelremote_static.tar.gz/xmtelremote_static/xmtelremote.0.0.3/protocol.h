#ifndef PROTOCOL_H
	#define PROTOCOL_H
	/* The difference between terrestrial and ephemeris time is determined       */
	/*   by the accumulated number of leapseconds at this moment.                */

	/* Updated on January 1, 2009 from 33.0                                      */

	#ifndef LEAPSECONDS
		#define LEAPSECONDS    34.0
	#endif

	/* Important constant                                                        */

	#ifndef PI
		#define PI             3.14159265358
	#endif

	#ifndef TRUE
		#define TRUE 1
	#endif

	#ifndef FALSE
		#define FALSE 0
	#endif

	/* Mounts                                                                    */
	#define ALTAZ 		0       /* Alt-azimuth mount with at least 2-axis tracking */ 
	#define EQFORK 		1       /* Equatorial fork */
	#define GEM    		2       /* German equatorial */
	#define QUIETSLEW 	0		/* Flag for quiet, limited speed, slower slew */

	/* Track motion speeds                                                        */
	#define	SIDEREAL	-1
	#define	LUNAR		-2
	#define	SOLAR		-3

	/* Slew directions                                                           */
	#define	NORTH		1
	#define	SOUTH		2
	#define	EAST		4
	#define	WEST		8

	//Dynamic feature enable
	#define FLTRACK   0
	#define FLSITE    1
	#define FLGRATE   2
	#define FLPGUIDE  3
	#define FLFOCUS   4
	#define FLFAN     5
	#define FLHEATER  6
	#define FLROTAT   7
	#define FLRETIC   8
	#define FLMAXSLW  9
	#define FLLEVEL  10
	#define FLHORIZ  11
	#define FLCLOSE  12

	#include <sys/types.h>

	typedef struct                         	    /* telescope structure  */
	{
		char telport[256];                  	/* Serial port if needed */
		int  tellink;     					    /* telescope connection flag */
		unsigned char modcod[10];
		char modfeat[20];
		char desc[80];
		unsigned char hcver[10];
		unsigned char motver[10];
		int teltype;							/* One of GEM, EQFORK, ALTAZ */
		int telmode;							/* One of GEM, EQFORK, ALTAZ */
		int teltypefixed;			   			/* Disable tel mode GUI setting when set in pref file */
		int telspd;								/* drive speed */
		double trkspd;							/* tracking speed */
		int trkStatus;							/* Track status, default to no tracking */
		int trkActive;							/* Track isActive */
		double homeha;							/* Startup HA */
		double homedec;							/* Startup Dec */
		int    homefixed;						/* Disable tel type home default when set in pref file*/
		double parkha;							/* Park telescope at this HA */
		double parkdec;							/* Park telescope at this Dec */
		int    parkfixed;						/* Disable tel type park default when set in pref file*/
		double offsetabsra;						// offsets for absolute positions
		double offsetabsdec;
		double SiteLatitude;        			/* Latitude in degrees + north */  
		double SiteLongitude;      				/* Longitude in degrees + east */  
		double SiteAltitude;        			/* Altitude in meters */
		double SitePressure;        			/* Atmospheric pressure in mbar */
		double SiteTemperature; 				/* Local atmospheric temperature in C */
		double offsetra;
		double offsetdec;
		double polaraz;
		double polaralt;
		int    polarfixed;
		double decaxis;
		double optew;
		double optns;
		double flexure;
		double slewtolha;
		double slewtoldec;
		double slewtolfixed;
		int basis;								/* Flag indicating OTA flip for German mount = 1 Ota is west of pier, = -1 Ota is east of pier */
		int level;								/* Flag indicating mount has been leveled, set to 0 if levelling is not supported in firmware  */
		int align;								/* Flag indicating mount has been sky sligned (negative values are the align process next step */
		int quietslew;							/* Flag for quiet, limited speed, slower slew */
		int guideratera;
		int guideratedec;
		int horizon[36][3];						/*MinH,MaxH each 10Deg Az*/
		int axralimits[2];						/* Low and High ha permitted values to limit Ra rotation (also for GEM)*/
	} mount;

	extern void update_message();           /* Update message area with string message */
	extern int  comfailCB();				// Call for communication fail interactive messages

	/* Telescope and mounting commands that may be called externally, others may be protocol specific, but must be controlled with compile switch */
	/* Interface control */
	int  ConnectTel(char *telserial);
	int  DisconnectTel(mount *mnt);
	int  CheckConnectTel(void);
	int  CheckInfoTel(mount *mnt);
	int  CheckInitTel(mount *mnt);
	int  SetHomeNowTel(mount *mnt);
	int  SetMountDefaultHome(mount *mnt);

	/* Slew and track control */
	int  SetRate(mount *mnt, int newRate);
	int  StartSlew(mount *mnt, int direction);
	int  StopSlew(mount *mnt, int direction);
	int  SetTrack(mount *mnt);
	int  StartTrack(mount *mnt);
	int  StopTrack(mount *mnt);
	int  FullStop(mount *mnt);
	int  SetTrkSpd(mount *mnt, double newRate);
	int  SetGuideSpd(mount *mnt, int val, int radec);
	int  GetGuideSpd(mount *mnt, int *val, int radec);
	int  GetGuideStep(void); 							// Step to move the guide speed spin(s). Also minimum value.
	int  GetTrackStatus(mount *mnt);
	void SetTrackStatus(mount *mnt,int trk);
	int  GetTrackActive(mount *mnt);
	int  SetMountMode(mount *mnt, int newType);

	/* Init */
	int  LevelScope(mount *mnt, int ra, int dec);
	int  CheckLevel(int ra, int dec);

	/* Coordinates */
	int  GetTel(mount *mnt, double *telra, double *teldec, int pmodel);
	int  SetTel(mount *mnt, double homeha, double homedec);
	int  GoToCoords(mount *mnt, double newra, double newdec, int pmodel, int park);
	int  CheckGoTo(mount *mnt, double desRA, double desDec, int pmodel, int park);

	/* Slew limits */
	int  SetLimits(int limits);
	int  GetLimits(int *limits);
	int  ChkTarget(mount *mnt, double chkra, double chkdec, int pmodel);
	int  ChkRaAxAngle(mount *mnt, double chkra, double chkdec, int pmodel);


	/* Synchronizing */
	int  SyncTelOffsets(mount *mnt, double newoffsetra, double newoffsetdec);

	/* Instrumentation */
	#ifdef ISHEATER
		int Heater(int heatercmd);
	#endif
	#ifdef ISFAN
		int Fan(int fancmd);
	#endif
	#ifdef ISFOCUS
		int Focus(int focuscmd, int focusspd);
		int GetFocus(double *telfocus);
		int GetTemperature(double *teltemperature);
	#endif
	#ifdef ISROTATOR
		int Rotate(int rotatecmd, int rotatespd);
		int GetRotate(double *telrotate);
	#endif
	#ifdef ISRETICLE
		int Reticle(int reticle);
	#endif
#endif

