/* -------------------------------------------------------------------------- */
/*  					-Routines for SYS time correction- 					  */
/* -------------------------------------------------------------------------- */
/*                                                                            */
/* Copyright 2013 Giampiero Spezzano                                          */
/*                                                                            */
/* Distributed under the terms of the General Public License (see LICENSE)    */
/*                                                                            */
/* Giampiero Spezzano (gspezzano@gmail.com)                                   */
/*                                                                            */
/* Marc 30, 2013                                                              */
/*     First release                                                          */
/*                                                                            */
// gcc -o fixtime fixtime.c
#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <time.h>
#include <sys/time.h>

void usage() 
{
	fprintf(stderr, "Usage:\n\t fixtime -t <seconds>\n");
}

int main( int argc , char **argv ) 
{
	int c, seconds = 0, retcode = EXIT_FAILURE;
	struct timeval systime;
	struct tm * tmsys;

	while ((c = getopt(argc,argv, "t:h"))!=-1)
	{
		switch(c) 
		{
			case 'h' : usage(); exit(EXIT_SUCCESS); break;
			case 't' : seconds = atoi(optarg); retcode = EXIT_SUCCESS; break;
		}
	}

	if (retcode == EXIT_SUCCESS && seconds != 0)
	{
		if (gettimeofday(&systime, NULL) == 0)
		{
			systime.tv_sec += seconds;
			if (settimeofday(&systime, NULL) == 0)
			{
				tmsys = localtime(&systime.tv_sec);
				fprintf(stderr, "New system time: %s\n", asctime(tmsys));
			}
			else
			{
				retcode = EXIT_FAILURE;
			}
		}
		else
		{
			retcode = EXIT_FAILURE;
		}
		
	}
	else
	{
		usage();
	}
	exit(retcode);
}
