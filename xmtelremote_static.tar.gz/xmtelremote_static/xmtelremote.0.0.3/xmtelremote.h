#ifndef XMTELREMOTE_H
	#define XMTELREMOTE_H
	/* ----------------------------------------------------------------------- */
	/* -                   Astronomical Telescope Control                    - */
	/* -                         XmTel Header File                           - */
	/* ----------------------------------------------------------------------- */
	/*                                                                         */
	/* Copyright (c) 2008 John Kielkopf                                        */
	/* kielkopf@louisville.edu                                                 */
	/*                                                                         */
	/* This file is part of XmTel.                                             */
	/*                                                                         */
	/* Distributed under the terms of the General Public License (see LICENSE) */ 
	/*                                                                         */
	/* Date: June 16, 2010                                                     */
	/* Version: 5.2.0                                                          */
	/* Date: April 01, 2012                                                    */
	/* Version: 0.0.1 - based on xmtel 5.2.0                                   */
	/* Date: March 01, 2012                                                    */
	/* Version: 0.0.2 - code rearranged for better protocol separation         */

	#define XMTEL2VER		"Tue 18 Mar 2014 06:12:23 PM CET"

	/* Useful values */
	#ifndef FALSE
		#define FALSE 0
	#endif

	#ifndef TRUE
		#define TRUE 1
	#endif

	/* User interface polling */
	#define	POLLMS      2000   /* Poll period, ms */

	/* List lenght */
	#define QUEUELEN   10000
	#define HISTORYLEN   100

	/* Menu flags */
	#define OK         1     
	#define CANCEL     2

	/* Menu item identifiers */
	#define NEWQUEUE        1
	#define NEWHISTORY      2
	#define EDITQUEUE       3 
	#define EDITHISTORY	    4 
	#define SAVEQUEUE       5
	#define SAVEHISTORY     6
	#define SAVECONFIG      7
	#define SAVESTATUS      8
	#define EXIT            9
	#define POINTOPTION1   10
	#define POINTOPTION2   11
	#define POINTOPTION4   12
	#define POINTOPTION8   13
	#define POINTOPTION16  14
	#define POINTOPTION32  15
	#define POINTOPTION64  16
	#define TELLEVEL       17 
	#define TELPOLE	       18 
	#define TELSKY	       19
	#define TELPARK	       20
	#define TELFOCUS       21
	#define TELFAN         22
	#define TELHEATER      23
	#define TELSITE        24 
	#define NEWCONFIG      25
	#define EDITCONFIG     26
	#define NEWHORIZON     27
	#define EDITHORIZON    28
	#define TOOLSHOME      29 
	#define TOOLSMERIDIAN  30 
	#define TOOLSZENITH    31 

	/* Command Buttons */
	#define CMD_BUTTONS 	17
	//
	#define CMD_CONNECT 	0
	#define CMD_TRACK 		1
	#define CMD_STOP		2
	#define CMD_SLEW		3
	#define CMD_SAVE		4
	#define CMD_RECALL		5
	#define CMD_SYNC		6
	#define CMD_UNSYNC		7
	#define CMD_MARKTEL		8
	#define CMD_TELRA		9
	#define CMD_TELDEC		10
	#define CMD_TELEPCH		11
	#define CMD_MARKTGT		12
	#define CMD_GETRA		13
	#define CMD_GETDEC		14
	#define CMD_TGTEPCH		15
	#define CMD_SPIRAL		16

	/* Faketab togglebuttons */
	#define TAB_QUEUE		0
	#define TAB_HISTORY		1
	#define TAB_STATUS		2

	/* Focus panel identifiers */
	#ifdef ISFOCUS
		#define FOCUSIN        1
		#define FOCUSOUT       2
		#define FOCUSOK        4
	#endif
	
	/* Fan panel identifiers */
	#ifdef ISFAN
		#define FANOK          1
	#endif
	
	/* Heater panel identifiers */
	#ifdef ISHEATER
		#define HEATEROK       1
	#endif

	/* site panel identifiers */
	#define GPSSERIAL    1
	#define GPSCONNECT   2
	#define GPSLONN      3
	#define GPSLON       4
	#define GPSLATN      5
	#define GPSLAT       6
	#define GPSALT       7
	#define GPSTEMP      8
	#define GPSPRESS     9
	#define GPSAPPLY    10
	#define GPSNVJ      11
	#define GPSTDIFF    12
	#define GPSTAPPLY   13
	
	/* Display epochs (selected with GUI button)                                 */
	#define J2000       0      /* Epoch 2000.0 as entered or precessed without pm */
	#define EOD      	1      /* Epoch of date with pm if available  (default) */

	/* Display coords (selected with GUI button)                                 */
	#define RADEC       1      
	#define AZALT      	0      

	/* Target input flags */
	#define RA        1               
	#define DEC       2               

	/* Configuration file */
	#ifdef LX200AST_H
		#define CONFIGFILE "/usr/local/bin/xmtelremote/ast_prefs.tel"
	#endif
	#ifdef NEXSTAR_H
		#define CONFIGFILE "/usr/local/bin/xmtelremote/nex_prefs.tel"
	#endif
	#ifdef SYNTA_H
		#define CONFIGFILE "/usr/local/bin/xmtelremote/eq_prefs.tel"
	#endif
	#define COORDFILE "/usr/local/bin/xmtelremote/telcoords"

	/* Horizon feature */
	#define HORIZONFILE "/usr/local/bin/xmtelremote/horizon.tel"
	#define HORIZONDISABLED 1 
	#define AXRALOW -90 
	#define AXRAHIGH 90 

	/* Reserve space for characters in file descriptors */
	#define MAXPATHLEN  100

	/* Default pipes */
	//#define READPIPE    	"~/.goto_fifo"
	//#define WRITEPIPE   	"~/.mark_fifo"
	#define READPIPE    	"/usr/local/bin/xmtelremote/goto_fifo"
	#define WRITEPIPE   	"/usr/local/bin/xmtelremote/mark_fifo"
	#define RPIPEDISABLED 	1   /* If greater than 0 function is disabled */
	#define WPIPEDISABLED 	1   /* If greater than 0 function is disabled */
	#define AUTOCONNECT 	0   /* Telescope auto-connect. If greater than 0 function is enabled */


	/* Default log and queue editor e.g. nedit or gedit */
	#define XMTEL_EDITOR  "gedit"

	/* timefix program */
	#define XMTEL_TIMEFIX  "/usr/local/bin/xmtelremote/fixtime"

	/* Telescope feature flags */
	#define FOCUSDISABLED   1   /* If greater than 0 function is disabled */
	#define FANDISABLED     1   /* If greater than 0 function is disabled */
	#define HEATERDISABLED  1   /* If greater than 0 function is disabled */

	// Menu items
	#define TOOLSDISABLED	1 	/* If greater than 0 function is disabled */

	/* Defaults for site  */
	#define LONGITUDE     -85.5300
	#define LATITUDE       38.3334
	#define ALTITUDE      230.0000
	#define TEMPERATURE    20.0
	#define PRESSURE     1013.0

	/* Telescope defaults flags */
	#define HOMEHA          0.0
	#define HOMEDEC         0.0
	#define PARKHA          0.0
	#define PARKDEC         0.0
	#define TELSERIAL     	"/dev/ttyS0"
	#define TELTYPE			1   /* One of GEM=2, EQFORK=1, ALTAZ=0 */
	#define TELTYPEFIXED	0   

	/* Slew directions */
	#define	CMDNORTH	0
	#define	CMDEAST		1
	#define	CMDWEST		2
	#define	CMDSOUTH	3

	typedef struct                         	/* catalog structure assuming EOD */
	{
		char name[80];
		char desc[80];
		double ra;
		double dec;
		double mag;
		double j2kra;
		double jpmra;
		double j2kdec;
		double jpmdec;
		int abspos;	
	} catalog;

	void set_init_config(void);
	void read_config(void);                	/* Configuration file reader */
	void read_horizon(void);                /* Horizon file reader */
	void apply_config(void);			   	/* Configuration settings to the GUI */

	/* Menu functions */
	Widget make_menu_item();     /* adds an pushbutton item into the menu */
	Widget make_menu_toggle();   /* adds a toggle item into the menu      */
	Widget make_menu();          /* creates a menu on the menu bar        */

	void create_main_window();  /* creates all the interface */
	void create_menus(Widget menu_bar);    /* Creates all menus for program  */
	void menuCB();             /* Callback routine used for all menus        */
	void setup_site();         /* Create the unmanaged site panel            */
	void setup_focus();        /* Create the unmanaged focus panel           */
	void siteCB();             /* Callback function for the site panel       */
	void siteChangedCB();
	void focusCB();            /* Callback function for the focus panel      */
	void focus_speedCB();      /* Callback function for focus speed toggles  */
	void setup_fan();          /* Create the unmanaged fan panel             */
	void fanCB();              /* Callback function for the fan panel        */
	void fan_speedCB();        /* Callback function for fan speed toggles    */
	void setup_heater();       /* Create the unmanaged heater panel          */
	void heaterCB();           /* Callback function for the heater panel     */
	void heater_powerCB();     /* Callback function for heater power toggles */


	void dialogCB();           /* Callback function for the dialog box       */
	void dialogtextCB();       /* Called whenever the user clicks on         */
	void degmotionCB(); /* The OK or Cancel buttons on the            */
		                       /*   dialog box.                              */

	void buttonCB();           /* Callback function for the 4 paddle         */
		                       
	void speedCB();            /* Callback function for the 9 slew speed buttons */
	void trackCB();            /* Callback function for the 3 tracking buttons */
	void trkspinVerifyCB();
	void trkspinChangedCB();
	void guidespinVerifyCB();
	void guidespinChangedCB();
	void swapCB();               /* Callback function for the 2 swap buttons */
	void opteqazCB();		   /* Callback function for the eq/az selector   */
	void faketabCB();          /* Callback function for the 2 faketab buttons */
		                       
	void commandCB();          /* Callback function for the 8 command        */
		                       /* Buttons called when one of the command     */
		                       /* Buttons is clicked.                        */

	void readhistoryCB();        /* Callback function for selecting the log file */
	void savehistoryCB();
	void edithistoryCB();


	void readqueueCB();        /* Callback function for opening the queue file */
	void savequeueCB();
	void editqueueCB();

	void readconfigCB();     /* Callback function for reading a new config file */
	void editconfigCB();

	void readhorizonCB();     /* Callback function for reading a new horizon file */
	void edithorizonCB();

	void selectqueueCB();      /* Callback function for selecting a queue entry */
	void selecthistoryCB();    /* Callback function for selecting a history entry */
	void txtsetCB();		   /* Callback function for txtserial */

	void set_target_park();		//Loads park coordinates on target
	void set_target_home();
	void set_target_meridian();
	void set_target_zenith();
	
	//Serial communication aid
	int  comfailCB();          //Call for communication fail interactive message

	/* User interface polling */
	unsigned long poll_interval = POLLMS;      
	void poll_interval_handler(XtPointer client_data_ptr, XtIntervalId *client_id);            
	XtIntervalId poll_interval_id;
	XtPointer poll_interval_data_ptr;
	void hide_popup_handler(XtPointer client_data_ptr, XtIntervalId *client_id);            
	XtIntervalId hide_popup_id;
	XtPointer hide_popup_data_ptr;
	void apply_tracking_handler(XtPointer client_data, XtIntervalId *client_id);            
	XtIntervalId apply_tracking_id;
	XtPointer apply_tracking_data_ptr;
	void apply_guide_handler(XtPointer client_data, XtIntervalId *client_id);            
	XtIntervalId apply_guide_id;
	XtPointer apply_guide_data_ptr;

	/* Telescope functions within XmTel */
	void show_telescope_coordinates();      /* Display latest telescope coordinates */
	void show_target_coordinates();         /* Display latest target coordinates  */
	void slew_telescope();                  /* Slew telescope to target */
	void check_slew_status();               /* Monitor slew progress */
	void show_focus();                      /* Display the focus count on the focus panel */
	void show_rotation();                   /* Display the rotation reading */
	void show_temperature();                /* Display the temperature */
	void level_telescope();                 /* Level telescope to index marks */
	void check_level_status();              /* Monitor level progress */
	void close_app_callback();				/* callback for application clean close */

	void mark_fifo_telescope();             /* Export telescope coordinates to XEphem */
	void read_edb_fifo();                   /* Read target coordinates from XEphem goto fifo */
	void mark_fifo_target();                /* Export target coordinates to XEphem */

	int  save_coordinates(int read);        /* Save a log entry and add to the history */
	int  recall_coordinates();              /* Read from log and add to the history */

	void history_add();                     /* Save ha and dec to the history */
	void queue_add();                       /* Save target ha and dec to the queue */

	void update_message();                  /* Update message area with string message */

	void fetch_telescope_coordinates();     /* Import current telescope coordinates */
	void new_target_ra();                   /* User input of target RA */
	void new_target_dec();                  /* User input of target Dec */
	void reference_telescope_to_target();   /* Set offset reference to target coordinates */
	void reference_telescope_to_zenith();   /* Set offset reference assuming current zenith */
	void reference_telescope_clear();       /* Reset offset reference */
	void sync_telescope_to_target();        // Set encoder count on target

	void reset_telescope();
	void reset_features();
	void link_telescope();                  /* Startup telescope link routine */
	void unlink_telescope();                /* Shutdown telescope link routine */
	void link_fifos();                      /* Startup fifo link routine */
	void unlink_fifos();                    /* Shutdown fifo link routine */
	void log_status();

	void align_telescope_polaris(int step);
	void align_polarisCB();
	void align_telescope(int step);
	void alignCB();
	void skyalign_telescope(int step);
	void skyalignCB();
	void test_align();

	// Gps / Site
	void reset_site();
	void set_site();
	void set_tel_site();

	/* Replace char into string
	void replace(char *strbuf, const char *strold, const char *strnew);
	size_t strcrspn( char * s1, char * s2 );
	int file_exists (char * fileName);  */

	/* Read edb file into memory structure */
	int read_edb_file(FILE * fileptr, catalog *cat, int catlen);
	int read_edb_row(char *rowstr, catalog *cat, int catlen);
	int write_edb_file(FILE * fileptr, catalog *cat, int catlen);
	int write_edb_row(FILE * fileptr, catalog *cat, int index);
	void reload_list(Widget list_area, catalog *cat, int catlen);
#endif

