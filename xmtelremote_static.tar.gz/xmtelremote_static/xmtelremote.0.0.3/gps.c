/* -------------------------------------------------------------------------- */
/* -Routines for GPS access, Serial port communication, NMEA $GPGGA sentence- */
/* -------------------------------------------------------------------------- */
/*                                                                            */
/* Copyright 2013 Giampiero Spezzano                                          */
/*                                                                            */
/* Distributed under the terms of the General Public License (see LICENSE)    */
/*                                                                            */
/* Giampiero Spezzano (gspezzano@gmail.com)                                   */
/*                                                                            */
/* Marc 2013                                                                  */
/*     First release                                                          */
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>
#include <unistd.h>
#include <time.h>
#include <errno.h>
#include <sys/time.h>
#include <sys/types.h>
#include <termios.h>

#include <sys/stat.h>
#include <sys/ioctl.h>
#include <fcntl.h>
#include "gps.h"
#include "ttycom.h"
#include "logging.h"

/* System variables and prototypes */
static int  ttyread(int fd, char *buf, int timeout);
static int  gpsAck(void);

/* TTY to results transformations */
static int  parseGPGGAString(gpsdata *gps, char *str);

/* Communications variables and routines for internal use */
static int  GpsPortFD;
static int  GpsConnectFlag = FALSE;
static char strMsgLine[256];
static char ttyerrormsg[TTY_ERRMSG_SIZE];

int  parseGPGGAString(gpsdata *gps, char *str)
{
	int retval = 0, i = 0, j = 0, s = 0, isdst = 0;
	int deg = 0.;
	double dec = 0.;
	char *strptr = str;
	char fldstr[GPS_LEN];
	char cutstr[GPS_LEN];
	time_t local, utc;
	struct tm tmutc;
	
	// $GPGGA,092204.999,4250.5589,S,14718.5084,E,1,04,24.4,19.7,M,,,,0000*1F
	strptr = str;
	for (i = 0; i < 11; i++)
	{
		j = strcspn(strptr, GPSFLDSEPSTR);
		strncpy(fldstr, strptr, j);
		fldstr[j] = '\0';
		if (i == 0)
		{
			if (strcmp(fldstr, "$GPGGA") != 0)
			{
				// Not the right sentence
				break;
			}
		}
		else if (i == 1)
		{
			// Local time to verify dst status
			local = time(NULL);
			tmutc = *localtime(&local);
			isdst = (tmutc.tm_isdst > 0);
			// UTC time
			tmutc = *gmtime(&local);
			local = mktime(&tmutc);

			strncpy(cutstr, fldstr, 2);
			cutstr[2] = '\0';
			sscanf(cutstr, "%d", &tmutc.tm_hour);

			strncpy(cutstr, fldstr + 2, 2);
			cutstr[2] = '\0';
			sscanf(cutstr, "%d", &tmutc.tm_min);

			strncpy(cutstr, fldstr + 4, 2);
			cutstr[2] = '\0';
			sscanf(cutstr, "%d", &tmutc.tm_sec);

			strncpy(cutstr, fldstr + 7, 2);
			cutstr[2] = '\0';
			sscanf(cutstr, "%d", &s);
			if (s > 50)
			{
				tmutc.tm_sec += 1;
			}
		
			utc = mktime(&tmutc);

			//fprintf(stderr, "GPS time and date: %s", asctime(&tmutc));
			//fprintf(stderr, "SYS time and date: %s", asctime(localtime(&local)));
			
			
			gps->TimeDifference = (int) difftime(utc, local) + (3600 * isdst);
			//fprintf(stderr, "gps.TimeDifference: %d\n", gps->TimeDifference);
		}
		else if (i == 2)
		{
			// Latitude
			sscanf(fldstr, "%2d%lf", &deg, &dec);
			gps->SiteLatitude = deg + (dec / 60.);
		}
		else if (i == 3)
		{
			// N/S
			if (memcmp(fldstr, "S", 1) == 0)
			{
				gps->SiteLatitude *= -1;
			}
			//fprintf(stderr, "gps.SiteLatitude: %lf %s\n", gps->SiteLatitude, ((gps->SiteLatitude > 0) ? "N" : "S"));
		}
		else if (i == 4)
		{
			// Longitude
			sscanf(fldstr, "%3d%lf", &deg, &dec);
			gps->SiteLongitude = deg + (dec / 60.);
		}
		else if (i == 5)
		{
			// E/W
			if (memcmp(fldstr, "W", 1) == 0)
			{
				gps->SiteLongitude *= -1;
			}
			//fprintf(stderr, "gps.SiteLongitude: %lf %s\n", gps->SiteLongitude, ((gps->SiteLongitude > 0) ? "E" : "W"));
		}
		else if (i == 6)
		{
			// Flag for valid fix
			if (memcmp(fldstr, "1", 1) == 0)
			{
				gps->gpsvalid = 1;
				retval = 1;
			}
			else
			{
				gps->gpsvalid = 0;
				retval = 0;
			}			
		}
		else if (i == 7)
		{
			// Satellites in use
			sscanf(fldstr, "%d", &gps->gpssats);
			//fprintf(stderr, "gps.Sat number: %d\n", gps->gpssats);
		}
		else if (i == 8)
		{
			// Horiz Precision diluition
			sscanf(fldstr,"%lf",&gps->gpsHDOP);
			if (gps->gpsHDOP < 1.)
			{
				sprintf(gps->gpsHDOPrating, "%2.2f - Ideal", gps->gpsHDOP);
				//fprintf(stderr, "gps.HDOP: %2.2f - Ideal\n", gps->gpsHDOP);
			}
			else if(gps->gpsHDOP < 2.)
			{
				sprintf(gps->gpsHDOPrating, "%2.2f - Excellent", gps->gpsHDOP);
				//fprintf(stderr, "gps.HDOP: %2.2f - Excellent\n", gps->gpsHDOP);
			}
			else if(gps->gpsHDOP < 5.)
			{
				sprintf(gps->gpsHDOPrating, "%2.2f - Good", gps->gpsHDOP);
				//fprintf(stderr, "gps.HDOP: %2.2f - Good\n", gps->gpsHDOP);
			}
			else if(gps->gpsHDOP < 10.)
			{
				sprintf(gps->gpsHDOPrating, "%2.2f - Moderate", gps->gpsHDOP);
				//fprintf(stderr, "gps.HDOP: %2.2f - Moderate\n", gps->gpsHDOP);
			}
			else if(gps->gpsHDOP < 20.)
			{
				sprintf(gps->gpsHDOPrating, "%2.2f - Fair", gps->gpsHDOP);
				//fprintf(stderr, "gps.HDOP: %2.2f - Fair\n", gps->gpsHDOP);
			}
			else
			{
				sprintf(gps->gpsHDOPrating, "%2.2f - Poor", gps->gpsHDOP);
				//fprintf(stderr, "gps.HDOP: %2.2f - Poor\n", gps->gpsHDOP);
			}			
		}
		else if (i == 9)
		{
			// Altitude
			sscanf(fldstr, "%lf", &gps->SiteAltitude);
			//fprintf(stderr, "gps.Altitude: %lf\n", gps->SiteAltitude);
		}
		else if (i == 10)
		{
			// M
			if (memcmp(fldstr, "M", 1) != 0)
			{
				// Should units not be "M" it may mean corrupted packet.
				gps->gpsvalid = 0;
				retval = 0;
			}
		}
		// Set up for next read
		strptr = strptr + j + 1;
	}
	return(retval);
}

int gpsAck(void)
{
	int retval = 0;
	char gpsstr[GPS_LEN];
	time_t t0, t1;
	
	t0 = time(NULL);
	t1 = time(NULL);

	while ((difftime(t1, t0) < GPS_TIME) && (retval == 0))
	{
		if (ttyread(GpsPortFD, gpsstr, TTY_TIME) > 0)
		{
			if (memcmp(gpsstr, "$", 1) == 0)
			{
				retval = 1;
			}
		}
		t1 = time(NULL);
	}
	return(retval);
}

/* Communications variables and routines for external use */
int GpsCheckConnect(void)
{
	if (GpsConnectFlag == TRUE)
	{
		return TRUE;
	}
	else
	{
		return FALSE;
	}
}

int GpsConnect(char *gpsserial)
{  
	int err_code = 0;	
	
	if(GpsConnectFlag != TRUE)
	{
		/* Make the connection */
		if ((err_code = tty_connect(gpsserial, 4800, 8, 0, 1, &GpsPortFD)) == TTY_OK)
		{
			sprintf(strMsgLine,"Gps port open %s\n", gpsserial);
			setMessage(strMsgLine);
			GpsConnectFlag = TRUE;
			if (gpsAck())
			{
				setMessage("Gps device found\n");
			}
			else
			{
				setMessage("Gps device not found\n");
				GpsDisconnect();
			}
		}
		else
		{
			tty_error_msg(err_code, ttyerrormsg, TTY_ERRMSG_SIZE);
			setMessage(ttyerrormsg);
			sprintf(strMsgLine,"Gps port not available ... \n");
			setMessage(strMsgLine);
		}	
	}
	return(GpsConnectFlag);
}

int GpsDisconnect()
{
	int err_code = 0;
	
	if(GpsConnectFlag == TRUE)
	{
		if (tty_disconnect(GpsPortFD) == 0)
		{
			GpsConnectFlag = FALSE;
			sprintf(strMsgLine, "Gps port disconnected\n");
			setMessage(strMsgLine);
		}
		else
		{
			tty_error_msg(err_code, ttyerrormsg, TTY_ERRMSG_SIZE);
			setMessage(ttyerrormsg);
			sprintf(strMsgLine,"TTy disconnect failed... \n");
			setMessage(strMsgLine);
		}		
	}
	return(GpsConnectFlag == FALSE);
}

int GetGPGGA(gpsdata *gps)
{
	int retval = 0;
	char gpsstr[GPS_LEN];
	time_t t0, t1;
	
	t0 = time(NULL);
	t1 = time(NULL);

	while ((difftime(t1, t0) < GPS_TIME) && (retval == 0))
	{
		if (ttyread(GpsPortFD, gpsstr, TTY_TIME) > 0)
		{
			if (memcmp(gpsstr, "$GPGGA", 6) == 0)
			{
				retval = 1;
				parseGPGGAString(gps, gpsstr);
			}
		}
		t1 = time(NULL);
	}
	return(retval);
}

/* Serial port utilities */
int ttyread(int fd, char *buf, int timeout)
{
	int err_code = 0, nbytes_read = 0;

	// Since the device is polling we have to clear pending buffer
	/* Flush the input buffer */
	tcflush(GpsPortFD,TCIOFLUSH);

	// Clear string(s)
	ttyerrormsg[0] = '\0';
	buf[0] = '\0';
    if ((err_code = tty_read_section(fd, buf, GPSRECSEPCHR, timeout, &nbytes_read)) == TTY_OK)
    {
		// Remove CR
		buf[nbytes_read-1] = '\0';
    }
    else
    {
		tty_error_msg(err_code, ttyerrormsg, TTY_ERRMSG_SIZE);
		setMessage(ttyerrormsg); 
	}
	return nbytes_read;
}

