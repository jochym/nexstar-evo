#ifndef SYNTA_H
	#define SYNTA_H
	/* -------------------------------------------------------------------------- */
	/* -      Protocol for Synta sky watcher telescope control (EQ6, HEQ5...    - */
	/* -------------------------------------------------------------------------- */
	/*                                                                            */
	/* Copyright 2013 Giampiero Spezzano                                           */
	/*                                                                            */
	/* Distributed under the terms of the General Public License (see LICENSE)    */
	/*                                                                            */
	/* Giampiero Spezzano (gspezzano@gmail.com)                                   */
	/*                                                                            */
	/* Official Skywatcher Protocol												  */
	/* See http://code.google.com/p/skywatcher/wiki/SkyWatcherProtocol            */
	/*																		      */
	/* This work is based on INDI skywatcher protocol from Geehalel               */
	/* (geehalel AT gmail DOT com) and eq6direct from Pierre Nerzic				  */
	/* (pierre.nerzic@free.fr)  												  */
	/* Marc 01, 2013                                                              */
	/*     First release                                                          */

	#define HEX(c) (((c) < 'A')?((c)-'0'):((c) - 'A') + 10)

	/* Site parameters are not defined here.                                     */    

	/* The following parameters are used internally to set speed and direction.  */
	/* Do not change these values.                                               */

	/* Tracking */
	#define STELLAR_DAY 86164.098903691
	#define SOLAR_DAY 86400
	#define TRACKRATE_SIDEREAL 15.041067179										//((360.0 * 3600.0) / STELLAR_DAY)
	#define TRACKRATE_SOLAR 15.0												//((360.0 * 3600.0) / SOLAR_DAY)
	#define TRACKRATE_LUNAR 14.511415

	/* Slew motion speeds                                                        */
	#define	GUIDE1		  2
	#define	GUIDE2		  4
	#define	CENTER3		  8
	#define	CENTER4		 32
	#define	CENTER5		 64
	#define	FIND6		128
	#define	FIND7		250
	#define	FIND8		400
	#define	SLEW9		800
	 
	/* Slew tolerances intentionally kept large to minimize looping              */
	#define SLEWTOLHA  0.006667 	/* 0.1/15 degree  or 24 seconds of time */
	#define SLEWTOLDEC 0.006667    	/*        degree  or 24 seconds of  arc  */

	#define CMD_RETRY    5
	#define READ_TIME    3
	#define CMD_LEN     16
	#define RES_LEN     16

    // Official Skywatcher Protocol
    // See http://code.google.com/p/skywatcher/wiki/SkyWatcherProtocol
	#define MODESLEW     0
	#define MODEGOTO     1
	#define SPEEDLOW     0
	#define SPEEDHIGH    1
	#define AXDIRNE      0
	#define AXDIRSW      1
	#define AXRA         1
	#define AXDE         2

    #define SWLEADCHR     ':'
    #define SWTRAILCHR    0x0D
    #define MIN_RATE      0.05
    #define MAX_RATE      800.0 
	#define LOWSPEED_RATE 128
	#define BRAKE_POINT  3500
	
	#define MAXREFRESH    0.5
	
	#define CMDAXINIT       'F'
	#define CMDGETMBVER     'e'
	#define CMDGETSTEPS360  'a'
	#define CMDGETSTEPSWORM 'b'
	#define CMDGETHSPDRATIO 'g'
	#define CMDGETPECPPER   's'
	#define CMDAXSTOPNOW    'L'
	#define CMDAXSTOP       'K'
	#define CMDSETAXPOS     'E'
	#define CMDGETAXPOS     'j'
	#define CMDGETAXSTATUS  'f'
	#define CMDSWITCH       'O'
	#define CMDSETMOTMODE   'G'
	#define CMDSETGOTOTGT   'H'
	#define CMDSETSLOWTGT   'M'
	#define CMDSETBKSTEPS   'U'
	#define CMDSETTRKSPD    'I'
	#define CMDSTARTMOVE    'J'
	#define CMDGETTRKSPD    'D' // See Merlin protocol http://www.papywizard.org/wiki/DevelopGuide
	#define CMDACTIVATE     'B' // See eq6direct implementation http://pierre.nerzic.free.fr/INDI/
	#define CMDSETGUIDERATE 'P'  // See EQASCOM driver
	
	#include "protocol.h"
#endif

