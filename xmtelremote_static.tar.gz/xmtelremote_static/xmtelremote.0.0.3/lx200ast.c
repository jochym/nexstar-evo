/* ------------------------------------------------------------------------- */
/* -           Protocol for LX200  command set telescope control           - */
/* ------------------------------------------------------------------------- */
/*                                                                           */
/* Copyright 2010 John Kielkopf                                              */
/*                                                                           */
/* Distributed under the terms of the General Public License (see LICENSE)   */
/*                                                                           */
/* John Kielkopf (kielkopf@louisville.edu)                                   */
/*                                                                           */
/* Date: August 11, 2010                                                     */
/* Version: 5.2.0                                                            */
/*                                                                           */
/* History:                                                                  */ 
/*                                                                           */
/* February 17, 2002 -- Version 1.00                                         */ 
/*   These routines originated with lx200.c by                               */ 
/*   Ken Shouse (kshouse@econtrols.com)                                      */ 
/*     as modified by Carlos Guirao (cguirao@eso.org).                       */ 
/*                                                                           */
/* November 20, 2002 -- Version 1.10                                         */ 
/*   Thanks to Peter McCullough for a correction to the routine for          */ 
/*     parsing declination.                                                  */ 
/*                                                                           */
/* April 17, 2003 -- Version 2.00                                            */ 
/*   New functions implemented following Peter McCullough's use              */ 
/*     of protocol.c in his cltel program.                                   */ 
/*                                                                           */ 
/* New in version 2.00 --                                                    */ 
/*   Control focus, fan, reticle, derotator                                  */ 
/*   Optional max slew rate at compile time                                  */ 
/*   Function to set slew rate in degrees/second                             */ 
/*   Stop all NSEW motions                                                   */ 
/*   Set time at LX200                                                       */ 
/*                                                                           */ 
/* August 13, 2005 -- Version 2.10                                           */ 
/*   Updated for compatibility with new xmtel functions under development    */ 
/*                                                                           */
/* March 25, 2006 -- Version 3.0                                             */ 
/*   New structure for implementing pointing corrections                     */ 
/*                                                                           */
/* September 3, 2006 -- Version 3.0.4                                        */ 
/*   Added null functions for alignment with other protocols                 */ 
/*                                                                           */
/* September 12, 2008 -- Version 5.0                                         */ 
/*   Modified to work with INDI version of xmtel                             */ 
/*                                                                           */
/* June 26, 2010 -- Version 5.2.0                                            */ 
/*   Modified for compatibility with current xmtel                           */ 
/*   Some of the new xmtel functions remain unsupported with the LX200       */
/*   Added serial port option to header                                      */
/* Giampiero Spezzano (gspezzano@gmail.com)                                  */
/*                                                                           */
/* Marc 22, 2013                                                             */
/*     First release (Adapted from Mr Kielkopf original)                     */
 
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>
#include <unistd.h>

#include <termios.h>

#include "lx200ast.h"
#include "ttycom.h"
#include "algorithms.h"
#include "pointing.h"
#include "logging.h"

#define NULL_PTR(x) (x *)0

/* System variables and prototypes */
/* Slew and track control */
int SetMaxRate(int slewRate);

/* LX200 local data */
static int slewphase = 0;             			/* Slew sequence counter 									*/
#ifdef ISFOCUS
	static int focuscount;      /* Used to keep a focus position count */
#endif

/* Communications variables and routines for internal use */
static int TelPortFD;
static int TelConnectFlag = FALSE;
static char strMsgLine[256];
static char ttyerrormsg[TTY_ERRMSG_SIZE];
static int  ishprecision = 0;

int ttyread(int fd, char *buf);
int ttywrite(int fd, const char *buffer);
int ttychrread(int fd, char *buf, int nbytes);
int getMountString(char *sendstr, char *returnstr, int expected);
int getMountAck(char *sendstr, char ackchar);
int tryMountString(char *sendstr, char *returnstr, int expected);
int tryMountAck(char *sendstr, char ackchar);
int tryMountHex(char *sendstr, char *returnstr, int length);

/* End of prototype and variable definitions */

#include "protocol.c"

/* Report on telescope connection status */
int CheckConnectTel(void)
{
	if (TelConnectFlag == TRUE)
	{
		return TRUE;
	}
	else
	{
		return FALSE;
	}
}

/* Connect to the telescope serial interface */
int ConnectTel(char *telserial)
{
	char returnstr[RES_LEN];
	int err_code = 0;	
	
	if(TelConnectFlag != TRUE)
	{
		// Make the connection 
		if ((err_code=tty_connect(telserial, 9600, 8, 0, 1, &TelPortFD)) == TTY_OK)
		{
			sprintf(strMsgLine,"Port open %s\n", telserial);
			setMessage(strMsgLine);

			TelConnectFlag = TRUE;

			// ask for local time to test connection
			if (getMountString(":GL#", returnstr, -1))
			{
				sprintf(strMsgLine,"Connected to serial port %s\n", telserial);
				setMessage(strMsgLine);
				sprintf(strMsgLine,"HC current time %s\n", returnstr);
				setMessage(strMsgLine);
			}
			else
			{
				// Some times a bonjour is needed
				sprintf(strMsgLine,"Could not send bonjour on %s\n", telserial);
				setMessage(strMsgLine);
				TelConnectFlag = FALSE;
			}
		}
		else
		{
			tty_error_msg(err_code, ttyerrormsg, TTY_ERRMSG_SIZE);
			setMessage(ttyerrormsg);
			sprintf(strMsgLine,"Serial port not available ... \n");
			setMessage(strMsgLine);
		}	
	}
	return(TelConnectFlag);
}

int CheckInfoTel(mount *mnt)
{
	char returnstr[RES_LEN];
	char sendstr[1] = {0x06};
	int retval = 0;

	if (TelConnectFlag)
	{
		mnt->teltype = GEM;
		if (tryMountString(":GVP#", returnstr, -1))
		{
			// Full LX200 command set is supported
			mnt->motver[0] = 11;
			mnt->motver[1] = '\0';
			mnt->modfeat[FLTRACK] = 1;
			mnt->modfeat[FLSITE] = 1;
			mnt->modfeat[FLGRATE] = 1;
			mnt->modfeat[FLPGUIDE] = 1;
			mnt->modfeat[FLFOCUS] = 1;
			mnt->modfeat[FLFAN] = 1;
			mnt->modfeat[FLHEATER] = 0;
			mnt->modfeat[FLROTAT] = 1;
			mnt->modfeat[FLRETIC] = 1;
			mnt->modfeat[FLMAXSLW] = 1;
			mnt->modfeat[FLLEVEL] = 0;
			// Product name
			strcpy(mnt->desc, returnstr);
			sprintf(strMsgLine,"Mount: %s\n", returnstr);
			setMessage(strMsgLine);
			if (strncmp(mnt->desc, "Autostar", strlen("Autostar")) == 0)
			{
				mnt->motver[0] = 11;
				mnt->motver[1] = '\0';
			}
			else
			{
				mnt->motver[0] = 2;
				mnt->motver[1] = '\0';
			}
			if (tryMountString(":GVN#", returnstr, -1))
			{
				// Firmware version
				memcpy(mnt->hcver, returnstr, strlen(returnstr));
				sprintf(strMsgLine,"Hc firmware: %s\n", returnstr);
				setMessage(strMsgLine);

				// Flush the input buffer
				tcflush(TelPortFD,TCIOFLUSH);
				// Need to use low level functions because some versions do not return trailing #
				if (ttywrite(TelPortFD, ":GW#"))
				{
					usleep(10000);
					if (ttychrread(TelPortFD, returnstr, 3) == 3)
					{
						// <Mount><Tracking><Alignment>
						//fprintf(stderr, ":GW# = '%s'\n", returnstr);
						switch (returnstr[0])
						{
							case 'A':
								mnt->teltype = ALTAZ;
								sprintf(strMsgLine,"Type: AltAz\n");
								setMessage(strMsgLine);
								break;
							case 'P':
								mnt->teltype = EQFORK;
								sprintf(strMsgLine,"Type: Eq\n");
								setMessage(strMsgLine);
								break;
							case 'G':
								mnt->teltype = GEM;
								sprintf(strMsgLine,"Type: GEM\n");
								setMessage(strMsgLine);
								break;
						}
						mnt->teltypefixed = 1;
						switch (returnstr[1])
						{
							case 'N':
								mnt->trkActive = 0;
								sprintf(strMsgLine,"Mount is stopped\n");
								setMessage(strMsgLine);
								break;
							case 'T':
								mnt->trkActive = 1;
								sprintf(strMsgLine,"Mount is tracking\n");
								setMessage(strMsgLine);
								break;
						}
						switch (returnstr[2])
						{
							case '0':
								mnt->align = 0;
								sprintf(strMsgLine,"Mount is not aligned\n");
								setMessage(strMsgLine);
								break;
							default:
								mnt->align = 1;
								sprintf(strMsgLine,"Mount is aligned\n");
								setMessage(strMsgLine);
								break;
						}
						retval = 1;
					}
				}
				else
				{
					sprintf(strMsgLine, "chkInfoTel: Attempt write command %s, failed.\n", ":GW#");
					setMessage(strMsgLine); 
				}
			}		
		}
		else if (tryMountString(":GV#", returnstr, -1))
		{
			// Should be Rajiva LittleFoot controller 
			// Full LX200 command set is supported
			mnt->motver[0] = 1;
			mnt->motver[1] = '\0';
			mnt->modfeat[FLTRACK] = 1;
			mnt->modfeat[FLSITE] = 0;
			mnt->modfeat[FLGRATE] = 0;
			mnt->modfeat[FLPGUIDE] = 1;
			mnt->modfeat[FLFOCUS] = 1;
			mnt->modfeat[FLFAN] = 1;
			mnt->modfeat[FLHEATER] = 0;
			mnt->modfeat[FLMAXSLW] = 0;
			mnt->modfeat[FLROTAT] = 0;
			mnt->modfeat[FLRETIC] = 0;
			mnt->modfeat[FLLEVEL] = 0;
			// Product name
			strcpy(mnt->desc, "Rajiva LittleFoot");
			sprintf(strMsgLine,"Mount: %s\n", mnt->desc);
			setMessage(strMsgLine);
			// Firmware version
			memcpy(mnt->hcver, returnstr, strlen(returnstr));
			sprintf(strMsgLine,"Hc firmware: %s\n", returnstr);
			setMessage(strMsgLine);
			if (tryMountHex(sendstr, returnstr, 1))
			{
				switch (returnstr[0])
				{
					case 'A':
						mnt->teltype = ALTAZ;
						sprintf(strMsgLine,"Type: AltAz\n");
						setMessage(strMsgLine);
						break;
					case 'P':
					    // This is to allow a force through config as controllers may return P for both Gem and EqFork
						if (!mnt->teltypefixed || (mnt->teltypefixed && mnt->teltype == ALTAZ))
						{
							mnt->teltype = EQFORK;
							sprintf(strMsgLine,"Type: Eq\n");
						}
						else
						{
							if (mnt->teltype == GEM)
							{
								sprintf(strMsgLine,"Type: GEM\n");
							}
							else
							{
								sprintf(strMsgLine,"Type: Eq\n");
							}
						}
						setMessage(strMsgLine);
						break;
					case 'G':
						mnt->teltype = GEM;
						sprintf(strMsgLine,"Type: GEM\n");
						setMessage(strMsgLine);
						break;
					case 'L':
						sprintf(strMsgLine,"Rajiva driver can't switch from Land mode\nTelescope disconnected\n");
						setMessage(strMsgLine);
						TelConnectFlag = FALSE;
						close(TelPortFD);
						break;
					default:
						sprintf(strMsgLine,"Unknown mount mode\nTelescope disconnected\n");
						setMessage(strMsgLine);
						TelConnectFlag = FALSE;
						close(TelPortFD);
						break;
				}
				mnt->teltypefixed = 1;
				retval = 1;
			}
		}
		else if (tryMountHex(sendstr, returnstr, 1))
		{
			mnt->motver[0] = 0;
			mnt->motver[1] = '\0';
			mnt->modfeat[FLTRACK] = 0;
			mnt->modfeat[FLSITE] = 0;
			mnt->modfeat[FLGRATE] = 0;
			mnt->modfeat[FLPGUIDE] = 0;
			mnt->modfeat[FLFOCUS] = 0;
			mnt->modfeat[FLFAN] = 0;
			mnt->modfeat[FLHEATER] = 0;
			mnt->modfeat[FLMAXSLW] = 0;
			mnt->modfeat[FLROTAT] = 0;
			mnt->modfeat[FLRETIC] = 0;
			mnt->modfeat[FLLEVEL] = 0;
			// Only subset LX200 command set is supported
			strcpy(mnt->desc, "LX200 Generic");
			sprintf(strMsgLine,"Mount: %s\n", mnt->desc);
			setMessage(strMsgLine);
			switch (returnstr[0])
			{
				case 'A':
					mnt->teltype = ALTAZ;
					sprintf(strMsgLine,"Type: AltAz\n");
					setMessage(strMsgLine);
					break;
				case 'P':
					// This is to allow a force through config as controllers may return P for both Gem and EqFork
					if (!mnt->teltypefixed || (mnt->teltypefixed && mnt->teltype == ALTAZ))
					{
						mnt->teltype = EQFORK;
						sprintf(strMsgLine,"Type: Eq\n");
					}
					else
					{
						if (mnt->teltype == GEM)
						{
							sprintf(strMsgLine,"Type: GEM\n");
						}
						else
						{
							sprintf(strMsgLine,"Type: Eq\n");
						}
					}
					setMessage(strMsgLine);
					break;
				case 'G':
					mnt->teltype = GEM;
					sprintf(strMsgLine,"Type: GEM\n");
					setMessage(strMsgLine);
					break;
				case 'L':
					sprintf(strMsgLine,"LX200 generic driver can't switch from Land mode\nTelescope disconnected\n");
					setMessage(strMsgLine);
					TelConnectFlag = FALSE;
					close(TelPortFD);
					break;
				default:
					sprintf(strMsgLine,"Unknown mount mode\nTelescope disconnected\n");
					setMessage(strMsgLine);
					TelConnectFlag = FALSE;
					close(TelPortFD);
					break;
			}
			mnt->teltypefixed = 1;
			if (TelConnectFlag == TRUE)
			{
				mnt->trkActive = 1;
				mnt->trkStatus = 1;
				mnt->trkspd = SIDEREAL;
				sprintf(strMsgLine,"Mount is tracking\nRate is Sidereal\nLX200 Generic can't control tracking\n");
				setMessage(strMsgLine);
				retval = 1;
			}
		}
		else
		{
			sprintf(strMsgLine,"LX200 command set too limited to be supported\nTelescope disconnected\n");
			setMessage(strMsgLine);
			TelConnectFlag = FALSE;
			close(TelPortFD);
		}
	}
	return(retval);
}

int CheckInitTel(mount *mnt)
{
	//int limits;
	char returnstr[RES_LEN];
	int retval = 1;
	double tra = 0., tdec = 0.; 
	
	if (TelConnectFlag)
	{
		// Check precision pointing and toggle to high precision if needed 
		if (tryMountString(":GR#", returnstr, -1))
		{
			if (strlen(returnstr) < 8)
			{
				if (ttywrite(TelPortFD,":U#"))
				{
					usleep(250000);
					if (tryMountString(":GR#", returnstr, -1))
					{
						if (strlen(returnstr) < 8)
						{
							ishprecision = 0;
							sprintf(strMsgLine,"Telescope does not support high accuracy mode\nUsing low accuracy mode");
							setMessage(strMsgLine);
						}
						else
						{
							ishprecision = 1;
							sprintf(strMsgLine,"Telescope is now in high accuracy mode\n");
							setMessage(strMsgLine);
						}
					}
				}
				else
				{
					sprintf(strMsgLine,"Failed to set high accuracy mode!\n");
					setMessage(strMsgLine);
					retval = 0;
				}
			}
			else
			{
				ishprecision = 1;
				sprintf(strMsgLine,"Telescope is in high accuracy (already)\n");
				setMessage(strMsgLine);
			}

			if (!mnt->align)
			{
				// If mount is aligned we keep current reading
				retval = SetHomeNowTel(mnt);
			}
			else
			{
				if (GetTel(mnt, &tra, &tdec, RAW))
				{
					sprintf(strMsgLine,"Mount now reading RA: %lf\n Mount now reading Dec: %lf\n", tra, tdec);
					setMessage(strMsgLine);
					retval = 1;
				}
			}

			if (retval)
			{
				if (mnt->modfeat[FLTRACK])
				{
					if (mnt->trkStatus != mnt->trkActive)
					{
						SetTrack(mnt);
					} 
				}
				#ifdef ISLIMITS
					// Perform startup tests 
					/* Limit override is not allowed for now
					if (!GetLimits(&limits))
					{
						usleep(500000);
						limits = FALSE;
						if (!SetLimits(limits))
						{
							usleep(500000);  
							GetLimits(&limits);
						}
					}*/
				#endif
				// Set initial guiderate
				if (mnt->modfeat[FLGRATE])
				{
					mnt->guideratera = 25;
					SetGuideSpd(mnt, mnt->guideratera, 0);
					mnt->guideratedec = 25;			
					SetGuideSpd(mnt, mnt->guideratedec, 1);
				}
				if (mnt->modfeat[FLMAXSLW])
				{
					if (mnt->quietslew)
					{
						retval = SetMaxRate(2);
					}
				}
			}
		}
		else
		{
			retval = 0;
		}
	}
	else
	{
		retval = 0;
	}
	return(retval);
}

int SetMountDefaultHome(mount *mnt)
{
	int retval = 1;
	if (!mnt->homefixed)
	{
		if (mnt->telmode == GEM)
		{
			if (mnt->SiteLatitude < 0.)
			{
				mnt->homedec = -89.9999;
				mnt->homeha = 6.;
			}
			else
			{  
				mnt->homedec = 89.9999;
				mnt->homeha = -6.;
			}
		}
		else if (mnt->telmode == EQFORK)
		{
			if (mnt->SiteLatitude < 0.)
			{
				mnt->homedec = 0.;
				mnt->homeha = 0.;
			}
			else
			{  
				mnt->homedec = 0.;
				mnt->homeha = 0.;
			}
		}
		else if (mnt->telmode == ALTAZ)
		{
			/* Set azimuth */
			mnt->homeha = 0.;    

			/* Set altitude */
			mnt->homedec = 0.; 
		}
		else
		{
			sprintf(strMsgLine,"SetMountDefaultHome: Telescope mounting must be GEM, EQFORK, or ALTAZ\n");
			setMessage(strMsgLine);
			retval = 0;
		}
	}
	if (!mnt->parkfixed)
	{
		mnt->parkha = mnt->homeha;
		mnt->parkdec = mnt->homedec;
	}
	return retval;
}

int SetHomeNowTel(mount *mnt)
{
	int retval = 0;
	time_t local;
	struct tm tmlocal;
	char sendstr[CMD_LEN];
	//char returnstr[RES_LEN];
	double value;
	int valh, valm, valy;
	double homeha= 0., homera = 0., homedec = 0.;
	char tmpHour[10];
	double tmpVal;

	if (TelConnectFlag)
	{
		if (mnt->modfeat[FLSITE])
		{
			// Set Date, Time, DST, Site Latitude, Longitude
			local   = time(NULL);
			tmlocal = *localtime(&local);
			valy = tmlocal.tm_year - 100;
			sprintf(sendstr, ":SC%02d/%02d/%02d#", tmlocal.tm_mon, tmlocal.tm_mday, valy);
			//fprintf(stderr, ":SC%02d/%02d/%02d#", tmlocal.tm_mon, tmlocal.tm_mday, valy);
			if (tryMountAck(sendstr, '1'))
			{
				// Some time is needed to allow HC sky model to update
				usleep(500000);
				sprintf(sendstr, ":SL%02d:%02d:%02d#", tmlocal.tm_hour, tmlocal.tm_min, tmlocal.tm_sec);
				//fprintf(stderr, ":SL%02d:%02d:%02d#", tmlocal.tm_hour, tmlocal.tm_min, tmlocal.tm_sec);
				if (tryMountAck(sendstr, '1'))
				{
					//usleep(100000);
					sprintf(sendstr, ":SH%d#", (tmlocal.tm_isdst > 0));
					//fprintf(stderr, ":SH%d#", (tmlocal.tm_isdst > 0));
					if (tryMountAck(sendstr, '1'))
					{
						//usleep(100000);
						value = mnt->SiteLatitude;
						valh = (int) value;
						valm = lround(fabs((value  - valh)) * 60);
						sprintf(sendstr, ":St%+02d*%02d#", valh, valm);
						//fprintf(stderr, ":St%+02d*%02d#", valh, valm);
						if (tryMountAck(sendstr, '1'))
						{
							//usleep(100000);
							// Meade uses "wrong" standard for longitude
							value = (mnt->SiteLongitude > 0) ? (360 - mnt->SiteLongitude) : fabs(mnt->SiteLongitude);
							valh = (int) value;
							valm = lround((value  - valh) * 60);
							sprintf(sendstr, ":Sg%03d*%02d#", valh, valm);
							//fprintf(stderr, ":Sg%03d*%02d#", valh, valm);
							if (tryMountAck(sendstr, '1'))
							{
								//usleep(100000);
								if (ttywrite(TelPortFD,":hF#") > 0)
								{
									//We need reset encoder on home position before being able to set anything else
									retval = 1;
								}
								else
								{
									sprintf(strMsgLine,"SetHomeNowTel: Error resetting encoders on built in position!\n");
									setMessage(strMsgLine);
									retval = 0;
								}
							}
							else
							{
								sprintf(strMsgLine,"Could not set HC site lon: %s\n", sendstr);
								setMessage(strMsgLine);	
							}		
						}
						else
						{
							sprintf(strMsgLine,"Could not set HC site lat: %s\n", sendstr);
							setMessage(strMsgLine);	
						}
					}		
					else
					{
						sprintf(strMsgLine,"Could not set HC DST: %s\n", sendstr);
						setMessage(strMsgLine);	
					}		
				}
				else
				{
					sprintf(strMsgLine,"Could not set HC local time to %s\n", sendstr);
					setMessage(strMsgLine);	
				}		
			}
			else
			{
				sprintf(strMsgLine,"Could not set HC data to %s\n", sendstr);
				setMessage(strMsgLine);	
			}
		}
		else
		{
			retval = 1;
		}
		if (retval)
		{
			sprintf(strMsgLine, "Using initial HA(RA): %lf(%lf)\n", mnt->homeha, (Map24(LSTNow(mnt->SiteLongitude) - mnt->homeha)));
			setMessage(strMsgLine);
			sprintf(strMsgLine, "Using initial Dec: %lf\n",mnt->homedec); 
			setMessage(strMsgLine);
			if (SetTel(mnt, mnt->homeha, mnt->homedec))
			{
				mnt->offsetabsra = 0.;
				mnt->offsetabsdec = 0.;
				//fprintf(stderr,"offsetabsra : %f h\n", mnt->offsetabsra);
				//fprintf(stderr,"offsetabsdec: %f deg\n", mnt->offsetabsdec);
				/* Read encoders and confirm pointing */
				if (GetTel(mnt, &homera, &homedec, RAW))
				{
					homeha = Map12(LSTNow(mnt->SiteLongitude) - homera);
					sprintf(strMsgLine, "Local latitude: %lf\n", mnt->SiteLatitude);
					setMessage(strMsgLine);
					sprintf(strMsgLine, "Local longitude: %lf\n", mnt->SiteLongitude);
					setMessage(strMsgLine);
					tmpVal = Map24(LSTNow(mnt->SiteLongitude));
					dtodms(tmpHour, &tmpVal);
					sprintf(strMsgLine, "Local sidereal Time: %s\n", tmpHour);
					setMessage(strMsgLine);
					sprintf(strMsgLine, "Mount mode: %u\n", mnt->telmode);
					setMessage(strMsgLine);
					sprintf(strMsgLine, "Mount now reading HA(RA): %lf(%lf)\n", homeha, homera);
					setMessage(strMsgLine);
					sprintf(strMsgLine, "Mount now reading Dec: %lf\n", homedec);
					setMessage(strMsgLine);
				}
				else
				{
					retval = 0;
				}
				// We need to stop tracking because it starts when Sync.
				if (mnt->trkStatus != mnt->trkActive)
				{
					SetTrack(mnt);
				}
			}	
			else
			{
				retval = 0;
			}
		}
	}
	return(retval);
}

/* Set mount mode */
int SetMountMode(mount *mnt, int newMode)
{
	if (newMode >= ALTAZ && newMode <= GEM)
	{
		mnt->telmode = newMode;
		SetMountDefaultHome(mnt);
	}
	sprintf(strMsgLine,"Mount Mode set to %u\n", mnt->telmode);
	setMessage(strMsgLine);	
	return(0);
}

/* Set the speed for a motion command */
int SetRate(mount *mnt, int newRate)
{
	int retval = 0; 
	
	switch (newRate)
	{
		case SLEW9:
  		    retval = 1;
			mnt->telspd = SLEW9;
  		    break;
  		case FIND6:
    		retval = 1;
			mnt->telspd = FIND6;
    		break;
		case CENTER3:
			retval = 1;
			mnt->telspd = CENTER3;
			break;
		case GUIDE1:
    		retval = 1;
			mnt->telspd = GUIDE1;
			break;
	}
	if (retval)
	{
		sprintf(strMsgLine,"Slew rate set to %c\n", mnt->telspd);
	}
	else
	{
		sprintf(strMsgLine,"SetRate: could not set slew rate\n");		
	}
	setMessage(strMsgLine);
	return(retval);
}

int SetTrkSpd(mount *mnt, double newRate)
{
	int retval = 0;
	
	if (mnt->modfeat[FLTRACK])
	{
		switch ((int) newRate)
		{
			case SIDEREAL:
				mnt->trkspd = SIDEREAL;
				sprintf(strMsgLine,"Track rate set to sidereal\n");	
				retval = 1;
				break;
			case LUNAR:
				mnt->trkspd = LUNAR;
				sprintf(strMsgLine,"Track rate set to lunar\n");		
				retval = 1;
				break;
			case SOLAR:
				mnt->trkspd = SOLAR;
				sprintf(strMsgLine,"Track rate set to solar\n");		
				retval = 1;
				break;
			default:
				if (newRate > 0)
				{
				}
		}
		if (!retval)
		{
			sprintf(strMsgLine,"SetTrkSpd: could not set track rate\n");		
		}
	}
	else
	{
		sprintf(strMsgLine,"SetTrkSpd: tracking rate change is not supported\n");		
	}
	setMessage(strMsgLine);
	return(retval);
}

int SetGuideSpd(mount *mnt, int val, int radec)
{
	double guideval;
	int    retval = 0;
	char   outstr[CMD_LEN];
	
	if (mnt->modfeat[FLGRATE])
	{
		if (TelConnectFlag)
		{
			if (val >= 0 && val <= 100)
			{
				if (radec == 0) 
				{
					mnt->guideratera = val;
				}
				if (radec == 1) 
				{
					mnt->guideratedec = val;
				}
				guideval = TRACKRATE_SIDEREAL * val / 100.;
				sprintf(outstr,":Rg%2.1f#", guideval);
				retval = (ttywrite(TelPortFD, outstr) > 0);
			}
		}
	}
	else
	{
		sprintf(strMsgLine,"SetGuideSpd: Guide rate change is not supported\n");		
		setMessage(strMsgLine);
	}
	return(retval);
}

int GetGuideSpd(mount *mnt, int *val, int radec)
{
	int retval = 1;

	if (radec == 0) 
	{
		*val = mnt->guideratera;
	}
	if (radec == 1) 
	{
		*val = mnt->guideratedec;
	}
	return(retval);
}

int GetGuideStep(void)
{
	// Step on the Gui is 1
	return(1);
}

/* Start a slew in chosen direction at slewRate */
int StartSlew(mount *mnt, int direction)
{
	int retval = 0;

	if (TelConnectFlag)
	{
		/* If there's a slew in progress we need to cancel il properly and restore the tracking status*/  
		if (slewphase)
		{
			sprintf(strMsgLine, "Canceling the current goto operation\n");
			setMessage(strMsgLine);
			retval = FullStop(mnt);
			if (mnt->modfeat[FLTRACK])
			{
				if(mnt->trkStatus != mnt->trkActive)
				{
					retval = SetTrack(mnt);
				}
			}
		}
		else
		{
			// We need to be sure the speed is the one intended
			// Someone on the aux port can change?
			switch (mnt->telspd)
			{
				case SLEW9:
		  		    retval = (ttywrite(TelPortFD,":RS#") > 0);
					usleep(10000);
		  		    break;
		  		case FIND6:
					retval = (ttywrite(TelPortFD,":RM#") > 0);
					usleep(10000);
					break;
				case CENTER3:
					retval = (ttywrite(TelPortFD,":RC#") > 0);
					usleep(10000);
					break;
				case GUIDE1:
					retval = (ttywrite(TelPortFD,":RG#") > 0);
					usleep(10000);
					break;
			}
			if (retval)
			{
				retval =  0;
				switch (direction)
				{
					case NORTH:		
						retval = (ttywrite(TelPortFD,":Mn#") > 0);
						usleep(10000);
						sprintf(strMsgLine, "Slewing north\n");
						break;
			  		case EAST:
						retval = (ttywrite(TelPortFD,":Me#") > 0);
						usleep(10000);
						sprintf(strMsgLine, "Slewing east\n");
						break;
					case SOUTH:
						retval = (ttywrite(TelPortFD,":Ms#") > 0);
						usleep(10000);
						sprintf(strMsgLine, "Slewing south\n");
						break;
					case WEST:
						retval= (ttywrite(TelPortFD,":Mw#") > 0);
						usleep(10000);
						sprintf(strMsgLine, "Slewing west\n");
						break;
				}
				if (!retval)
				{
					sprintf(strMsgLine,"StartSlew: could not start slew\n");		
				}
			}
			else
			{
				sprintf(strMsgLine,"StartSlew: could not set slew speed\n");		
			}
			setMessage(strMsgLine);
		}
	}
	return(retval);
}

/* Stop the slew in chosen direction */
int StopSlew(mount *mnt, int direction)
{
	int retval = 0;

	if (TelConnectFlag)
	{
		/* If there's a slew in progress we need to cancel il properly and restore the tracking status*/  
		if (slewphase)
		{
			sprintf(strMsgLine, "Canceling the current goto operation\n");
			setMessage(strMsgLine);
			retval = FullStop(mnt);
			if (mnt->modfeat[FLTRACK])
			{
				if(mnt->trkStatus != mnt->trkActive)
				{
					retval = SetTrack(mnt);
				}
			}
		}
		else
		{
			switch (direction)
			{
				case NORTH:		
					retval = (ttywrite(TelPortFD,":Qn#") > 0);
					break;
		  		case EAST:
					retval = (ttywrite(TelPortFD,":Qe#") > 0);
					break;
				case SOUTH:
					retval = (ttywrite(TelPortFD,":Qs#") > 0);
					break;
				case WEST:
					retval = (ttywrite(TelPortFD,":Qw#") > 0);
					break;
			}
			if (retval)
			{
				sprintf(strMsgLine,"Slew stopped\n");		
			}
			else
			{
				sprintf(strMsgLine,"StopSlew: could not stop slew\n");		
			}
			setMessage(strMsgLine);
		}
	}
	return(retval);
}

int DisconnectTel(mount *mnt)
{
	int err_code = 0;
	
	if(TelConnectFlag == TRUE)
	{
		if (mnt->modfeat[FLTRACK])
		{
			if(mnt->trkActive)
			{
				StopTrack(mnt);
			}
		}
		else
		{
			sprintf(strMsgLine, "Warning: Telescope will still track after disconnection\n");
			setMessage(strMsgLine);
		}
		if (tty_disconnect(TelPortFD) == 0)
		{
			TelConnectFlag = FALSE;
			sprintf(strMsgLine, "Telescope disconnected\n");
			setMessage(strMsgLine);
		}
		else
		{
			tty_error_msg(err_code, ttyerrormsg, TTY_ERRMSG_SIZE);
			setMessage(ttyerrormsg);
			sprintf(strMsgLine,"TTy disconnect failed... \n");
			setMessage(strMsgLine);
		}		
	}
	return(TelConnectFlag == FALSE);
}

// Sync telescope on Ha/Dec (no pointing correction is performed here)
// We set the target to Ra/Dec (Ra corresponding to Ha @ current time)
// Then we sync on target
int SetTel(mount *mnt, double setha, double setdec)
{
	double setra;
	int    raHr, raMin, raSec;
	int    decDeg, decMin, decSec;
	double dms, hms, ms;
	char   outputStr[CMD_LEN], inputStr[RES_LEN];
	int    retval = 0;

	if (TelConnectFlag)
	{
		// Get target Ra from Ha
		setra = Map24(LSTNow(mnt->SiteLongitude) - setha);
		
		/* Check altitude limit 
		if (!ChkTarget(mnt, setra, setdec, RAW))
		{
			slewphase = 0;
			return(0);
		}
		*/

		/* German equatorial */
		if (mnt->telmode == GEM)
		{
			/* Basis is needed for future Chk MedianFlip */
			if (setha < 0.)
			{ 
				/* OTA west of pier looking east */
				mnt->basis = -1;
			}
			else if (setha > 0.)
			{ 
				/*OTA east of pier looking west */
				mnt->basis = 1;
			}
			else if ((setha == 0.) && ( setdec >= 0))
			{ 
				/*OTA east of pier looking west */
				mnt->basis = 1;
			}
			else if ((setha == 0.) && ( setdec < 0))
			{ 
				/* OTA west of pier looking east */
				mnt->basis = -1;
			}
		}
		
		// Set target Ra/Dec to mount
		if (ishprecision)
		{
			/* In high precision mode, we must send hh:mm:ss and dd:mm:ss */
			/* Allow for truncation if input is in seconds of arc */
			hms = setra;
			hms = hms + 0.5/3600.;
			raHr = (int) hms;
			ms = hms - (double) raHr;
			ms = ms*60.;
			raMin = (int) ms;
			raSec = (int) 60.*(ms - (double) raMin);

			sprintf(outputStr, ":Sr %02d:%02d:%02d#\n", raHr, raMin, raSec);
		}
		else
		{
			/* In Low precision mode, we must send hh:mm.t and dd:mm */
			hms = setra;
			raHr = (int) hms;
			ms = hms - (double) raHr;
			ms = ms * 60.;
			raMin = (int) ms;
			raSec = (int) 10.*(ms - (double) raMin);

			sprintf(outputStr, ":Sr %02d:%02d.%01d#\n", raHr, raMin, raSec);
		}
		
		if(getMountAck(outputStr, '1'))
		{
			if (ishprecision)
			{
				dms = fabs(setdec);
				dms = dms + 0.5/3600.;
				decDeg = (int) dms;
				ms = dms - (double) decDeg;
				ms = ms*60.;
				decMin = (int) ms;
				decSec = (int) 60.*(ms - (double) decMin);
				if(setdec >= 0.0)
				{
					sprintf(outputStr,":Sd +%02d*%02d:%02d#\n",decDeg,decMin,decSec);
				}
				else
				{
					sprintf(outputStr,":Sd -%02d*%02d:%02d#\n",decDeg,decMin,decSec);
				}
			}
			else
			{
				dms = fabs(setdec);
				decDeg = (int) dms;
				ms = dms - (double) decDeg;
				ms = ms*60.;
				decMin = lround(ms);
				decSec = 0;
				if(setdec >= 0.0)
				{
					sprintf(outputStr,":Sd +%02d*%02d#\n",decDeg,decMin);
				}
				else
				{
					sprintf(outputStr,":Sd -%02d*%02d#\n",decDeg,decMin);
				}
			}

			if(getMountAck(outputStr, '1')) 
			{
				if (getMountString(":CM#", inputStr, -1))
				{
					// Sync command
					retval = 1;
					// Sync also start tracking, so
					mnt->trkActive = 1;
				}
				else 
				{
					sprintf(strMsgLine,"SetTel: Object is outside HC goto limits\n");
					setMessage(strMsgLine);
				}
			}
			else
			{
				sprintf(strMsgLine,"SetTel: Error setting object DEC\n");
				setMessage(strMsgLine);
			}
		}
		else
		{
			sprintf(strMsgLine,"SetTel: Error setting object RA\n");
			setMessage(strMsgLine);
		}
	}
	return(retval);
}

int GetTel(mount *mnt, double *telra, double *teldec, int pmodel)
{  
	int    retval = 0; 
	char   returnstr[RES_LEN];
	double raHr,raMin,raSec;
	double decDeg,decMin,decSec;
	double telra1 = 0.;
	double teldec1 = 0.;
	
	if (getMountString(":GR#", returnstr, ((ishprecision) ? 8 : 7)))
	{
		if (ishprecision)
		{
			sscanf(returnstr,"%lf:%lf:%lf", &raHr, &raMin, &raSec);	
			telra1 = raHr + raMin/60.0 + raSec/3600.0;
		}
		else
		{
			sscanf(returnstr,"%lf:%lf.%lf", &raHr, &raMin, &raSec);	
			telra1 = raHr + raMin/60.0 + raSec/600.0;
		}
		if (getMountString(":GD#", returnstr, ((ishprecision) ? 9 : 6)))
		{
			/*   Since the LX200 may return something other than ':' as a delimiter,      */ 
			/*   we swap the delimiter to ":" no matter what                              */

			/*   Thanks to cltel this now returns correct sign when decDeg = 0            */
			if (ishprecision)
			{
				returnstr[3] = returnstr[6] = ':';  
				sscanf(returnstr,"%lf:%lf:%lf",&decDeg, &decMin, &decSec);                  
				teldec1 = (double) fabs(decDeg) + decMin/60.0 + decSec/3600.0;
			}
			else
			{
				returnstr[3] = ':';  
				sscanf(returnstr,"%lf:%lf",&decDeg, &decMin);                  
				decSec = 0;
				teldec1 = (double) fabs(decDeg) + decMin/60.0;
			}
			if(returnstr[0] == '-')
			{
				teldec1 *= -1.;
			}
			/* Correct the coordinates that are reported by the telescope */
			PointingFromTel(mnt, telra, teldec, telra1, teldec1, pmodel);
			retval = 1;
		}
		else
		{
			sprintf(strMsgLine,"GetTel: Error reading actual mount position (Dec)\n");
			setMessage(strMsgLine);
		}
	}
	else
	{
		sprintf(strMsgLine,"GetTel: Error reading actual mount position (Ra)\n");
		setMessage(strMsgLine);
	}
	return(retval);
}

/* Go to new celestial coordinates                                    */
/* Evaluate if target coordinates are valid                           */
/* Test slew limits in altitude, polar, and hour angles               */
/* Query if target is above the horizon                               */
/* Return without action for invalid requests                         */
/* Interrupt any slew sequence in progress                            */
/* Set slewphase equal to number of slew segments needed              */
/* Return 1 if underway                                               */
/* Return 0 if done or not permitted                                  */
int GoToCoords(mount *mnt, double newra, double newdec, int pmodel, int abspos)
{
	double newra0, newdec0, newdec1;
	double newha0, newha1;
	int    raHr, raMin, raSec;
	int    decDeg, decMin, decSec;
	double dms, hms, ms;
	char   outputStr[CMD_LEN];
	int    retval = 0;

	if (TelConnectFlag)
	{
		strcat(strMsgLine,"Setting up a goto slew to target\n"); 
		setMessage(strMsgLine);

		/* Mount coordinates for the target */
		if (!abspos)
		{
			PointingToTel(mnt, &newra0, &newdec0, newra, newdec, pmodel);  
		}
		else
		{
			newra0 = newra + mnt->offsetabsra;
			newdec0 = newdec - mnt->offsetabsdec;
		}

		newha0 = Map12(LSTNow(mnt->SiteLongitude) - newra0);
	
		/* Check altitude limit */
		if (!abspos)
		{
			if (!ChkTarget(mnt, newra0, newdec0, RAW))
			{
				slewphase = 0;
				return(0);
			}
		}

		/* German equatorial */
		if (mnt->telmode == GEM)
		{
			/* Flip signs for the southern sky */
			newdec1 = (mnt->SiteLatitude < 0.) ? -1. * newdec0 : newdec0;
			newha1 = (mnt->SiteLatitude < 0.) ? -1. * newha0 : newha0;
			
			/* Basis is needed for future Chk MedianFlip */
			if (newha1 < 0.)
			{ 
				/* OTA west of pier looking east */
				mnt->basis = -1;
			}
			else if (newha1 > 0.)
			{ 
				/*OTA east of pier looking west */
				mnt->basis = 1;
			}
			else if ((newha1 == 0.) && ( newdec1 >= 0))
			{ 
				/*OTA east of pier looking west */
				mnt->basis = 1;
			}
			else if ((newha1 == 0.) && ( newdec1 < 0))
			{ 
				/* OTA west of pier looking east */
				mnt->basis = -1;
			}
		}
		
		if (ishprecision)
		{
			/* In high precision mode, we must send hh:mm:ss and dd:mm:ss */
			/* Allow for truncation if input is in seconds of arc */
			hms = newra0;
			hms = hms + 0.5/3600.;
			raHr = (int) hms;
			ms = hms - (double) raHr;
			ms = ms*60.;
			raMin = (int) ms;
			raSec = (int) 60.*(ms - (double) raMin);

			sprintf(outputStr, ":Sr %02d:%02d:%02d#\n", raHr, raMin, raSec);
		}
		else
		{
			/* In Low precision mode, we must send hh:mm.t and dd:mm */
			hms = newra0;
			raHr = (int) hms;
			ms = hms - (double) raHr;
			ms = ms * 60.;
			raMin = (int) ms;
			raSec = (int) 10.*(ms - (double) raMin);

			sprintf(outputStr, ":Sr %02d:%02d.%01d#\n", raHr, raMin, raSec);
		}

		if(getMountAck(outputStr, '1'))
		{
			if (ishprecision)
			{
				dms = fabs(newdec0);
				dms = dms + 0.5/3600.;
				decDeg = (int) dms;
				ms = dms - (double) decDeg;
				ms = ms*60.;
				decMin = (int) ms;
				decSec = (int) 60.*(ms - (double) decMin);
				if(newdec0 >= 0.0)
				{
					sprintf(outputStr,":Sd +%02d*%02d:%02d#\n",decDeg,decMin,decSec);
				}
				else
				{
					sprintf(outputStr,":Sd -%02d*%02d:%02d#\n",decDeg,decMin,decSec);
				}
			}
			else
			{
				dms = fabs(newdec0);
				decDeg = (int) dms;
				ms = dms - (double) decDeg;
				ms = ms*60.;
				decMin = lround(ms);
				decSec = 0;
				if(newdec0 >= 0.0)
				{
					sprintf(outputStr,":Sd +%02d*%02d#\n",decDeg,decMin);
				}
				else
				{
					sprintf(outputStr,":Sd -%02d*%02d#\n",decDeg,decMin);
				}
			}

			if(getMountAck(outputStr, '1')) 
			{
				if (getMountAck(":MS#", '0'))
				{
					// Goto in progress
					retval = 1;
					slewphase = 1;
					// Goto also start tracking, so
					mnt->trkActive = 1;
				}
				else 
				{
					sprintf(strMsgLine,"GoToCoords: Object is outside HC goto limits\n");
					setMessage(strMsgLine);
				}
			}
			else
			{
				sprintf(strMsgLine,"GoToCoords: Error setting object DEC\n");
				setMessage(strMsgLine);
			}
		}
		else
		{
			sprintf(strMsgLine,"GoToCoords: Error setting object RA\n");
			setMessage(strMsgLine);
		}
	}
	return(retval);
}

/* Test whether the destination was reached */
/* Reset slewphase when goto has finished                    */
/* Return value is                                           */
/*   0 -- goto in progress                                   */
/*   1 -- goto complete                                      */
int CheckGoTo(mount *mnt, double desRA, double desDec, int pmodel, int abspos)
{
	int    retval = 0;

	if (mnt->motver[0] > 10)
	{
		// Meade autostar
		char returnstr[RES_LEN];
		// Meade specific command LX200/Autostar/AutostarII
		if (getMountString(":D#", returnstr, -1))
		{
			if (returnstr[0] != 0x7F) //Bar char
			{
				retval = 1;
				if(mnt->trkStatus != mnt->trkActive)
				{
					retval = SetTrack(mnt);
				}
			}
		}
	}
	else
	{
		// All Other LX200 controllers
		double telra0, telra1, teldec0, teldec1;
		double  errorRA, errorDec, nowRA, nowDec;
		static double perrorRA = 0, perrorDec = 0, count = 0;
		
		// Where do we really want to go to?
		telra1 = desRA;
		teldec1 = desDec;

		// Where will the telescope point to make this happen?
		PointingToTel(mnt, &telra0, &teldec0, telra1, teldec1, pmodel);

		// Work with the telescope coordinates 
		desRA = telra0;
		desDec = teldec0;
	
		if (GetTel(mnt, &nowRA, &nowDec, pmodel))
		{
			errorRA = nowRA - desRA;
			errorDec = nowDec - desDec;
		
			// Chek if movement is ceased 
			if (errorRA == perrorRA && errorDec == perrorDec && count == 1 )
			{
				// No more movement, goto finished
				perrorRA = 0;
				perrorDec = 0;
				count = 0;
				slewphase = 0;
				retval = 1;
				if(mnt->trkStatus != mnt->trkActive)
				{
					retval = SetTrack(mnt);
				}
				/*if (abspos)
				{
					// i.e. Park
					FullStop(mnt);
				}*/
			}
			else
			{
				count = (errorRA == perrorRA && errorDec == perrorDec) ? (count + 1) : 0;
				perrorRA = errorRA;
				perrorDec = errorDec;
				retval = 0;
			}
		}
	}
	return(retval);
}

/* Level scope (GEM) before align */
int LevelScope(mount *mnt, int ra, int dec)
{
	sprintf(strMsgLine,"Level telescope is not supported\n");
	setMessage(strMsgLine);       
	return(1);
}

/* Check Level Done */
int CheckLevel(int ra, int dec)
{
	sprintf(strMsgLine,"Level telescope is not supported\n");
	setMessage(strMsgLine);       
	return(1);
}

/* Update global offsets */
int SyncTelOffsets(mount *mnt, double newoffsetra, double newoffsetdec)
{
  mnt->offsetra = newoffsetra;
  mnt->offsetdec = newoffsetdec;
  return 1;
}

int SetTrack(mount *mnt)
{
	int retval = 0;
	
	if (TelConnectFlag)
	{
		if (mnt->modfeat[FLTRACK])
		{
			if (mnt->trkStatus)
			{
				retval = StartTrack(mnt);
			}
			else
			{
				retval = StopTrack(mnt);
			}
		}
		else
		{
			sprintf(strMsgLine,"SetTrack: tracking control is not supported\n");
			setMessage(strMsgLine);       
		}
	}
	return (retval);
}

/* Start sidereal tracking */
int StartTrack(mount *mnt)
{
	int retval = 0;
	
	if (TelConnectFlag)
	{
		if (mnt->modfeat[FLTRACK])
		{
			if (mnt->motver[0] > 10)
			{
				switch(mnt->telmode)
				{
					case GEM:
					case EQFORK:
						retval = (ttywrite(TelPortFD,":AP#") > 0);
						break;
					case ALTAZ:
						retval = (ttywrite(TelPortFD,":AA#") > 0);
						break;
				}
				if (retval)
				{
					retval = 0;
					switch ((int)mnt->trkspd)
					{
						case SIDEREAL:
				  		    retval = (ttywrite(TelPortFD,":TQ#") > 0);
							break;
						case LUNAR:
				  		    retval = (ttywrite(TelPortFD,":TL#") > 0);
							break;
						case SOLAR:
				  		    retval = (ttywrite(TelPortFD,":TS#") > 0);
							break;
						default:
							if (mnt->trkspd > 0)
							{
							}
					}
				}
				else
				{
					sprintf(strMsgLine,"StartTrack: could not set mount mode\n");		
				}
			}
			else if (mnt->motver[0] > 0)
			{
				//Should be rajiva's
				switch ((int)mnt->trkspd)
				{
					case SIDEREAL:
			  		    retval = (ttywrite(TelPortFD,"0T") > 0);
						break;
					case LUNAR:
			  		    retval = (ttywrite(TelPortFD,"1T") > 0);
						break;
					case SOLAR:
			  		    retval = (ttywrite(TelPortFD,"2T") > 0);
						break;
					default:
						if (mnt->trkspd > 0)
						{
						}
				}
			}						
			else
			{
				sprintf(strMsgLine,"StartTrack: tracking control is not supported\n");
			}		
			if (retval)
			{
				sprintf(strMsgLine,"Mount is tracking\n");		
				mnt->trkActive = 1;
			}
			else
			{
				sprintf(strMsgLine,"StartTrack: could not start tracking\n");		
			}
		}
		else
		{
			sprintf(strMsgLine,"StartTrack: tracking control is not supported\n");
		}		
		setMessage(strMsgLine);
	}
	return (retval);
}

/* Stop tracking if it is running */
int StopTrack(mount *mnt)
{
	int retval = 0;

	if (TelConnectFlag)
	{
		if (mnt->modfeat[FLTRACK])
		{
			if (mnt->motver[0] > 10)
			{
				if (ttywrite(TelPortFD,":AL#"))
				{
					sprintf(strMsgLine,"Mount stopped tracking\n");
					mnt->trkActive = 0;
					retval = 1;
				}
				else
				{
					sprintf(strMsgLine,"StopTrack: could not stop tracking\n");		
				}
			}
			else if (mnt->motver[0] > 0)
			{
				//Should be rajiva's
				if (ttywrite(TelPortFD,"-1T"))
				{
					sprintf(strMsgLine,"Mount stopped tracking\n");
					mnt->trkActive = 0;
					retval = 1;
				}
				else
				{
					sprintf(strMsgLine,"StopTrack: could not stop tracking\n");		
				}
			}
			else
			{
				sprintf(strMsgLine,"StopTrack: tracking control is not supported\n");
			}		
		}
		else
		{
			sprintf(strMsgLine,"StopTrack: tracking control is not supported\n");
		}		
		setMessage(strMsgLine);
	}
	return (retval);
}

/* Get tracking status */
int GetTrackStatus(mount *mnt)
{
	int retval = mnt->trkStatus;
	return(retval);
}

/* Get tracking active status */
int GetTrackActive(mount *mnt)
{
	int retval = mnt->trkActive;
	return(retval);
}

/* Set tracking status */
void SetTrackStatus(mount *mnt, int trk)
{
	if (mnt->modfeat[FLTRACK])
	{
		mnt->trkStatus = trk;
		if (mnt->trkStatus)
		{
			sprintf(strMsgLine,"Setting up for active tracking\n");
		}
		else
		{
			sprintf(strMsgLine,"Setting up for inactive tracking\n");
		}
	}
	else
	{
		sprintf(strMsgLine,"SetTrackStatus: tracking control is not supported\n");
	}		
	setMessage(strMsgLine); 		
	return;
}

/* Full stop */
int FullStop(mount *mnt)
{  
	int retval = 0;

	if (TelConnectFlag)
	{
		sprintf(strMsgLine, "Stop all motion\n");
		setMessage(strMsgLine);  	
		/* Also Clear the slew flag */
		slewphase = 0;
		if (ttywrite(TelPortFD,":Q#"))
		{
			sprintf(strMsgLine,"All slew stopped\n");
			retval = 1;
		}
		else
		{
			sprintf(strMsgLine,"FullStop: could not stop all slew\n");		
		}
		setMessage(strMsgLine);

		if (mnt->modfeat[FLTRACK])
		{
			usleep(25000.);		
			/* Stop tracking */
			retval = retval + StopTrack(mnt);
			if (retval)
			{
				sprintf(strMsgLine,"All motion stopped\n");
			}
			setMessage(strMsgLine);
			usleep(25000.);
		}
	}
	return(retval);
}

/* Set slew speed */
int SetMaxRate(int slewRate)
{
	char outputStr[CMD_LEN];
	int  retval = 0;

	if (TelConnectFlag)
	{
		if(slewRate > 1 && slewRate <= 4)
		{
			sprintf(outputStr, ":Sw %1d#\n", slewRate);
			retval = getMountAck(outputStr, '1');
			if (retval)
			{
				sprintf(strMsgLine, "Slew Rate set to %1d deg/sec\n", slewRate);
			}
			else
			{
				sprintf(strMsgLine, "SetSlewRate: could not set Slew Rate to %1d deg/sec.\n", slewRate);
			}
			setMessage(strMsgLine);
		}
		else
		{
			sprintf(strMsgLine, "SetSlewRate: Invalid Slew Rate: %1d deg/sec, must be 2 to 4 deg/sec \n", slewRate);
			setMessage(strMsgLine);
		}
	}
	return(retval);
}

#ifdef ISLIMITS
	/* Set slew limits control off or on */
	int SetLimits(int limits)
	{
		return (1);
	}

	/* Get status of slew limits control */
	int GetLimits(int *limits)
	{
		return (1);
	}
#endif  

#ifdef ISFOCUS
	/* Run the focus using focuscmd */
	/* The LX200 has fast and slow defined, so we have only two states */
	/* Focus count is maintained by timing because the LX200 does not encode focus */
	int Focus(int focuscmd, int focusspd)
	{
		static int focusflag;
		static double focustime;
		int retval = 0;

		if (TelConnectFlag == TRUE)
		{
			if ( focuscmd == FOCUSCMDOUT ) 
			{
				focusflag = 1;
				focustime = UTNow();

				if ( focusspd == FOCUSSPD1 )
				{
					retval = (ttywrite(TelPortFD,":FS#") > 0); 
				}
				else if ( focusspd == FOCUSSPD2 )
				{
					retval = (ttywrite(TelPortFD,":F2#") > 0);
				} 
				else if ( focusspd == FOCUSSPD4 )
				{
					retval = (ttywrite(TelPortFD,":F3#") > 0);
				} 
				else if ( focusspd == FOCUSSPD4 )
				{
					retval = (ttywrite(TelPortFD,":FF#") > 0);
				} 
				if (retval)
				{   
					retval = (ttywrite(TelPortFD,":F+#") > 0);
				}
			}
			else if ( focuscmd == FOCUSCMDIN )
			{
				focusflag = -1;
				focustime = UTNow();

				if ( focusspd == FOCUSSPD1 )
				{
					retval = (ttywrite(TelPortFD,":FS#") > 0); 
				}
				else if ( focusspd == FOCUSSPD2 )
				{
					retval = (ttywrite(TelPortFD,":F2#") > 0);
				} 
				else if ( focusspd == FOCUSSPD4 )
				{
					retval = (ttywrite(TelPortFD,":F3#") > 0);
				} 
				else if ( focusspd == FOCUSSPD4 )
				{
					retval = (ttywrite(TelPortFD,":FF#") > 0);
				} 
				if (retval)
				{
					retval = (ttywrite(TelPortFD,":F-#") > 0);
				}
			}  
			else if ( focuscmd == FOCUSCMDOFF ) 
			{  
				if (focusflag != 0)
				{
					/* Focus is in motion so we note the time and then stop it */
					/* Keep track of count as number of seconds at slowest speed */

					focustime = UTNow() - focustime;

					/* Send the command */  
					if (ttywrite(TelPortFD,":FQ#") > 0)
					{
						/* Just in case the UT clock rolled over one day while focusing */
						/* Try to trap the error but ...                                */
						/*   for very short focustime roundoff error may give negative  */
						/*   values instead of zero.  We trap those cases.              */

						if ( focustime < 0. )
						{
							if ( focustime < -23.9 )
							{
								focustime = focustime + 24.;
							}
							focustime = 0.;
						}

						/* Count time in tenths of seconds to get the focus change */
						/* This is to give more feedback to the observer but */
						/* UTNow does not pick up fractions of a second so least count is 10 */

						focustime = focustime * 36000.;

						if ( focusflag == -1 )
						{
							focuscount = focuscount - focusspd * ( (int) focustime);
						}
						else if ( focusflag == 1 )
						{
							focuscount = focuscount + focusspd * ( (int) focustime);
						}
						focusflag = 0;
						retval = 1;
					}
				}
				else
				{
					/* Focus motion is already stopped so there is nothing to do */
				}
			} 
		}
		else
		{
			sprintf(strMsgLine,"Focus: Telescope is not connected\n");
			setMessage(strMsgLine);
		}  	
		return(retval);   
	}

	/* Report the focus  setting */
	int GetFocus(double *telfocus)
	{ 
		*telfocus = (double) focuscount;
		return(1);
	}

	/* Report the temperature */
	int GetTemperature(double *teltemperature)
	{
		return(1);
	}
#endif

#ifdef ISHEATER
	/* Control the dew heater */
	int Heater(int heatercmd)
	{
		return(1);
	}
#endif

#ifdef ISFAN
	/* Control the fan */
	/* LX200 fan has only one speed */
	int Fan(int fancmd)
	{
		int retval = 0;
		
		if (TelConnectFlag == TRUE)
		{
			if ( fancmd != FANCMDOFF ) 
			{
				retval = (ttywrite(TelPortFD,":f+#") > 0);
			}
			else if ( fancmd == FANCMDOFF ) 
			{
				retval = (ttywrite(TelPortFD,":f-#") > 0);
			}
		}
		else
		{
			sprintf(strMsgLine,"Fan: Telescope is not connected\n");
			setMessage(strMsgLine);
		}  	
		return(retval);
	}
#endif

#ifdef ISROTATOR
	/* Adjust the rotation */
	/* LX200 rotator compensates for sidereal motion in an alt-az mounting */
	int Rotate(int rotatecmd, int rotatespd)
	{
		int retval = 0;
		
		if (TelConnectFlag == TRUE)
		{
			if ( rotatecmd != ROTATECMDOFF) 
			{
				if ( rotatespd == ROTATESPDSIDEREAL )
				{
					retval = (ttywrite(TelPortFD,":r+#") > 0);
				}
			}
			else if ( rotatecmd == ROTATECMDOFF ) 
			{
				retval = (ttywrite(TelPortFD,":r-#") > 0);
			}
			else
			{
				sprintf(strMsgLine,"Unsupported rotation request for LX200.\n");
				setMessage(strMsgLine);
			}
		}
		else
		{
			sprintf(strMsgLine,"Rotate: Telescope is not connected\n");
			setMessage(strMsgLine);
		}  	
		return(retval);
	}

	/* Report the rotation setting */
	int GetRotate(double *telrotate)
	{
		return(1);
	}
#endif

#ifdef ISRETICLE
	/* Control the reticle function using predefined values */
	int Reticle(int reticle)
	{    
		int retval = 0;
		
		if (TelConnectFlag == TRUE)
		{
			if ( reticle == RETICLEBRI)
			{
				retval = (ttywrite(TelPortFD,":B+#") > 0);
			}
			else if ( reticle == RETICLEDIM )
			{
				retval = (ttywrite(TelPortFD,":B-#") > 0);
			}
			else if ( reticle == RETICLEBLK0 )
			{
				retval = (ttywrite(TelPortFD,":B0#") > 0);
			}
			else if ( reticle == RETICLEBLK1 )
			{
				retval = (ttywrite(TelPortFD,":B1#") > 0);
			}
			else if ( reticle == RETICLEBLK2 )
			{
				retval = (ttywrite(TelPortFD,":B2#") > 0); 
			}
			else if ( reticle == RETICLEBLK3 )
			{
				retval = (ttywrite(TelPortFD,":B3#") > 0);	
			}
		}
		else
		{
			sprintf(strMsgLine,"Reticle: Telescope is not connected\n");
			setMessage(strMsgLine);
		}  	
		return(retval);
	}
#endif

/* Serial port utilities */
int ttywrite(int fd, const char * buffer)
{
	int err_code = 0, nbytes_written = 0;

	ttyerrormsg[0] = '\0';

	/* flush the input (read) buffer */
	tcflush(TelPortFD,TCIOFLUSH);

	if ((err_code = tty_write_string(fd, buffer, &nbytes_written)) != TTY_OK)
	{
		tty_error_msg(err_code, ttyerrormsg, TTY_ERRMSG_SIZE);
		setMessage(ttyerrormsg); 
	}
	return nbytes_written;
}

int ttyread(int fd, char *buf)
{
	int err_code = 0, nbytes_read = 0;

	// Clear string(s)
	ttyerrormsg[0] = '\0';
	buf[0] = '\0';
    if ((err_code = tty_read_section(fd, buf, 0x23, READ_TIME, &nbytes_read)) == TTY_OK)
    {
    	buf[nbytes_read - 1] = '\0';
    	nbytes_read--;
    }
    else
    {
		tty_error_msg(err_code, ttyerrormsg, TTY_ERRMSG_SIZE);
		setMessage(ttyerrormsg); 
	}
	return nbytes_read;
}

int ttychrread(int fd, char *buf, int nbytes)
{
	int err_code = 0, nbytes_read = 0;

	// Clear string(s)
	ttyerrormsg[0] = '\0';
	buf[0] = '\0';
    if ((err_code = tty_read(fd, buf, nbytes, READ_TIME, &nbytes_read)) == TTY_OK)
    {
    	buf[nbytes_read] = '\0';
    }
    else
    {
		tty_error_msg(err_code, ttyerrormsg, TTY_ERRMSG_SIZE);
		setMessage(ttyerrormsg); 
	}
	return nbytes_read;
}

int getMountAck(char *sendstr, char ackchar)
{
	char returnstr[RES_LEN];
	int  retval = 0, err = 0, i = 0;

	if (TelConnectFlag == TRUE)
	{
		while (retval == 0)
		{
			/* Flush the input buffer */
			tcflush(TelPortFD,TCIOFLUSH);

			ttywrite(TelPortFD, "#");
			usleep(10000);

			if (ttywrite(TelPortFD, sendstr))
			{
				usleep(10000);
				if (ttychrread(TelPortFD, returnstr, 1))
				{
					retval = (returnstr[0] == ackchar);
					if (err)
					{
						err = 0;
						sprintf(strMsgLine, "getMountAck: Ok.\n");
						setMessage(strMsgLine); 
					}
				}	
				else
				{
					err = 1;
					sprintf(strMsgLine, "getMountAck: Attempt %d to read command %s reply, failed. Wait...\n", (i + 1), sendstr);
					setMessage(strMsgLine); 
					usleep(1000000);
					i++;
				}	
			}
			else
			{
				err = 1;
				sprintf(strMsgLine, "getMountAck: Attempt write command %s, failed.\n", sendstr);
				setMessage(strMsgLine); 
				usleep(1000000);
				i++;
			}
			if ((i % CMD_RETRY) == 0 && retval == 0)
			{
				if (!comfailCB())
				{
					break;
				}
			}
		}
		if (retval == 0)
		{
			// On total failure, telescope is not connected...
			TelConnectFlag = FALSE;
			sprintf(strMsgLine, "Telescope does not respond\nPort closed\n");
			setMessage(strMsgLine);
			close(TelPortFD);
		}
	}
	return(retval);
}

int tryMountAck(char *sendstr, char ackchar)
{
	char returnstr[RES_LEN];
	int  retval = 0;

	if (TelConnectFlag == TRUE)
	{
		/* Flush the input buffer */
		tcflush(TelPortFD,TCIOFLUSH);

		ttywrite(TelPortFD, "#");
		usleep(10000);

		if (ttywrite(TelPortFD, sendstr))
		{
			usleep(10000);
			if (ttychrread(TelPortFD, returnstr, 1))
			{
				retval = (returnstr[0] == ackchar);
			}	
		}
		else
		{
			sprintf(strMsgLine, "tryMountAck: Attempt write command %s, failed.\n", sendstr);
			setMessage(strMsgLine); 
		}
	}
	return(retval);
}

int getMountString(char *sendstr, char *returnstr, int expected)
{
	int retval = 0, nbytes_read = 0, err = 0, i = 0;

	if (TelConnectFlag == TRUE)
	{
		while (retval == 0)
		{
			/* Flush the input buffer */
			tcflush(TelPortFD,TCIOFLUSH);

			ttywrite(TelPortFD, "#");
			usleep(10000);

			if (ttywrite(TelPortFD, sendstr))
			{
				usleep(10000);
				nbytes_read = ttyread(TelPortFD, returnstr);
				//fprintf(stderr, "Got: %s, %d, %d\n", returnstr, (nbytes_read == expected), expected);
				if (nbytes_read == expected || expected == -1)
				{
					retval = 1;
					if (err)
					{
						err = 0;
						sprintf(strMsgLine, "getMountString: Ok.\n");
						setMessage(strMsgLine); 
					}
				}	
				else
				{
					err = 1;
					sprintf(strMsgLine, "getMountString: Attempt %d to read command %s reply, failed. Wait...\n", (i + 1), sendstr);
					setMessage(strMsgLine); 
					usleep(1000000);
					i++;
				}	
			}
			else
			{
				err = 1;
				//fprintf(stderr, "Write error\n");
				sprintf(strMsgLine, "getMountString: Attempt write command %s, failed.\n", sendstr);
				setMessage(strMsgLine); 
				usleep(1000000);
				i++;
			}
			if ((i % CMD_RETRY) == 0 && retval == 0)
			{
				if (!comfailCB())
				{
					break;
				}
			}
		}
		if (retval == 0)
		{
			// On total failure, telescope is not connected...
			TelConnectFlag = FALSE;
			sprintf(strMsgLine, "Telescope does not respond\nPort closed\n");
			setMessage(strMsgLine);
			close(TelPortFD);
		}
	}
	return(retval);
}

int tryMountString(char *sendstr, char *returnstr, int expected)
{
	int retval = 0, nbytes_read = 0;

	if (TelConnectFlag == TRUE)
	{
		/* Flush the input buffer */
		tcflush(TelPortFD,TCIOFLUSH);

		ttywrite(TelPortFD, "#");
		usleep(10000);

		if (ttywrite(TelPortFD, sendstr))
		{
			usleep(10000);
			nbytes_read = ttyread(TelPortFD, returnstr);
			if (nbytes_read == expected || expected == -1)
			{
				retval = 1;
			}
		}
		else
		{
			sprintf(strMsgLine, "tryMountString: Attempt write command %s, failed.\n", sendstr);
			setMessage(strMsgLine); 
		}
	}
	return(retval);
}

int tryMountHex(char *sendstr, char *returnstr, int length)
{
	int retval = 0, nbytes_read = 0, err_code = 0;

	ttyerrormsg[0] = '\0';

	if (TelConnectFlag == TRUE)
	{
		/* Flush the input buffer */
		tcflush(TelPortFD,TCIOFLUSH);

		if ((err_code = tty_write(TelPortFD, sendstr, length, &nbytes_read)) == TTY_OK)
		{
			usleep(10000);
			if (ttychrread(TelPortFD, returnstr, 1))
			{
				retval = 1;
			}
		}
		else
		{
			tty_error_msg(err_code, ttyerrormsg, TTY_ERRMSG_SIZE);
			setMessage(ttyerrormsg); 
			sprintf(strMsgLine, "tryMountHex: Attempt write command failed.\n");
			setMessage(strMsgLine); 
		}
	}
	return(retval);
}

