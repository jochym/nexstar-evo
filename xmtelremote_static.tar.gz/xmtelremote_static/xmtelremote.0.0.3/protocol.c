int ChkTarget(mount *mnt, double chkra, double chkdec, int pmodel)
{
	double chkaz = 0.;
	double chkalt = 0.;
	double chkra0, chkdec0, chkha0;
	int    i = 0;
	int    retval = 1;
	
	if (mnt->modfeat[FLHORIZ])
	{
		/* Mount coordinates for the target */
		PointingToTel(mnt, &chkra0, &chkdec0, chkra, chkdec, pmodel);  

		chkha0 = Map12(LSTNow(mnt->SiteLongitude) - chkra0);

		/* Convert HA and Dec to Alt and Az */
		EquatorialToHorizontal(mnt->SiteLatitude, chkha0, chkdec0, &chkaz, &chkalt);
	
		i = chkaz / 10;

		/* Check altitude limit	*/
		if (i > -1 && i < 36)
		{
			if ((retval = ((chkalt >= mnt->horizon[i][1]) && (chkalt <= mnt->horizon[i][2]))) == 0)
			{
				setMessage("Target is below telescope horizon\n");
			}
		}
	}
	return(retval);
}

int ChkRaAxAngle(mount *mnt, double chkra, double chkdec, int pmodel)
{
	int    retval = 1;
	double chkra0, chkdec0, chkha0, chkdeg;

	if (mnt->telmode > ALTAZ)
	{
		/* Mount coordinates for the target */
		PointingToTel(mnt, &chkra0, &chkdec0, chkra, chkdec, pmodel);  

		chkha0 = Map12(LSTNow(mnt->SiteLongitude) - chkra0);
		chkdeg = chkha0 * 15.;

		if (mnt->telmode == EQFORK)
		{	
			/* Check axis rotation */
			if ((retval = ((chkdeg >= mnt->axralimits[0]) && (chkdeg <= mnt->axralimits[1]))) == 0)
			{
				setMessage("Ra axis rotation limit reached\n");
			}
		}		
		else if (mnt->telmode == GEM)
		{
			/* Check axis rotation keeping basis in mind, we care only how much is above 90, if it's above 90. */
			if (chkha0 > 0. && mnt->basis < 0)
			{
				retval = (chkdeg <= (mnt->axralimits[1] - 90));
			}
			else if (chkha0 < 0. && mnt->basis > 0)
			{
				retval = (chkdeg >= (mnt->axralimits[0] + 90));
			}
			
			if (retval == 0)
			{
				setMessage("Telescope has reached meridian flip limit\n");
			}
		}
	}
	return(retval);
}

