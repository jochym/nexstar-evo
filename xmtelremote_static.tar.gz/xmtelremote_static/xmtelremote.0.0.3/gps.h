/* -------------------------------------------------------------------------- */
/* -Routines for GPS access, Serial port communication, NMEA $GPGGA sentence- */
/* -------------------------------------------------------------------------- */
/*                                                                            */
/* Copyright 2013 Giampiero Spezzano                                          */
/*                                                                            */
/* Distributed under the terms of the General Public License (see LICENSE)    */
/*                                                                            */
/* Giampiero Spezzano (gspezzano@gmail.com)                                   */
/*                                                                            */
/* Marc 2013                                                                  */
/*     First release                                                          */
#ifndef GPS_H
	#define GPS_H
	
	#define TTY_TIME     2
	#define GPS_TIME     6
	
	#define GPS_LEN      256
	#define GPSRECSEPCHR 0x0A //Lf
	#define GPSFLDSEPSTR ","

	typedef struct                         	    /* GPS structure  */
	{
		char   gpsport[256];                  	/* Serial port if needed */
		int    gpslink;     					/* gps connection flag */
		double SiteLatitude;        			/* Latitude in degrees + north */  
		double SiteLongitude;      				/* Longitude in degrees + east */  
		double SiteAltitude;        			/* Altitude in meters */
		double SiteTemperature;        			/* Temperature in C */
		double SitePressure;        			/* Pressute in mbar */
		int    TimeDifference;					/* Number of seconds (GPS - SYS) */
		double gpsHDOP;						    /* Horizontal DOP value */
		int    gpsvalid;						/* Flag for valid data received */
		int    gpssats;							/* Number of satellites used */		
		char   gpsHDOPrating[32];				/* Precision comment based on HDOP value */
	} gpsdata;

	int GpsConnect(char *gpsserial);
	int GpsDisconnect();
	int GpsCheckConnect(void);
	int GetGPGGA (gpsdata *gps);
#endif

