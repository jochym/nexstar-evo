#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "logging.h"

static char strMessage[4096];
static int outtype = 0;

void getMessage(char *returnstr)
{
	strcpy(returnstr, strMessage);
	strMessage[0] = '\0';
}

void setMessage(char *setstr)
{
	if (outtype)
	{
		strcat(strMessage, setstr);
	}
	else
	{
		fprintf(stderr, "%s", setstr);
	}
}

/* This is used to change to log output from console to string */
void setOutput(int type)
{
	if ((type == 0) || (type == 1))
	{
		outtype = type;
	}
}


