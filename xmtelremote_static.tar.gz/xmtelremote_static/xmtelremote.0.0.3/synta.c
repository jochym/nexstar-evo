/* -------------------------------------------------------------------------- */
/* -      Protocol for Synta sky watcher telescope control (EQ6, HEQ5...    - */
/* -------------------------------------------------------------------------- */
/*                                                                            */
/* Copyright 2013 Giampiero Spezzano                                          */
/*                                                                            */
/* Distributed under the terms of the General Public License (see LICENSE)    */
/*                                                                            */
/* Giampiero Spezzano (gspezzano@gmail.com)                                   */
/*                                                                            */
/* Official Skywatcher Protocol												  */
/* See http://code.google.com/p/skywatcher/wiki/SkyWatcherProtocol            */
/*																		      */
/* This work is based on INDI skywatcher protocol from Geehalel               */
/* (geehalel AT gmail DOT com) and eq6direct from Pierre Nerzic				  */
/* (pierre.nerzic@free.fr)  												  */
/* Marc 01, 2013                                                              */
/*     First release                                                          */

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>
#include <unistd.h>

#include <termios.h>

#include "synta.h"
#include "ttycom.h"
#include "algorithms.h"
#include "pointing.h"
#include "logging.h"

#define NULL_PTR(x) (x *)0

/* System variables and prototypes */
static int  ttyread(int fd, char *buf);
static int  ttywrite(int fd, const char * buffer);
static int  getMountAck (char *sendstr);
static int  getMountString (char *sendstr, char *returnstr);
static void CmdFormat(char cmd, int axis, char *cmdargs, char *strcmd);
static int  GetAxIsRunning(int axis);
static int  GetSlewStatus(mount *mnt);

/* TTY to results and results to TTY transformations */
unsigned long Revu24str2long(char *s);
void          long2Revu24str(unsigned long n, char *str);

/* Synta local data */
unsigned long RASteps360;
unsigned long DESteps360;
unsigned long RAStepsWorm;
unsigned long DEStepsWorm;
unsigned long RAStepInit;
unsigned long DEStepInit;
unsigned long RAStepHome;
unsigned long DEStepHome;
unsigned long RAHighspeedRatio; // Motor controller multiplies speed values by this ratio when in low speed mode
unsigned long DEHighspeedRatio; // This is a reflect of either using a timer interrupt with an interrupt count greater than 1 for low speed
                                // or of using microstepping only for low speeds and half/full stepping for high speeds
unsigned long minperiods[3];
unsigned long gotolper[3];

double laststatus[3];
double initstatus[3];

static double altcountperdeg = 0;      
static double azcountperdeg = 0; 
static int    slewphase = 0;             		/* Slew sequence counter 									*/
static double telencoderalt = 0.;    			/* Global encoder angle updated by GetTel 					*/
static double telencoderaz = 0.;      			/* Global encoder angle updated by GetTel 					*/

/* Set global switch angles for a GEM OTA over the pier pointing at pole   									*/
/* They correspond to ha ~ -6 hr and dec ~ +90 deg for northern telescope  									*/
/* They correspond to ha ~ +6 hr and dec ~ -90 deg for southern telescope  									*/
/* Non-zero values work better in goto routines on nexstar                									*/    
static double switchaz = 1.; 					/* Global encoder angle of switch position only used if GEM */
static double switchalt = -1.0;					/* Global encoder angle of switch position only used if GEM */

/* Communications variables and routines for internal use */
static int TelPortFD;
static int TelConnectFlag = FALSE;
static char strMsgLine[256];
static char ttyerrormsg[TTY_ERRMSG_SIZE];

#include "protocol.c"
 
/* Report on telescope connection status */
int CheckConnectTel(void)
{
	if (TelConnectFlag == TRUE)
	{
		return TRUE;
	}
	else
	{
		return FALSE;
	}
}

/* Connect to the telescope serial interface */
/* Returns without action if TelConnectFlag is TRUE */
/* Sets TelConnectFlag TRUE on success */
int ConnectTel(char *telserial)
{  
	int err_code = 0;	
	
	if(TelConnectFlag != TRUE)
	{
		/* Make the connection */
		if ((err_code=tty_connect(telserial, 9600, 8, 0, 1, &TelPortFD)) == TTY_OK)
		{
			sprintf(strMsgLine,"Port open %s\n", telserial);
			setMessage(strMsgLine);
			TelConnectFlag = TRUE;
		}
		else
		{
			tty_error_msg(err_code, ttyerrormsg, TTY_ERRMSG_SIZE);
			setMessage(ttyerrormsg);
			sprintf(strMsgLine,"Serial port not available ... \n");
			setMessage(strMsgLine);
		}	
	}
	return(TelConnectFlag);
}

int CheckInfoTel(mount *mnt)
{
	char mntcmd[CMD_LEN];
	char returnstr[RES_LEN];
	unsigned long tmpMCVersion=0;
    unsigned long MCVersion = 0; // Motor Controller Version
    unsigned long MountCode = 0; // 
	int retval = 0;

	if (TelConnectFlag)
	{
		// Feature list is in common for all supported model
		mnt->modfeat[FLTRACK] = 1;
		mnt->modfeat[FLSITE] = 0;
		mnt->modfeat[FLGRATE] = 1;
		mnt->modfeat[FLPGUIDE] = 1;
		mnt->modfeat[FLFOCUS] = 0;
		mnt->modfeat[FLFAN] = 0;
		mnt->modfeat[FLHEATER] = 0;
		mnt->modfeat[FLROTAT] = 0;
		mnt->modfeat[FLRETIC] = 0;
		mnt->modfeat[FLMAXSLW] = 1;
		mnt->modfeat[FLLEVEL] = 0;
		/* Test connectivity */
		CmdFormat(CMDGETMBVER, AXRA, NULL, mntcmd);
		if (getMountString (mntcmd, returnstr))
		{
			tmpMCVersion=Revu24str2long(returnstr + 1);
			MCVersion = ((tmpMCVersion & 0xFF) << 16) | ((tmpMCVersion & 0xFF00)) | ((tmpMCVersion & 0xFF0000) >> 16);
			MountCode = MCVersion & 0xFF;
			sprintf(returnstr, "%lx", MCVersion);
			memcpy(mnt->motver, returnstr, strlen(returnstr));
			mnt->modcod[0] = MountCode; //mnt->motver[0] & 0xFF;
			switch(MountCode) 
			{
				case 0x00: 
					strcpy(mnt->desc,"EQ6"); 
					minperiods[AXRA] = 11;
					minperiods[AXDE] = 11;
					gotolper[AXRA] = 4; // 128x
					gotolper[AXDE] = 4; 
					if (!mnt->teltypefixed)
					{
						mnt->teltype = GEM;
					}
					retval = 1;
					break;
				case 0x01: 
					strcpy(mnt->desc,"HEQ5"); 
					minperiods[AXRA] = 11;
					minperiods[AXDE] = 11;
					gotolper[AXRA] = 4; // 128x
					gotolper[AXDE] = 4; 
					if (!mnt->teltypefixed)
					{
						mnt->teltype = GEM;
					}
					retval = 1;
					break;
				case 0x02: 
					strcpy(mnt->desc,"EQ5"); 
					minperiods[AXRA] = 11;
					minperiods[AXDE] = 11;
					gotolper[AXRA] = 4; // 128x
					gotolper[AXDE] = 4; 
					if (!mnt->teltypefixed)
					{
						mnt->teltype = GEM;
					}
					retval = 1;
					break;
				case 0x03: 
					strcpy(mnt->desc,"EQ3"); 
					minperiods[AXRA] = 11;
					minperiods[AXDE] = 11;
					gotolper[AXRA] = 4; // 128x
					gotolper[AXDE] = 4; 
					if (!mnt->teltypefixed)
					{
						mnt->teltype = GEM;
					}
					retval = 1;
					break;
				case 0x80: 
					strcpy(mnt->desc,"GT"); 
					minperiods[AXRA] = 6;
					minperiods[AXDE] = 6;
					gotolper[AXRA] = 18; // 32x
					gotolper[AXDE] = 18; 
					if (!mnt->teltypefixed)
					{
						mnt->teltype = EQFORK;
					}
					break;
				case 0x81: 
					strcpy(mnt->desc,"MF"); 
					minperiods[AXRA] = 6;
					minperiods[AXDE] = 6;
					gotolper[AXRA] = 18; // 32x
					gotolper[AXDE] = 18; 
					if (!mnt->teltypefixed)
					{
						mnt->teltype = ALTAZ;
					}
					break;
				case 0x82: 
					strcpy(mnt->desc,"114GT"); 
					minperiods[AXRA] = 6;
					minperiods[AXDE] = 6;
					gotolper[AXRA] = 18; // 32x
					gotolper[AXDE] = 18; 
					if (!mnt->teltypefixed)
					{
						mnt->teltype = ALTAZ;
					}
					break;
				case 0x90: 
					strcpy(mnt->desc,"DOB"); 
					minperiods[AXRA] = 6;
					minperiods[AXDE] = 6;
					gotolper[AXRA] = 18; // 32x
					gotolper[AXDE] = 18; 
					if (!mnt->teltypefixed)
					{
						mnt->teltype = ALTAZ;
					}
					break;
				case 0xF0: 
					strcpy(mnt->desc,"GEEHALEL"); 
					minperiods[AXRA] = 12; 
					minperiods[AXDE] = 16;
					gotolper[AXRA] = 18; // 32x
					gotolper[AXDE] = 18; 
					if (!mnt->teltypefixed)
					{
						mnt->teltype = GEM;
					}
					retval = 1;
					break;
				default:  
					strcpy(mnt->desc,"CUSTOM"); 
					minperiods[AXRA] = 6;
					minperiods[AXDE] = 6;
					gotolper[AXRA] = 18; // 32x
					gotolper[AXDE] = 18; 
					if (!mnt->teltypefixed)
					{
						mnt->teltype = ALTAZ;
					}
					break;
			}
			
			//sprintf(strMsgLine,"Mount Name: %s, Mount Code: %d, Controller Version: %d\n", mnt->desc, mnt->modcod[0], mnt->motver[0]);
			sprintf(strMsgLine,"Mount Name: %s, Mount Code: %d, Controller Version: %s\n", mnt->desc, mnt->modcod[0], mnt->motver);
			setMessage(strMsgLine);
			if (retval)
			{
				sprintf(strMsgLine,"Connected\n");
				setMessage(strMsgLine);
			}
			else
			{
				sprintf(strMsgLine,"Is not supported at the moment\n");
				setMessage(strMsgLine);
			}
		} 
	}
	return(retval);
}

int CheckInitTel(mount *mnt)
{
	//int limits;
	char mntcmd[CMD_LEN];
	char returnstr[RES_LEN];
	int retval = 0;
	double tha = 0., tra = 0., tdec = 0.; 
	
	if (TelConnectFlag)
	{			
		GetAxIsRunning(AXRA);
		GetAxIsRunning(AXDE);
		if (!initstatus[AXRA] && !initstatus[AXDE])
		{
			// Axis not initialized, assume home position.
			mnt->align = 0;	
			CmdFormat(CMDGETAXPOS, AXRA, NULL, mntcmd);
			if (getMountString (mntcmd, returnstr))
			{
				RAStepInit = Revu24str2long(returnstr + 1);

				CmdFormat(CMDGETAXPOS, AXDE, NULL, mntcmd);
				if (getMountString (mntcmd, returnstr))
				{
					DEStepInit = Revu24str2long(returnstr + 1);
					retval = 1;
				}
			}
			if (retval)
			{
				retval = 0;
				CmdFormat(CMDAXINIT, AXRA, NULL, mntcmd);
				if (getMountAck (mntcmd))
				{
					CmdFormat(CMDAXINIT, AXDE, NULL, mntcmd);
					if (getMountAck (mntcmd))
					{
						retval = 1;
						setMessage("Motors powered on\n");
					}
				}
			}			
		}
		else
		{
			// Axis initialized already. Default initial position.
			RAStepInit = 0x800000;
			DEStepInit = 0x800000;
			setMessage("Motors already powered on\n");
			retval = 1;
		}
		
		if (retval)
		{
			// Read other relevant parameters
			retval = 0;
			CmdFormat(CMDGETSTEPS360, AXRA, NULL, mntcmd);
			if (getMountString (mntcmd, returnstr))
			{
				RASteps360 = Revu24str2long(returnstr + 1);

				switch(mnt->modcod[0]) 
				{
					case 0x80: 
						RAStepsWorm = 0x162B97;           // for 80GT mount
						retval = 1;
						break;
					case 0x82: 
						RAStepsWorm = 0x205318;           // for 114GT mount
						retval = 1;
						break;
					default:
						CmdFormat(CMDGETSTEPSWORM, AXRA, NULL, mntcmd);
						if (getMountString (mntcmd, returnstr))
						{
							RAStepsWorm = Revu24str2long(returnstr + 1);
							retval = 1;
						}
						break;
				}
				
				if (retval)
				{
					retval = 0;
					switch(mnt->modcod[0]) 
					{
						case 0x00: 
							RAHighspeedRatio = 15;
							retval = 1;
							break;
						case 0x01: 
							RAHighspeedRatio = 15;
							retval = 1;
							break;
						case 0x02: 
							RAHighspeedRatio = 15;
							retval = 1;
							break;
						case 0x03: 
							RAHighspeedRatio = 15;
							retval = 1;
							break;
						default:
							CmdFormat(CMDGETHSPDRATIO, AXRA, NULL, mntcmd);
							if (getMountString (mntcmd, returnstr))
							{
								RAHighspeedRatio = Revu24str2long(returnstr + 1);
								retval = 1;
							}
							break;
					}
				}
			}
		}

		if (retval)
		{
			// Read other relevant parameters (DEC)
			retval = 0;
			CmdFormat(CMDGETSTEPS360, AXDE, NULL, mntcmd);
			if (getMountString (mntcmd, returnstr))
			{
				DESteps360 = Revu24str2long(returnstr + 1);

				switch(mnt->modcod[0]) 
				{
					case 0x80: 
						DEStepsWorm = 0x162B97;           // for 80GT mount
						retval = 1;
						break;
					case 0x82: 
						DEStepsWorm = 0x205318;           // for 114GT mount
						retval = 1;
						break;
					default:
						CmdFormat(CMDGETSTEPSWORM, AXDE, NULL, mntcmd);
						if (getMountString (mntcmd, returnstr))
						{
							DEStepsWorm = Revu24str2long(returnstr + 1);
							retval = 1;
						}
						break;
				}
				
				if (retval)
				{
					retval = 0;
					switch(mnt->modcod[0]) 
					{
						case 0x00: 
							DEHighspeedRatio = 15;
							retval = 1;
							break;
						case 0x01: 
							DEHighspeedRatio = 15;
							retval = 1;
							break;
						case 0x02: 
							DEHighspeedRatio = 15;
							retval = 1;
							break;
						case 0x03: 
							DEHighspeedRatio = 15;
							retval = 1;
							break;
						default:
							CmdFormat(CMDGETHSPDRATIO, AXDE, NULL, mntcmd);
							if (getMountString (mntcmd, returnstr))
							{
								DEHighspeedRatio = Revu24str2long(returnstr + 1);
								retval = 1;
							}
							break;
					}
				}
			}
		}

		if (retval)
		{
			retval = 0;	
			azcountperdeg = (double) RASteps360 / 360.; 
			altcountperdeg = (double) DESteps360 / 360.;      

			sprintf(strMsgLine,"RaSteps360: %lu\n DeSteps360: %lu\n", RASteps360, DESteps360);
			setMessage(strMsgLine);
			sprintf(strMsgLine,"RaStepsWorm: %lu\n DeStepsWorm: %lu\n", RAStepsWorm, DEStepsWorm);
			setMessage(strMsgLine);
			sprintf(strMsgLine,"azcountperdeg: %lf\n altcountperdeg: %lf\n", azcountperdeg, altcountperdeg);
			setMessage(strMsgLine);
			sprintf(strMsgLine,"RAHighspeedRatio: %lu\n DEHighspeedRatio: %lu\n", RAHighspeedRatio, DEHighspeedRatio);
			setMessage(strMsgLine);

			setMessage("Motors geometry read\n");
			
			if (mnt->align)
			{
				if (GetTel(mnt, &tra, &tdec, RAW))
				{
					tha = Map12(LSTNow(mnt->SiteLongitude) - tra);
					sprintf(strMsgLine,"Mount now reading HA(RA): %lf(%lf)\n Mount now reading Dec: %lf\n", tha, tra, tdec);
					setMessage(strMsgLine);
					retval = 1;
				}
			}
			else
			{
				retval = SetHomeNowTel(mnt);
			}
			/* Perform startup tests */
			/* Limit override is not allowed for now
			if (!GetLimits(&limits))
			{
				usleep(500000);
				limits = FALSE;
				if (!SetLimits(limits))
				{
					usleep(500000);  
					GetLimits(&limits);
				}
			}*/
			if (retval)
			{
				// Set initial guiderate
				SetGuideSpd(mnt, mnt->guideratera, AXRA-1);
				SetGuideSpd(mnt, mnt->guideratedec, AXDE-1);
			}
		}	
	}
	return(retval);
}

int SetMountDefaultHome(mount *mnt)
{
	int retval = 1;
	if (!mnt->homefixed)
	{
		if (mnt->telmode == GEM)
		{
			if (mnt->SiteLatitude < 0.)
			{
				mnt->homedec = -89.9999;
				mnt->homeha = 6.;
			}
			else
			{  
				mnt->homedec = 89.9999;
				mnt->homeha = -6.;
			}
		}
		else if (mnt->telmode == EQFORK)
		{
			if (mnt->SiteLatitude < 0.)
			{
				mnt->homedec = 0.;
				mnt->homeha = 0.;
			}
			else
			{  
				mnt->homedec = 0.;
				mnt->homeha = 0.;
			}
		}
		else if (mnt->telmode == ALTAZ)
		{
			/* Set azimuth */
			mnt->homeha = 0.;    

			/* Set altitude */
			mnt->homedec = 0.; 
		}
		else
		{
			sprintf(strMsgLine,"Telescope mounting must be GEM, EQFORK, or ALTAZ\n");
			setMessage(strMsgLine);
			retval = 0;
		}
	}
	if (!mnt->parkfixed)
	{
		mnt->parkha = mnt->homeha;
		mnt->parkdec = mnt->homedec;
	}
	return retval;
}

int SetHomeNowTel(mount *mnt)
{
	int retval = 1;
	double homeha= 0., homera = 0., homedec = 0.;
	char tmpHour[10];
	double tmpVal;

	if (TelConnectFlag)	
	{
		/* Hardcoded defaults for homeha and homedec are overridden by prefs */
		/* GEM: over the pier pointing at the pole */
		/* EQFORK: pointing at the equator on the meridian */
		/* ALTAZ: level and pointing north */
		sprintf(strMsgLine, "Using initial HA(RA): %lf(%lf)\n", mnt->homeha, (Map24(LSTNow(mnt->SiteLongitude) - mnt->homeha)));
		setMessage(strMsgLine);
		sprintf(strMsgLine, "Using initial Dec: %lf\n",mnt->homedec); 
		setMessage(strMsgLine);

		if (SetTel(mnt, mnt->homeha, mnt->homedec))
		{
			mnt->offsetabsra = 0.;
			mnt->offsetabsdec = 0.;
			//fprintf(stderr,"offsetabsra : %f h\n", mnt->offsetabsra);
			//fprintf(stderr,"offsetabsdec: %f deg\n", mnt->offsetabsdec);
		}	
		else
		{
			sprintf(strMsgLine,"Error setting initial telescope pointing!\n");
			setMessage(strMsgLine);
			retval = 0;
		}
	
		if (retval)
		{
			homeha = mnt->homeha;
			homera = Map24(LSTNow(mnt->SiteLongitude) - homeha);
			homedec = mnt->homedec;
			/* Read encoders and confirm pointing */
			if (GetTel(mnt, &homera, &homedec, RAW))
			{
				homeha = Map12(LSTNow(mnt->SiteLongitude) - homera);
				sprintf(strMsgLine, "Local latitude: %lf\n", mnt->SiteLatitude);
				setMessage(strMsgLine);
				sprintf(strMsgLine, "Local longitude: %lf\n", mnt->SiteLongitude);
				setMessage(strMsgLine);
				tmpVal = Map24(LSTNow(mnt->SiteLongitude));
				dtodms(tmpHour, &tmpVal);
				sprintf(strMsgLine, "Local sidereal Time: %s\n", tmpHour);
				setMessage(strMsgLine);
				sprintf(strMsgLine, "Mount mode: %u\n", mnt->telmode);
				setMessage(strMsgLine);
				sprintf(strMsgLine, "Mount now reading HA(RA): %lf(%lf)\n", homeha, homera);
				setMessage(strMsgLine);
				sprintf(strMsgLine, "Mount now reading Dec: %lf\n", homedec);
				setMessage(strMsgLine);
			}
		}
	}
	else
	{
		retval = 0;
	}
	return retval;
}

/* Set mount mode */
int SetMountMode(mount *mnt, int newMode)
{
	if (newMode >= ALTAZ && newMode <= GEM)
	{
		mnt->telmode = newMode;
		SetMountDefaultHome(mnt);
	}
	sprintf(strMsgLine,"Mount Mode set to %u\n", mnt->telmode);
	setMessage(strMsgLine);	
	return(0);
}

/* Assign and save slewRate for use in StartSlew */
int SetRate(mount *mnt, int newRate)
{
	if (newRate >= MIN_RATE && newRate <= MAX_RATE)
	{
		mnt->telspd = newRate;
	}
	sprintf(strMsgLine,"Slew rate set to %u\n", mnt->telspd);
	setMessage(strMsgLine);	
	return(0);
}
 
/* Assign and save track rate for use in StartTrack  */
/* If in tracking mode already wil be sent to the mount too  */
int SetTrkSpd(mount *mnt, double newRate)
{
	int retval = 0;
	
	
	if (newRate == SIDEREAL)
	{
		mnt->trkspd = TRACKRATE_SIDEREAL;
		sprintf(strMsgLine,"Track rate set to sidereal\n");
		setMessage(strMsgLine);
	}
	else if (newRate == LUNAR)
	{
		mnt->trkspd = TRACKRATE_LUNAR;
		sprintf(strMsgLine,"Track rate set to lunar\n");
		setMessage(strMsgLine);
	}
	else if (newRate == SOLAR)
	{
		mnt->trkspd = TRACKRATE_SOLAR;
		sprintf(strMsgLine,"Track rate set to solar\n");
		setMessage(strMsgLine);
	}
	else if (newRate > 0)
	{
		mnt->trkspd = newRate;
		sprintf(strMsgLine,"Track rate set to %f arcseconds per second\n", (newRate));
		setMessage(strMsgLine);
	}
	if (mnt->trkStatus > 0) //(mnt->trkStatus != mnt->trkActive)
	{
		retval = StartTrack(mnt);
	}
	return(retval);
}

int SetGuideSpd(mount *mnt, int val, int radec)
{
	char mntcmd[CMD_LEN];
	char cmdpars[7];
	int retval = 0;
	int sendval = 0;	
	
	if (TelConnectFlag)
	{
		sendval = (val / 25) - 1;
		if (sendval < 0)
		{
			sendval = 0;
			val = 25;
		}
		else if  (val > 3) 
		{
			sendval = 3;
			val = 100;
		}	

		// This protocol has no "get" function for these values.
		// Hence we need to set the mnt property when sending values to the mount too
		// in order to emulate following "get"
		radec += 1;		
		if (radec == AXRA) 
		{
			mnt->guideratera = val;
		}
		if (radec == AXDE) 
		{
			mnt->guideratedec = val;
		}

		long2Revu24str(sendval, cmdpars);	
		CmdFormat(CMDSETGUIDERATE, radec, cmdpars, mntcmd);

		if (getMountAck(mntcmd))
		{
			retval = 1;		
			if (radec == AXRA) 
			{
				sprintf(strMsgLine,"Az controller rate set to %d%% sidereal\n", val);
			}
			else
			{
				sprintf(strMsgLine,"Alt controller guide rate set to %d%% sidereal\n", val);
			}
		}
		else
		{
			retval = 0;		
			if (radec == 0) 
			{
				sprintf(strMsgLine,"SetGuideSpd: No acknowledgement from Az motor control\n");
			}
			else
			{
				sprintf(strMsgLine,"SetGuideSpd: No acknowledgement from Alt motor control\n");
			}
		}
		setMessage(strMsgLine);
	}
	else
	{
		retval = 0;
	}
	return(retval);
}

int GetGuideSpd(mount *mnt, int *val, int radec)
{
	int retval = 1;

	radec += 1;		
	if (radec == AXRA) 
	{
		*val = mnt->guideratera;
	}
	if (radec == AXDE) 
	{
		*val = mnt->guideratedec;
	}

	return(retval);
}

int GetGuideStep(void)
{
	// This protocol only allow for 1, 3/4, 1/2, 1/4 sidereal rate
	// Hence 100%, 75%, 50%, 25% of sidereal rate
	// This helps code to manage the gui accordingly
	return(25);
}

/* Start a slew in chosen direction at slewRate */
int StartSlew(mount *mnt, int direction)
{
	char mntcmd[CMD_LEN];
	char cmdpars[7];
	int  retval = 0;
	double rate = mnt->telspd;
	int axis = 0;
	unsigned long period = 0;
	int useHighSpeed = 0; 

	if (TelConnectFlag)
	{
		/* If there's a slew in progress we need to cancel il properly and restore the tracking status*/  
		if (slewphase)
		{
			sprintf(strMsgLine, "Canceling the current goto operation\n");
			setMessage(strMsgLine);
			retval = FullStop(mnt);
			if(mnt->trkStatus != mnt->trkActive)
			{
				retval = SetTrack(mnt);
			}
			retval = 0;
		}
		else
		{
			// If mount is tracking we need to stop
			if(mnt->trkActive > 0)
			{
				retval = StopTrack(mnt);
			}

			if (retval)
			{
				retval = 0;
				cmdpars[0] = '\0';

				if(direction == NORTH || direction == SOUTH)
				{
					axis = AXDE;
					if (rate > LOWSPEED_RATE) 
					{
						rate = rate / DEHighspeedRatio;
						useHighSpeed = 1;
					}

					period = (long) (((STELLAR_DAY * (double)DEStepsWorm) / (double)DESteps360) / rate);

					cmdpars[0] = (useHighSpeed == 0) ? '1' : '3';
					cmdpars[1] = (direction == NORTH) ? '0' : '1';
					cmdpars[2] = '\0';
			
				}
				else if(direction == EAST || direction == WEST)
				{
					axis = AXRA;
					if (rate > LOWSPEED_RATE) 
					{
						rate = rate / RAHighspeedRatio;
						useHighSpeed = 1;
					}

					period = (long) (((STELLAR_DAY * (double)RAStepsWorm) / (double)RASteps360) / rate);

					cmdpars[0] = (useHighSpeed == 0) ? '1' : '3';
					cmdpars[1] = (direction == EAST) ? '0' : '1';
					cmdpars[2] = '\0';
				}

				if ((useHighSpeed) && (period < minperiods[axis])) 
				{
					sprintf(strMsgLine, "StartSlew: Setting axis %d period to minimum. Requested is %lx, minimum is %lx\n", axis, period, minperiods[axis]);
					setMessage(strMsgLine);
					period = minperiods[axis];
				}

				retval = 0;
				CmdFormat(CMDSETMOTMODE, axis, cmdpars, mntcmd);

				if (getMountAck(mntcmd))
				{
					long2Revu24str(period, cmdpars);
		
					CmdFormat(CMDSETTRKSPD, axis, cmdpars, mntcmd);
				  
					if (getMountAck(mntcmd))
					{
						CmdFormat(CMDSTARTMOVE, axis, NULL, mntcmd);

						if (getMountAck(mntcmd))
						{
							sprintf(strMsgLine,"Rate: %f\n Period: %lu\n", rate, period);
							setMessage(strMsgLine);
							if (direction == NORTH)
							{
								sprintf(strMsgLine, "Slewing north\n");
							}
							else if (direction == SOUTH)
							{
								sprintf(strMsgLine, "Slewing south\n");
							}
							else if (direction == EAST)
							{
								sprintf(strMsgLine, "Slewing east\n");
							}
							else if (direction == WEST)
							{
								sprintf(strMsgLine, "Slewing west\n");
							}
							setMessage(strMsgLine);
							retval = 1;
						}
						else
						{
							sprintf(strMsgLine,"StartSlew: No acknowledgement starting motion\n");
							setMessage(strMsgLine);
						}
					}  
					else
					{
						sprintf(strMsgLine,"StartSlew: No acknowledgement setting track speed\n");
						setMessage(strMsgLine);
					}
				} 
				else
				{
					sprintf(strMsgLine,"StartSlew: No acknowledgement setting motion mode\n");
					setMessage(strMsgLine);
				}
			}  
		}
	}
	return(retval);   
}


/* Stop the slew in chosen direction */
int StopSlew(mount *mnt, int direction)
{
	char mntcmd[CMD_LEN];
	int axis = 0;
	int retval = 0;

	if (TelConnectFlag)
	{
		/* If there's a slew in progress we need to cancel il properly and restore the tracking status*/  
		if (slewphase)
		{
			sprintf(strMsgLine, "Canceling the current goto operation\n");
			setMessage(strMsgLine);		
			retval = FullStop(mnt);
			if(mnt->trkStatus != mnt->trkActive)
			{
				retval = SetTrack(mnt);
			}
			retval = 0;
		}
		else
		{
			if(direction == NORTH || direction == SOUTH)
			{
				axis = AXDE;
			}
			else if(direction == EAST || direction == WEST)
			{
				axis = AXRA;
			}

			CmdFormat(CMDAXSTOP, axis, NULL, mntcmd);

			if (getMountAck(mntcmd))
			{
				sprintf(strMsgLine,"Slew stopped\n");
				setMessage(strMsgLine);
				retval = 1;

				// If mount must be tracking we need to sart
				if(mnt->trkStatus != mnt->trkActive)
				{
					retval = SetTrack(mnt);
				}
			}
			else
			{
				if ((direction == NORTH) || (direction == SOUTH))
				{
					sprintf(strMsgLine,"StopSlew: No acknowledgement from Alt motor control\n");
				}
				else
				{
					sprintf(strMsgLine,"StopSlew: No acknowledgement from Az motor control\n");
				}
				setMessage(strMsgLine);
			}
		}
	}
	return(retval);  
}

int DisconnectTel(mount *mnt)
{
	int err_code = 0;
	
	if(TelConnectFlag == TRUE)
	{
		if(mnt->trkStatus == mnt->trkActive)
		{
			StopTrack(mnt);
		}
		if (tty_disconnect(TelPortFD) == 0)
		{
			TelConnectFlag = FALSE;
			sprintf(strMsgLine, "Telescope disconnected\n");
			setMessage(strMsgLine);
		}
		else
		{
			tty_error_msg(err_code, ttyerrormsg, TTY_ERRMSG_SIZE);
			setMessage(ttyerrormsg);
			sprintf(strMsgLine,"TTy disconnect failed... \n");
			setMessage(strMsgLine);
		}		
	}
	return(TelConnectFlag == FALSE);
}

/* Set the encoder count for current ha and dec                           */
/* Returns +1 (TRUE) if operation is allowed and 0 (FALSE) otherwise      */
int SetTel(mount *mnt, double setha, double setdec)
{
	char mntcmd[CMD_LEN];
	char cmdpars[7];

	//double setra;

	/* Count registers */
	int azcount, altcount; 
	int retval = 0; 

	/* Temporary variables for altitude and azimuth in degrees */
	double altnow, aznow; 

	/* Temporary variables for real encoder readings in degrees */
	double encoderalt = 0.;
	double encoderaz = 0.;

	if (TelConnectFlag)
	{
		// Get target Ra from Ha
		//setra = Map24(LSTNow(mnt->SiteLongitude) - setha);

		/* Test ha and dec for valid range */
		if ( setha > 12. || setha < -12. )
		{
			sprintf(strMsgLine,"SetTel: Telescope cannot be pointed outside valid HA range (%f)\n", setha);
			setMessage(strMsgLine);
			return(0);
		}

		if ( setdec >= 90. || setdec <= -90. )
		{
			sprintf(strMsgLine,"SetTel: Telescope cannot be pointed outside valid Dec range (%f)\n", setdec);
			setMessage(strMsgLine);
			return(0);
		}

		/* Check altitude limit 
		if (!ChkTarget(mnt, setra, setdec, RAW))
		{
			slewphase = 0;
			return(0);
		}
		*/
					
		/* Convert coordinates to counts                             */
		/* Zero points:                                              */
		/* Alt-Az -- horizon north                                   */
		/* Fork equatorial -- equator meridian                       */
		/* German equatorial -- over the mount at the pole           */
		/* Sign of encolder scales assumed:                          */
		/* When switched on, read value is 800000. 					 */
		/* Right(East) increments axis 1 (Ra), left decrements it.   */
		/* Up (North) increments axis 2 (Dec); down decrements it.   */
		/* Counts wrap signed 24-bit integer where 16777216 is 2^24  */
		/* Complete turn, 360°, is XXSteps360 steps, usually 0E6600  */
		/* so, axis can make more than one turn before the counter   */
		/* overflow 												 */

		if (mnt->telmode == GEM)
		{
			/* Flip signs if sited below the equator */
			if (mnt->SiteLatitude < 0.)
			{
				setdec = -1.*setdec;
				setha = -1.*setha;
			}

			/* Encoder az increases as this resigned ha increases */
			/* Zero point is with telescope over the pier pointed at pole */        
			if (setha == 0. && mnt->basis == 1)
			{ 
				/* OTA looking at meridian coming from East of Pier */
				/* It'll stay east of Pier */
				encoderaz = 90.;
				encoderalt = setdec - 90.;
			}
			else if (setha == 0. && mnt->basis == -1)
			{ 
				/* OTA looking at meridian coming from West of Pier */
				/* It'll stay West of Pier */
				encoderaz = -90.;
				encoderalt = 90. - setdec;
			}
			else if (setha == -6.)
			{
				/* OTA looking east */
				mnt->basis = -1;
				encoderaz = 0.;
				encoderalt = setdec - 90.;
			}
			else if (setha == 6.)
			{
				/* OTA looking west */
				mnt->basis = 1;
				encoderaz = 0.;
				encoderalt = 90. - setdec;
			}    
			else if ((setha > -12.) && ( setha < -6.))
			{ 
				/* OTA east of pier looking below the pole */
				mnt->basis = 1;
				encoderaz = setha*15. + 90.;
				encoderalt = setdec - 90.;
			}
			else if ((setha > -6.) && ( setha < 0.))
			{ 
				/* OTA west of pier looking east */
				mnt->basis = -1;
				encoderaz = setha*15. + 90.;
				encoderalt = setdec - 90.;
			}
			else if ((setha > 0.) && ( setha <= 6.))
			{ 
				/* OTA east of pier looking west */
				mnt->basis = 1;
				encoderaz = setha*15. - 90.;
				encoderalt = 90. - setdec;
			}
			else if ((setha > 6.) && ( setha < 12.))
			{ 
				/* OTA west of pier looking below the pole */
				mnt->basis = -1;
				encoderaz = setha*15. - 90.;
				encoderalt = 90. - setdec;
			}    
			else
			{
				sprintf(strMsgLine,"Settel: German equatorial outside limits\n");
				setMessage(strMsgLine);
				return(0);      
			}

			//fprintf(stderr, "Set encoderaz : %f\n", encoderaz);
			//fprintf(stderr, "Set ecoderalt: %f\n", encoderalt);

			encoderaz = encoderaz * azcountperdeg;
			azcount = encoderaz + RAStepInit;

			encoderalt = encoderalt * altcountperdeg;
			altcount = encoderalt + DEStepInit;

	
			//fprintf(stderr, "Set Azcount: %d\n", azcount);
			//fprintf(stderr, "Set Altcount: %d\n", altcount);
		}
		else if (mnt->telmode == EQFORK)
		{

			/* Flip signs for the southern sky */

			if (mnt->SiteLatitude < 0.)
			{
				setdec = -1.*setdec;
				setha = -1.*setha;
			}

			encoderaz = setha * 15.;
			encoderalt = setdec;
			encoderaz = encoderaz * azcountperdeg;
			azcount = encoderaz + RAStepInit;

			encoderalt = encoderalt * altcountperdeg;       
			altcount = encoderalt + DEStepInit;

		}  
		else if (mnt->telmode == ALTAZ)
		{
			/* Convert HA and Dec to Alt and Az */
			EquatorialToHorizontal(mnt->SiteLatitude, setha, setdec, &aznow, &altnow);

			encoderaz = aznow * altcountperdeg;
			azcount = encoderaz + RAStepInit;

			encoderalt = altnow * altcountperdeg;
			altcount = encoderalt + DEStepInit + (DESteps360 / 4);
		}
		else
		{
			sprintf(strMsgLine,"Settel: Unknown mount type\n");
			setMessage(strMsgLine);
			return(0);
		}   

		//fprintf(stderr, "encaz: %f\nencalt: %f\n", encoderaz, encoderalt);

		long2Revu24str(azcount, cmdpars);
		CmdFormat(CMDSETAXPOS, AXRA, cmdpars, mntcmd);
		if (getMountAck(mntcmd))
		{
			long2Revu24str(altcount, cmdpars);
			CmdFormat(CMDSETAXPOS, AXDE, cmdpars, mntcmd);
			if (getMountAck(mntcmd))
			{
				retval = 1;
			}
			else
			{
				sprintf(strMsgLine, "Settel: cannot get Ack from Alt controller!\n");
				setMessage(strMsgLine);
			}	
		}
		else
		{
			sprintf(strMsgLine, "Settel: cannot get Ack from Az controller!\n");
			setMessage(strMsgLine);
		}  
	}
	return(retval);
}

/* Read the mount encoders                                            */
/* Requires access to global telmount                                 */
/* Save encoder angle readings in global telencoder variables         */
/* Convert the encoder readings to mounting ha and dec                */
/* Use an NTP synchronized clock to find lst and ra                   */
/* Correct for the pointing model to find the true direction vector   */
/* Report the ra and dec at which the telescope is pointed            */
int GetTel(mount *mnt, double *telra, double *teldec, int pmodel)
{  
   
	char mntcmd[CMD_LEN];
	char returnstr[RES_LEN];

	/* Packet preset to request HA/Azimuth counts */
	int azcount = 0; 
	int altcount = 0;
	double encoderaz = 0.;
	double encoderalt = 0.;
	double telha0 = 0.;
	double teldec0 = 0.;
	double telra0 = 0.;
	double telra1 = 0.;
	double teldec1 = 0.;
	int retval = 0;
	
	if (TelConnectFlag)
	{
		CmdFormat(CMDGETAXPOS, AXRA, NULL, mntcmd);
		if (getMountString(mntcmd, returnstr))
		{
			azcount = Revu24str2long(returnstr + 1);

			CmdFormat(CMDGETAXPOS, AXDE, NULL, mntcmd);
			if (getMountString(mntcmd, returnstr))
			{
				altcount = Revu24str2long(returnstr + 1);
				retval = 1;
				//fprintf(stderr, "Get Azcount: %d\n", azcount);
				//fprintf(stderr, "Get Altcount: %d\n", altcount);
			}
			else
			{
				sprintf(strMsgLine,"GetTel: Error reading actual mount position (Alt)\n");
				setMessage(strMsgLine);
			}
		}
		else
		{
			sprintf(strMsgLine,"GetTel: Error reading actual mount position (Az)\n");
			setMessage(strMsgLine);
		}


		if (retval)	
		{
			/* Transform encoder readings to mount ha, ra and dec  */
			/* GEM encoders zero for OTA over pier pointed at pole */
			if (mnt->telmode == GEM)
			{
				encoderaz = (double) azcount;
				encoderaz -= (double) RAStepInit;
				encoderalt = (double) altcount;
				encoderalt -= (double) DEStepInit;

				/* Convert counts to degrees for both azimuth and altitude encoders */ 
				encoderaz = encoderaz / azcountperdeg;
				encoderalt = encoderalt / altcountperdeg;

				//fprintf(stderr, "Get encoderaz : %f\n", encoderaz);
				//fprintf(stderr, "Get ecoderalt: %f\n", encoderalt);

				if ( encoderaz == 0. ) 
				{
					if ( encoderalt < 0.)
					{
						telha0 = -6.;
						teldec0 = 90. + encoderalt;
					}
					else
					{
						telha0 = +6.;
						teldec0 = 90. - encoderalt;
					}
				}
				else if ( encoderaz == -90. )
				{
					if ( encoderalt < 0.)
					{
						telha0 = 0.;
						teldec0 = 90. + encoderalt;
					}
					else
					{
						telha0 = -12.;
						teldec0 = 90. - encoderalt;
					}    
				}
				else if ( encoderaz == 90. )
				{
					if ( encoderalt > 0.)
					{
						telha0 = 0.;
						teldec0 = 90. - encoderalt;
					}
					else
					{
						telha0 = -12.;
						teldec0 = 90. + encoderalt;
					}    
				}   
				else if ((encoderaz > -180. ) && (encoderaz < -90.))
				{
					teldec0 = 90. - encoderalt;
					telha0 = Map12(6. + encoderaz/15.);  
				}
				else if ((encoderaz > -90. ) && (encoderaz < 0.))
				{
					teldec0 = 90. - encoderalt;
					telha0 = Map12(6. + encoderaz/15.);  
				}    
				else if ((encoderaz > 0. ) && (encoderaz < 90.))
				{
					teldec0 = 90. + encoderalt;
					telha0 = Map12(-6. + encoderaz/15.);  
				}    
				else if ((encoderaz > 90. ) && (encoderaz < 180.))
				{
					teldec0 = 90. + encoderalt;
					telha0 = Map12(-6. + encoderaz/15.);  
				}   
				else
				{
					sprintf(strMsgLine,"GetTel: German equatorial ha encoder out of range\n");      
					setMessage(strMsgLine);
					teldec0 = 0.;
					telha0 = 0.;
				}   
	
				/* Flip signs for the southern sky */
				if (mnt->SiteLatitude < 0.)
				{
					teldec0 = -1.*teldec0;
					telha0 = -1.*telha0;
				}	
				telra0 = Map24(LSTNow(mnt->SiteLongitude) - telha0);

				//fprintf(stderr, "Get ra : %f\n", telra0);
				//fprintf(stderr, "Get ha : %f\n", telha0);
				//fprintf(stderr, "Get dec: %f\n", teldec0);
			}
	
			else if (mnt->telmode == EQFORK)
			{
				encoderaz = (double) azcount;
				encoderaz -= (double) RAStepInit;

				encoderalt = (double) altcount;
				encoderalt -= (double) DEStepInit;

				/* Convert counts to degrees for both azimuth and altitude encoders */ 
				encoderaz = encoderaz / azcountperdeg;
				encoderalt = encoderalt / altcountperdeg;

				teldec0 = encoderalt;
				telha0 = Map12(encoderaz/15.);

				/* Flip signs for the southern sky */
				if (mnt->SiteLatitude < 0.)
				{
					teldec0 = -1.*teldec0;
					telha0 = -1.*telha0;
				}

				telra0 = Map24(LSTNow(mnt->SiteLongitude) - telha0);    

				//fprintf(stderr, "Get ha : %f\n", telha0);
				//fprintf(stderr, "Get dec: %f\n", teldec0);
			}
			  
			else if (mnt->telmode == ALTAZ)
			{
				encoderaz = (double) azcount;
				encoderaz -= (double) RAStepInit;

				encoderalt = (double) altcount;
				encoderalt -= (double) DEStepInit + (DESteps360 / 4.);

				/* Convert counts to degrees for both azimuth and altitude encoders */ 
				encoderaz = encoderaz / azcountperdeg;
				encoderalt = encoderalt / altcountperdeg;

				HorizontalToEquatorial(mnt->SiteLatitude, encoderaz, encoderalt, &telha0, &teldec0);
				telha0 = Map12(telha0);
				telra0 = Map24(LSTNow(mnt->SiteLongitude) - telha0);   
			}

			else
			{
				sprintf(strMsgLine,"GetTel: Unknown mounting type\n");  
				setMessage(strMsgLine);
				*telra=0.;
				*teldec=0.;
				telencoderaz = 0.;
				telencoderalt = 0.;
				retval = 0;
			}
				
			if (retval)
			{
				/* Handle special case if not already treated where dec is beyond a pole */
				if (teldec0 > 90.)
				{
					teldec0 = 180. - teldec0;
					telra0 = Map24(telra0 + 12.);
				}
				else if (teldec0 < -90.)
				{
					teldec0 = -180. - teldec0;
					telra0 = Map24(telra0 + 12.);
				}

				/* Apply pointing model to the coordinates that are reported by the telescope */
				PointingFromTel(mnt, &telra1, &teldec1, telra0, teldec0, pmodel);

				//fprintf(stderr, "Get ra1: %f\n", telra1);
				//fprintf(stderr, "Get dec1: %f\n", teldec1);

				/* Return corrected values */
				*telra=telra1;
				*teldec=teldec1;

				/* Update global encoder reading */
				telencoderaz =  encoderaz;
				telencoderalt = encoderalt;

				//fprintf(stderr, "Telencoderaz: %f\n", telencoderaz);
				//fprintf(stderr, "Telencoderalt: %f\n", telencoderalt);

				/* all is well that ends well */
				retval = 1;
			}
		}
	}
	return(retval);
}


/* Go to new celestial coordinates                                    */
/* Evaluate if target coordinates are valid                           */
/* Test slew limits in altitude, polar, and hour angles               */
/* Query if target is above the horizon                               */
/* Return without action for invalid requests                         */
/* Interrupt any slew sequence in progress                            */
/* Check current pointing                                             */
/* Find encoder readings required to point at target                  */
/* Set slewphase equal to number of slew segments needed              */
/* Begin next segment needed to reach target from current pointing    */
/* Repeated calls are required when more than one segment is needed   */
/* Return 1 if underway                                               */
/* Return 0 if done or not permitted                                  */
int GoToCoords(mount *mnt, double newra, double newdec, int pmodel, int abspos)
{
	char mntcmd[CMD_LEN];
	char cmdpars[7];
	unsigned long period = 0;
	int useHighSpeed = 0;
	
	int azcount= 0, altcount = 0; // These will be the number of steps to get to target
	int brake = BRAKE_POINT, bkratio = 1;
	int retval = 0; 
	double newha0, newalt0, newaz0;
	double newra0, newdec0;
	double newra1, newdec1;
	double nowra0, nowdec0;
	double encoderalt = 0.;
	double encoderaz = 0.;
	
	if (TelConnectFlag)
	{
		strcat(strMsgLine,"Setting up a goto slew to target\n"); 
		setMessage(strMsgLine);

		/* Mount coordinates for the target */
		newra1 = newra;
		newdec1 = newdec;
		if (!abspos)
		{
			PointingToTel(mnt, &newra0, &newdec0, newra1, newdec1, pmodel);  
		}
		else
		{
			newra0 = newra + mnt->offsetabsra;
			newdec0 = newdec - mnt->offsetabsdec;
		}
	
		newha0 = Map12(LSTNow(mnt->SiteLongitude) - newra0);
	
		/* Check altitude limit */
		if (!abspos)
		{
			/* Test ha and dec for valid range */
			if ( newha0 > 12. || newha0 < -12. )
			{
				sprintf(strMsgLine,"Goto: Telescope cannot be pointed outside valid HA range (%f)\n", newha0);
				setMessage(strMsgLine);
				slewphase = 0;
				return(0);
			}

			if ( newdec0 >= 90. || newdec0 <= -90. )
			{
				sprintf(strMsgLine,"Goto: Telescope cannot be pointed outside valid Dec range (%f)\n", newdec0);
				setMessage(strMsgLine);
				slewphase = 0;
				return(0);
			}

			if (!ChkTarget(mnt, newra0, newdec0, RAW))
			{
				slewphase = 0;
				return(0);
			}		
		}

		//fprintf(stderr, "LST: %f\nGoto ra: %f\nGoto dec: %f\n",LSTNow(mnt->SiteLongitude), newra, newdec);
		//fprintf(stderr, "Goto appha: %f\nGoto appra: %f\nGoto appdec: %f\n",newha0, newra0, newdec0);

		/* Stop all mount motion in preparation for a slew */
		if (FullStop(mnt))
		{
			/* Get current mount coordinates */
			if (GetTel(mnt, &nowra0, &nowdec0, RAW))
			{					  
				/* German equatorial */
				if (mnt->telmode == GEM)
				{
					slewphase = 1;
					/* Flip signs for the southern sky */
					if (mnt->SiteLatitude < 0.)
					{
						newdec0 = -1.*newdec0;
						newha0 = -1.*newha0;
					}

					if (newha0 == 0. && mnt->basis == 1)
					{ 
						/* OTA looking at meridian coming from East of Pier */
						/* It'll stay east of Pier */
						encoderaz = 90.;
						encoderalt = newdec0 - 90.;
					}
					else if (newha0 == 0. && mnt->basis == -1)
					{ 
						/* OTA looking at meridian coming from West of Pier */
						/* It'll stay West of Pier */
						encoderaz = -90.;
						encoderalt = 90. - newdec0;
					}
					else if (newha0 == -6.)
					{
						/* OTA looking east */
						mnt->basis = -1;
						encoderaz = 0.;
						encoderalt = newdec0 - 90.;
					}
					else if (newha0 == 6.)
					{
						/* OTA looking west */
						mnt->basis = 1;
						encoderaz = 0.;
						encoderalt = 90. - newdec0;
					}    
					else if ((newha0 > -12.) && ( newha0 < -6.))
					{ 
						/* OTA east of pier looking below the pole */
						mnt->basis = 1;
						encoderaz = newha0*15. + 90.;
						encoderalt = newdec0 - 90.;
					}
					else if ((newha0 > -6.) && ( newha0 < 0.))
					{ 
						/* OTA west of pier looking east */
						mnt->basis = -1;
						encoderaz = newha0*15. + 90.;
						encoderalt = newdec0 - 90.;
					}
					else if ((newha0 > 0.) && ( newha0 < 6.))
					{ 
						/*OTA east of pier looking west */
						mnt->basis = 1;
						encoderaz = newha0*15. - 90.;
						encoderalt = 90. - newdec0;
					}
					else if ((newha0 > 6.) && ( newha0 < 12.))
					{ 
						/* OTA west of pier looking below the pole */
						mnt->basis = -1;
						encoderaz = newha0*15. - 90.;
						encoderalt = 90. - newdec0;
					}    
					else
					{
						sprintf(strMsgLine,"Goto: German equatorial slew request outside limits\n");
						setMessage(strMsgLine);
						slewphase = 0;
						/* Since we're canceling the slew request we need to restore the tracking status */
						if(mnt->trkStatus != mnt->trkActive)
						{
							SetTrack(mnt);
						}
						return(0);      
					}

					/* Tests for safe slew based on encoder readings would go here */
	
					/* Test need for two-segment slew for changes of more than 90 degrees */
					//fprintf(stderr, "Goto Encoderaz: %f\n", encoderaz);
					//fprintf(stderr, "Goto Encoderalt: %f\n", encoderalt);
					//fprintf(stderr, "Distance encoder AZ: %f\nDistance encoder ALT: %f\n", fabs(telencoderaz - encoderaz), fabs(telencoderalt - encoderalt));
					if ((fabs(telencoderalt - encoderalt) > 90.1) || (fabs(telencoderaz - encoderaz) > 90.1))
					{

						/* Slew request of more than 90 degrees on one axis */
						//fprintf(stderr, "Encoder ALT: %f\n", telencoderalt);
						if ( fabs(telencoderalt) > 10. )
						{
							//fprintf(stderr, "Meridian Flip\n");

							/* Telescope currently more than 10 degrees from the pole in dec */
							/* Set new target to switch position */
							encoderalt = switchalt;
							encoderaz = switchaz;
							slewphase = 2;
						}  
						else
						{
							if (mnt->SiteLatitude < 0.)
							{
								//fprintf(stderr, "Goto 2D west/north of target (>90)\n");
								encoderalt += 2 ;
								encoderaz += 2;
							}
							else
							{
								//fprintf(stderr, "Goto 2D east/south of target (>90)\n");
								encoderalt -= 2 ;
								encoderaz -= 2;
							}
							slewphase = 2;
						}
					}
					else if ((fabs(telencoderalt - encoderalt) > 30.1) || (fabs(telencoderaz - encoderaz) > 30.1))
					{
						//fprintf(stderr, "Double speed goto\n");
						if (mnt->SiteLatitude < 0.)
						{
							//fprintf(stderr, "Goto 2D west/north of target\n");
							encoderalt += 2 ;
							encoderaz += 2;
						}
						else
						{
							//fprintf(stderr, "Goto 2D east/south of target\n");
							encoderalt -= 2 ;
							encoderaz -= 2;
						}
						slewphase = 2;
					}
			
					// Steps to target
					azcount = (encoderaz -  telencoderaz) * azcountperdeg;     
					altcount = (encoderalt - telencoderalt) * altcountperdeg;
				
					//fprintf(stderr, "Goto Azcount: %d\n", azcount);
					//fprintf(stderr, "Goto Altcount: %d\n", altcount);
				}

				/* Equatorial fork */
				if (mnt->telmode == EQFORK)
				{
					slewphase = 1;
					encoderaz = newha0*15.;
					encoderalt = newdec0;

					/* Tests for safe slew based on encoder readings would go here */

					// Steps to target
					azcount = (encoderaz -  telencoderaz) * azcountperdeg;     
					altcount = (encoderalt - telencoderalt) * altcountperdeg;
				}

				/* Alt-az fork */
				if (mnt->telmode == ALTAZ)
				{
					EquatorialToHorizontal(mnt->SiteLatitude, newha0, newdec0, &newaz0, &newalt0);

					slewphase = 1;
					encoderaz = newaz0;
					encoderalt = newalt0;

					/* Tests for safe slew based on encoder readings would go here */

					// Steps to target
					azcount = (encoderaz -  telencoderaz) * azcountperdeg;     
					altcount = (encoderalt - telencoderalt) * altcountperdeg;
				}

				// Emisphere
				if (mnt->SiteLatitude < 0.)
				{
					encoderalt *= -1 ;
					encoderaz *= -1;
				}

				// Ra axis first.
				useHighSpeed = (azcount > 3. * azcountperdeg);
				cmdpars[0] = (useHighSpeed) ? '2' : '0'; 	//Speed
				cmdpars[1] = (azcount >= 0) ? '0' : '1';	//Direction
				cmdpars[2] = '\0';
				period     = (useHighSpeed) ? minperiods[AXRA] : gotolper[AXRA];
				period     *= ((useHighSpeed) && (mnt->quietslew)) ? 2 : 1; 
				CmdFormat(CMDSETMOTMODE, AXRA, cmdpars, mntcmd);

				if (getMountAck(mntcmd))
				{
					//Ra Motion mode set
					long2Revu24str(period, cmdpars);
					CmdFormat(CMDSETTRKSPD, AXRA, cmdpars, mntcmd);

					if (getMountAck(mntcmd))
					{
						//Ra Speed set
						long2Revu24str(fabs(azcount), cmdpars);
						CmdFormat(CMDSETGOTOTGT, AXRA, cmdpars, mntcmd);

						if (getMountAck(mntcmd))
						{
							//Ra Target set
							bkratio = (azcount > 3. * azcountperdeg) ? 1 : 10;
							brake = (azcount > (BRAKE_POINT / bkratio)) ? (BRAKE_POINT / bkratio) : azcount;
							long2Revu24str(brake, cmdpars);
							CmdFormat(CMDSETSLOWTGT, AXRA, cmdpars, mntcmd);

							if (getMountAck(mntcmd))
							{
								CmdFormat(CMDSTARTMOVE, AXRA, NULL, mntcmd);

								if (getMountAck(mntcmd))
								{
									// Ra Axis moving, go on with Dec
									useHighSpeed = (altcount > 3. * altcountperdeg);
									cmdpars[0] = (useHighSpeed) ? '2' : '0'; 	//Speed
									cmdpars[1] = (altcount >= 0) ? '0' : '1';	//Direction
									cmdpars[2] = '\0';
									period     = (useHighSpeed) ? minperiods[AXDE] : gotolper[AXDE];
									period     *= ((useHighSpeed) && (mnt->quietslew)) ? 2 : 1; 
									CmdFormat(CMDSETMOTMODE, AXDE, cmdpars, mntcmd);

									if (getMountAck(mntcmd))
									{
										//Dec Motion mode set
										long2Revu24str(period, cmdpars);
										CmdFormat(CMDSETTRKSPD, AXDE, cmdpars, mntcmd);

										if (getMountAck(mntcmd))
										{
											//Dec Speed set
											long2Revu24str(fabs(altcount), cmdpars);
											CmdFormat(CMDSETGOTOTGT, AXDE, cmdpars, mntcmd);

											if (getMountAck(mntcmd))
											{
												//Dec Target set
												bkratio = (altcount > 3. * altcountperdeg) ? 1 : 10;
												brake = (altcount > (BRAKE_POINT / bkratio)) ? (BRAKE_POINT / bkratio) : altcount;
												long2Revu24str(brake, cmdpars);
												CmdFormat(CMDSETSLOWTGT, AXDE, cmdpars, mntcmd);

												if (getMountAck(mntcmd))
												{
													CmdFormat(CMDSTARTMOVE, AXDE, NULL, mntcmd);

													if (getMountAck(mntcmd))
													{
														// Dec Axis moving too, success!
														retval = 1;
													}
													else
													{
														sprintf(strMsgLine,"Goto: Cannot get a Ack from Alt controller on START MOVE command!\n");
														setMessage(strMsgLine);
													}
												}
												else
												{
													sprintf(strMsgLine,"Goto: Cannot get a Ack from Alt controller on BRAKE MODE command!\n");
													setMessage(strMsgLine);
												}
											}
											else
											{
												sprintf(strMsgLine,"Goto: Cannot get a Ack from Alt controller on SET TARGET command!\n");
												setMessage(strMsgLine);
											}
										}
										else
										{
											sprintf(strMsgLine,"Goto: Cannot get a Ack from Alt controller on SET SPEED command!\n");
											setMessage(strMsgLine);
										}
									}
									else
									{
										sprintf(strMsgLine,"Goto: Cannot get a Ack from Alt controller on MOTION MODE command!\n");
										setMessage(strMsgLine);
									}
								}
								else
								{
									sprintf(strMsgLine,"Goto: Cannot get a Ack from Az controller on START MOVE command!\n");
									setMessage(strMsgLine);
								}
							}
							else
							{
								sprintf(strMsgLine,"Goto: Cannot get a Ack from Az controller on BRAKE MODE command!\n");
								setMessage(strMsgLine);
							}
						}
						else
						{
							sprintf(strMsgLine,"Goto: Cannot get a Ack from Az controller on SET TARGET command!\n");
							setMessage(strMsgLine);
						}
					}
					else
					{
						sprintf(strMsgLine,"Goto: Cannot get a Ack from Az controller on SET SPEED command!\n");
						setMessage(strMsgLine);
					}
				}
				else
				{
					sprintf(strMsgLine,"Goto: Cannot get a Ack from Az controller on MOTION MODE command!\n");
					setMessage(strMsgLine);
				}
			}
		}
	}
	return(retval);
}

/* Low level check of slew status on both axes */
/* Advise using CheckGoTo in external applications */
/* Return a flag indicating whether a slew is now in progress */
/*   1 -- slew is in progress on either drive */
/*   0 -- slew not in progress for either drive */

int GetSlewStatus(mount *mnt)
{
	int retval = 0;

	if (TelConnectFlag)
	{
		if (GetAxIsRunning(AXRA) == 2)
		{
			retval = 1;
		}
		else
		{
			//Since ra is stopped already we restore tracking status to limit object ra slippery
			if (mnt->trkStatus != mnt->trkActive)
			{
				StartTrack(mnt);
			}
		}
		if (GetAxIsRunning(AXDE) == 2)
		{
			retval = 1;
		}
	}
	return(retval);
}


/* Test whether the destination was reached                  */
/* Reset slewphase when goto has finished                    */
/* Return value is                                           */
/*   0 -- goto in progress                                   */
/*   1 -- goto complete within tolerance                     */
/*   2 -- goto complete but outside tolerance                */

int CheckGoTo(mount *mnt, double desRA, double desDec, int pmodel, int abspos)
{
	double errorHA, errorDec, desHA, nowHA, nowRA, nowDec;
	double tolha, toldec;
	int retval = 0;

	if (TelConnectFlag)
	{
		/* Is the telescope slewing? */
		if ( GetSlewStatus(mnt) == 1 )
		{
			/* One or more axes remain in motion */
			/* Try again later */
			retval = 0;
		}
		else
		{
			/* Was this a two-phase slew? */
			if ( slewphase == 2 )
			{       
				/* Reset the slew phase and continue to the destination */
				slewphase = 0;    

				/* Go to the original destination */
				/* GoToCoords will change slewphase to 1 */  
				if (GoToCoords(mnt, desRA, desDec, pmodel, abspos))
				{
					/* Return a flag indicating a new goto operation is in progress */
					retval = 0;
				}
				else
				{
					retval = 2;	
				}
			}
			else if ( slewphase == 1 )
			{
				/* No axes are moving. Reset the slew flag. Insure that tracking is started again. */
				slewphase = 0;
				if(mnt->trkStatus != mnt->trkActive)
				{
					retval = SetTrack(mnt);
				}
				else
				{
					retval = 1;
				}

				if (retval)
				{
					/* Where are we now? */
					if (GetTel(mnt, &nowRA, &nowDec, pmodel))
					{
						/* need to compare HA in 0-24h form */
						desHA = (LSTNow(mnt->SiteLongitude) - desRA);
						nowHA = (LSTNow(mnt->SiteLongitude) - nowRA);

						// HA slew tolerance in hours 
						tolha = mnt->slewtolha;

						/* Dec slew tolerance in degrees */
						toldec = mnt->slewtoldec;

						/* What is the absolute value of the pointing error? */

						// Magnitude of HA pointing error in hours 
						errorHA = fabs(nowHA - desHA);
						if (errorHA >= 12.)
						{
							errorHA -= 12.;
						}

						/* Magnitude of Dec pointing error in degrees */
						errorDec = fabs(nowDec - desDec);

						// Compare and notify whether we are within tolerance 
						if( ( errorHA > tolha ) || ( errorDec > toldec ) )
						{
							//fprintf(stderr, "Error HA: %f\nErrorDec: %f\n", errorHA, errorDec);
							/* Result of slew is outside acceptable tolerance */
							/* Signal the calling routine that another goto may be needed */
							retval = 2;
						}
						else
						{
							/* Success */
							retval = 1;
						}
					}
					else
					{		
						retval = 2;
					}
				}
				else
				{		
					retval = 2;
				}

			}    
			else
			{
				/* Unexpected slew phase */
				/* Reset and return success without a test */
				/* This should clear errors and enable another slew request from the UI */
				/* Better would be to flag an error but that might have unintended consequences */
				/* It also apply when user stopped a goto with UI */
				slewphase = 0;
				retval = 1;    
			}
		}
	} 
	return(retval); 
}

/* Level scope (GEM) before align */
int LevelScope(mount *mnt, int ra, int dec)
{
	sprintf(strMsgLine,"Synta protocol does not support level feature!\n");
	setMessage(strMsgLine);
	return 1;
}

/* Check Level Done */
int CheckLevel(int ra, int dec)
{
	sprintf(strMsgLine,"Synta protocol does not support level feature!\n");
	setMessage(strMsgLine);
	return 1;
}

/* Update global offsets */
int SyncTelOffsets(mount *mnt, double newoffsetra, double newoffsetdec)
{
  mnt->offsetra = newoffsetra;
  mnt->offsetdec = newoffsetdec;
  return 1;
}

int SetTrack(mount *mnt)
{
	int retval = 0;
	
	if (TelConnectFlag)
	{
		if (mnt->trkStatus)
		{
			retval = StartTrack(mnt);
		}
		else
		{
			retval = StopTrack(mnt);
		}
	}
	return (retval);
}

/* Start sidereal tracking                                                    */
/* StartTrack is aware of the latitude and will set the direction accordingly */
/* Call StartTrack at least once after the driver has the latitude            */
int StartTrack(mount *mnt)
{
  
	char mntcmd[CMD_LEN];
	char cmdpars[7];
	int retval = 0;
	double rate = 0.0;
	unsigned long period = 0;
	int useHighSpeed = 0; 
	
	if (TelConnectFlag)
	{
		if (mnt->trkActive)
		{
			StopTrack(mnt);
	
		}

		if (GetAxIsRunning(AXRA))
		{
			StopSlew(mnt, WEST);
		}

		if (!mnt->trkActive)
		{

			if (mnt->trkspd != 0.0)
			{
				/* Apply trkSpeed user selection if any */
				rate = mnt->trkspd / TRACKRATE_SIDEREAL;

				if (!((rate < MIN_RATE) || (rate > MAX_RATE)))
				{

					if (rate > LOWSPEED_RATE) 
					{
						rate = rate / RAHighspeedRatio;
						useHighSpeed = 1;
					}

					period = (long) (((STELLAR_DAY * (double)RAStepsWorm) / (double)RASteps360) / rate);

					if ((useHighSpeed) && (period < minperiods[AXRA])) 
					{
						sprintf(strMsgLine, "StartTrack: Setting axis %c period to minimum. Requested is %lx, minimum is %lx\n", AXRA, period, minperiods[AXRA]);
						setMessage(strMsgLine);
						period = minperiods[AXRA];
					}

					/* Test for southern hemisphere */
					/* Set negative drive rate if we're south of the equator */
					if ( mnt->SiteLatitude < 0. )
					{
						rate = -rate;
					}
								
					cmdpars[0] = (useHighSpeed == 0) ? '1' : '3';
					cmdpars[1] = (rate >= 0) ? '0' : '1';
					cmdpars[2] = '\0';
				
					CmdFormat(CMDSETMOTMODE, AXRA, cmdpars, mntcmd);

					if (getMountAck(mntcmd))
					{
						long2Revu24str(period, cmdpars);
					
						CmdFormat(CMDSETTRKSPD, AXRA, cmdpars, mntcmd);
					  
						if (getMountAck(mntcmd))
						{

							CmdFormat(CMDSTARTMOVE, AXRA, NULL, mntcmd);

							if (getMountAck(mntcmd))
							{
								sprintf(strMsgLine,"Mount is tracking\n");
								setMessage(strMsgLine);
								mnt->trkActive = 1;
								retval = 1;
							}
							else
							{
								sprintf(strMsgLine,"StartTrack: No acknowledgement starting motion\n");
								setMessage(strMsgLine);
							}
						}  
						else
						{
							sprintf(strMsgLine,"StartTrack: No acknowledgement setting track speed\n");
							setMessage(strMsgLine);
						}
					}  
					else
					{
						sprintf(strMsgLine,"StartTrack: No acknowledgement setting motion mode\n");
						setMessage(strMsgLine);
					} 
				} 
				else
				{
					sprintf(strMsgLine,"StartTrack: Speed rate out of limits: %.2fx Sidereal (min=%.2f, max=%.2f)\n", (double)fabs(rate), (double)MIN_RATE, (double)MAX_RATE);
					setMessage(strMsgLine);
				}  
			}
		}
	}
	return(retval);
} 


/* Stop tracking if it is running */
int StopTrack(mount *mnt)
{
	char slewCmd[CMD_LEN];
	int retval = 0;

	if (TelConnectFlag)
	{
		CmdFormat(CMDAXSTOP, AXRA, NULL, slewCmd);
	
		/* Look for acknowledgement of request*/
		if (getMountAck(slewCmd))
		{
			sprintf(strMsgLine,"Mount stopped tracking\n");
			setMessage(strMsgLine);
			mnt->trkActive = 0;
			retval = 1;
		}
		else
		{
			sprintf(strMsgLine,"No acknowledgement from telescope sidereal track off request\n");
			setMessage(strMsgLine);
		}
	}
	return(retval);
}

/* Get tracking status */
int GetTrackStatus(mount *mnt)
{
	int retval = mnt->trkStatus;
	return(retval);
}

/* Get tracking active status */
int GetTrackActive(mount *mnt)
{
	int retval = mnt->trkActive;
	return(retval);
}

/* Set tracking status */
void SetTrackStatus(mount *mnt, int trk)
{
	mnt->trkStatus = trk;
	if (mnt->trkStatus)
	{
		sprintf(strMsgLine,"Setting up for active tracking\n");
	}
	else
	{
		sprintf(strMsgLine,"Setting up for inactive tracking\n");
	}
	setMessage(strMsgLine); 		
	return;
}

/* Full stop */
int FullStop(mount *mnt)
{  
	int retval = 0;

	if (TelConnectFlag)
	{
		sprintf(strMsgLine, "Stop all motion\n");
		setMessage(strMsgLine);  	
		/* Also Clear the slew flag */
		slewphase = 0;
		/* Stop AR */
		retval = retval + StopSlew(mnt, WEST);
		usleep(25000.);
		/* Stop DEC */
		retval = retval + StopSlew(mnt, NORTH);
		usleep(25000.);
		/* Stop tracking */
		retval = retval + StopTrack(mnt);
		usleep(25000.);
		if (retval)
		{
			sprintf(strMsgLine,"All motion stopped\n");
		}
		setMessage(strMsgLine);
	}
	return(retval);
}

// Return 0 = Axis stopped, 1 = Axis slewing, 2 = Axis Goto
int GetAxIsRunning(int axis)
{
	char strCmd[CMD_LEN];
	char response[RES_LEN];
	int  retval = 1;

	CmdFormat(CMDGETAXSTATUS, axis, NULL, strCmd);

	if (getMountString(strCmd, response))
	{
		laststatus[axis] = 0;
		if ((response[2]&0x01) != 0)
		{
			// Is moving
			if ((response[1]&0x01) != 0)
			{
				// It's a slew
				laststatus[axis] = 1;
			}
			else
			{
				// It's a goto
				laststatus[axis] = 2;
			}	
		}			
		initstatus[axis] = (response[3]&0x01);
	}
	retval = laststatus[axis];
	return(retval);
}

/* TTY Data transformations */
void CmdFormat(char cmd, int axis, char *cmdargs, char *strcmd)
{
	strcmd[0] = '\0';
	if (cmdargs == NULL)
	{
		sprintf(strcmd, "%c%c%d%c", SWLEADCHR, cmd, axis, SWTRAILCHR);
	}
	else
	{
		sprintf(strcmd, "%c%c%d%s%c", SWLEADCHR, cmd, axis, cmdargs, SWTRAILCHR);
	}
	return;
}

unsigned long Revu24str2long(char *s) 
{
	unsigned long res = 0;

	res=HEX(s[4]); res <<= 4;
	res|=HEX(s[5]); res <<= 4;
	res|=HEX(s[2]); res <<= 4;
	res|=HEX(s[3]); res <<= 4;
	res|=HEX(s[0]); res <<= 4;
	res|=HEX(s[1]); 
	return res;
}

void long2Revu24str(unsigned long n, char *str) 
{
	char hexa[16] = {'0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'A', 'B', 'C', 'D', 'E', 'F'};

	str[0]=hexa[(n & 0xF0) >> 4];
	str[1]=hexa[(n & 0x0F)];
	str[2]=hexa[(n & 0xF000) >> 12];
	str[3]=hexa[(n & 0x0F00) >> 8];
	str[4]=hexa[(n & 0xF00000) >> 20];
	str[5]=hexa[(n & 0x0F0000) >> 16];
	str[6]='\0';
}

/* Serial port utilities */
int ttywrite(int fd, const char * buffer)
{
	int err_code = 0, nbytes_written = 0;

	ttyerrormsg[0] = '\0';

	if ((err_code = tty_write_string(fd, buffer, &nbytes_written)) != TTY_OK)
	{
		tty_error_msg(err_code, ttyerrormsg, TTY_ERRMSG_SIZE);
		setMessage(ttyerrormsg); 
	}
	return nbytes_written;
}

int ttyread(int fd, char *buf)
{
	int err_code = 0, nbytes_read = 0;

	// Clear string(s)
	ttyerrormsg[0] = '\0';
	buf[0] = '\0';
    if ((err_code = tty_read_section(fd, buf, SWTRAILCHR, READ_TIME, &nbytes_read)) == TTY_OK)
    {
		// Remove CR
		buf[nbytes_read-1] = '\0';
    }
    else
    {
		tty_error_msg(err_code, ttyerrormsg, TTY_ERRMSG_SIZE);
		setMessage(ttyerrormsg); 
	}
	return nbytes_read;
}

int getMountAck (char *sendstr)
{
	char returnstr[RES_LEN];

	return (getMountString(sendstr, returnstr));
}

int getMountString(char *sendstr, char *returnstr)
{
	int retval = 0, err = 0, i = 0;

	if (TelConnectFlag == TRUE)
	{
		while (retval == 0)
		{
			/* Flush the input buffer */
			tcflush(TelPortFD,TCIOFLUSH);

			if (ttywrite(TelPortFD, sendstr))
			{
				usleep(10000);
				if (ttyread(TelPortFD, returnstr) > 0)
				{
					retval = 1;
					if (returnstr[0] == ':')
					{
						//Rx and Tx are bound, we are reading command just sent, read again to get answer from mount
						retval = (ttyread(TelPortFD, returnstr) > 0);
					}
					if (retval)
					{
						if (err)
						{
							err = 0;
							sprintf(strMsgLine, "getMountString: Ok.\n");
							setMessage(strMsgLine); 
						}
						switch (returnstr[0]) 
						{
							case '=': 
								retval = 1; 
								break;
							case '!': 
								retval = -1;
								break;
							default : 
								sprintf(strMsgLine, "getMountString: Invalid response to command %s - Reply %s\n", sendstr, returnstr);
								setMessage(strMsgLine); 
								retval = 0;
								i++;
								break;
						} 
					}
				}	
				else
				{
					err = 1;
					sprintf(strMsgLine, "getMountString: Attempt %d to read command %s reply, failed. Wait...\n", (i + 1), sendstr);
					setMessage(strMsgLine); 
					usleep(1000000);
					i++;
				}	
			}
			else
			{
				err = 1;
				sprintf(strMsgLine, "getMountString: Attempt write command %s, failed.\n", sendstr);
				setMessage(strMsgLine); 
				usleep(1000000);
				i++;
			}
			if ((i % CMD_RETRY) == 0 && retval == 0)
			{
				if (!comfailCB())
				{
					break;
				}
			}
		}
		if (retval == 0)
		{
			// On total failure, telescope is not connected...
			TelConnectFlag = FALSE;
			sprintf(strMsgLine, "Telescope does not respond\nPort closed\n");
			setMessage(strMsgLine);
			close(TelPortFD);
		}
	}
	return (retval > 0);
}

