#ifndef LX200AST_H
	#define LX200AST_H
	/* -------------------------------------------------------------------------- */
	/*             - Protocol header for LX200 telescope control -                */
	/* -------------------------------------------------------------------------- */
	/*                                                                            */
	/* Copyright 2010 John Kielkopf                                               */
	/* kielkopf@louisville.edu                                                    */
	/*                                                                            */
	/* Distributed under the terms of the General Public License (see LICENSE)    */
	/*                                                                            */
	/* Date: August 21, 2010                                                      */
	/* Version: 5.2.0                                                             */
	/*                                                                            */
	/* Giampiero Spezzano (gspezzano@gmail.com)                                   */
	/* Marc 22, 2013                                                              */
	/*     First release (Adapted from Mr Kielkopf original)                      */

	/* Focus commands                                                            */
	/* Distance from the CCD to the focal plane                                  */
	/* Direction is + from the CCD toward the sky                                */
	/* Used by Focus(focuscmd, focusspd)                                         */
	#define ISFOCUS
	#define FOCUSSPD4       4   /* Fast    */
	#define FOCUSSPD3       3   /* Medium  */
	#define FOCUSSPD2       2   /* Slow    */
	#define FOCUSSPD1       1   /* Precise */

	#define FOCUSCMDOUT     2   /* CCD moves away from sky */
	#define FOCUSCMDIN      1   /* CCD moves toward the  sky */
	#define FOCUSCMDOFF     0   /* CCD does not move */

	/* Fan commands */
	#define ISFAN
	#define FANCMDHIGH      1   /* cooling fan on high speed */
	#define FANCMDLOW       1   /* cooling fan on low speed */
	#define FANCMDOFF       0   /* cooling fan off */

	/* Dew heater commands */
	#define ISHEATER
	#define HEATERCMDHIGH      2   /* dew heater on high */
	#define HEATERCMDLOW       1   /* dew heater on low */
	#define HEATERCMDOFF       0   /* dew heater off */

	/* Rotator commands */
	#define ISROTATOR
	#define ROTATESPDFAST       4   /* Fast set */
	#define ROTATESPDSLOW       2   /* Slow set */
	#define ROTATESPDSIDEREAL   1   /* Sidereal rate */
	#define ROTATECMDCW         2   /* Camera rotates CW looking toward the sky */
	#define ROTATECMDCCW        1   /* Camera rotates CCW looking toward the sky */
	#define ROTATECMDOFF        0   /* Camera does not rotate */

	/* Reticle commands */
	#define ISRETICLE
	#define RETICLEBRI         16   /* increase */
	#define RETICLEDIM          8   /* decrease */
	#define RETICLEBLK0         0   /* no blinking */ 
	#define RETICLEBLK1         1   /* blink rate 1 */
	#define RETICLEBLK2         2   /* blink rate 2 */
	#define RETICLEBLK3         4   /* blink rate 3 */
	
	//Enable level function for the protocol
	//#define ISLEVEL
	//Enable limits function for the protocol
	//#define ISLIMITS

	/* The following parameters are used internally to set speed and direction. */
	/* Do not change these values. */

	/* Slew speed */
	#define	GUIDE1		0x47 //G
	#define	GUIDE2		0
	#define	CENTER3		0x43 //C
	#define	CENTER4		0
	#define	CENTER5		0
	#define	FIND6		0x4D //M
	#define	FIND7		0
	#define	FIND8		0
	#define	SLEW9		0x53 //S
	 
	/* Slew tolerances unused really in this protocol, but definition is needed code wise */
	/* For 1 minute of arc precision */
	#define SLEWTOLHA  0.001111111  //Used for Ra  1 arcmin
	#define SLEWTOLDEC 0.016666666  //Used for Dec 1 arcmin

	#define CMD_RETRY    5
	#define READ_TIME    3
	#define CMD_LEN    128
	#define RES_LEN    128

	#define TRACKRATE_SIDEREAL 15.041067179
	
	#include "protocol.h"	
#endif

